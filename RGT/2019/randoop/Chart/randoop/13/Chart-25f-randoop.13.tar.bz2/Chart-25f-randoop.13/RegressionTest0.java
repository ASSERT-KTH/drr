import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (short) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (short) 0);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range1, lengthConstraintType4, (double) 100L, range8, lengthConstraintType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, 0.0d, categoryLabelWidthType4, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=255,b=128]", font1, (java.awt.Paint) color2, rectangleEdge5, horizontalAlignment6, verticalAlignment7, rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 1, (-1.0d), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, (float) (short) 1, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-6553600) + "'", int3 == (-6553600));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.yellow;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (byte) 10, 128, 0, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 1, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray9 = new float[] { 3, (short) 1, (byte) 100, (-1L), (-1.0f) };
        try {
            float[] floatArray10 = color0.getColorComponents(colorSpace3, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) (-1.0f));
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            legendTitle1.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 0);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = columnArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 'a', (float) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-15423) + "'", int3 == (-15423));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = categoryAxis1.draw(graphics2D2, (double) 128, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getItemLabelPadding();
        try {
            org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font1, paint3, rectangleEdge4, horizontalAlignment5, verticalAlignment6, rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        java.lang.Comparable comparable18 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, comparable18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 200.0d + "'", number17.equals(200.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        try {
            legendTitle1.setHorizontalAlignment(horizontalAlignment4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE1" + "'", str1.equals("ItemLabelAnchor.INSIDE1"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER" + "'", str2.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        objectList0.clear();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 0);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        legendTitle7.setNotify(true);
        java.lang.Object obj10 = legendTitle7.clone();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle7);
        java.awt.Graphics2D graphics2D12 = null;
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray21, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(0.0d, range30);
        try {
            org.jfree.chart.util.Size2D size2D32 = columnArrangement4.arrange(blockContainer5, graphics2D12, rectangleConstraint31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("EXPAND", graphics2D1, (float) (byte) -1, (float) 'a', 0.0d, (float) ' ', 0.95f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        boolean boolean3 = projectInfo1.equals((java.lang.Object) blockContainer2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = borderArrangement0.arrange(blockContainer2, graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape9, false, (java.awt.Paint) color13, false, paint15, stroke16, false, shape18, stroke19, paint21);
        java.awt.Color color23 = java.awt.Color.yellow;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis25.setCategoryLabelPositions(categoryLabelPositions26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke30 = categoryAxis29.getTickMarkStroke();
        categoryAxis25.setAxisLineStroke(stroke30);
        java.awt.Paint paint32 = null;
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("poly", "EXPAND", "Range[0.0,0.0]", "", shape9, (java.awt.Paint) color23, stroke30, paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = null;
        try {
            blockContainer0.setArrangement(arrangement1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getShapeType();
        java.awt.Color color7 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        boolean boolean8 = chartEntity2.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "poly" + "'", str4.equals("poly"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str10 = textBlockAnchor9.toString();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType13 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9, textAnchor11, (double) (short) 0, categoryLabelWidthType13, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.Shape shape18 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) (-6553600), 10.0f, textAnchor11, 0.0d, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextBlockAnchor.CENTER" + "'", str10.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelWidthType13);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject(1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (short) 1, (double) (byte) -1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getTextAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = itemLabelPosition2.getItemLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        boolean boolean10 = itemLabelPosition2.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) "ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("TextBlockAnchor.CENTER", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("java.awt.Color[r=128,g=255,b=128]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=128,g=255,b=128], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle10.setLegendItemGraphicPadding(rectangleInsets13);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets13);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            legendTitle1.setBounds(rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2);
        java.lang.Class<?> wildcardClass4 = textAnchor2.getClass();
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor5, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.INSIDE1");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ItemLabelAnchor.INSIDE1, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=128,g=255,b=128]", graphics2D1, 3.0d, (float) (short) -1, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis2.setAxisLineStroke(stroke7);
        java.awt.Font font9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        categoryAxis2.setLabelFont(font9);
        org.jfree.chart.plot.Plot plot11 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("poly", font9, plot11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.INSIDE1", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) 100L);
        try {
            java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (double) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        try {
            legendTitle1.setPosition(rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        textTitle2.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        try {
            java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 200.0d + "'", number17.equals(200.0d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        java.lang.Object obj11 = numberTick10.clone();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState();
        axisState9.cursorLeft(200.0d);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            java.util.List list14 = categoryAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        try {
            org.jfree.chart.LegendItem legendItem2 = legendItemCollection0.get((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str3 = textBlockAnchor2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float5 = categoryLabelPosition4.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str10 = textBlockAnchor9.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions0.getLabelPosition(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER" + "'", str3.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextBlockAnchor.CENTER" + "'", str10.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNull(categoryLabelPosition14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(arrangement1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        float float4 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategoryMiddle((int) 'a', (int) (short) 10, rectangle2D7, rectangleEdge8);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Color color9 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle1.setItemPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray20, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray27);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(0.0d, range29);
        try {
            org.jfree.chart.util.Size2D size2D31 = legendTitle1.arrange(graphics2D11, rectangleConstraint30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) graphics2D3, jFreeChart6, chartChangeEventType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Range[0.0,0.0]");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        try {
            boolean boolean2 = categoryPlot0.removeAnnotation(categoryAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getToolTipText();
        java.awt.Paint paint20 = legendItem18.getOutlinePaint();
        java.awt.Shape shape21 = legendItem18.getShape();
        org.jfree.data.general.Dataset dataset22 = legendItem18.getDataset();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(dataset22);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        try {
            categoryPlot0.zoom((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', (int) (short) 10, (-6553600));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.lang.String str8 = textTitle2.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER" + "'", str8.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        legendItem18.setSeriesKey((java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle2.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        textTitle2.setMargin(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets11.createInsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 1L);
        int int3 = legendItemCollection0.getItemCount();
        java.lang.Object obj4 = legendItemCollection0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Color color9 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle1.setItemPaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=128,g=255,b=128]", graphics2D1, (float) (-15423), (float) 128, (double) 100.0f, 0.0f, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, textAnchor7, (double) (short) 0, categoryLabelWidthType9, 0.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str13 = lengthAdjustmentType12.toString();
        boolean boolean14 = categoryLabelWidthType9.equals((java.lang.Object) str13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EXPAND" + "'", str13.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 100L };
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { "", (byte) 1, (short) 0, (short) 1, (short) 100, "java.awt.Color[r=128,g=255,b=128]" };
        double[] doubleArray13 = new double[] { 3, 10.0f, 105.0d, 10.0d };
        double[] doubleArray18 = new double[] { 3, 10.0f, 105.0d, 10.0d };
        double[] doubleArray23 = new double[] { 3, 10.0f, 105.0d, 10.0d };
        double[] doubleArray28 = new double[] { 3, 10.0f, 105.0d, 10.0d };
        double[][] doubleArray29 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray8, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        categoryPlot0.setNoDataMessage("Range[0.0,0.0]");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color1 = color0.brighter();
        float[] floatArray2 = null;
        float[] floatArray3 = color0.getRGBColorComponents(floatArray2);
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        float[] floatArray9 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray10 = color4.getRGBComponents(floatArray9);
        float[] floatArray11 = color0.getRGBComponents(floatArray10);
        int int12 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            legendTitle1.draw(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 1L, true, (byte) 100, 3.0d, (-1.0f) };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { "LegendItemEntity: seriesKey=null, dataset=null" };
        double[] doubleArray9 = new double[] { 3.0d };
        double[] doubleArray11 = new double[] { 3.0d };
        double[] doubleArray13 = new double[] { 3.0d };
        double[][] doubleArray14 = new double[][] { doubleArray9, doubleArray11, doubleArray13 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray7, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        boolean boolean13 = categoryPlot2.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray9 = new float[] { 0L, '#', (short) 10, 128, (-6553600), (-1) };
        float[] floatArray10 = color2.getRGBComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getColorComponents(colorSpace1, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str3 = textBlockAnchor2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        float float9 = categoryLabelPosition8.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = categoryLabelPosition8.getCategoryAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        float float15 = categoryLabelPosition14.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = categoryLabelPosition14.getCategoryAnchor();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition4, categoryLabelPosition8, categoryLabelPosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER" + "'", str3.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER" + "'", str7.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.95f + "'", float9 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.95f + "'", float15 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        boolean boolean4 = categoryAnchor0.equals((java.lang.Object) stroke3);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (byte) 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        double double3 = axisSpace0.getRight();
        axisSpace0.setTop((double) (short) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        try {
            axisSpace0.add((double) 0.0f, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        java.lang.String str11 = tickType2.toString();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "MINOR" + "'", str11.equals("MINOR"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) true);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle3.draw(graphics2D4, rectangle2D5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        boolean boolean8 = textTitle3.equals((java.lang.Object) horizontalAlignment7);
        boolean boolean9 = legendItemCollection0.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setCopyright("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        legendTitle1.setHeight(0.0d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = legendTitle1.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("EXPAND", "Range[0.0,0.0]", "poly", "", shape8, (java.awt.Paint) color9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color12 = color11.brighter();
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int15 = color14.getRed();
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "MINOR", "", "DatasetRenderingOrder.FORWARD", shape8, (java.awt.Paint) color12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 128 + "'", int15 == 128);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis1.addChangeListener(axisChangeListener4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis1.getCategoryLabelPositions();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis1.getCategoryEnd((int) '4', (int) (byte) -1, rectangle2D10, rectangleEdge11);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle1.setPadding(rectangleInsets9);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getShapeType();
        chartEntity2.setURLText("ThreadContext");
        java.lang.String str7 = chartEntity2.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "poly" + "'", str4.equals("poly"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        java.awt.Color color7 = java.awt.Color.PINK;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo13, point2D14);
        java.awt.Stroke stroke16 = categoryPlot8.getOutlineStroke();
        java.awt.Paint paint17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "EXPAND", shape6, (java.awt.Paint) color7, stroke16, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100L, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        org.jfree.chart.axis.TickType tickType11 = numberTick10.getTickType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextOutlinePaint();
        boolean boolean14 = numberTick10.equals((java.lang.Object) defaultDrawingSupplier12);
        boolean boolean16 = defaultDrawingSupplier12.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (-1));
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape1, "Range[0.0,0.0]", "Range[0.0,0.0]");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.lang.String str22 = legendItemEntity21.getURLText();
        java.lang.Object obj23 = null;
        boolean boolean24 = legendItemEntity21.equals(obj23);
        java.lang.String str25 = legendItemEntity21.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getRed();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("EXPAND", "EXPAND", "poly", "ItemLabelAnchor.INSIDE1");
        java.lang.String str5 = library4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EXPAND" + "'", str5.equals("EXPAND"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset16);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = null;
        org.jfree.data.Range range22 = null;
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray31, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType43 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range46 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range46);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = rectangleConstraint47.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedHeight((double) (-6553600));
        org.jfree.data.KeyedObjects2D keyedObjects2D51 = new org.jfree.data.KeyedObjects2D();
        int int52 = keyedObjects2D51.getRowCount();
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray60, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray67);
        org.jfree.data.Range range69 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset68);
        boolean boolean70 = keyedObjects2D51.equals((java.lang.Object) range69);
        double double71 = range69.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = rectangleConstraint50.toRangeHeight(range69);
        java.lang.Number[] numberArray81 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray87 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray88 = new java.lang.Number[][] { numberArray81, numberArray87 };
        org.jfree.data.category.CategoryDataset categoryDataset89 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray88);
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset89);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint91 = new org.jfree.chart.block.RectangleConstraint(0.0d, range90);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint93 = rectangleConstraint91.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType94 = rectangleConstraint91.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint95 = new org.jfree.chart.block.RectangleConstraint((double) '4', range42, lengthConstraintType43, 1.0d, range69, lengthConstraintType94);
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint96 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range19, lengthConstraintType20, (double) 100, range22, lengthConstraintType43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0d + "'", number18.equals(1.0d));
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(lengthConstraintType43);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 105.0d + "'", double71 == 105.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint72);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(numberArray87);
        org.junit.Assert.assertNotNull(numberArray88);
        org.junit.Assert.assertNotNull(categoryDataset89);
        org.junit.Assert.assertNotNull(range90);
        org.junit.Assert.assertNotNull(rectangleConstraint93);
        org.junit.Assert.assertNotNull(lengthConstraintType94);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        legendItem18.setDataset((org.jfree.data.general.Dataset) categoryDataset34);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer36 = null;
        try {
            legendItem18.setFillPaintTransformer(gradientPaintTransformer36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("EXPAND");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor15);
        java.lang.String str17 = categoryAnchor15.toString();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CategoryAnchor.END" + "'", str17.equals("CategoryAnchor.END"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("DatasetRenderingOrder.FORWARD", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        float float6 = categoryLabelPosition5.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = categoryLabelPosition5.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str11 = textBlockAnchor10.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition12);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.95f + "'", float6 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextBlockAnchor.CENTER" + "'", str11.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        double double4 = categoryAxis1.getUpperMargin();
        categoryAxis1.setMaximumCategoryLabelLines((-6553600));
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) color4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str14 = textBlockAnchor13.toString();
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13, textAnchor15, (double) (short) 0, categoryLabelWidthType17, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor6, categoryLabelWidthType17, (float) ' ');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str24 = textBlockAnchor23.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor23);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        double double29 = legendTitle28.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle28.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle28.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str33 = textBlockAnchor32.toString();
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType36 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition38 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor31, textBlockAnchor32, textAnchor34, (double) (short) 0, categoryLabelWidthType36, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition40 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor26, categoryLabelWidthType36, (float) (-6553600));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition41 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor26);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER" + "'", str2.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER" + "'", str7.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.CENTER" + "'", str14.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextBlockAnchor.CENTER" + "'", str24.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TextBlockAnchor.CENTER" + "'", str33.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(categoryLabelWidthType36);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis1.configure();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str9 = rectangleInsets8.toString();
        legendTitle6.setItemLabelPadding(rectangleInsets8);
        categoryAxis1.setLabelInsets(rectangleInsets8);
        double double13 = rectangleInsets8.calculateLeftOutset((double) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        legendTitle11.setNotify(true);
        java.lang.Object obj14 = legendTitle11.clone();
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11);
        legendTitle1.setWrapper(blockContainer9);
        double double17 = legendTitle1.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!");
        textLine1.addFragment(textFragment3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        boolean boolean6 = textFragment3.equals((java.lang.Object) textLine5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot21.getDomainAxisForDataset((-15423));
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker28, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(categoryAxis27);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 10, (double) (short) 10, (double) (-15423), (double) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        boolean boolean7 = legendItemCollection5.equals((java.lang.Object) 1L);
        int int8 = legendItemCollection5.getItemCount();
        boolean boolean9 = blockBorder4.equals((java.lang.Object) int8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis1.configure();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str9 = rectangleInsets8.toString();
        legendTitle6.setItemLabelPadding(rectangleInsets8);
        categoryAxis1.setLabelInsets(rectangleInsets8);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str15 = color14.toString();
        int int16 = color14.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font13, (java.awt.Paint) color14);
        categoryAxis1.setLabelPaint((java.awt.Paint) color14);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) 100);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str15.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 128 + "'", int16 == 128);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) -1, (double) 3, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("EXPAND", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Color color9 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle1.setItemPaint((java.awt.Paint) color9);
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle1.getItemContainer();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.KeyedObjects2D keyedObjects2D14 = new org.jfree.data.KeyedObjects2D();
        int int15 = keyedObjects2D14.getRowCount();
        try {
            java.lang.Object obj16 = blockContainer11.draw(graphics2D12, rectangle2D13, (java.lang.Object) int15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) '4');
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, (-15423), 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        float float4 = categoryAxis1.getTickMarkOutsideLength();
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("poly", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle1.getSources();
        legendTitle1.setNotify(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        try {
            legendTitle1.setHorizontalAlignment(horizontalAlignment8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        try {
            java.lang.Object obj9 = labelBlock5.draw(graphics2D6, rectangle2D7, (java.lang.Object) stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str5 = textBlockAnchor4.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor4);
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor3);
        try {
            java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER" + "'", str5.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("PlotOrientation.VERTICAL", graphics2D1, 0.95f, (float) (-6553600), textAnchor4, 100.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot2.addChangeListener(plotChangeListener12);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        labelBlock5.setURLText("");
        labelBlock5.setURLText("poly");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        double double3 = axisSpace0.getRight();
        double double4 = axisSpace0.getRight();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.shrink(rectangle2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.lang.Comparable comparable22 = legendItemEntity21.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(comparable22);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, 105.0d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray34);
        legendItem19.setDataset((org.jfree.data.general.Dataset) categoryDataset35);
        boolean boolean37 = itemLabelAnchor0.equals((java.lang.Object) legendItem19);
        java.lang.String str38 = legendItem19.getURLText();
        boolean boolean39 = legendItem19.isLineVisible();
        java.lang.Comparable comparable40 = legendItem19.getSeriesKey();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "TextBlockAnchor.CENTER" + "'", str38.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(comparable40);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getDescription();
        java.awt.Stroke stroke20 = legendItem18.getOutlineStroke();
        java.lang.Comparable comparable21 = legendItem18.getSeriesKey();
        int int22 = legendItem18.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { (byte) 1 };
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { "Range[0.0,0.0]" };
        double[] doubleArray9 = new double[] { 4.0d, (byte) 10, 255, 1.0f, 'a' };
        double[] doubleArray15 = new double[] { 4.0d, (byte) 10, 255, 1.0f, 'a' };
        double[] doubleArray21 = new double[] { 4.0d, (byte) 10, 255, 1.0f, 'a' };
        double[] doubleArray27 = new double[] { 4.0d, (byte) 10, 255, 1.0f, 'a' };
        double[] doubleArray33 = new double[] { 4.0d, (byte) 10, 255, 1.0f, 'a' };
        double[][] doubleArray34 = new double[][] { doubleArray9, doubleArray15, doubleArray21, doubleArray27, doubleArray33 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray3, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) (short) 100, (float) '4', textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        float float2 = textFragment1.getBaselineOffset();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle7.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str12 = textBlockAnchor11.toString();
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType15 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor10, textBlockAnchor11, textAnchor13, (double) (short) 0, categoryLabelWidthType15, 0.0f);
        try {
            textFragment1.draw(graphics2D3, 0.0f, (float) 10L, textAnchor13, (float) (byte) 100, (float) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextBlockAnchor.CENTER" + "'", str12.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(categoryLabelWidthType15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) 100L);
        java.lang.String str19 = range18.toString();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[100.0,300.0]" + "'", str19.equals("Range[100.0,300.0]"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            legendTitle1.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1.0E-8d, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        axisState8.cursorRight(1.0E-8d);
        try {
            java.lang.Object obj11 = labelBlock5.draw(graphics2D6, rectangle2D7, (java.lang.Object) 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.awt.Color color2 = java.awt.Color.getColor("poly", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str3 = textBlockAnchor2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float5 = categoryLabelPosition4.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str10 = textBlockAnchor9.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition11);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER" + "'", str3.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextBlockAnchor.CENTER" + "'", str10.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot9.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot0.addDomainMarker(categoryMarker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(layer20);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("ThreadContext", graphics2D1, (float) (-15423), 0.95f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot8.getRenderer();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot8.getOrientation();
        categoryPlot0.setOrientation(plotOrientation17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNull(categoryAxis19);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Font font7 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        legendTitle1.setItemLabelPadding(rectangleInsets12);
        double double15 = rectangleInsets12.calculateTopInset((double) 3);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 0, (-1.0f), 10.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (-1));
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "RectangleAnchor.BOTTOM_LEFT", "ItemLabelAnchor.INSIDE1", "ChartEntity: tooltip = EXPAND", shape5, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            numberAxis0.setTickLabelInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        java.lang.Object obj6 = keyedObjects2D0.getObject((java.lang.Comparable) "MINOR", (java.lang.Comparable) (-1));
        try {
            java.lang.Object obj9 = keyedObjects2D0.getObject((int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) 0L, (double) 128, (double) 0.0f, 1.0E-8d);
        boolean boolean8 = datasetRenderingOrder0.equals((java.lang.Object) 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        org.jfree.data.RangeType rangeType3 = null;
        try {
            numberAxis0.setRangeType(rangeType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str1.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        int int9 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(layer11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Color color3 = java.awt.Color.yellow;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double10 = categoryAxis1.getCategoryStart(0, (int) 'a', rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getDescription();
        java.awt.Stroke stroke20 = legendItem18.getOutlineStroke();
        legendItem18.setSeriesIndex((int) (byte) 0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        org.jfree.data.KeyToGroupMap keyToGroupMap18 = null;
        try {
            org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, keyToGroupMap18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 200.0d + "'", number17.equals(200.0d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 0);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str9 = textBlockAnchor8.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor7);
        java.awt.Color color14 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle6.setItemPaint((java.awt.Paint) color14);
        org.jfree.chart.block.BlockContainer blockContainer16 = legendTitle6.getItemContainer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedHeight((double) (-6553600));
        org.jfree.data.KeyedObjects2D keyedObjects2D24 = new org.jfree.data.KeyedObjects2D();
        int int25 = keyedObjects2D24.getRowCount();
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray33, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray40);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset41);
        boolean boolean43 = keyedObjects2D24.equals((java.lang.Object) range42);
        double double44 = range42.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint23.toRangeHeight(range42);
        try {
            org.jfree.chart.util.Size2D size2D46 = columnArrangement4.arrange(blockContainer16, graphics2D17, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.CENTER" + "'", str9.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(blockContainer16);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 105.0d + "'", double44 == 105.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        java.lang.String str12 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str12.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str4 = rectangleInsets3.toString();
        legendTitle1.setItemLabelPadding(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str4.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = labelBlock5.getMargin();
        java.awt.Graphics2D graphics2D7 = null;
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray16, numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(0.0d, range25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toFixedWidth((double) (short) 10);
        org.jfree.data.Range range29 = rectangleConstraint28.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint28.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D31 = labelBlock5.arrange(graphics2D7, rectangleConstraint28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        categoryAxis24.setLabelAngle(4.0d);
        double double30 = categoryAxis24.getCategoryMargin();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartEntity: tooltip = EXPAND", graphics2D1, (float) (byte) -1, 0.0f, (double) 3, (float) (short) 100, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle1.getSources();
        legendTitle1.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getMargin();
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot0.setDomainAxis((int) (byte) 1, categoryAxis12);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle1.removeChangeListener(titleChangeListener4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str9 = color8.toString();
        int int10 = color8.getBlue();
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        float[] floatArray16 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray17 = color11.getRGBComponents(floatArray16);
        float[] floatArray18 = color8.getRGBColorComponents(floatArray17);
        try {
            java.lang.Object obj19 = legendTitle1.draw(graphics2D6, rectangle2D7, (java.lang.Object) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str9.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 128 + "'", int10 == 128);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, textAnchor7, (double) (short) 0, categoryLabelWidthType9, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition11.getRotationAnchor();
        float float13 = categoryLabelPosition11.getWidthRatio();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.resizeRange(0.05d);
        org.jfree.data.Range range9 = null;
        try {
            numberAxis0.setRangeWithMargins(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        double double3 = axisSpace0.getRight();
        axisSpace0.setTop((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = axisSpace0.reserved(rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        double double8 = categoryAxis1.getFixedDimension();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "Range[100.0,300.0]", "PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str2 = color1.toString();
        int int3 = color1.getBlue();
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        float[] floatArray9 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray10 = color4.getRGBComponents(floatArray9);
        float[] floatArray11 = color1.getRGBColorComponents(floatArray10);
        float[] floatArray12 = color0.getRGBColorComponents(floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str2.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        projectInfo0.setName("MINOR");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "MINOR");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot9.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            categoryPlot0.drawOutline(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape10, "poly", "DatasetRenderingOrder.FORWARD");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double18 = categoryAxis1.getCategoryMiddle((int) (byte) 100, 0, rectangle2D16, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        java.awt.Paint paint10 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot0.addRangeMarker(marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(layer12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.plot.Plot plot22 = categoryAxis5.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(plot22);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        float float4 = categoryLabelPosition3.getWidthRatio();
        float float5 = categoryLabelPosition3.getWidthRatio();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER" + "'", str2.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str20 = color19.toString();
        int int21 = color19.getBlue();
        java.awt.Color color22 = java.awt.Color.DARK_GRAY;
        float[] floatArray27 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray28 = color22.getRGBComponents(floatArray27);
        float[] floatArray29 = color19.getRGBColorComponents(floatArray28);
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic30 = new org.jfree.chart.title.LegendGraphic(shape14, (java.awt.Paint) color19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str20.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 128 + "'", int21 == 128);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot0.getRenderer();
        boolean boolean28 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.plot.Plot plot29 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image7 = projectInfo6.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "TextBlockAnchor.CENTER", "ChartEntity: tooltip = EXPAND", image7, "EXPAND", "Range[0.0,0.0]", "");
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("LegendItemEntity: seriesKey=null, dataset=null", "RectangleAnchor.BOTTOM_LEFT", "java.awt.Color[r=255,g=0,b=255]", image7, "DatasetRenderingOrder.FORWARD", "CategoryAnchor.END", "");
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(image7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.entity.EntityCollection entityCollection3 = categoryItemRendererState1.getEntityCollection();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getToolTipText();
        java.lang.Comparable comparable20 = legendItem18.getSeriesKey();
        int int21 = legendItem18.getDatasetIndex();
        java.awt.Shape shape22 = legendItem18.getShape();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        org.jfree.data.Range range8 = null;
        try {
            numberAxis0.setRangeWithMargins(range8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            labelBlock5.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        boolean boolean4 = numberAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis6.setCategoryLabelPositions(categoryLabelPositions7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape15, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape15, false, (java.awt.Paint) color19, false, paint21, stroke22, false, shape24, stroke25, paint27);
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray36, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray43);
        legendItem28.setDataset((org.jfree.data.general.Dataset) categoryDataset44);
        java.awt.Paint paint46 = legendItem28.getLinePaint();
        categoryAxis6.setTickLabelPaint(paint46);
        numberAxis0.setAxisLinePaint(paint46);
        double double49 = numberAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "Range[0.0,0.0]", numberArray2);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 0L, 10.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 1, (double) (byte) 0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        legendTitle11.setNotify(true);
        java.lang.Object obj14 = legendTitle11.clone();
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11);
        legendTitle1.setWrapper(blockContainer9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = legendTitle1.getVerticalAlignment();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        double double9 = legendTitle1.getContentYOffset();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle16.setLegendItemGraphicPadding(rectangleInsets19);
        legendTitle14.setPadding(rectangleInsets19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle23.setLegendItemGraphicPadding(rectangleInsets26);
        legendTitle14.setLegendItemGraphicPadding(rectangleInsets26);
        categoryPlot2.setInsets(rectangleInsets26);
        java.awt.Paint paint30 = categoryPlot2.getRangeGridlinePaint();
        java.awt.Paint paint31 = categoryPlot2.getOutlinePaint();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        org.jfree.data.Range range21 = rectangleConstraint20.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedHeight((double) 1L);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions3);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape10, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape19 = null;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape10, false, (java.awt.Paint) color14, false, paint16, stroke17, false, shape19, stroke20, paint22);
        categoryAxis2.setTickMarkStroke(stroke20);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis2.getCategoryEnd((int) (byte) 1, (int) (short) 1, rectangle2D27, rectangleEdge28);
        boolean boolean30 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) rectangle2D27);
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray38, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset46, false);
        try {
            java.lang.String str51 = standardCategorySeriesLabelGenerator0.generateLabel(categoryDataset46, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer((int) (short) 1, categoryItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, false);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "TextAnchor.TOP_CENTER", "", categoryDataset23, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape35, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape44 = null;
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape35, false, (java.awt.Paint) color39, false, paint41, stroke42, false, shape44, stroke45, paint47);
        java.lang.String str49 = legendItem48.getDescription();
        java.awt.Stroke stroke50 = legendItem48.getOutlineStroke();
        java.awt.Paint paint51 = null;
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem(attributedString0, "Range[100.0,300.0]", "ChartEntity: tooltip = EXPAND", "HorizontalAlignment.CENTER", shape5, (java.awt.Paint) color29, stroke50, paint51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        int int9 = categoryPlot0.getDomainAxisCount();
        int int10 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        boolean boolean4 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        try {
            org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 200.0d + "'", number17.equals(200.0d));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 200.0d + "'", number18.equals(200.0d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) '4');
        double double6 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str5 = textBlockAnchor4.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean8 = rectangleAnchor3.equals((java.lang.Object) color7);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean10 = rectangleAnchor3.equals((java.lang.Object) textAnchor9);
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 10, (double) (short) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER" + "'", str5.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation16);
        try {
            double double18 = numberAxis0.java2DToValue(0.2d, rectangle2D8, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        java.awt.Paint paint9 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        int int28 = categoryPlot21.getWeight();
        java.awt.Paint paint29 = categoryPlot21.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot31.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo36, point2D37);
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity(shape44, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape53 = null;
        java.awt.Stroke stroke54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint56 = defaultDrawingSupplier55.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape44, false, (java.awt.Paint) color48, false, paint50, stroke51, false, shape53, stroke54, paint56);
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] { numberArray65, numberArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        legendItem57.setDataset((org.jfree.data.general.Dataset) categoryDataset73);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = categoryPlot31.getRendererForDataset(categoryDataset73);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot31.setRangeAxisLocation(0, axisLocation77);
        org.jfree.chart.LegendItemSource legendItemSource79 = null;
        org.jfree.chart.title.LegendTitle legendTitle80 = new org.jfree.chart.title.LegendTitle(legendItemSource79);
        org.jfree.chart.LegendItemSource legendItemSource81 = null;
        org.jfree.chart.title.LegendTitle legendTitle82 = new org.jfree.chart.title.LegendTitle(legendItemSource81);
        double double83 = legendTitle82.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets84 = legendTitle82.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle82.setLegendItemGraphicPadding(rectangleInsets85);
        legendTitle80.setPadding(rectangleInsets85);
        org.jfree.chart.LegendItemSource legendItemSource88 = null;
        org.jfree.chart.title.LegendTitle legendTitle89 = new org.jfree.chart.title.LegendTitle(legendItemSource88);
        double double90 = legendTitle89.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets91 = legendTitle89.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets92 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle89.setLegendItemGraphicPadding(rectangleInsets92);
        legendTitle80.setLegendItemGraphicPadding(rectangleInsets92);
        boolean boolean95 = axisLocation77.equals((java.lang.Object) legendTitle80);
        org.jfree.chart.plot.PlotOrientation plotOrientation96 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge97 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation77, plotOrientation96);
        categoryPlot21.setRangeAxisLocation((int) (byte) 100, axisLocation77);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNull(categoryItemRenderer75);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets84);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets91);
        org.junit.Assert.assertNotNull(rectangleInsets92);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(plotOrientation96);
        org.junit.Assert.assertNotNull(rectangleEdge97);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getDescription();
        java.awt.Stroke stroke20 = legendItem18.getOutlineStroke();
        java.lang.Comparable comparable21 = legendItem18.getSeriesKey();
        java.awt.Paint paint22 = legendItem18.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        java.awt.Image image22 = null;
        categoryPlot13.setBackgroundImage(image22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot13.setRenderer(255, categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            categoryAxis1.setLabelInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Font font7 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        legendTitle1.setItemLabelPadding(rectangleInsets12);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE1", font15);
        legendTitle1.setItemFont(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = labelBlock5.getMargin();
        java.awt.Graphics2D graphics2D7 = null;
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray16, numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(0.0d, range25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = rectangleConstraint26.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D30 = labelBlock5.arrange(graphics2D7, rectangleConstraint26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset26);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        numberAxis0.setUpperMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double10 = numberAxis0.lengthToJava2D(2.0d, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.resizeRange(0.05d);
        java.lang.String str9 = numberAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis1.setTickMarksVisible(false);
        categoryAxis1.setAxisLineVisible(true);
        categoryAxis1.setMaximumCategoryLabelLines(15);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("poly");
        projectInfo0.setLicenceName("");
        projectInfo0.setCopyright("Layer.BACKGROUND");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = rectangleConstraint18.getHeightConstraintType();
        org.jfree.data.Range range22 = rectangleConstraint18.getWidthRange();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        categoryAxis24.setLabelAngle(4.0d);
        categoryAxis24.setFixedDimension((double) 128);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str5 = textBlockAnchor4.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor4);
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor3);
        java.awt.Font font8 = legendTitle2.getItemFont();
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType13 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean14 = categoryAxis12.equals((java.lang.Object) tickType13);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str19 = textAnchor18.toString();
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType13, (double) 3, "", textAnchor17, textAnchor18, (double) (short) 0);
        try {
            float float22 = textFragment9.calculateBaselineOffset(graphics2D10, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER" + "'", str5.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(tickType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str19.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        categoryPlot13.setWeight((int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        org.jfree.chart.axis.TickType tickType11 = numberTick10.getTickType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextOutlinePaint();
        boolean boolean14 = numberTick10.equals((java.lang.Object) defaultDrawingSupplier12);
        java.lang.String str15 = numberTick10.getText();
        java.lang.Object obj16 = numberTick10.clone();
        java.lang.String str17 = numberTick10.toString();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        java.lang.Object obj6 = keyedObjects2D0.getObject((java.lang.Comparable) "MINOR", (java.lang.Comparable) (-1));
        int int8 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setNotify(true);
        java.lang.Object obj5 = legendTitle2.clone();
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle2);
        double double7 = blockContainer0.getWidth();
        org.jfree.chart.block.Block block8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        try {
            blockContainer0.add(block8, (java.lang.Object) numberAxis9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.NumberAxis cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = numberAxis4.getRange();
        java.awt.Shape shape6 = numberAxis4.getDownArrow();
        numberAxis0.setDownArrow(shape6);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset23, false);
        numberAxis0.setRange(range26, true, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis1.addChangeListener(axisChangeListener4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo19, point2D20);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape36 = null;
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape27, false, (java.awt.Paint) color31, false, paint33, stroke34, false, shape36, stroke37, paint39);
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray48, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray55);
        legendItem40.setDataset((org.jfree.data.general.Dataset) categoryDataset56);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = categoryPlot14.getRendererForDataset(categoryDataset56);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot14.setRangeAxisLocation(0, axisLocation60);
        org.jfree.chart.LegendItemSource legendItemSource62 = null;
        org.jfree.chart.title.LegendTitle legendTitle63 = new org.jfree.chart.title.LegendTitle(legendItemSource62);
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle65.setLegendItemGraphicPadding(rectangleInsets68);
        legendTitle63.setPadding(rectangleInsets68);
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle72.setLegendItemGraphicPadding(rectangleInsets75);
        legendTitle63.setLegendItemGraphicPadding(rectangleInsets75);
        boolean boolean78 = axisLocation60.equals((java.lang.Object) legendTitle63);
        org.jfree.chart.plot.PlotOrientation plotOrientation79 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation60, plotOrientation79);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        try {
            org.jfree.chart.axis.AxisState axisState82 = categoryAxis1.draw(graphics2D10, (double) 2, rectangle2D12, rectangle2D13, rectangleEdge80, plotRenderingInfo81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNull(categoryItemRenderer58);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(plotOrientation79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getDescription();
        java.awt.Stroke stroke20 = legendItem18.getOutlineStroke();
        java.lang.Comparable comparable21 = legendItem18.getSeriesKey();
        java.lang.Object obj22 = null;
        boolean boolean23 = legendItem18.equals(obj22);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot21.getDomainAxisForDataset((-15423));
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis29.setCategoryLabelPositions(categoryLabelPositions30);
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape37, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape46 = null;
        java.awt.Stroke stroke47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint49 = defaultDrawingSupplier48.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape37, false, (java.awt.Paint) color41, false, paint43, stroke44, false, shape46, stroke47, paint49);
        categoryAxis29.setTickMarkStroke(stroke47);
        categoryPlot21.setDomainGridlineStroke(stroke47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot21.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(categoryLabelPositions30);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(sortOrder53);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle2.getText();
        boolean boolean7 = textTitle2.getNotify();
        boolean boolean8 = textTitle2.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str3 = textBlockAnchor2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float5 = categoryLabelPosition4.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str10 = textBlockAnchor9.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition11);
        double double13 = categoryLabelPosition11.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER" + "'", str3.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextBlockAnchor.CENTER" + "'", str10.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        legendTitle11.setNotify(true);
        java.lang.Object obj14 = legendTitle11.clone();
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11);
        legendTitle1.setWrapper(blockContainer9);
        java.util.List list17 = blockContainer9.getBlocks();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers((int) (short) 0);
        java.awt.Stroke stroke14 = categoryPlot11.getDomainGridlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke14);
        int int16 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.expand(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle10.setLegendItemGraphicPadding(rectangleInsets13);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets13);
        double double17 = rectangleInsets13.trimWidth(0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-5.95d) + "'", double17 == (-5.95d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        double double6 = numberAxis0.getUpperBound();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) 100L);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, 2.0d);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot9.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot0.getDomainMarkers(layer19);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryItemRendererState1, jFreeChart3, (int) (short) 1, (-6553600));
        chartProgressEvent6.setType(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        org.jfree.data.RangeType rangeType7 = org.jfree.data.RangeType.FULL;
        numberAxis0.setRangeType(rangeType7);
        java.lang.Object obj9 = numberAxis0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape10, "poly", "DatasetRenderingOrder.FORWARD");
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) axisLabelEntity13);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        numberAxis0.setTickMarkInsideLength((float) 128);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("poly");
        projectInfo0.setLicenceName("");
        projectInfo0.setInfo("ThreadContext");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        java.lang.String str26 = categoryItemEntity24.getShapeType();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "rect" + "'", str26.equals("rect"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (-1));
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.toString();
        boolean boolean5 = booleanList0.equals((java.lang.Object) str4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ItemLabelAnchor.INSIDE1");
        boolean boolean8 = booleanList0.equals((java.lang.Object) "ItemLabelAnchor.INSIDE1");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str11 = textBlockAnchor10.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean14 = rectangleAnchor9.equals((java.lang.Object) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean16 = rectangleAnchor9.equals((java.lang.Object) textAnchor15);
        boolean boolean17 = booleanList0.equals((java.lang.Object) boolean16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartEntity: tooltip = null" + "'", str4.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextBlockAnchor.CENTER" + "'", str11.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        try {
            categoryPlot0.setRenderer((int) (short) -1, categoryItemRenderer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("AxisLabelEntity: label = TextBlockAnchor.CENTER", graphics2D1, (float) (byte) -1, (float) '#', textAnchor5, (double) 10, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        double double12 = rectangleInsets10.calculateRightInset((double) '#');
        double double14 = rectangleInsets10.calculateBottomInset(0.0d);
        double double16 = rectangleInsets10.trimWidth(200.0d);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 198.0d + "'", double16 == 198.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 0);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle7.draw(graphics2D8, rectangle2D9);
        textTitle7.setExpandToFitSpace(true);
        java.lang.String str13 = textTitle7.getText();
        java.awt.Font font14 = textTitle7.getFont();
        org.jfree.chart.util.ObjectList objectList16 = new org.jfree.chart.util.ObjectList((int) '#');
        objectList16.clear();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) objectList16);
        textTitle7.setToolTipText("-100,100,-100,100,-100,100,100,100,100,100,100,100,100,-100,100,-100,100,-100,-100,-100,-100,-100,-100,-100,-100,-100");
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (byte) 100);
        flowArrangement8.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        boolean boolean6 = rectangleInsets3.equals((java.lang.Object) defaultDrawingSupplier4);
        java.awt.Paint paint7 = defaultDrawingSupplier4.getNextFillPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (-15423));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis1.setLabelInsets(rectangleInsets8);
        categoryAxis1.setVisible(false);
        categoryAxis1.setTickMarkInsideLength((float) 128);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = rectangleConstraint18.getHeightConstraintType();
        java.lang.String str22 = rectangleConstraint18.toString();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str22.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType4 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean5 = categoryAxis3.equals((java.lang.Object) tickType4);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str10 = textAnchor9.toString();
        org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick(tickType4, (double) 3, "", textAnchor8, textAnchor9, (double) (short) 0);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor9, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(tickType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str10.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        float float4 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.axis.AxisState axisState11 = categoryAxis1.draw(graphics2D5, (double) (short) 10, rectangle2D7, rectangle2D8, rectangleEdge9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setFixedDimension(100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape9, false, (java.awt.Paint) color13, false, paint15, stroke16, false, shape18, stroke19, paint21);
        categoryAxis1.setTickMarkStroke(stroke19);
        int int24 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation29 = axisLocation28.getOpposite();
        categoryPlot25.setRangeAxisLocation(axisLocation29, false);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot25.getRowRenderingOrder();
        java.awt.Paint paint33 = categoryPlot25.getRangeCrosshairPaint();
        java.awt.Paint paint34 = categoryPlot25.getDomainGridlinePaint();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot25);
        java.lang.Object obj36 = categoryPlot25.clone();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        int int28 = categoryPlot21.getWeight();
        java.awt.Paint paint29 = categoryPlot21.getDomainGridlinePaint();
        java.lang.Object obj30 = categoryPlot21.clone();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot21.getDomainAxisForDataset((-15423));
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis29.setCategoryLabelPositions(categoryLabelPositions30);
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape37, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape46 = null;
        java.awt.Stroke stroke47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint49 = defaultDrawingSupplier48.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape37, false, (java.awt.Paint) color41, false, paint43, stroke44, false, shape46, stroke47, paint49);
        categoryAxis29.setTickMarkStroke(stroke47);
        categoryPlot21.setDomainGridlineStroke(stroke47);
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        categoryPlot21.addChangeListener(plotChangeListener53);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(categoryLabelPositions30);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.lang.Object obj3 = textTitle2.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis5.getCategoryMiddle(10, (int) (short) 10, rectangle2D9, rectangleEdge10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis5.setLabelInsets(rectangleInsets12);
        textTitle2.setMargin(rectangleInsets12);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets12.createInsetRectangle(rectangle2D15, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.lang.String str22 = legendItemEntity21.getURLText();
        java.lang.String str23 = legendItemEntity21.toString();
        org.jfree.data.general.Dataset dataset24 = legendItemEntity21.getDataset();
        legendItemEntity21.setToolTipText("rect");
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str23.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(dataset24);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent26);
        categoryPlot21.setRangeCrosshairValue((double) 10, true);
        try {
            categoryPlot21.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(markerAxisBand6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.jfree.data.general.Dataset dataset2 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.general.DatasetChangeEvent(obj1, dataset2);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.TickType tickType3 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean4 = legendItemCollection0.equals((java.lang.Object) tickType3);
        org.jfree.chart.LegendItem legendItem5 = null;
        legendItemCollection0.add(legendItem5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(tickType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        try {
            categoryPlot21.setRenderer((-15423), categoryItemRenderer23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setMaximumCategoryLabelLines(128);
        int int7 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setLabelURL("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(15);
        java.lang.Object obj3 = null;
        try {
            objectList1.set((int) (byte) -1, obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = legendTitle1.arrange(graphics2D5, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = categoryItemRendererState1.getInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = categoryItemRendererState1.getInfo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertNull(plotRenderingInfo4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        boolean boolean4 = projectInfo2.equals((java.lang.Object) blockContainer3);
        java.lang.String str5 = projectInfo2.toString();
        projectInfo2.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo0.setVersion("poly");
        java.lang.String str11 = projectInfo0.getVersion();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        boolean boolean4 = numberAxis0.isAutoTickUnitSelection();
        org.jfree.data.KeyedObjects2D keyedObjects2D5 = new org.jfree.data.KeyedObjects2D();
        int int6 = keyedObjects2D5.getRowCount();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray14, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset22);
        boolean boolean24 = keyedObjects2D5.equals((java.lang.Object) range23);
        double double25 = range23.getLength();
        numberAxis0.setRangeWithMargins(range23, true, true);
        double double29 = range23.getLength();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 105.0d + "'", double25 == 105.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 105.0d + "'", double29 == 105.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "java.awt.Color[r=128,g=255,b=128]", "ChartEntity: tooltip = null", shape5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("EXPAND", "Range[0.0,0.0]", "poly", "", shape6, (java.awt.Paint) color7);
        java.lang.String str9 = legendItem8.getDescription();
        boolean boolean10 = shapeList0.equals((java.lang.Object) str9);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[0.0,0.0]" + "'", str9.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        boolean boolean22 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        try {
            java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2);
        java.lang.Class<?> wildcardClass4 = textAnchor2.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("DatasetRenderingOrder.FORWARD", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(inputStream5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (short) 0);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getUpperBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        boolean boolean10 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str9 = chartEntity8.getShapeType();
        java.lang.String str10 = chartEntity8.getURLText();
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) chartEntity8);
        java.lang.Comparable comparable12 = null;
        try {
            java.awt.Paint paint13 = categoryAxis1.getTickLabelPaint(comparable12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "poly" + "'", str9.equals("poly"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "ChartEntity: tooltip = EXPAND");
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getTextAnchor();
        boolean boolean5 = textAnchor3.equals((java.lang.Object) "TextAnchor.TOP_CENTER");
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset15, false);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 100.0d + "'", number19.equals(100.0d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        java.lang.Object obj2 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers((int) (short) 0);
        java.awt.Stroke stroke14 = categoryPlot11.getDomainGridlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke14);
        java.awt.Paint paint16 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) (-1.0f));
        double double4 = rectangleInsets0.calculateRightInset((double) 3);
        double double6 = rectangleInsets0.calculateBottomOutset(105.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        java.awt.Color color10 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        boolean boolean12 = color10.equals((java.lang.Object) 10);
        boolean boolean13 = sortOrder7.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.Graphics2D graphics2D4 = null;
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray13, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(0.0d, range22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint23.toFixedWidth((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D26 = legendTitle1.arrange(graphics2D4, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray34);
        legendItem19.setDataset((org.jfree.data.general.Dataset) categoryDataset35);
        boolean boolean37 = itemLabelAnchor0.equals((java.lang.Object) legendItem19);
        int int38 = legendItem19.getSeriesIndex();
        java.lang.String str39 = legendItem19.getURLText();
        java.text.AttributedString attributedString40 = legendItem19.getAttributedLabel();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextBlockAnchor.CENTER" + "'", str39.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(attributedString40);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '#');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Color color3 = java.awt.Color.yellow;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = categoryAxis1.draw(graphics2D6, (double) 2, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        java.lang.String str9 = legendTitle1.getID();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        categoryItemEntity24.setToolTipText("Range[100.0,300.0]");
        java.lang.Comparable comparable27 = categoryItemEntity24.getRowKey();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100L + "'", comparable27.equals(100L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        float float4 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setMaximumCategoryLabelLines(128);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset15, false);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 200.0d + "'", number19.equals(200.0d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str1.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str5 = textBlockAnchor4.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor4);
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor3);
        java.awt.Font font8 = legendTitle2.getItemFont();
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font8);
        java.awt.Paint paint10 = textFragment9.getPaint();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = null;
        try {
            textFragment9.draw(graphics2D11, (float) 10, (float) 3, textAnchor14, (float) (short) 100, (float) 100, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER" + "'", str5.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f);
        int int2 = numberTickUnit1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        double double3 = categoryAxis1.getLabelAngle();
        java.awt.Stroke stroke4 = categoryAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Color color2 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        boolean boolean4 = color2.equals((java.lang.Object) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str6 = color5.toString();
        int int7 = color5.getBlue();
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        float[] floatArray13 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray14 = color8.getRGBComponents(floatArray13);
        float[] floatArray15 = color5.getRGBColorComponents(floatArray14);
        float[] floatArray16 = color2.getComponents(floatArray14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str6.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        categoryAxis24.setLabelAngle(4.0d);
        categoryAxis24.setCategoryMargin((double) (-15423));
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        axisState3.cursorRight(1.0E-8d);
        axisState3.setMax(0.0d);
        double double8 = axisState3.getMax();
        axisState3.setCursor((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list13 = numberAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset17);
        boolean boolean19 = keyedObjects2D0.equals((java.lang.Object) range18);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 200.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle2.getText();
        java.awt.Font font7 = textTitle2.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        boolean boolean4 = legendTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 1L);
        java.lang.Object obj3 = legendItemCollection0.clone();
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font5);
        java.lang.Object obj7 = textTitle6.clone();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle6.draw(graphics2D8, rectangle2D9);
        boolean boolean11 = legendItemCollection0.equals((java.lang.Object) rectangle2D9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        boolean boolean2 = datasetGroup0.equals((java.lang.Object) textBlockAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryAxis1, (org.jfree.data.general.Dataset) categoryDataset19);
        java.awt.Stroke stroke27 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.0d + "'", number21.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        boolean boolean4 = numberAxis0.isAutoTickUnitSelection();
        java.text.NumberFormat numberFormat5 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        double double16 = rectangleInsets13.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        java.lang.Object obj15 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textBlockAnchor12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle2.getPadding();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = textTitle2.arrange(graphics2D17, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryItemEntity24.getDataset();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        boolean boolean4 = projectInfo2.equals((java.lang.Object) blockContainer3);
        java.lang.String str5 = projectInfo2.toString();
        projectInfo2.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str9 = projectInfo2.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ThreadContext");
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedWidth();
        boolean boolean5 = rangeType0.equals((java.lang.Object) rectangleConstraint4);
        org.jfree.data.KeyedObjects2D keyedObjects2D6 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D6.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        boolean boolean10 = rangeType0.equals((java.lang.Object) (short) -1);
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        textTitle13.draw(graphics2D14, rectangle2D15);
        textTitle13.setExpandToFitSpace(true);
        textTitle13.setPadding(3.0d, (double) (byte) 1, (double) (-15423), (double) '#');
        boolean boolean24 = rangeType0.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, (double) 0.0f, 10.0d);
        java.awt.Color color10 = java.awt.Color.ORANGE;
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray18, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        categoryPlot32.setRangeGridlineStroke(stroke35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray45 = new float[] { 0L, '#', (short) 10, 128, (-6553600), (-1) };
        float[] floatArray46 = color38.getRGBComponents(floatArray45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor50 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str51 = textBlockAnchor50.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition52 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor49, textBlockAnchor50);
        legendTitle48.setLegendItemGraphicAnchor(rectangleAnchor49);
        java.awt.Color color56 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle48.setItemPaint((java.awt.Paint) color56);
        java.awt.color.ColorSpace colorSpace58 = color56.getColorSpace();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str60 = color59.toString();
        int int61 = color59.getBlue();
        java.awt.Color color62 = java.awt.Color.DARK_GRAY;
        float[] floatArray67 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray68 = color62.getRGBComponents(floatArray67);
        float[] floatArray69 = color59.getRGBColorComponents(floatArray68);
        float[] floatArray70 = color38.getColorComponents(colorSpace58, floatArray69);
        java.awt.Color color71 = java.awt.Color.yellow;
        java.awt.Color color72 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray79 = new float[] { 0L, '#', (short) 10, 128, (-6553600), (-1) };
        float[] floatArray80 = color72.getRGBComponents(floatArray79);
        float[] floatArray81 = color71.getColorComponents(floatArray79);
        float[] floatArray82 = color37.getColorComponents(colorSpace58, floatArray81);
        try {
            org.jfree.chart.LegendItem legendItem83 = new org.jfree.chart.LegendItem(attributedString0, "ChartEntity: tooltip = null", "ItemLabelAnchor.INSIDE1", "HorizontalAlignment.CENTER", shape9, (java.awt.Paint) color10, stroke35, (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(textBlockAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "TextBlockAnchor.CENTER" + "'", str51.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(colorSpace58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str60.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 128 + "'", int61 == 128);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray80);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertNotNull(floatArray82);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0d + "'", number25.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 200.0d + "'", number26.equals(200.0d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) 3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (byte) 100);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment9, 1.0E-8d, (double) 100);
        flowArrangement12.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        float float14 = jFreeChart13.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart13.draw(graphics2D15, rectangle2D16, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        java.awt.Graphics2D graphics2D31 = null;
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray40, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray47);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset48);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(0.0d, range49);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = rectangleConstraint50.toFixedWidth((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D53 = labelBlock5.arrange(graphics2D31, rectangleConstraint52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(rectangleConstraint52);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        float float17 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f);
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        axisSpace2.ensureAtLeast((-1.0d), rectangleEdge4);
        int int7 = numberTickUnit1.compareTo((java.lang.Object) axisSpace2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle3.draw(graphics2D4, rectangle2D5);
        textTitle3.setExpandToFitSpace(true);
        java.lang.String str9 = textTitle3.getText();
        java.awt.Font font10 = textTitle3.getFont();
        java.awt.Paint paint11 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("CategoryAnchor.END", font10, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.CENTER" + "'", str9.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets4);
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        try {
            legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets13.createInsetRectangle(rectangle2D15, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent22);
        categoryPlot13.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Color color3 = java.awt.Color.yellow;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo6);
        java.util.List list8 = null;
        projectInfo0.setContributors(list8);
        java.lang.String str10 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color1 = java.awt.Color.getColor("TextAnchor.CENTER_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot9.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            categoryPlot0.drawBackground(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        java.awt.Paint paint10 = categoryPlot0.getNoDataMessagePaint();
        int int11 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis13.setCategoryLabelPositions(categoryLabelPositions14);
        categoryAxis13.configure();
        java.awt.Stroke stroke17 = categoryAxis13.getTickMarkStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke17);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Font font7 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        legendTitle1.setItemLabelPadding(rectangleInsets12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            legendTitle1.draw(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset17);
        boolean boolean19 = keyedObjects2D0.equals((java.lang.Object) range18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType22 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean23 = categoryAxis21.equals((java.lang.Object) tickType22);
        categoryAxis21.clearCategoryLabelToolTips();
        java.awt.Paint paint25 = categoryAxis21.getTickLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) paint25, (java.lang.Comparable) "HorizontalAlignment.CENTER", (java.lang.Comparable) (short) 1);
        java.lang.Comparable comparable29 = null;
        java.lang.Object obj31 = keyedObjects2D0.getObject(comparable29, (java.lang.Comparable) "PlotOrientation.VERTICAL");
        try {
            java.lang.Comparable comparable33 = keyedObjects2D0.getColumnKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(tickType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape10, "poly", "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape10, "LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        axisSpace11.ensureAtLeast((-1.0d), rectangleEdge13);
        boolean boolean16 = numberTick10.equals((java.lang.Object) rectangleEdge13);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle36.setLegendItemGraphicPadding(rectangleInsets39);
        legendTitle34.setPadding(rectangleInsets39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str44 = textBlockAnchor43.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition45 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor42, textBlockAnchor43);
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean47 = rectangleAnchor42.equals((java.lang.Object) color46);
        org.jfree.chart.text.TextAnchor textAnchor48 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean49 = rectangleAnchor42.equals((java.lang.Object) textAnchor48);
        legendTitle34.setLegendItemGraphicLocation(rectangleAnchor42);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        boolean boolean53 = rectangleInsets51.equals((java.lang.Object) (-1.0f));
        double double55 = rectangleInsets51.calculateRightInset((double) 3);
        double double56 = rectangleInsets51.getRight();
        legendTitle34.setItemLabelPadding(rectangleInsets51);
        try {
            java.lang.Object obj58 = labelBlock5.draw(graphics2D31, rectangle2D32, (java.lang.Object) rectangleInsets51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "TextBlockAnchor.CENTER" + "'", str44.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.0d + "'", double55 == 3.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.0d + "'", double56 == 3.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 1);
        numberAxis0.setFixedAutoRange((double) (byte) 10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Layer.BACKGROUND", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        double double2 = numberAxis0.getUpperMargin();
        org.jfree.data.Range range3 = numberAxis0.getRange();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot2.setRenderer((int) (short) 1, categoryItemRenderer14, false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity24 = new org.jfree.chart.entity.TickLabelEntity(shape6, "EXPAND", "poly");
        java.lang.String str25 = tickLabelEntity24.toString();
        java.lang.String str26 = tickLabelEntity24.getShapeType();
        java.lang.String str27 = tickLabelEntity24.getToolTipText();
        java.lang.String str28 = tickLabelEntity24.getToolTipText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ChartEntity: tooltip = EXPAND" + "'", str25.equals("ChartEntity: tooltip = EXPAND"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "poly" + "'", str26.equals("poly"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "EXPAND" + "'", str27.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "EXPAND" + "'", str28.equals("EXPAND"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 0.95f, (double) 100);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("MINOR", "TextBlockAnchor.CENTER", "java.awt.Color[r=255,g=0,b=255]", image4, "ChartEntity: tooltip = EXPAND", "java.awt.Color[r=128,g=255,b=128]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str9 = projectInfo8.getInfo();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str9.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 0);
        columnArrangement4.clear();
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4, true);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        legendTitle10.setNotify(true);
        java.lang.Object obj13 = legendTitle10.clone();
        legendTitle10.setHeight(0.0d);
        legendTitle10.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent18.setType(chartChangeEventType19);
        boolean boolean21 = sortOrder8.equals((java.lang.Object) chartChangeEventType19);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType24 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean25 = categoryAxis23.equals((java.lang.Object) tickType24);
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str30 = textAnchor29.toString();
        org.jfree.chart.axis.NumberTick numberTick32 = new org.jfree.chart.axis.NumberTick(tickType24, (double) 3, "", textAnchor28, textAnchor29, (double) (short) 0);
        org.jfree.chart.axis.TickType tickType33 = numberTick32.getTickType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint35 = defaultDrawingSupplier34.getNextOutlinePaint();
        boolean boolean36 = numberTick32.equals((java.lang.Object) defaultDrawingSupplier34);
        java.lang.String str37 = numberTick32.getText();
        boolean boolean38 = sortOrder8.equals((java.lang.Object) str37);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(tickType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str30.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(tickType33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setNotify(true);
        java.lang.Object obj5 = legendTitle2.clone();
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle2);
        double double7 = blockContainer0.getWidth();
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrangement8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6, (org.jfree.chart.block.Arrangement) flowArrangement13, (org.jfree.chart.block.Arrangement) flowArrangement14);
        java.awt.Font font16 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis18.getCategoryMiddle(10, (int) (short) 10, rectangle2D22, rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis18.setLabelInsets(rectangleInsets25);
        java.util.List list27 = categoryPlot6.getCategoriesForAxis(categoryAxis18);
        projectInfo0.setContributors(list27);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(list27);
    }
}

