import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        boolean boolean2 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
//        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
//        java.lang.String str3 = projectInfo0.toString();
//        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//        projectInfo0.setName("MINOR");
//        java.lang.String str8 = projectInfo0.getLicenceName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) color0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 1);
        boolean boolean3 = numberAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        float float14 = jFreeChart13.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart13.createBufferedImage((int) (byte) 0, (-6553600), chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-6553600) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        textTitle2.setExpandToFitSpace(true);
        java.lang.String str8 = textTitle2.getText();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font12);
        boolean boolean14 = textTitle13.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement17 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj18 = textTitle13.draw(graphics2D15, rectangle2D16, (java.lang.Object) borderArrangement17);
        java.awt.Paint paint19 = textTitle13.getBackgroundPaint();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str24 = textBlockAnchor23.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor23);
        java.lang.Object obj26 = textTitle13.draw(graphics2D20, rectangle2D21, (java.lang.Object) textBlockAnchor23);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle13.getPadding();
        java.lang.Object obj28 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textTitle13);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER" + "'", str8.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextBlockAnchor.CENTER" + "'", str24.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(obj28);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Color color0 = java.awt.Color.blue;
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray9 = new float[] { 0L, '#', (short) 10, 128, (-6553600), (-1) };
        float[] floatArray10 = color2.getRGBComponents(floatArray9);
        float[] floatArray11 = color1.getColorComponents(floatArray9);
        float[] floatArray12 = color0.getRGBComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        categoryAxis24.setLabelAngle(4.0d);
        categoryAxis24.setFixedDimension((double) (-15423));
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle2.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle2.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6, textAnchor8, (double) (short) 0, categoryLabelWidthType10, 0.0f);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str16 = textBlockAnchor15.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean19 = rectangleAnchor14.equals((java.lang.Object) color18);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str21 = textBlockAnchor20.toString();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = legendTitle23.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str28 = textBlockAnchor27.toString();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType31 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor26, textBlockAnchor27, textAnchor29, (double) (short) 0, categoryLabelWidthType31, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition35 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor20, categoryLabelWidthType31, (float) ' ');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER" + "'", str7.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextBlockAnchor.CENTER" + "'", str16.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextBlockAnchor.CENTER" + "'", str21.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TextBlockAnchor.CENTER" + "'", str28.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryLabelWidthType31);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        java.awt.Image image22 = null;
        categoryPlot13.setBackgroundImage(image22);
        categoryPlot13.setRangeCrosshairLockedOnData(false);
        categoryPlot13.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.resizeRange(0.05d);
        java.awt.Shape shape9 = null;
        try {
            numberAxis0.setUpArrow(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        boolean boolean6 = rectangleInsets3.equals((java.lang.Object) defaultDrawingSupplier4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = color7.brighter();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 1, 0.0d);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        legendTitle6.setMargin(3.0d, 0.0d, (double) (byte) 1, (double) (-1));
        java.awt.Paint paint12 = legendTitle6.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets13.getUnitType();
        flowArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) unitType14);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        java.lang.String str5 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=100.0,l=0.0,b=97.0,r=0.0]" + "'", str5.equals("RectangleInsets[t=100.0,l=0.0,b=97.0,r=0.0]"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=128]");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            jFreeChart13.draw(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape6 = numberAxis5.getLeftArrow();
        java.awt.Shape shape7 = numberAxis5.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setAutoRangeStickyZero(false);
        java.lang.Object obj11 = numberAxis8.clone();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range13 = numberAxis12.getRange();
        java.awt.Shape shape14 = numberAxis12.getDownArrow();
        numberAxis8.setDownArrow(shape14);
        numberAxis5.setUpArrow(shape14);
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray25, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray32);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis42.setTickMarksVisible(false);
        categoryPlot39.setDomainAxis((int) (short) 100, categoryAxis42);
        int int46 = categoryPlot39.getWeight();
        java.awt.Paint paint47 = categoryPlot39.getDomainGridlinePaint();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions52 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis51.setCategoryLabelPositions(categoryLabelPositions52);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke56 = categoryAxis55.getTickMarkStroke();
        categoryAxis51.setAxisLineStroke(stroke56);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier59 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape60 = defaultDrawingSupplier59.getNextShape();
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray77 = new java.lang.Number[][] { numberArray70, numberArray76 };
        org.jfree.data.category.CategoryDataset categoryDataset78 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray77);
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset78);
        java.lang.Number number80 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset78);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity83 = new org.jfree.chart.entity.CategoryItemEntity(shape60, "TextAnchor.TOP_CENTER", "", categoryDataset78, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        org.jfree.chart.axis.CategoryAxis categoryAxis85 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke86 = categoryAxis85.getTickMarkStroke();
        java.awt.Paint paint87 = null;
        try {
            org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem(attributedString0, "", "LegendItemEntity: seriesKey=null, dataset=null", "UnitType.ABSOLUTE", false, shape14, false, paint47, true, (java.awt.Paint) color49, stroke56, false, shape60, stroke86, paint87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 1.0d + "'", number35.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(categoryLabelPositions52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray77);
        org.junit.Assert.assertNotNull(categoryDataset78);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 200.0d + "'", number80.equals(200.0d));
        org.junit.Assert.assertNotNull(stroke86);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str6 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        boolean boolean4 = numberAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis6.setCategoryLabelPositions(categoryLabelPositions7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape15, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape15, false, (java.awt.Paint) color19, false, paint21, stroke22, false, shape24, stroke25, paint27);
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray36, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray43);
        legendItem28.setDataset((org.jfree.data.general.Dataset) categoryDataset44);
        java.awt.Paint paint46 = legendItem28.getLinePaint();
        categoryAxis6.setTickLabelPaint(paint46);
        numberAxis0.setAxisLinePaint(paint46);
        numberAxis0.setTickMarkInsideLength((float) 3);
        org.jfree.data.RangeType rangeType51 = org.jfree.data.RangeType.FULL;
        org.jfree.data.Range range53 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range53);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint54.toUnconstrainedWidth();
        boolean boolean56 = rangeType51.equals((java.lang.Object) rectangleConstraint55);
        org.jfree.data.KeyedObjects2D keyedObjects2D57 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D57.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        boolean boolean61 = rangeType51.equals((java.lang.Object) (short) -1);
        numberAxis0.setRangeType(rangeType51);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rangeType51);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeListener chartChangeListener28 = null;
        try {
            jFreeChart27.addChangeListener(chartChangeListener28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean2 = keyedObjects0.equals((java.lang.Object) columnArrangement1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) flowArrangement13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getItemLabelPadding();
        categoryPlot5.setInsets(rectangleInsets18);
        categoryPlot5.configureRangeAxes();
        boolean boolean21 = categoryPlot5.isDomainZoomable();
        int int22 = categoryPlot5.getBackgroundImageAlignment();
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray31, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis48.setTickMarksVisible(false);
        categoryPlot45.setDomainAxis((int) (short) 100, categoryAxis48);
        categoryAxis48.setLabelAngle(4.0d);
        categoryPlot5.setDomainAxis(3, categoryAxis48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        categoryPlot5.zoomDomainAxes((double) 10L, plotRenderingInfo56, point2D57);
        java.awt.Paint paint59 = categoryPlot5.getNoDataMessagePaint();
        keyedObjects0.setObject((java.lang.Comparable) (byte) 10, (java.lang.Object) categoryPlot5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1.0d + "'", number41.equals(1.0d));
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.INSIDE1", graphics2D1, 0.05d, (float) (-6553600), (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj3 = axisSpace2.clone();
        boolean boolean4 = datasetGroup0.equals(obj3);
        java.lang.Object obj5 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setTop((double) 1L);
        double double32 = axisSpace29.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot0.getRangeAxis((int) (byte) 10);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNull(valueAxis38);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        java.util.List list29 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(list29);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getToolTipText();
        java.awt.Paint paint20 = legendItem18.getFillPaint();
        boolean boolean21 = legendItem18.isShapeFilled();
        java.awt.Paint paint22 = legendItem18.getFillPaint();
        boolean boolean23 = legendItem18.isLineVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getLeftArrow();
        org.jfree.data.RangeType rangeType2 = numberAxis0.getRangeType();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray10, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18);
        numberAxis0.setRangeWithMargins(range21, false, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertNotNull(range21);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        double double8 = categoryAxis1.getFixedDimension();
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Paint paint10 = categoryAxis1.getLabelPaint();
        java.awt.Font font12 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) '#', font12);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        try {
            categoryPlot21.addRangeMarker((int) (byte) 100, marker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        boolean boolean13 = categoryPlot0.isOutlineVisible();
        int int14 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis1.addChangeListener(axisChangeListener4);
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 10);
        categoryAxis1.setVisible(false);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray18, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset26, (double) 100L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range33);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint34.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint35.toFixedHeight((double) (-6553600));
        org.jfree.data.KeyedObjects2D keyedObjects2D38 = new org.jfree.data.KeyedObjects2D();
        int int39 = keyedObjects2D38.getRowCount();
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray47, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset55);
        boolean boolean57 = keyedObjects2D38.equals((java.lang.Object) range56);
        double double58 = range56.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = rectangleConstraint37.toRangeHeight(range56);
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray68, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray75);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset76);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint78 = new org.jfree.chart.block.RectangleConstraint(0.0d, range77);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = rectangleConstraint78.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType81 = rectangleConstraint78.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = new org.jfree.chart.block.RectangleConstraint((double) '4', range29, lengthConstraintType30, 1.0d, range56, lengthConstraintType81);
        boolean boolean83 = categoryAxis1.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 105.0d + "'", double58 == 105.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNotNull(rectangleConstraint80);
        org.junit.Assert.assertNotNull(lengthConstraintType81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) 0L, (double) 128, (double) 0.0f, 1.0E-8d);
        java.lang.String str7 = unitType1.toString();
        java.lang.String str8 = unitType1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis1.setLabelInsets(rectangleInsets8);
        categoryAxis1.setVisible(false);
        boolean boolean12 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape13, false, (java.awt.Paint) color17, false, paint19, stroke20, false, shape22, stroke23, paint25);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        legendItem26.setDataset((org.jfree.data.general.Dataset) categoryDataset42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot0.getRendererForDataset(categoryDataset42);
        boolean boolean45 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str48 = layer47.toString();
        java.util.Collection collection49 = categoryPlot0.getDomainMarkers(2, layer47);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier50 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(categoryItemRenderer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Layer.BACKGROUND" + "'", str48.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(drawingSupplier50);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape13, false, (java.awt.Paint) color17, false, paint19, stroke20, false, shape22, stroke23, paint25);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        legendItem26.setDataset((org.jfree.data.general.Dataset) categoryDataset42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot0.getRendererForDataset(categoryDataset42);
        boolean boolean45 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(categoryItemRenderer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle16.setLegendItemGraphicPadding(rectangleInsets19);
        legendTitle14.setPadding(rectangleInsets19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle23.setLegendItemGraphicPadding(rectangleInsets26);
        legendTitle14.setLegendItemGraphicPadding(rectangleInsets26);
        categoryPlot2.setInsets(rectangleInsets26);
        double double31 = rectangleInsets26.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-6.0d) + "'", double31 == (-6.0d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft(200.0d);
        double double3 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (-1));
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.toString();
        boolean boolean5 = booleanList0.equals((java.lang.Object) str4);
        java.lang.Boolean boolean7 = booleanList0.getBoolean((int) (short) 1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartEntity: tooltip = null" + "'", str4.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        legendItem18.setDataset((org.jfree.data.general.Dataset) categoryDataset34);
        java.awt.Paint paint36 = legendItem18.getLinePaint();
        legendItem18.setDatasetIndex((-6553600));
        int int39 = legendItem18.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape10 = defaultDrawingSupplier9.getNextShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray20, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray27);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset28);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "TextAnchor.TOP_CENTER", "", categoryDataset28, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 200.0d + "'", number30.equals(200.0d));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.0d + "'", number34.equals(1.0d));
        org.junit.Assert.assertNull(categoryItemRenderer35);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(1);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray34);
        legendItem19.setDataset((org.jfree.data.general.Dataset) categoryDataset35);
        boolean boolean37 = itemLabelAnchor0.equals((java.lang.Object) legendItem19);
        int int38 = legendItem19.getSeriesIndex();
        java.lang.Comparable comparable39 = null;
        legendItem19.setSeriesKey(comparable39);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle2.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle2.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6, textAnchor8, (double) (short) 0, categoryLabelWidthType10, 0.0f);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot15.setRangeAxisLocation(axisLocation19, false);
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray30, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray37);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset38);
        categoryPlot15.setDataset(0, categoryDataset38);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset38, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) '#', range43);
        boolean boolean45 = categoryLabelPositions13.equals((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER" + "'", str7.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 200.0d + "'", number40.equals(200.0d));
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Paint paint29 = jFreeChart28.getBackgroundPaint();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.title.Title title10 = titleChangeEvent9.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = title10.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(title10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", graphics2D1, 1.0d, (float) 1L, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setAutoRangeStickyZero(false);
        java.lang.Object obj6 = numberAxis3.clone();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = numberAxis7.getRange();
        java.awt.Shape shape9 = numberAxis7.getDownArrow();
        numberAxis3.setDownArrow(shape9);
        boolean boolean11 = textBlock2.equals((java.lang.Object) numberAxis3);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str17 = textBlockAnchor16.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16);
        java.awt.Shape shape22 = textBlock2.calculateBounds(graphics2D12, 0.0f, (float) (byte) 100, textBlockAnchor16, (float) (short) -1, (float) 10L, 4.0d);
        try {
            java.awt.GradientPaint gradientPaint23 = standardGradientPaintTransformer0.transform(gradientPaint1, shape22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextBlockAnchor.CENTER" + "'", str17.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = labelBlock5.getMargin();
        java.awt.Graphics2D graphics2D7 = null;
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray16, numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(0.0d, range25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toFixedWidth((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D29 = labelBlock5.arrange(graphics2D7, rectangleConstraint28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle2.getText();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        textTitle2.setMargin(rectangleInsets11);
        textTitle2.setURLText("UnitType.ABSOLUTE");
        textTitle2.setID("");
        java.awt.Font font17 = textTitle2.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        java.lang.Object obj15 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textBlockAnchor12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle2.getPadding();
        java.awt.Graphics2D graphics2D17 = null;
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint(0.0d, range35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint36.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint36.toFixedHeight((double) 1.0f);
        try {
            org.jfree.chart.util.Size2D size2D41 = textTitle2.arrange(graphics2D17, rectangleConstraint36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(0);
        java.lang.Object obj3 = null;
        boolean boolean4 = strokeList0.equals(obj3);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setNotify(true);
        java.lang.Object obj5 = legendTitle2.clone();
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle2);
        double double7 = blockContainer0.getWidth();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font9);
        boolean boolean11 = textTitle10.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj15 = textTitle10.draw(graphics2D12, rectangle2D13, (java.lang.Object) borderArrangement14);
        java.awt.Paint paint16 = textTitle10.getBackgroundPaint();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str21 = textBlockAnchor20.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        java.lang.Object obj23 = textTitle10.draw(graphics2D17, rectangle2D18, (java.lang.Object) textBlockAnchor20);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = textTitle10.getPadding();
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray33, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray40);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint(0.0d, range42);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType46 = rectangleConstraint43.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType47 = rectangleConstraint43.getWidthConstraintType();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) lengthConstraintType47);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.block.LengthConstraintType cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextBlockAnchor.CENTER" + "'", str21.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(lengthConstraintType46);
        org.junit.Assert.assertNotNull(lengthConstraintType47);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.String str7 = axisLocation4.toString();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str7.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 1, 100.0f, (float) 15);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        int int9 = categoryPlot0.getDomainAxisCount();
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        double double13 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=128,g=255,b=128]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        legendTitle4.setNotify(true);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle4.getSources();
        legendTitle1.setSources(legendItemSourceArray7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Color color3 = java.awt.Color.yellow;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        categoryAxis1.setCategoryMargin(0.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape8 = numberAxis7.getLeftArrow();
        java.awt.Shape shape9 = numberAxis7.getLeftArrow();
        numberAxis0.setLeftArrow(shape9);
        java.awt.Paint paint11 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape9, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        org.jfree.chart.util.Size2D size2D21 = null;
        try {
            org.jfree.chart.util.Size2D size2D22 = rectangleConstraint18.calculateConstrainedSize(size2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray34);
        legendItem19.setDataset((org.jfree.data.general.Dataset) categoryDataset35);
        boolean boolean37 = itemLabelAnchor0.equals((java.lang.Object) legendItem19);
        int int38 = legendItem19.getSeriesIndex();
        java.lang.String str39 = legendItem19.getURLText();
        boolean boolean40 = legendItem19.isShapeFilled();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextBlockAnchor.CENTER" + "'", str39.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType6 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean7 = categoryAxis5.equals((java.lang.Object) tickType6);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str12 = textAnchor11.toString();
        org.jfree.chart.axis.NumberTick numberTick14 = new org.jfree.chart.axis.NumberTick(tickType6, (double) 3, "", textAnchor10, textAnchor11, (double) (short) 0);
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextAnchor.TOP_CENTER", graphics2D1, (float) 10, (float) 10, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str12.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        numberAxis0.resizeRange((double) (short) 1);
        numberAxis0.setRangeAboutValue((double) '#', (double) 1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        boolean boolean12 = blockContainer11.isEmpty();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        float float14 = jFreeChart13.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart13.getTitle();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNull(textTitle15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.setAxisLineVisible(false);
        java.awt.Shape shape9 = numberAxis0.getDownArrow();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape8 = numberAxis7.getLeftArrow();
        java.awt.Shape shape9 = numberAxis7.getLeftArrow();
        numberAxis0.setLeftArrow(shape9);
        numberAxis0.setAutoRange(true);
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot15.setRangeAxisLocation(axisLocation19, false);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot15.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot23 = categoryPlot15.getParent();
        boolean boolean24 = textLine14.equals((java.lang.Object) categoryPlot15);
        java.awt.Paint paint25 = categoryPlot15.getOutlinePaint();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        boolean boolean3 = projectInfo1.equals((java.lang.Object) blockContainer2);
        boolean boolean4 = blockBorder0.equals((java.lang.Object) projectInfo1);
        java.lang.Object obj5 = null;
        boolean boolean6 = blockBorder0.equals(obj5);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape7, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape7, false, (java.awt.Paint) color11, false, paint13, stroke14, false, shape16, stroke17, paint19);
        boolean boolean21 = numberTickUnit1.equals((java.lang.Object) "TextBlockAnchor.CENTER");
        double double22 = numberTickUnit1.getSize();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str29 = textBlockAnchor28.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition30 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor27, textBlockAnchor28);
        boolean boolean31 = categoryItemEntity24.equals((java.lang.Object) rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "TextBlockAnchor.CENTER" + "'", str29.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setTop((double) 1L);
        double double32 = axisSpace29.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str35 = rectangleInsets34.toString();
        double double36 = rectangleInsets34.getBottom();
        categoryPlot0.setInsets(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str35.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        org.jfree.chart.axis.Axis axis23 = axisChangeEvent22.getAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axis23);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10.0f, shape2, "ChartEntity: tooltip = EXPAND", "ClassContext");
        java.lang.Comparable comparable6 = categoryLabelEntity5.getKey();
        java.lang.Comparable comparable7 = categoryLabelEntity5.getKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10.0f + "'", comparable6.equals(10.0f));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0f + "'", comparable7.equals(10.0f));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = rectangleConstraint18.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = rectangleConstraint18.getWidthConstraintType();
        java.lang.String str23 = lengthConstraintType22.toString();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LengthConstraintType.FIXED" + "'", str23.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis1.setAxisLineStroke(stroke6);
        categoryAxis1.setLabelAngle((double) (-1.0f));
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) categoryLabelPositions1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation7 = axisLocation6.getOpposite();
        categoryPlot3.setRangeAxisLocation(axisLocation7, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation7, plotOrientation10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = categoryLabelPositions1.getLabelPosition(rectangleEdge11);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition13);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(categoryLabelPosition12);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot22, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) flowArrangement30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot22.setRenderer(categoryItemRenderer32, true);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot22);
        float float36 = jFreeChart35.getBackgroundImageAlpha();
        categoryPlot21.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        jFreeChart35.fireChartChanged();
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str43 = textBlockAnchor42.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor41, textBlockAnchor42);
        legendTitle40.setLegendItemGraphicAnchor(rectangleAnchor41);
        java.awt.Color color48 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle40.setItemPaint((java.awt.Paint) color48);
        org.jfree.chart.block.BlockContainer blockContainer50 = legendTitle40.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        boolean boolean53 = rectangleInsets51.equals((java.lang.Object) (-1.0f));
        double double55 = rectangleInsets51.calculateRightInset((double) 3);
        double double56 = rectangleInsets51.getRight();
        legendTitle40.setLegendItemGraphicPadding(rectangleInsets51);
        double double58 = legendTitle40.getContentYOffset();
        jFreeChart35.removeSubtitle((org.jfree.chart.title.Title) legendTitle40);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "TextBlockAnchor.CENTER" + "'", str43.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(blockContainer50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.0d + "'", double55 == 3.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.0d + "'", double56 == 3.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        int int28 = categoryPlot21.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot21.zoomDomainAxes((double) '#', plotRenderingInfo30, point2D31);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.lang.String str2 = projectInfo0.getLicenceName();
//        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
//        java.util.List list4 = textBlock3.getLines();
//        projectInfo0.setContributors(list4);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
//        org.junit.Assert.assertNotNull(list4);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.awt.Paint paint6 = textTitle2.getPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle2.draw(graphics2D7, rectangle2D8);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE1", font11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle12.getTextAlignment();
        textTitle2.setTextAlignment(horizontalAlignment13);
        java.awt.Paint paint15 = textTitle2.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color8 = color7.brighter();
        float[] floatArray9 = null;
        float[] floatArray10 = color7.getRGBColorComponents(floatArray9);
        legendTitle1.setItemPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str14 = textBlockAnchor13.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        float float16 = categoryLabelPosition15.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = categoryLabelPosition15.getCategoryAnchor();
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor17);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.CENTER" + "'", str14.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.95f + "'", float16 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis1.setAxisLineStroke(stroke6);
        java.awt.Font font8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        categoryAxis1.setLabelFont(font8);
        categoryAxis1.setLabelURL("java.awt.Color[r=255,g=0,b=255]");
        categoryAxis1.configure();
        categoryAxis1.setUpperMargin((double) 128);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=128,g=255,b=128]", graphics2D1, (-1.0d), (float) 1L, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset17);
        boolean boolean19 = keyedObjects2D0.equals((java.lang.Object) range18);
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        boolean boolean22 = projectInfo20.equals((java.lang.Object) blockContainer21);
        keyedObjects2D0.setObject((java.lang.Object) boolean22, (java.lang.Comparable) 0.2d, (java.lang.Comparable) "RectangleInsets[t=100.0,l=0.0,b=97.0,r=0.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Object obj0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot1, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot1.setRenderer(categoryItemRenderer11, true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart14.addProgressListener(chartProgressListener16);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo22 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image23 = projectInfo22.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo27 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "TextBlockAnchor.CENTER", "ChartEntity: tooltip = EXPAND", image23, "EXPAND", "Range[0.0,0.0]", "");
        jFreeChart14.setBackgroundImage(image23);
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart14, (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(projectInfo22);
        org.junit.Assert.assertNotNull(image23);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeStickyZero(false);
        java.lang.Object obj30 = numberAxis27.clone();
        numberAxis27.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = numberAxis27.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape35 = numberAxis34.getLeftArrow();
        java.awt.Shape shape36 = numberAxis34.getLeftArrow();
        numberAxis27.setLeftArrow(shape36);
        boolean boolean38 = categoryItemEntity24.equals((java.lang.Object) numberAxis27);
        numberAxis27.setLowerMargin((double) 1L);
        double double41 = numberAxis27.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(markerAxisBand33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0E-8d + "'", double41 == 1.0E-8d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray13);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot0.setDomainAxisLocation(3, axisLocation18, false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
        org.junit.Assert.assertNotNull(categoryAnchor50);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        java.lang.Object obj3 = axisSpace0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        axisSpace4.setTop((double) 1L);
        axisSpace4.setBottom(0.2d);
        axisSpace0.ensureAtLeast(axisSpace4);
        double double10 = axisSpace0.getBottom();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) (-1.0f));
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        java.awt.Font font10 = legendTitle9.getItemFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle9.arrange(graphics2D11);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            numberAxis0.setLabelInsets(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo51, point2D52);
        java.awt.Paint paint54 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        categoryPlot0.setRenderer(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = numberAxis4.getRange();
        java.awt.Shape shape6 = numberAxis4.getDownArrow();
        java.awt.Color color7 = java.awt.Color.GRAY;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "ClassContext", "Range[0.0,0.0]", "ChartEntity: tooltip = null", shape6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setMaximumCategoryLabelLines(128);
        double double7 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.block.BlockContainer blockContainer2 = legendTitle1.getItemContainer();
        java.lang.String str3 = legendTitle1.getID();
        double double4 = legendTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(blockContainer2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4, true);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Image image9 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot0.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape13 = defaultDrawingSupplier12.getNextShape();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray30);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset31);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "TextAnchor.TOP_CENTER", "", categoryDataset31, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str37 = categoryItemEntity36.toString();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryItemEntity36.getDataset();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setAutoRangeStickyZero(false);
        java.lang.Object obj42 = numberAxis39.clone();
        numberAxis39.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = numberAxis39.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape47 = numberAxis46.getLeftArrow();
        java.awt.Shape shape48 = numberAxis46.getLeftArrow();
        numberAxis39.setLeftArrow(shape48);
        boolean boolean50 = categoryItemEntity36.equals((java.lang.Object) numberAxis39);
        numberAxis39.setLowerMargin((double) 1L);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        java.lang.String str54 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 200.0d + "'", number33.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNull(markerAxisBand45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Category Plot" + "'", str54.equals("Category Plot"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        numberAxis0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ChartEntity: tooltip = null", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        float float4 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Paint paint5 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelLines((-6553600));
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis1.getCategoryEnd((int) (short) 100, 0, rectangle2D10, rectangleEdge11);
        float float13 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        float float29 = jFreeChart28.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toFixedHeight((double) (-6553600));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = numberAxis7.getRange();
        java.awt.Shape shape9 = numberAxis7.getDownArrow();
        double double10 = numberAxis7.getLowerBound();
        boolean boolean11 = numberAxis7.isAutoTickUnitSelection();
        org.jfree.data.KeyedObjects2D keyedObjects2D12 = new org.jfree.data.KeyedObjects2D();
        int int13 = keyedObjects2D12.getRowCount();
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray21, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset29);
        boolean boolean31 = keyedObjects2D12.equals((java.lang.Object) range30);
        double double32 = range30.getLength();
        numberAxis7.setRangeWithMargins(range30, true, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint3.toRangeHeight(range30);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 105.0d + "'", double32 == 105.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        double double3 = axisSpace0.getRight();
        axisSpace0.setTop((double) (short) 100);
        double double6 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        double double12 = rectangleInsets10.calculateRightInset((double) '#');
        double double14 = rectangleInsets10.calculateBottomInset(0.0d);
        double double15 = rectangleInsets10.getTop();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str3 = textBlockAnchor2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float5 = categoryLabelPosition4.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition4);
        java.lang.Object obj8 = null;
        boolean boolean9 = categoryLabelPositions7.equals(obj8);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER" + "'", str3.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeStickyZero(false);
        java.lang.Object obj30 = numberAxis27.clone();
        numberAxis27.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = numberAxis27.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape35 = numberAxis34.getLeftArrow();
        java.awt.Shape shape36 = numberAxis34.getLeftArrow();
        numberAxis27.setLeftArrow(shape36);
        boolean boolean38 = categoryItemEntity24.equals((java.lang.Object) numberAxis27);
        numberAxis27.setLowerMargin((double) 1L);
        double double41 = numberAxis27.getLowerBound();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(markerAxisBand33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.removeObject((java.lang.Comparable) "EXPAND", (java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable7 = null;
        keyedObjects2D0.removeObject(comparable7, (java.lang.Comparable) 128);
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range11);
        keyedObjects2D0.setObject((java.lang.Object) range11, (java.lang.Comparable) false, (java.lang.Comparable) 'a');
        int int17 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1);
        keyedObjects2D0.removeObject((java.lang.Comparable) 3, (java.lang.Comparable) 0.0f);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartEntity: tooltip = EXPAND");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setTop((double) 1L);
        double double32 = axisSpace29.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeStickyZero(false);
        java.lang.Object obj41 = numberAxis38.clone();
        numberAxis38.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat44 = null;
        numberAxis38.setNumberFormatOverride(numberFormat44);
        numberAxis38.setInverted(false);
        numberAxis38.setAutoRange(true);
        categoryPlot0.setRangeAxis(53, (org.jfree.chart.axis.ValueAxis) numberAxis38, true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4, true);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        legendTitle10.setNotify(true);
        java.lang.Object obj13 = legendTitle10.clone();
        legendTitle10.setHeight(0.0d);
        legendTitle10.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent18.setType(chartChangeEventType19);
        boolean boolean21 = sortOrder8.equals((java.lang.Object) chartChangeEventType19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str26 = textBlockAnchor25.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25);
        legendTitle23.setLegendItemGraphicAnchor(rectangleAnchor24);
        java.awt.Font font29 = legendTitle23.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        legendTitle23.setItemLabelPadding(rectangleInsets34);
        double double36 = rectangleInsets34.getLeft();
        boolean boolean37 = chartChangeEventType19.equals((java.lang.Object) rectangleInsets34);
        double double39 = rectangleInsets34.calculateLeftInset((double) 1.0f);
        double double41 = rectangleInsets34.calculateLeftInset(4.0d);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextBlockAnchor.CENTER" + "'", str26.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        boolean boolean4 = projectInfo2.equals((java.lang.Object) blockContainer3);
        java.lang.String str5 = projectInfo2.toString();
        projectInfo2.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str9 = projectInfo2.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "MINOR" + "'", str9.equals("MINOR"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        legendTitle11.setNotify(true);
        java.lang.Object obj14 = legendTitle11.clone();
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11);
        legendTitle1.setWrapper(blockContainer9);
        boolean boolean17 = blockContainer9.isEmpty();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType22 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean23 = categoryAxis21.equals((java.lang.Object) tickType22);
        float float24 = categoryAxis21.getTickMarkOutsideLength();
        java.awt.Paint paint25 = categoryAxis21.getLabelPaint();
        int int26 = categoryAxis21.getMaximumCategoryLabelLines();
        try {
            java.lang.Object obj27 = blockContainer9.draw(graphics2D18, rectangle2D19, (java.lang.Object) int26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(tickType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets4);
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        java.awt.Font font7 = legendTitle1.getItemFont();
        java.awt.Color color10 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        boolean boolean12 = color10.equals((java.lang.Object) 10);
        legendTitle1.setItemPaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 0.95f, (double) 100);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number4 = meanAndStandardDeviation2.getMean();
        java.lang.Object obj5 = null;
        boolean boolean6 = meanAndStandardDeviation2.equals(obj5);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.949999988079071d + "'", number4.equals(0.949999988079071d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        boolean boolean13 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType16 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean17 = categoryAxis15.equals((java.lang.Object) tickType16);
        categoryAxis15.clearCategoryLabelToolTips();
        java.awt.Paint paint19 = categoryAxis15.getTickLabelPaint();
        categoryPlot0.setBackgroundPaint(paint19);
        int int21 = categoryPlot0.getDomainAxisCount();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(tickType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        java.awt.Font font31 = labelBlock5.getFont();
        java.lang.String str32 = labelBlock5.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        boolean boolean3 = paintList0.equals((java.lang.Object) legendItemSource1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets4.getLeft();
        double double7 = rectangleInsets4.calculateBottomOutset((double) 0L);
        boolean boolean8 = paintList0.equals((java.lang.Object) double7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        categoryPlot9.setDomainAxisLocation((int) (byte) 1, axisLocation13, true);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot9.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot9.getDomainGridlinePosition();
        boolean boolean19 = paintList0.equals((java.lang.Object) categoryAnchor18);
        java.awt.Paint paint21 = paintList0.getPaint((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = legendTitle1.getSources();
        legendTitle1.setNotify(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(legendItemSourceArray4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean4 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
//        boolean boolean3 = projectInfo1.equals((java.lang.Object) blockContainer2);
//        boolean boolean4 = blockBorder0.equals((java.lang.Object) projectInfo1);
//        java.lang.String str5 = projectInfo1.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "poly" + "'", str5.equals("poly"));
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot22, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) flowArrangement30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot22.setRenderer(categoryItemRenderer32, true);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot22);
        float float36 = jFreeChart35.getBackgroundImageAlpha();
        categoryPlot21.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        java.awt.image.BufferedImage bufferedImage40 = jFreeChart35.createBufferedImage((int) '4', (int) '4');
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNotNull(bufferedImage40);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        java.lang.Object obj13 = categoryPlot2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape18 = numberAxis17.getLeftArrow();
        java.awt.Shape shape19 = numberAxis17.getLeftArrow();
        numberAxis15.setLeftArrow(shape19);
        java.awt.Shape shape21 = numberAxis15.getDownArrow();
        numberAxis15.resizeRange(0.05d);
        categoryPlot2.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis15, true);
        int int26 = categoryPlot2.getRangeAxisCount();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection28 = categoryPlot2.getDomainMarkers(layer27);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        java.lang.Object obj15 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textBlockAnchor12);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        textTitle2.draw(graphics2D16, rectangle2D17);
        textTitle2.setExpandToFitSpace(true);
        textTitle2.setURLText("Category Plot");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setAutoRangeStickyZero(false);
        java.lang.Object obj32 = numberAxis29.clone();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range34 = numberAxis33.getRange();
        java.awt.Shape shape35 = numberAxis33.getDownArrow();
        numberAxis29.setDownArrow(shape35);
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray51);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset52);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset52, false);
        numberAxis29.setRange(range55, true, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29 };
        categoryPlot0.setRangeAxes(valueAxisArray59);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(valueAxisArray59);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str3 = textBlockAnchor2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean6 = rectangleAnchor1.equals((java.lang.Object) color5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str8 = textBlockAnchor7.toString();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle10.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str15 = textBlockAnchor14.toString();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14, textAnchor16, (double) (short) 0, categoryLabelWidthType18, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor7, categoryLabelWidthType18, (float) ' ');
        boolean boolean23 = gradientPaintTransformType0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.CENTER" + "'", str3.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER" + "'", str8.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.CENTER" + "'", str15.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Font font7 = legendTitle1.getItemFont();
        double double8 = legendTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset16, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) 15, range25);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0d + "'", number18.equals(1.0d));
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryLabelPosition3.getCategoryAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition3.getRotationAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER" + "'", str2.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16, (double) 100L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint24.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint25.toFixedHeight((double) (-6553600));
        org.jfree.data.KeyedObjects2D keyedObjects2D28 = new org.jfree.data.KeyedObjects2D();
        int int29 = keyedObjects2D28.getRowCount();
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray37, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        boolean boolean47 = keyedObjects2D28.equals((java.lang.Object) range46);
        double double48 = range46.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint27.toRangeHeight(range46);
        java.lang.Number[] numberArray58 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray65 = new java.lang.Number[][] { numberArray58, numberArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray65);
        org.jfree.data.Range range67 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset66);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = new org.jfree.chart.block.RectangleConstraint(0.0d, range67);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = rectangleConstraint68.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType71 = rectangleConstraint68.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = new org.jfree.chart.block.RectangleConstraint((double) '4', range19, lengthConstraintType20, 1.0d, range46, lengthConstraintType71);
        double double74 = range46.constrain(0.05d);
        org.jfree.data.Range range77 = org.jfree.data.Range.shift(range46, (double) (short) -1, false);
        boolean boolean79 = range77.contains((double) 0.95f);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 105.0d + "'", double48 == 105.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(rectangleConstraint70);
        org.junit.Assert.assertNotNull(lengthConstraintType71);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.05d + "'", double74 == 0.05d);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double10 = categoryAxis1.getCategoryMiddle(0, (-6553600), rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.setAxisLineVisible(false);
        numberAxis0.setFixedAutoRange((double) (-1));
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str15 = rectangleInsets14.toString();
        legendTitle12.setItemLabelPadding(rectangleInsets14);
        numberAxis0.setLabelInsets(rectangleInsets14);
        numberAxis0.setInverted(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str15.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape13 = numberAxis12.getLeftArrow();
        java.awt.Shape shape14 = numberAxis12.getLeftArrow();
        numberAxis10.setLeftArrow(shape14);
        java.awt.Shape shape16 = numberAxis10.getDownArrow();
        org.jfree.data.RangeType rangeType17 = org.jfree.data.RangeType.FULL;
        numberAxis10.setRangeType(rangeType17);
        boolean boolean19 = flowArrangement7.equals((java.lang.Object) numberAxis10);
        double double20 = numberAxis10.getFixedAutoRange();
        boolean boolean21 = numberAxis10.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape10, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape19 = null;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape10, false, (java.awt.Paint) color14, false, paint16, stroke17, false, shape19, stroke20, paint22);
        int int24 = objectList4.indexOf((java.lang.Object) shape10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity25 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity28 = new org.jfree.chart.entity.TickLabelEntity(shape10, "EXPAND", "poly");
        boolean boolean29 = defaultDrawingSupplier0.equals((java.lang.Object) tickLabelEntity28);
        java.lang.Object obj30 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.lang.Object obj8 = null;
        boolean boolean9 = borderArrangement6.equals(obj8);
        borderArrangement6.clear();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot22, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) flowArrangement30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot22.setRenderer(categoryItemRenderer32, true);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot22);
        float float36 = jFreeChart35.getBackgroundImageAlpha();
        categoryPlot21.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        jFreeChart35.fireChartChanged();
        jFreeChart35.setBackgroundImageAlignment(2);
        org.jfree.chart.title.TextTitle textTitle41 = jFreeChart35.getTitle();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNull(textTitle41);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        java.awt.Paint paint29 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        double double3 = axisSpace0.getRight();
        double double4 = axisSpace0.getTop();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        try {
            axisSpace0.ensureAtLeast(axisSpace5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str8 = textBlockAnchor7.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean11 = rectangleAnchor6.equals((java.lang.Object) color10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean13 = rectangleAnchor6.equals((java.lang.Object) textAnchor12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor5, textAnchor12, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getTextAnchor();
        boolean boolean17 = textLine1.equals((java.lang.Object) textAnchor16);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER" + "'", str8.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.title.LegendTitle legendTitle14 = null;
        try {
            jFreeChart13.addLegend(legendTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        float float28 = categoryAxis24.getTickMarkOutsideLength();
        boolean boolean29 = categoryAxis24.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getToolTipText();
        java.awt.Paint paint20 = legendItem18.getFillPaint();
        boolean boolean21 = legendItem18.isShapeFilled();
        java.lang.String str22 = legendItem18.getURLText();
        java.lang.String str23 = legendItem18.getDescription();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextBlockAnchor.CENTER" + "'", str22.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        numberAxis0.setFixedAutoRange(0.2d);
        org.jfree.data.Range range10 = numberAxis0.getRange();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Paint paint7 = null;
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = legendTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) (byte) 100);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment9, 1.0E-8d, (double) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType15 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean16 = categoryAxis14.equals((java.lang.Object) tickType15);
        float float17 = categoryAxis14.getTickMarkOutsideLength();
        java.awt.Paint paint18 = categoryAxis14.getLabelPaint();
        categoryAxis14.setMaximumCategoryLabelLines((-6553600));
        boolean boolean21 = flowArrangement12.equals((java.lang.Object) (-6553600));
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(tickType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Paint paint28 = jFreeChart27.getBackgroundPaint();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot15.setRangeAxisLocation(axisLocation19, false);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot15.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot23 = categoryPlot15.getParent();
        boolean boolean24 = textLine14.equals((java.lang.Object) categoryPlot15);
        float float25 = categoryPlot15.getBackgroundImageAlpha();
        java.awt.Stroke stroke26 = categoryPlot15.getRangeCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke26);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("LengthConstraintType.FIXED");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.block.BlockContainer blockContainer2 = legendTitle1.getItemContainer();
        java.awt.Paint paint3 = legendTitle1.getItemPaint();
        org.junit.Assert.assertNotNull(blockContainer2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { 198.0d, "AxisLocation.TOP_OR_LEFT", false, "LegendItemEntity: seriesKey=null, dataset=null" };
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        boolean boolean26 = numberTickUnit6.equals((java.lang.Object) "TextBlockAnchor.CENTER");
        double double27 = numberTickUnit6.getSize();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f);
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        axisSpace30.ensureAtLeast((-1.0d), rectangleEdge32);
        int int35 = numberTickUnit29.compareTo((java.lang.Object) axisSpace30);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { double27, numberTickUnit29 };
        double[] doubleArray43 = new double[] { 0.2d, 100.0f, 1, (short) 1 };
        double[][] doubleArray44 = new double[][] { doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER_LEFT", "poly", doubleArray44);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray36, doubleArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        boolean boolean3 = blockContainer1.isEmpty();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            blockContainer1.draw(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot7.getRenderer();
        int int16 = categoryPlot7.getDomainAxisCount();
        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
        statisticalBarRenderer0.setSeriesOutlinePaint(0, paint17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        float float14 = jFreeChart13.getBackgroundImageAlpha();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart13.addProgressListener(chartProgressListener15);
        int int17 = jFreeChart13.getSubtitleCount();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        boolean boolean22 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        try {
            org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (java.lang.Comparable) 0.95f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.awt.Paint paint6 = textTitle2.getPaint();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        boolean boolean26 = textTitle2.equals((java.lang.Object) stroke19);
        boolean boolean27 = textTitle2.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("EXPAND", "Range[0.0,0.0]", "poly", "", shape4, (java.awt.Paint) color5);
        java.lang.String str7 = legendItem6.getDescription();
        legendItem6.setSeriesKey((java.lang.Comparable) "-100,100,-100,100,-100,100,100,100,100,100,100,100,100,-100,100,-100,100,-100,-100,-100,-100,-100,-100,-100,-100,-100");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,0.0]" + "'", str7.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator28, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = borderArrangement0.equals((java.lang.Object) booleanList1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle16.setLegendItemGraphicPadding(rectangleInsets19);
        legendTitle14.setPadding(rectangleInsets19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle23.setLegendItemGraphicPadding(rectangleInsets26);
        legendTitle14.setLegendItemGraphicPadding(rectangleInsets26);
        categoryPlot2.setInsets(rectangleInsets26);
        java.awt.Paint paint30 = categoryPlot2.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        boolean boolean35 = categoryPlot2.render(graphics2D31, rectangle2D32, (int) '#', plotRenderingInfo34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot2.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup37 = categoryPlot2.getDatasetGroup();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNull(datasetGroup37);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape25 = numberAxis24.getLeftArrow();
        org.jfree.data.RangeType rangeType26 = numberAxis24.getRangeType();
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setAutoRangeStickyZero(false);
        java.lang.Object obj32 = numberAxis29.clone();
        boolean boolean33 = numberAxis29.getAutoRangeIncludesZero();
        categoryPlot13.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis29, true);
        double double36 = numberAxis29.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.data.general.Dataset dataset20 = legendItemEntity19.getDataset();
        java.lang.String str21 = legendItemEntity19.toString();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(dataset20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str21.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        boolean boolean19 = legendItem18.isLineVisible();
        java.lang.Comparable comparable20 = legendItem18.getSeriesKey();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(comparable20);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.lang.Object obj6 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        labelBlock5.setFont(font31);
        java.lang.String str33 = labelBlock5.getToolTipText();
        double double34 = labelBlock5.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Paint paint10 = legendTitle1.getItemPaint();
        java.lang.Object obj11 = legendTitle1.clone();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle15.setLegendItemGraphicPadding(rectangleInsets18);
        legendTitle13.setPadding(rectangleInsets18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        legendTitle23.setNotify(true);
        java.lang.Object obj26 = legendTitle23.clone();
        blockContainer21.add((org.jfree.chart.block.Block) legendTitle23);
        legendTitle13.setWrapper(blockContainer21);
        legendTitle1.setWrapper(blockContainer21);
        java.util.List list30 = blockContainer21.getBlocks();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 0.95f);
        java.lang.String str3 = numberTickUnit1.valueToString(0.05d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.05" + "'", str3.equals("0.05"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        legendTitle1.setHeight(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle1.getItemLabelPadding();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.resizeRange(0.05d);
        numberAxis0.setRangeAboutValue((double) 10.0f, 1.0E-8d);
        java.text.NumberFormat numberFormat12 = null;
        numberAxis0.setNumberFormatOverride(numberFormat12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        java.lang.Object obj3 = axisSpace0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        axisSpace4.setTop((double) 1L);
        axisSpace4.setBottom(0.2d);
        axisSpace0.ensureAtLeast(axisSpace4);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = axisSpace4.expand(rectangle2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo51, point2D52);
        java.awt.Paint paint54 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.util.SortOrder sortOrder55 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setRangeCrosshairValue(1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(sortOrder55);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 182 + "'", int2 == 182);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot9.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder16);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis20.setCategoryLabelPositions(categoryLabelPositions21);
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        categoryAxis20.addChangeListener(axisChangeListener23);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = categoryAxis20.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis20.getCategoryLabelPositions();
        categoryAxis20.setLabelToolTip("Range[0.0,0.0]");
        categoryPlot0.setDomainAxis(2, categoryAxis20);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray9, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray16);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset17);
        boolean boolean19 = keyedObjects2D0.equals((java.lang.Object) range18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType22 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean23 = categoryAxis21.equals((java.lang.Object) tickType22);
        categoryAxis21.clearCategoryLabelToolTips();
        java.awt.Paint paint25 = categoryAxis21.getTickLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) paint25, (java.lang.Comparable) "HorizontalAlignment.CENTER", (java.lang.Comparable) (short) 1);
        java.lang.Comparable comparable29 = null;
        java.lang.Object obj31 = keyedObjects2D0.getObject(comparable29, (java.lang.Comparable) "PlotOrientation.VERTICAL");
        try {
            java.lang.Comparable comparable33 = keyedObjects2D0.getRowKey((-15423));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(tickType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean2 = keyedObjects0.equals((java.lang.Object) columnArrangement1);
        java.lang.Object obj4 = keyedObjects0.getObject((java.lang.Comparable) "ChartEntity: tooltip = EXPAND");
        java.lang.Comparable comparable6 = keyedObjects0.getKey((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        double double8 = categoryAxis1.getFixedDimension();
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.Object obj10 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape9, false, (java.awt.Paint) color13, false, paint15, stroke16, false, shape18, stroke19, paint21);
        categoryAxis1.setTickMarkStroke(stroke19);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis1.getCategoryEnd((int) (byte) 1, (int) (short) 1, rectangle2D26, rectangleEdge27);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        java.awt.Paint paint30 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setMargin(3.0d, 0.0d, (double) (byte) 1, (double) (-1));
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19, (double) 100L);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray31, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint(0.0d, range40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint41.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = rectangleConstraint41.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint(105.0d, range1, lengthConstraintType2, 0.0d, range22, lengthConstraintType44);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop((double) 1L);
        axisSpace0.setRight((double) 0);
        java.lang.Object obj5 = axisSpace0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace0.add(0.05d, rectangleEdge7);
        axisSpace0.setTop((double) (short) -1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        double double6 = labelBlock5.getContentYOffset();
        java.lang.String str7 = labelBlock5.getToolTipText();
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = labelBlock5.arrange(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape13, false, (java.awt.Paint) color17, false, paint19, stroke20, false, shape22, stroke23, paint25);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        legendItem26.setDataset((org.jfree.data.general.Dataset) categoryDataset42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot0.getRendererForDataset(categoryDataset42);
        try {
            java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset42);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(categoryItemRenderer44);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes((double) 1, (double) (short) -1, plotRenderingInfo14, point2D15);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        boolean boolean7 = textTitle2.equals((java.lang.Object) horizontalAlignment6);
        boolean boolean8 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle2.getPosition();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        double double4 = legendTitle1.getHeight();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str8 = color7.toString();
        int int9 = color7.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font6, (java.awt.Paint) color7);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) labelBlock10);
        double double12 = labelBlock10.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str8.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.lang.String str6 = textTitle2.getText();
        boolean boolean7 = textTitle2.getNotify();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot8, (org.jfree.chart.block.Arrangement) flowArrangement15, (org.jfree.chart.block.Arrangement) flowArrangement16);
        legendTitle17.setHeight((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle17.getItemLabelPadding();
        boolean boolean21 = textTitle2.equals((java.lang.Object) legendTitle17);
        textTitle2.setText("HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.setAxisLineVisible(false);
        numberAxis0.setTickMarkInsideLength((float) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = numberAxis2.getLeftArrow();
        java.awt.Shape shape4 = numberAxis2.getLeftArrow();
        numberAxis0.setLeftArrow(shape4);
        java.awt.Shape shape6 = numberAxis0.getDownArrow();
        numberAxis0.setAxisLineVisible(false);
        double double9 = numberAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setTop((double) 1L);
        double double32 = axisSpace29.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        boolean boolean34 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        axisSpace13.setTop((double) 1L);
        axisSpace13.setRight((double) 0);
        java.lang.Object obj18 = axisSpace13.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace13.add(0.05d, rectangleEdge20);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        org.jfree.data.KeyToGroupMap keyToGroupMap27 = null;
        try {
            org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset26, keyToGroupMap27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ChartEntity: tooltip = null");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        boolean boolean6 = jFreeChartResources0.containsKey("EXPAND");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis1.configure();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str9 = rectangleInsets8.toString();
        legendTitle6.setItemLabelPadding(rectangleInsets8);
        categoryAxis1.setLabelInsets(rectangleInsets8);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str15 = color14.toString();
        int int16 = color14.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font13, (java.awt.Paint) color14);
        categoryAxis1.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        categoryAxis1.removeChangeListener(axisChangeListener19);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str15.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 128 + "'", int16 == 128);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape10, "poly", "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.axis.Axis axis14 = axisLabelEntity13.getAxis();
        java.lang.String str15 = axisLabelEntity13.getShapeCoords();
        java.lang.String str16 = axisLabelEntity13.toString();
        java.lang.String str17 = axisLabelEntity13.getToolTipText();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(axis14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-100,100,-100,100,-100,100,100,100,100,100,100,100,100,-100,100,-100,100,-100,-100,-100,-100,-100,-100,-100,-100,-100" + "'", str15.equals("-100,100,-100,100,-100,100,100,100,100,100,100,100,100,-100,100,-100,100,-100,-100,-100,-100,-100,-100,-100,-100,-100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AxisLabelEntity: label = TextBlockAnchor.CENTER" + "'", str16.equals("AxisLabelEntity: label = TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "poly" + "'", str17.equals("poly"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean9 = rectangleAnchor4.equals((java.lang.Object) color8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean11 = rectangleAnchor4.equals((java.lang.Object) textAnchor10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3, textAnchor10, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition13.getTextAnchor();
        java.lang.Object obj15 = null;
        boolean boolean16 = itemLabelPosition13.equals(obj15);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4, true);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str10 = categoryAnchor9.toString();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str10.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ChartEntity: tooltip = null");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        java.util.Locale locale5 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(locale5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        java.lang.Object obj6 = keyedObjects2D0.getObject((java.lang.Comparable) 1.0f, (java.lang.Comparable) 1L);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) (short) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor9);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str14 = textBlockAnchor13.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean17 = rectangleAnchor12.equals((java.lang.Object) color16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean19 = rectangleAnchor12.equals((java.lang.Object) textAnchor18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor11, textAnchor18, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor22 = itemLabelPosition21.getTextAnchor();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition21, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.CENTER" + "'", str14.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        java.awt.Paint paint3 = statisticalBarRenderer0.lookupSeriesFillPaint((-6553600));
        java.awt.Stroke stroke5 = statisticalBarRenderer0.lookupSeriesOutlineStroke((-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) -1, (int) ' ');
        java.awt.Font font9 = statisticalBarRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers((int) (short) 0);
        java.awt.Stroke stroke14 = categoryPlot11.getDomainGridlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomRangeAxes((double) (short) -1, plotRenderingInfo17, point2D18);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Stroke stroke7 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) '#', (java.lang.Boolean) false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        categoryPlot21.clearRangeMarkers();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape25 = numberAxis24.getLeftArrow();
        org.jfree.data.RangeType rangeType26 = numberAxis24.getRangeType();
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        java.util.List list28 = categoryPlot13.getAnnotations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity24 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "TextAnchor.TOP_CENTER", "", categoryDataset19, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str25 = categoryItemEntity24.toString();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryItemEntity24.getDataset();
        java.lang.Comparable comparable27 = categoryItemEntity24.getColumnKey();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryItemEntity24.getDataset();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 200.0d + "'", number21.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + "ChartEntity: tooltip = null" + "'", comparable27.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextOutlinePaint();
        java.lang.Object obj3 = defaultDrawingSupplier1.clone();
        boolean boolean4 = rectangleInsets0.equals(obj3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        statisticalBarRenderer0.setSeriesOutlineStroke(53, stroke30);
        java.awt.Paint paint32 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.removeObject((java.lang.Comparable) "EXPAND", (java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable7 = null;
        keyedObjects2D0.removeObject(comparable7, (java.lang.Comparable) 128);
        int int11 = keyedObjects2D0.getRowIndex((java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        double double4 = legendTitle1.getHeight();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str8 = color7.toString();
        int int9 = color7.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font6, (java.awt.Paint) color7);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) labelBlock10);
        java.lang.Object obj12 = labelBlock10.clone();
        java.awt.Graphics2D graphics2D13 = null;
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray22, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray29);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset30);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(0.0d, range31);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint32.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType35 = rectangleConstraint32.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint32.toFixedWidth((double) (-1.0f));
        try {
            org.jfree.chart.util.Size2D size2D38 = labelBlock10.arrange(graphics2D13, rectangleConstraint32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str8.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(lengthConstraintType35);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent9.setType(chartChangeEventType10);
        org.jfree.chart.title.Title title12 = titleChangeEvent9.getTitle();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNotNull(title12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        double double8 = categoryAxis1.getFixedDimension();
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) '#');
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        boolean boolean17 = verticalAlignment15.equals((java.lang.Object) categoryLabelPositions16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation22 = axisLocation21.getOpposite();
        categoryPlot18.setRangeAxisLocation(axisLocation22, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation25);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = categoryLabelPositions16.getLabelPosition(rectangleEdge26);
        try {
            double double28 = categoryAxis1.getCategoryStart((int) (short) -1, 0, rectangle2D14, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(categoryLabelPosition27);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle3.draw(graphics2D4, rectangle2D5);
        textTitle3.setExpandToFitSpace(true);
        java.lang.String str9 = textTitle3.getText();
        java.awt.Font font10 = textTitle3.getFont();
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray18, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis35.setTickMarksVisible(false);
        categoryPlot32.setDomainAxis((int) (short) 100, categoryAxis35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot32.getRenderer((int) (short) 0);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("UnitType.ABSOLUTE", font10, (org.jfree.chart.plot.Plot) categoryPlot32, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        java.awt.image.BufferedImage bufferedImage48 = jFreeChart42.createBufferedImage((int) '4', 3, (double) 15, (double) 0.95f, chartRenderingInfo47);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.CENTER" + "'", str9.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNotNull(bufferedImage48);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
        java.awt.Color color9 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        legendTitle1.setItemPaint((java.awt.Paint) color9);
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle1.getItemContainer();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle13.getItemContainer();
        blockContainer11.add((org.jfree.chart.block.Block) legendTitle13);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER" + "'", str4.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(blockContainer14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str9 = chartEntity8.getShapeType();
        java.lang.String str10 = chartEntity8.getURLText();
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) chartEntity8);
        org.jfree.chart.plot.Plot plot12 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "poly" + "'", str9.equals("poly"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        numberAxis0.resizeRange((double) (short) 1);
        boolean boolean8 = numberAxis0.isAutoRange();
        double double9 = numberAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str5 = rectangleInsets4.toString();
        legendTitle2.setItemLabelPadding(rectangleInsets4);
        org.jfree.data.KeyedObject keyedObject7 = new org.jfree.data.KeyedObject((java.lang.Comparable) 105.0d, (java.lang.Object) rectangleInsets4);
        java.lang.Object obj8 = null;
        boolean boolean9 = keyedObject7.equals(obj8);
        java.lang.Comparable comparable10 = keyedObject7.getKey();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot11.setRangeAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation18);
        keyedObject7.setObject((java.lang.Object) rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 105.0d + "'", comparable10.equals(105.0d));
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        java.lang.Object obj15 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textBlockAnchor12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle2.getPadding();
        java.lang.String str17 = rectangleInsets16.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str17.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        categoryPlot21.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        statisticalBarRenderer0.setSeriesOutlineStroke(53, stroke30);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity(shape38, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape47 = null;
        java.awt.Stroke stroke48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint50 = defaultDrawingSupplier49.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape38, false, (java.awt.Paint) color42, false, paint44, stroke45, false, shape47, stroke48, paint50);
        java.lang.String str52 = legendItem51.getToolTipText();
        java.awt.Paint paint53 = legendItem51.getOutlinePaint();
        java.awt.Paint paint54 = legendItem51.getLinePaint();
        statisticalBarRenderer0.setSeriesFillPaint(0, paint54);
        java.awt.Shape shape57 = statisticalBarRenderer0.getSeriesShape((int) '4');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(shape57);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '#', (float) (-1L), (float) 1L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        boolean boolean14 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation15);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("MINOR", "TextBlockAnchor.CENTER", "java.awt.Color[r=255,g=0,b=255]", image4, "ChartEntity: tooltip = EXPAND", "java.awt.Color[r=128,g=255,b=128]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        projectInfo8.setCopyright("HorizontalAlignment.CENTER");
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot12, (org.jfree.chart.block.Arrangement) flowArrangement19, (org.jfree.chart.block.Arrangement) flowArrangement20);
        java.awt.Font font22 = categoryPlot12.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke25 = categoryAxis24.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis24.getCategoryMiddle(10, (int) (short) 10, rectangle2D28, rectangleEdge29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis24.setLabelInsets(rectangleInsets31);
        java.util.List list33 = categoryPlot12.getCategoriesForAxis(categoryAxis24);
        projectInfo8.setContributors(list33);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4, true);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Image image9 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot0.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape13 = defaultDrawingSupplier12.getNextShape();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray30);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset31);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "TextAnchor.TOP_CENTER", "", categoryDataset31, (java.lang.Comparable) 100L, (java.lang.Comparable) "ChartEntity: tooltip = null");
        java.lang.String str37 = categoryItemEntity36.toString();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryItemEntity36.getDataset();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setAutoRangeStickyZero(false);
        java.lang.Object obj42 = numberAxis39.clone();
        numberAxis39.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = numberAxis39.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape47 = numberAxis46.getLeftArrow();
        java.awt.Shape shape48 = numberAxis46.getLeftArrow();
        numberAxis39.setLeftArrow(shape48);
        boolean boolean50 = categoryItemEntity36.equals((java.lang.Object) numberAxis39);
        numberAxis39.setLowerMargin((double) 1L);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double54 = numberAxis39.getLowerBound();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 200.0d + "'", number33.equals(200.0d));
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNull(markerAxisBand45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-1.0d) + "'", double54 == (-1.0d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint9 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot11.setRangeAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation18);
        categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation15, false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot8.getRenderer();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot8.getOrientation();
        categoryPlot0.setOrientation(plotOrientation17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        categoryPlot0.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(plotOrientation17);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            labelBlock5.draw(graphics2D31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo6);
        basicProjectInfo6.setInfo("RectangleInsets[t=100.0,l=0.0,b=97.0,r=0.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj1 = axisSpace0.clone();
        double double2 = axisSpace0.getTop();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = numberAxis4.getRange();
        java.awt.Shape shape6 = numberAxis4.getDownArrow();
        numberAxis0.setDownArrow(shape6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState();
        axisState9.cursorUp(0.0d);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list14 = numberAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        java.lang.Object obj18 = defaultDrawingSupplier16.clone();
        java.awt.Stroke stroke19 = defaultDrawingSupplier16.getNextStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str4 = color3.toString();
        int int5 = color3.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font2, (java.awt.Paint) color3);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getToolTipText();
        java.awt.Paint paint27 = legendItem25.getFillPaint();
        boolean boolean28 = legendItem25.isShapeFilled();
        java.awt.Paint paint29 = legendItem25.getFillPaint();
        java.awt.Paint paint30 = legendItem25.getOutlinePaint();
        labelBlock6.setPaint(paint30);
        java.awt.Font font32 = labelBlock6.getFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis34.setCategoryLabelPositions(categoryLabelPositions35);
        org.jfree.chart.event.AxisChangeListener axisChangeListener37 = null;
        categoryAxis34.addChangeListener(axisChangeListener37);
        categoryAxis34.setCategoryLabelPositionOffset((int) (byte) 10);
        categoryAxis34.setVisible(false);
        java.awt.Color color44 = java.awt.Color.GREEN;
        categoryAxis34.setTickLabelPaint((java.lang.Comparable) 0.949999988079071d, (java.awt.Paint) color44);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer49 = new org.jfree.chart.text.G2TextMeasurer(graphics2D48);
        try {
            org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("rect", font32, (java.awt.Paint) color44, (float) 10, 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str4.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape8 = numberAxis7.getLeftArrow();
        java.awt.Shape shape9 = numberAxis7.getLeftArrow();
        numberAxis0.setLeftArrow(shape9);
        numberAxis0.setAutoRange(true);
        java.awt.Shape shape13 = numberAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot1, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement9);
        java.awt.Paint paint11 = categoryPlot1.getNoDataMessagePaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int14 = color13.getRed();
        org.jfree.data.KeyedObjects2D keyedObjects2D15 = new org.jfree.data.KeyedObjects2D();
        int int16 = keyedObjects2D15.getRowCount();
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray24, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset32);
        boolean boolean34 = keyedObjects2D15.equals((java.lang.Object) range33);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextStroke();
        boolean boolean37 = range33.equals((java.lang.Object) stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color13, stroke36);
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity(shape44, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape53 = null;
        java.awt.Stroke stroke54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint56 = defaultDrawingSupplier55.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape44, false, (java.awt.Paint) color48, false, paint50, stroke51, false, shape53, stroke54, paint56);
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int60 = color59.getRed();
        org.jfree.data.KeyedObjects2D keyedObjects2D61 = new org.jfree.data.KeyedObjects2D();
        int int62 = keyedObjects2D61.getRowCount();
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray77 = new java.lang.Number[][] { numberArray70, numberArray76 };
        org.jfree.data.category.CategoryDataset categoryDataset78 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray77);
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset78);
        boolean boolean80 = keyedObjects2D61.equals((java.lang.Object) range79);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier81 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke82 = defaultDrawingSupplier81.getNextStroke();
        boolean boolean83 = range79.equals((java.lang.Object) stroke82);
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color59, stroke82);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker86 = new org.jfree.chart.plot.ValueMarker(0.0d, paint11, stroke36, (java.awt.Paint) color48, stroke82, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 128 + "'", int60 == 128);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray77);
        org.junit.Assert.assertNotNull(categoryDataset78);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE1", font1);
        textTitle2.setURLText("hi!");
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle2.draw(graphics2D5, rectangle2D6);
        java.lang.String str8 = textTitle2.getURLText();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo14, point2D15);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape22, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape31 = null;
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint34 = defaultDrawingSupplier33.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape22, false, (java.awt.Paint) color26, false, paint28, stroke29, false, shape31, stroke32, paint34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray43, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        legendItem35.setDataset((org.jfree.data.general.Dataset) categoryDataset51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = categoryPlot9.getRendererForDataset(categoryDataset51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot9.getDomainAxisEdge();
        textTitle2.setPosition(rectangleEdge54);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(categoryItemRenderer53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, 1, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape13, false, (java.awt.Paint) color17, false, paint19, stroke20, false, shape22, stroke23, paint25);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        legendItem26.setDataset((org.jfree.data.general.Dataset) categoryDataset42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot0.getRendererForDataset(categoryDataset42);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(0, axisLocation46);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.LegendItemSource legendItemSource50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle(legendItemSource50);
        double double52 = legendTitle51.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle51.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle51.setLegendItemGraphicPadding(rectangleInsets54);
        legendTitle49.setPadding(rectangleInsets54);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        double double59 = legendTitle58.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = legendTitle58.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle58.setLegendItemGraphicPadding(rectangleInsets61);
        legendTitle49.setLegendItemGraphicPadding(rectangleInsets61);
        boolean boolean64 = axisLocation46.equals((java.lang.Object) legendTitle49);
        org.jfree.chart.plot.PlotOrientation plotOrientation65 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation46, plotOrientation65);
        java.lang.String str67 = rectangleEdge66.toString();
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(categoryItemRenderer44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(plotOrientation65);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "RectangleEdge.BOTTOM" + "'", str67.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.lang.String str22 = legendItemEntity21.getURLText();
        java.lang.String str23 = legendItemEntity21.toString();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str23.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        java.lang.Object obj9 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str15 = textBlockAnchor14.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14);
        java.awt.Shape shape20 = textBlock0.calculateBounds(graphics2D10, 0.0f, (float) (byte) 100, textBlockAnchor14, (float) (short) -1, (float) 10L, 4.0d);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = textBlock0.calculateDimensions(graphics2D21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str27 = textBlockAnchor26.toString();
        textBlock0.draw(graphics2D23, (float) 128, (float) (byte) 100, textBlockAnchor26);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.CENTER" + "'", str15.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextBlockAnchor.CENTER" + "'", str27.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ChartEntity: tooltip = null");
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.TickType tickType3 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean4 = legendItemCollection0.equals((java.lang.Object) tickType3);
        int int5 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(tickType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = labelBlock5.getMargin();
        double double8 = rectangleInsets6.calculateRightInset((double) (-1));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(0);
        strokeList0.clear();
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        int int9 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo15, point2D16);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape23, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint35 = defaultDrawingSupplier34.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape23, false, (java.awt.Paint) color27, false, paint29, stroke30, false, shape32, stroke33, paint35);
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray44, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray51);
        legendItem36.setDataset((org.jfree.data.general.Dataset) categoryDataset52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = categoryPlot10.getRendererForDataset(categoryDataset52);
        categoryPlot0.setDataset(categoryDataset52);
        categoryPlot0.clearRangeMarkers();
        java.awt.Paint paint57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setOutlinePaint(paint57);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNull(categoryItemRenderer54);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        double double21 = rectangleConstraint20.getWidth();
        org.jfree.data.Range range22 = rectangleConstraint20.getWidthRange();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(3.0d);
        boolean boolean3 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        java.awt.Stroke stroke21 = categoryPlot13.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot22, (org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.chart.block.Arrangement) flowArrangement30);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle33.getItemLabelPadding();
        categoryPlot22.setInsets(rectangleInsets35);
        categoryPlot22.configureRangeAxes();
        boolean boolean38 = categoryPlot22.isDomainZoomable();
        int int39 = categoryPlot22.getBackgroundImageAlignment();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray48, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray55);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset56);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis65.setTickMarksVisible(false);
        categoryPlot62.setDomainAxis((int) (short) 100, categoryAxis65);
        categoryAxis65.setLabelAngle(4.0d);
        categoryPlot22.setDomainAxis(3, categoryAxis65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        categoryPlot22.zoomDomainAxes((double) 10L, plotRenderingInfo73, point2D74);
        java.awt.Paint paint76 = categoryPlot22.getNoDataMessagePaint();
        org.jfree.chart.util.SortOrder sortOrder77 = categoryPlot22.getRowRenderingOrder();
        categoryPlot13.setRowRenderingOrder(sortOrder77);
        categoryPlot0.setColumnRenderingOrder(sortOrder77);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 1.0d + "'", number58.equals(1.0d));
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(sortOrder77);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
//        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
//        java.lang.String str3 = projectInfo0.toString();
//        projectInfo0.setInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo();
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo6);
//        java.util.List list8 = null;
//        projectInfo0.setContributors(list8);
//        java.lang.String str10 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        categoryAxis1.clearCategoryLabelToolTips();
        float float5 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        boolean boolean13 = categoryAxis5.isTickMarksVisible();
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape24, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape24, false, (java.awt.Paint) color28, false, paint30, stroke31, false, shape33, stroke34, paint36);
        int int38 = objectList18.indexOf((java.lang.Object) shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity39 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape24, "EXPAND", "poly");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke44 = defaultDrawingSupplier43.getNextStroke();
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        double double49 = legendTitle48.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = legendTitle48.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle48.setLegendItemGraphicPadding(rectangleInsets51);
        legendTitle46.setPadding(rectangleInsets51);
        org.jfree.chart.block.BlockContainer blockContainer54 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource55 = null;
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle(legendItemSource55);
        legendTitle56.setNotify(true);
        java.lang.Object obj59 = legendTitle56.clone();
        blockContainer54.add((org.jfree.chart.block.Block) legendTitle56);
        legendTitle46.setWrapper(blockContainer54);
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendTitle46.setItemPaint((java.awt.Paint) color62);
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "PlotOrientation.VERTICAL", "", "poly", shape24, stroke44, (java.awt.Paint) color62);
        categoryAxis5.setTickMarkPaint((java.awt.Paint) color62);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        int int26 = categoryPlot21.getWeight();
        categoryPlot21.setBackgroundImageAlignment((int) (byte) 100);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray35, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset43);
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset43);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        categoryPlot49.setRangeGridlineStroke(stroke52);
        boolean boolean54 = categoryAxis24.hasListener((java.util.EventListener) categoryPlot49);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1.0d + "'", number45.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        java.lang.Object obj13 = categoryPlot2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape18 = numberAxis17.getLeftArrow();
        java.awt.Shape shape19 = numberAxis17.getLeftArrow();
        numberAxis15.setLeftArrow(shape19);
        java.awt.Shape shape21 = numberAxis15.getDownArrow();
        numberAxis15.resizeRange(0.05d);
        categoryPlot2.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis15, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot2.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str34 = textBlockAnchor33.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition35 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor32, textBlockAnchor33);
        legendTitle31.setLegendItemGraphicAnchor(rectangleAnchor32);
        java.awt.Font font37 = legendTitle31.getItemFont();
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("ClassContext", font37);
        statisticalBarRenderer0.setSeriesItemLabelFont(3, font37, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TextBlockAnchor.CENTER" + "'", str34.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        labelBlock5.setURLText("");
        java.lang.Object obj33 = labelBlock5.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = color29.brighter();
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color29, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer((int) (short) 1, categoryItemRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot0.getParent();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot0.notifyListeners(plotChangeEvent17);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        java.lang.String str22 = categoryPlot13.getNoDataMessage();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment26, verticalAlignment27, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot23, (org.jfree.chart.block.Arrangement) flowArrangement30, (org.jfree.chart.block.Arrangement) flowArrangement31);
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getItemLabelPadding();
        categoryPlot23.setInsets(rectangleInsets36);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot23.setDomainGridlinePosition(categoryAnchor38);
        categoryPlot13.setDomainGridlinePosition(categoryAnchor38);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType45 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean46 = categoryAxis44.equals((java.lang.Object) tickType45);
        float float47 = categoryAxis44.getTickMarkOutsideLength();
        java.awt.Paint paint48 = categoryAxis44.getLabelPaint();
        int int49 = categoryAxis44.getMaximumCategoryLabelLines();
        java.awt.Paint paint50 = categoryAxis44.getTickLabelPaint();
        categoryPlot13.setDomainAxis(8, categoryAxis44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(categoryAnchor38);
        org.junit.Assert.assertNotNull(tickType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth(0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8d) + "'", double2 == (-1.8d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition29);
        boolean boolean31 = statisticalBarRenderer0.getIncludeBaseInRange();
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalBarRenderer0.setSeriesOutlinePaint(8, (java.awt.Paint) color35, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Color color3 = java.awt.Color.yellow;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo14, point2D15);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape22, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape31 = null;
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint34 = defaultDrawingSupplier33.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape22, false, (java.awt.Paint) color26, false, paint28, stroke29, false, shape31, stroke32, paint34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray43, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        legendItem35.setDataset((org.jfree.data.general.Dataset) categoryDataset51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = categoryPlot9.getRendererForDataset(categoryDataset51);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot9.setRangeAxisLocation(0, axisLocation55);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        org.jfree.chart.LegendItemSource legendItemSource59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle(legendItemSource59);
        double double61 = legendTitle60.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = legendTitle60.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle60.setLegendItemGraphicPadding(rectangleInsets63);
        legendTitle58.setPadding(rectangleInsets63);
        org.jfree.chart.LegendItemSource legendItemSource66 = null;
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle(legendItemSource66);
        double double68 = legendTitle67.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = legendTitle67.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle67.setLegendItemGraphicPadding(rectangleInsets70);
        legendTitle58.setLegendItemGraphicPadding(rectangleInsets70);
        boolean boolean73 = axisLocation55.equals((java.lang.Object) legendTitle58);
        org.jfree.chart.plot.PlotOrientation plotOrientation74 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation55, plotOrientation74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        try {
            org.jfree.chart.axis.AxisState axisState77 = categoryAxis1.draw(graphics2D5, (-1.8d), rectangle2D7, rectangle2D8, rectangleEdge75, plotRenderingInfo76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(categoryItemRenderer53);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(plotOrientation74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape25 = numberAxis24.getLeftArrow();
        org.jfree.data.RangeType rangeType26 = numberAxis24.getRangeType();
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setAutoRangeStickyZero(false);
        java.lang.Object obj32 = numberAxis29.clone();
        boolean boolean33 = numberAxis29.getAutoRangeIncludesZero();
        categoryPlot13.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis29, true);
        java.lang.Object obj36 = numberAxis29.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation41 = axisLocation40.getOpposite();
        categoryPlot37.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot37.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot45.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot45.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo50, point2D51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = categoryPlot45.getRenderer();
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = categoryPlot45.getOrientation();
        categoryPlot37.setOrientation(plotOrientation54);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        categoryPlot37.drawBackgroundImage(graphics2D56, rectangle2D57);
        org.jfree.chart.util.SortOrder sortOrder59 = categoryPlot37.getRowRenderingOrder();
        boolean boolean60 = numberAxis29.hasListener((java.util.EventListener) categoryPlot37);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNull(categoryItemRenderer53);
        org.junit.Assert.assertNotNull(plotOrientation54);
        org.junit.Assert.assertNotNull(sortOrder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str3 = rectangleAnchor2.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str5 = textBlockAnchor4.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str8 = textBlockAnchor7.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean11 = rectangleAnchor6.equals((java.lang.Object) color10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle15.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str20 = textBlockAnchor19.toString();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType23 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor18, textBlockAnchor19, textAnchor21, (double) (short) 0, categoryLabelWidthType23, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor12, categoryLabelWidthType23, (float) ' ');
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor4, categoryLabelWidthType23, (float) (short) 0);
        boolean boolean30 = gradientPaintTransformType1.equals((java.lang.Object) rectangleAnchor2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str3.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER" + "'", str5.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER" + "'", str8.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextBlockAnchor.CENTER" + "'", str20.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        java.lang.String str3 = numberTickUnit1.valueToString(10.0d);
        java.lang.String str5 = numberTickUnit1.valueToString((double) 100L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.lang.String str11 = horizontalAlignment10.toString();
        org.jfree.chart.util.BooleanList booleanList12 = new org.jfree.chart.util.BooleanList();
        boolean boolean13 = horizontalAlignment10.equals((java.lang.Object) booleanList12);
        textBlock0.setLineAlignment(horizontalAlignment10);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "HorizontalAlignment.CENTER" + "'", str11.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Font font30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        textTitle31.draw(graphics2D32, rectangle2D33);
        textTitle31.setExpandToFitSpace(true);
        java.lang.String str37 = textTitle31.getText();
        java.awt.Font font38 = textTitle31.getFont();
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("", font38);
        statisticalBarRenderer0.setBaseItemLabelFont(font38, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator43 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator43);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextOutlinePaint();
        java.lang.Object obj48 = defaultDrawingSupplier46.clone();
        java.awt.Stroke stroke49 = defaultDrawingSupplier46.getNextStroke();
        statisticalBarRenderer0.setSeriesStroke(0, stroke49);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextBlockAnchor.CENTER" + "'", str37.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!");
        textLine11.addFragment(textFragment13);
        textBlock0.addLine(textLine11);
        org.jfree.chart.text.TextFragment textFragment16 = textLine11.getFirstTextFragment();
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textFragment16.calculateDimensions(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textFragment16);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 0.95f);
        int int2 = numberTickUnit1.getMinorTickCount();
        java.lang.String str3 = numberTickUnit1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[size=0.95]" + "'", str3.equals("[size=0.95]"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo51, point2D52);
        categoryPlot0.clearRangeMarkers(1);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        boolean boolean3 = projectInfo1.equals((java.lang.Object) blockContainer2);
        boolean boolean4 = blockBorder0.equals((java.lang.Object) projectInfo1);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape10, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape19 = null;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape10, false, (java.awt.Paint) color14, false, paint16, stroke17, false, shape19, stroke20, paint22);
        java.lang.String str24 = legendItem23.getDescription();
        java.awt.Stroke stroke25 = legendItem23.getOutlineStroke();
        boolean boolean26 = blockBorder0.equals((java.lang.Object) legendItem23);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint13 = statisticalBarRenderer12.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        statisticalBarRenderer12.setSeriesToolTipGenerator(10, categoryToolTipGenerator15);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setAutoRangeStickyZero(false);
        java.lang.Object obj20 = numberAxis17.clone();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range22 = numberAxis21.getRange();
        java.awt.Shape shape23 = numberAxis21.getDownArrow();
        numberAxis17.setDownArrow(shape23);
        statisticalBarRenderer12.setBaseShape(shape23, true);
        numberAxis1.setRightArrow(shape23);
        numberAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        boolean boolean4 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setTickMarkOutsideLength((float) '#');
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        java.lang.Object obj15 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textBlockAnchor12);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        textTitle2.draw(graphics2D16, rectangle2D17);
        textTitle2.setExpandToFitSpace(true);
        textTitle2.setText("0.05");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        legendTitle11.setNotify(true);
        java.lang.Object obj14 = legendTitle11.clone();
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11);
        legendTitle1.setWrapper(blockContainer9);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendTitle1.setItemPaint((java.awt.Paint) color17);
        org.jfree.data.RangeType rangeType19 = org.jfree.data.RangeType.FULL;
        boolean boolean20 = color17.equals((java.lang.Object) rangeType19);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rangeType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getFillPaint();
        boolean boolean27 = legendItem24.isShapeFilled();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        java.awt.Paint paint29 = legendItem24.getOutlinePaint();
        labelBlock5.setPaint(paint29);
        java.awt.Font font31 = labelBlock5.getFont();
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font33);
        boolean boolean35 = textTitle34.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement38 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj39 = textTitle34.draw(graphics2D36, rectangle2D37, (java.lang.Object) borderArrangement38);
        java.awt.Paint paint40 = textTitle34.getBackgroundPaint();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str45 = textBlockAnchor44.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition46 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor43, textBlockAnchor44);
        java.lang.Object obj47 = textTitle34.draw(graphics2D41, rectangle2D42, (java.lang.Object) textBlockAnchor44);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        textTitle34.draw(graphics2D48, rectangle2D49);
        java.awt.Font font51 = textTitle34.getFont();
        labelBlock5.setFont(font51);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "TextBlockAnchor.CENTER" + "'", str45.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Color color3 = java.awt.Color.yellow;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot0.getRenderer(0);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
        org.junit.Assert.assertNull(categoryItemRenderer51);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        org.jfree.chart.axis.TickType tickType11 = numberTick10.getTickType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextOutlinePaint();
        boolean boolean14 = numberTick10.equals((java.lang.Object) defaultDrawingSupplier12);
        org.jfree.chart.text.TextAnchor textAnchor15 = numberTick10.getRotationAnchor();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint6 = statisticalBarRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double2 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        java.awt.Stroke stroke13 = categoryPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryPlot2.setDomainGridlinePaint(paint14);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray30);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis34, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment41, verticalAlignment42, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement46 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot38, (org.jfree.chart.block.Arrangement) flowArrangement45, (org.jfree.chart.block.Arrangement) flowArrangement46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        categoryPlot38.setRenderer(categoryItemRenderer48, true);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot38);
        float float52 = jFreeChart51.getBackgroundImageAlpha();
        categoryPlot37.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart51);
        jFreeChart51.fireChartChanged();
        java.awt.Color color55 = java.awt.Color.blue;
        jFreeChart51.setBackgroundPaint((java.awt.Paint) color55);
        categoryPlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart51);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.0d + "'", number33.equals(1.0d));
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.5f + "'", float52 == 0.5f);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23);
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray36, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset44);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint(0.0d, range45);
        org.jfree.data.Range range49 = org.jfree.data.Range.shift(range45, 0.0d, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(range27, range49);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        float float12 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle16.setLegendItemGraphicPadding(rectangleInsets19);
        legendTitle14.setPadding(rectangleInsets19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle23.setLegendItemGraphicPadding(rectangleInsets26);
        legendTitle14.setLegendItemGraphicPadding(rectangleInsets26);
        categoryPlot2.setInsets(rectangleInsets26);
        java.awt.Paint paint30 = categoryPlot2.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        boolean boolean35 = categoryPlot2.render(graphics2D31, rectangle2D32, (int) '#', plotRenderingInfo34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot2.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint17 = statisticalBarRenderer16.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        statisticalBarRenderer16.setSeriesToolTipGenerator(10, categoryToolTipGenerator19);
        java.awt.Paint paint21 = statisticalBarRenderer16.getBaseOutlinePaint();
        java.awt.Stroke stroke23 = statisticalBarRenderer16.lookupSeriesOutlineStroke((int) (byte) 1);
        categoryPlot0.setRangeCrosshairStroke(stroke23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        plot25.removeChangeListener(plotChangeListener26);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(plot25);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis1.setAxisLineStroke(stroke6);
        java.awt.Font font8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        categoryAxis1.setLabelFont(font8);
        categoryAxis1.setLabelURL("java.awt.Color[r=255,g=0,b=255]");
        categoryAxis1.setLabelToolTip("ChartEntity: tooltip = null");
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        java.lang.Object obj2 = null;
        boolean boolean3 = legendItemEntity1.equals(obj2);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer1.getArrangement();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(arrangement3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.setAnchorValue((-5.95d));
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxisForDataset((int) (byte) -1);
        boolean boolean13 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        numberAxis0.setInverted(false);
        numberAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 10, (float) (byte) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("rect");
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        java.lang.Object obj3 = textTitle2.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis5.getCategoryMiddle(10, (int) (short) 10, rectangle2D9, rectangleEdge10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis5.setLabelInsets(rectangleInsets12);
        textTitle2.setMargin(rectangleInsets12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setTextAlignment(horizontalAlignment15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, textAnchor7, (double) (short) 0, categoryLabelWidthType9, 0.0f);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape13 = defaultDrawingSupplier12.getNextShape();
        java.awt.Paint paint14 = defaultDrawingSupplier12.getNextPaint();
        boolean boolean15 = categoryLabelWidthType9.equals((java.lang.Object) defaultDrawingSupplier12);
        java.lang.String str16 = categoryLabelWidthType9.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str16.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        statisticalBarRenderer0.setSeriesOutlineStroke(53, stroke30);
        boolean boolean32 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        statisticalBarRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true, true);
        boolean boolean39 = statisticalBarRenderer0.getItemCreateEntity(53, (int) (byte) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator41);
        boolean boolean43 = statisticalBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setTop((double) 1L);
        double double32 = axisSpace29.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis35.setTickMarksVisible(false);
        java.awt.Paint paint39 = categoryAxis35.getTickLabelPaint((java.lang.Comparable) '4');
        double double40 = categoryAxis35.getCategoryMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment44, verticalAlignment45, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot41, (org.jfree.chart.block.Arrangement) flowArrangement48, (org.jfree.chart.block.Arrangement) flowArrangement49);
        java.awt.Font font51 = categoryPlot41.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke54 = categoryAxis53.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = categoryAxis53.getCategoryMiddle(10, (int) (short) 10, rectangle2D57, rectangleEdge58);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis53.setLabelInsets(rectangleInsets60);
        java.util.List list62 = categoryPlot41.getCategoriesForAxis(categoryAxis53);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType65 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean66 = categoryAxis64.equals((java.lang.Object) tickType65);
        double double67 = categoryAxis64.getUpperMargin();
        categoryAxis64.setMaximumCategoryLabelLines((-6553600));
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray70 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis35, categoryAxis53, categoryAxis64 };
        categoryPlot0.setDomainAxes(categoryAxisArray70);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(tickType65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.05d + "'", double67 == 0.05d);
        org.junit.Assert.assertNotNull(categoryAxisArray70);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer11 = legendTitle9.getItemContainer();
        java.awt.Color color12 = java.awt.Color.black;
        legendTitle9.setItemPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockContainer11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str5 = rectangleInsets4.toString();
        legendTitle2.setItemLabelPadding(rectangleInsets4);
        org.jfree.data.KeyedObject keyedObject7 = new org.jfree.data.KeyedObject((java.lang.Comparable) 105.0d, (java.lang.Object) rectangleInsets4);
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.trimWidth((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 94.0d + "'", double10 == 94.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot21.getRenderer((int) (short) 0);
        java.util.List list30 = categoryPlot21.getAnnotations();
        java.util.List list31 = categoryPlot21.getAnnotations();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = null;
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator15);
        boolean boolean17 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        categoryAxis1.setLabelInsets(rectangleInsets8);
        categoryAxis1.setVisible(false);
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 1, (float) (-16777216));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        java.awt.Image image22 = null;
        categoryPlot13.setBackgroundImage(image22);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        try {
            categoryPlot13.addDomainMarker(categoryMarker24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str29 = color28.toString();
        int int30 = color28.getBlue();
        java.awt.Color color31 = java.awt.Color.DARK_GRAY;
        float[] floatArray36 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray37 = color31.getRGBComponents(floatArray36);
        float[] floatArray38 = color28.getRGBColorComponents(floatArray37);
        jFreeChart27.setBorderPaint((java.awt.Paint) color28);
        boolean boolean40 = jFreeChart27.isNotify();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str29.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 128 + "'", int30 == 128);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.removeObject((java.lang.Comparable) "EXPAND", (java.lang.Comparable) 1.0f);
        java.lang.Object obj7 = keyedObjects2D0.clone();
        int int8 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean9 = rectangleAnchor4.equals((java.lang.Object) color8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean11 = rectangleAnchor4.equals((java.lang.Object) textAnchor10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3, textAnchor10, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean15 = itemLabelPosition13.equals((java.lang.Object) rectangleInsets14);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextPaint();
        boolean boolean4 = textAnchor0.equals((java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) '#', categoryURLGenerator2, false);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getOutlinePaint();
        statisticalBarRenderer0.setSeriesOutlinePaint(128, paint26);
        java.awt.Paint paint29 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (short) -1);
        java.awt.Stroke stroke32 = statisticalBarRenderer0.getItemOutlineStroke(0, (int) (short) 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]");
        java.awt.Paint paint2 = textFragment1.getPaint();
        float float3 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo6, point2D7);
        java.awt.Stroke stroke9 = categoryPlot1.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot1);
        int int11 = jFreeChart10.getSubtitleCount();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int2 = color1.getRed();
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        int int4 = keyedObjects2D3.getRowCount();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray12, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset20);
        boolean boolean22 = keyedObjects2D3.equals((java.lang.Object) range21);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextStroke();
        boolean boolean25 = range21.equals((java.lang.Object) stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color1, stroke24);
        java.awt.Stroke stroke27 = valueMarker26.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape7, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape7, false, (java.awt.Paint) color11, false, paint13, stroke14, false, shape16, stroke17, paint19);
        statisticalBarRenderer0.setSeriesOutlineStroke(53, stroke17, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = statisticalBarRenderer0.getURLGenerator((int) (byte) 100, 10);
        java.awt.Paint paint28 = statisticalBarRenderer0.getItemPaint(0, (int) (byte) 100);
        java.awt.Paint paint29 = statisticalBarRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.05d, shape2, "LegendItemEntity: seriesKey=null, dataset=null", "PlotOrientation.VERTICAL");
        java.lang.Comparable comparable6 = categoryLabelEntity5.getKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.05d + "'", comparable6.equals(0.05d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.getColor("Range[100.0,300.0]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        numberAxis0.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        numberAxis0.configure();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(15);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setAutoRangeStickyZero(false);
        java.lang.Object obj6 = numberAxis3.clone();
        numberAxis3.setLowerMargin((double) (byte) 1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis3.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        java.awt.Shape shape12 = numberAxis10.getLeftArrow();
        numberAxis3.setLeftArrow(shape12);
        objectList1.set((int) '4', (java.lang.Object) shape12);
        java.lang.Object obj15 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getToolTipText();
        java.awt.Paint paint20 = legendItem18.getFillPaint();
        java.awt.Stroke stroke21 = legendItem18.getLineStroke();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (short) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        int int20 = objectList0.indexOf((java.lang.Object) shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.lang.String str22 = legendItemEntity21.getURLText();
        java.lang.String str23 = legendItemEntity21.toString();
        java.lang.Object obj24 = legendItemEntity21.clone();
        java.lang.Object obj25 = null;
        boolean boolean26 = legendItemEntity21.equals(obj25);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str23.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.block.BlockContainer blockContainer2 = legendTitle1.getItemContainer();
        java.lang.String str3 = legendTitle1.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getPadding();
        org.junit.Assert.assertNotNull(blockContainer2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str5 = rectangleInsets4.toString();
        legendTitle2.setItemLabelPadding(rectangleInsets4);
        org.jfree.data.KeyedObject keyedObject7 = new org.jfree.data.KeyedObject((java.lang.Comparable) 105.0d, (java.lang.Object) rectangleInsets4);
        java.lang.Object obj8 = null;
        boolean boolean9 = keyedObject7.equals(obj8);
        java.lang.Comparable comparable10 = keyedObject7.getKey();
        java.lang.Comparable comparable11 = keyedObject7.getKey();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 105.0d + "'", comparable10.equals(105.0d));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 105.0d + "'", comparable11.equals(105.0d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(0);
        boolean boolean17 = statisticalBarRenderer0.getBaseCreateEntities();
        java.awt.Paint paint19 = null;
        statisticalBarRenderer0.setSeriesItemLabelPaint((int) '4', paint19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot21.getDomainAxisForDataset((-15423));
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int30 = color29.getRed();
        org.jfree.data.KeyedObjects2D keyedObjects2D31 = new org.jfree.data.KeyedObjects2D();
        int int32 = keyedObjects2D31.getRowCount();
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray40, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray47);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset48);
        boolean boolean50 = keyedObjects2D31.equals((java.lang.Object) range49);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke52 = defaultDrawingSupplier51.getNextStroke();
        boolean boolean53 = range49.equals((java.lang.Object) stroke52);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color29, stroke52);
        categoryPlot21.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker54);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 128 + "'", int30 == 128);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape11, false, (java.awt.Paint) color15, false, paint17, stroke18, false, shape20, stroke21, paint23);
        java.lang.String str25 = legendItem24.getToolTipText();
        java.awt.Paint paint26 = legendItem24.getOutlinePaint();
        statisticalBarRenderer0.setSeriesOutlinePaint(128, paint26);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        statisticalBarRenderer0.setSeriesStroke(15, stroke29);
        statisticalBarRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        categoryAxis24.removeCategoryLabelToolTip((java.lang.Comparable) "RectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis24.setTickMarksVisible(false);
        categoryPlot21.setDomainAxis((int) (short) 100, categoryAxis24);
        float float28 = categoryAxis24.getTickMarkOutsideLength();
        java.awt.Paint paint29 = categoryAxis24.getAxisLinePaint();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        boolean boolean6 = rectangleInsets3.equals((java.lang.Object) defaultDrawingSupplier4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis8.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        categoryAxis8.addChangeListener(axisChangeListener11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        axisState14.cursorRight(1.0E-8d);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        legendTitle18.setNotify(true);
        java.lang.Object obj21 = legendTitle18.clone();
        legendTitle18.setHeight(0.0d);
        legendTitle18.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent26 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        java.lang.Object obj27 = null;
        boolean boolean28 = legendTitle18.equals(obj27);
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.util.List list31 = categoryAxis8.refreshTicks(graphics2D13, axisState14, rectangle2D29, rectangleEdge30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets3.createOutsetRectangle(rectangle2D29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.text.TextBlock textBlock17 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeStickyZero(false);
        java.lang.Object obj21 = numberAxis18.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range23 = numberAxis22.getRange();
        java.awt.Shape shape24 = numberAxis22.getDownArrow();
        numberAxis18.setDownArrow(shape24);
        boolean boolean26 = textBlock17.equals((java.lang.Object) numberAxis18);
        numberAxis18.setAxisLineVisible(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint30 = statisticalBarRenderer29.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = null;
        statisticalBarRenderer29.setSeriesToolTipGenerator(10, categoryToolTipGenerator32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setAutoRangeStickyZero(false);
        java.lang.Object obj37 = numberAxis34.clone();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range39 = numberAxis38.getRange();
        java.awt.Shape shape40 = numberAxis38.getDownArrow();
        numberAxis34.setDownArrow(shape40);
        statisticalBarRenderer29.setBaseShape(shape40, true);
        numberAxis18.setRightArrow(shape40);
        boolean boolean45 = numberAxis18.isVisible();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot1.setRangeAxisLocation(axisLocation5, false);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot1.getRowRenderingOrder();
        java.awt.Paint paint9 = categoryPlot1.getRangeCrosshairPaint();
        java.lang.String str10 = categoryPlot1.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets6);
        legendTitle1.setPadding(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets6.createOutsetRectangle(rectangle2D9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(10.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str3 = verticalAlignment2.toString();
        boolean boolean4 = valueMarker1.equals((java.lang.Object) verticalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setNotify(true);
        java.lang.Object obj5 = legendTitle2.clone();
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle2);
        double double7 = blockContainer0.getWidth();
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean9 = blockContainer0.equals((java.lang.Object) paint8);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo6, point2D7);
        java.awt.Stroke stroke9 = categoryPlot1.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart10.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape5, false, (java.awt.Paint) color9, false, paint11, stroke12, false, shape14, stroke15, paint17);
        java.lang.String str19 = legendItem18.getDescription();
        java.awt.Stroke stroke20 = legendItem18.getOutlineStroke();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem18.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer21);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge();
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge27);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        boolean boolean4 = statisticalBarRenderer0.getItemCreateEntity((-15423), (int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint6 = statisticalBarRenderer5.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        statisticalBarRenderer5.setSeriesToolTipGenerator(10, categoryToolTipGenerator8);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape16, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape25 = null;
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape16, false, (java.awt.Paint) color20, false, paint22, stroke23, false, shape25, stroke26, paint28);
        java.lang.String str30 = legendItem29.getToolTipText();
        java.awt.Paint paint31 = legendItem29.getOutlinePaint();
        statisticalBarRenderer5.setSeriesOutlinePaint(128, paint31);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        statisticalBarRenderer5.setSeriesStroke(15, stroke34);
        statisticalBarRenderer0.setBaseStroke(stroke34);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str7 = textAnchor6.toString();
        try {
            java.awt.Shape shape8 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("VerticalAlignment.CENTER", graphics2D1, (float) 0, (float) 1, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str7.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("-100,100,-100,100,-100,100,100,100,100,100,100,100,100,-100,100,-100,100,-100,-100,-100,-100,-100,-100,-100,-100,-100", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset15, false);
        double double19 = range18.getUpperBound();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator17, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray34);
        legendItem19.setDataset((org.jfree.data.general.Dataset) categoryDataset35);
        boolean boolean37 = itemLabelAnchor0.equals((java.lang.Object) legendItem19);
        boolean boolean38 = legendItem19.isLineVisible();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = projectInfo0.equals((java.lang.Object) blockContainer1);
        java.lang.String str3 = projectInfo0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "TextBlockAnchor.CENTER", "ChartEntity: tooltip = EXPAND", image8, "EXPAND", "Range[0.0,0.0]", "");
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) projectInfo0, (java.lang.Object) "EXPAND");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape12, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape12, false, (java.awt.Paint) color16, false, paint18, stroke19, false, shape21, stroke22, paint24);
        java.lang.String str26 = legendItem25.getDescription();
        java.awt.Stroke stroke27 = legendItem25.getOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setTop((double) 1L);
        double double32 = axisSpace29.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace29);
        categoryPlot0.clearDomainMarkers((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot0.getRowRenderingOrder();
        float float37 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        java.awt.Shape shape2 = numberAxis0.getDownArrow();
        double double3 = numberAxis0.getLowerBound();
        boolean boolean4 = numberAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis6.setCategoryLabelPositions(categoryLabelPositions7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape15, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape15, false, (java.awt.Paint) color19, false, paint21, stroke22, false, shape24, stroke25, paint27);
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray43 = new java.lang.Number[][] { numberArray36, numberArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray43);
        legendItem28.setDataset((org.jfree.data.general.Dataset) categoryDataset44);
        java.awt.Paint paint46 = legendItem28.getLinePaint();
        categoryAxis6.setTickLabelPaint(paint46);
        numberAxis0.setAxisLinePaint(paint46);
        numberAxis0.setTickMarkInsideLength((float) 3);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = numberAxis0.getStandardTickUnits();
        java.lang.String str52 = numberAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis1.setAxisLineStroke(stroke6);
        java.awt.Font font8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        categoryAxis1.setLabelFont(font8);
        categoryAxis1.setLabelURL("java.awt.Color[r=255,g=0,b=255]");
        categoryAxis1.configure();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.05d, shape15, "LegendItemEntity: seriesKey=null, dataset=null", "PlotOrientation.VERTICAL");
        boolean boolean19 = categoryAxis1.equals((java.lang.Object) "LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        java.awt.Font font4 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        boolean boolean14 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle6.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str11 = textBlockAnchor10.toString();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType14 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, textAnchor12, (double) (short) 0, categoryLabelWidthType14, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor4, categoryLabelWidthType14, (float) (-6553600));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment21, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment21, 0.0d, (double) (byte) 100);
        boolean boolean28 = textBlockAnchor4.equals((java.lang.Object) horizontalAlignment19);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER" + "'", str2.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextBlockAnchor.CENTER" + "'", str11.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelWidthType14);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("EXPAND", "Range[0.0,0.0]", "poly", "", shape4, (java.awt.Paint) color5);
        java.lang.String str7 = legendItem6.getDescription();
        boolean boolean8 = legendItem6.isLineVisible();
        java.lang.Comparable comparable9 = legendItem6.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,0.0]" + "'", str7.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(comparable9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toFixedHeight((double) (-6553600));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint3.toFixedHeight((double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint3.toFixedHeight(4.0d);
        double double10 = rectangleConstraint3.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int2 = color1.getRed();
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        int int4 = keyedObjects2D3.getRowCount();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray12, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset20);
        boolean boolean22 = keyedObjects2D3.equals((java.lang.Object) range21);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextStroke();
        boolean boolean25 = range21.equals((java.lang.Object) stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color1, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = null;
        try {
            valueMarker26.setLabelOffset(rectangleInsets27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = categoryAxis1.equals((java.lang.Object) tickType2);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType2, (double) 3, "", textAnchor6, textAnchor7, (double) (short) 0);
        org.jfree.chart.axis.TickType tickType11 = numberTick10.getTickType();
        java.lang.Number number12 = numberTick10.getNumber();
        double double13 = numberTick10.getValue();
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str8.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 3.0d + "'", number12.equals(3.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement36 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment32, verticalAlignment33, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot29, (org.jfree.chart.block.Arrangement) flowArrangement36, (org.jfree.chart.block.Arrangement) flowArrangement37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        categoryPlot29.setRenderer(categoryItemRenderer39, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Paint paint44 = categoryAxis43.getLabelPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions48 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis47.setCategoryLabelPositions(categoryLabelPositions48);
        org.jfree.chart.event.AxisChangeListener axisChangeListener50 = null;
        categoryAxis47.addChangeListener(axisChangeListener50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = new org.jfree.chart.axis.AxisState();
        axisState53.cursorRight(1.0E-8d);
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        legendTitle57.setNotify(true);
        java.lang.Object obj60 = legendTitle57.clone();
        legendTitle57.setHeight(0.0d);
        legendTitle57.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent65 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle57);
        java.lang.Object obj66 = null;
        boolean boolean67 = legendTitle57.equals(obj66);
        java.awt.geom.Rectangle2D rectangle2D68 = legendTitle57.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.util.List list70 = categoryAxis47.refreshTicks(graphics2D52, axisState53, rectangle2D68, rectangleEdge69);
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D28, categoryPlot29, categoryAxis43, categoryMarker45, rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(categoryLabelPositions48);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertNotNull(list70);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 1, axisLocation4, true);
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        legendTitle10.setNotify(true);
        java.lang.Object obj13 = legendTitle10.clone();
        legendTitle10.setHeight(0.0d);
        legendTitle10.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent18.setType(chartChangeEventType19);
        boolean boolean21 = sortOrder8.equals((java.lang.Object) chartChangeEventType19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str26 = textBlockAnchor25.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25);
        legendTitle23.setLegendItemGraphicAnchor(rectangleAnchor24);
        java.awt.Font font29 = legendTitle23.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.0d, (double) 'a', 0.0d);
        legendTitle23.setItemLabelPadding(rectangleInsets34);
        double double36 = rectangleInsets34.getLeft();
        boolean boolean37 = chartChangeEventType19.equals((java.lang.Object) rectangleInsets34);
        double double38 = rectangleInsets34.getBottom();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TextBlockAnchor.CENTER" + "'", str26.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 97.0d + "'", double38 == 97.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryMiddle(10, (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape10, "poly", "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.axis.Axis axis14 = axisLabelEntity13.getAxis();
        java.lang.String str15 = axisLabelEntity13.getToolTipText();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(axis14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font1 = barRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot8.getRenderer();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot8.getOrientation();
        categoryPlot0.setOrientation(plotOrientation17);
        java.awt.Paint paint19 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo51, point2D52);
        double double54 = categoryPlot0.getRangeCrosshairValue();
        float float55 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 1.0f + "'", float55 == 1.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape6, false, (java.awt.Paint) color10, false, paint12, stroke13, false, shape15, stroke16, paint18);
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray34);
        legendItem19.setDataset((org.jfree.data.general.Dataset) categoryDataset35);
        boolean boolean37 = itemLabelAnchor0.equals((java.lang.Object) legendItem19);
        int int38 = legendItem19.getSeriesIndex();
        java.awt.Stroke stroke39 = legendItem19.getLineStroke();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        double double7 = legendTitle1.getContentYOffset();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, (double) ' ');
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint5 = statisticalBarRenderer4.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer4.setSeriesToolTipGenerator(10, categoryToolTipGenerator7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeStickyZero(false);
        java.lang.Object obj12 = numberAxis9.clone();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range14 = numberAxis13.getRange();
        java.awt.Shape shape15 = numberAxis13.getDownArrow();
        numberAxis9.setDownArrow(shape15);
        statisticalBarRenderer4.setBaseShape(shape15, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType21 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean22 = categoryAxis20.equals((java.lang.Object) tickType21);
        categoryAxis20.clearCategoryLabelToolTips();
        java.awt.Paint paint24 = categoryAxis20.getTickLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "ChartEntity: tooltip = EXPAND", "Category Plot", "VerticalAlignment.CENTER", shape15, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(tickType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str15 = textBlockAnchor14.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14);
        java.awt.Shape shape20 = textBlock0.calculateBounds(graphics2D10, 0.0f, (float) (byte) 100, textBlockAnchor14, (float) (short) -1, (float) 10L, 4.0d);
        java.util.List list21 = textBlock0.getLines();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.CENTER" + "'", str15.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str6 = textBlockAnchor5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, textAnchor7, (double) (short) 0, categoryLabelWidthType9, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis14.getCategoryMiddle(10, (int) (short) 10, rectangle2D18, rectangleEdge19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, 100.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis14, shape23, "poly", "DatasetRenderingOrder.FORWARD");
        boolean boolean27 = textAnchor12.equals((java.lang.Object) "poly");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.CENTER" + "'", str6.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray8, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) (short) 10);
        double double21 = rectangleConstraint20.getHeight();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets13);
        categoryPlot0.configureRangeAxes();
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        int int17 = categoryPlot0.getBackgroundImageAlignment();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray26, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        categoryAxis43.setTickMarksVisible(false);
        categoryPlot40.setDomainAxis((int) (short) 100, categoryAxis43);
        categoryAxis43.setLabelAngle(4.0d);
        categoryPlot0.setDomainAxis(3, categoryAxis43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo51, point2D52);
        java.awt.Paint paint54 = categoryPlot0.getNoDataMessagePaint();
        java.awt.Color color57 = java.awt.Color.getColor("TextBlockAnchor.CENTER", (int) (short) 0);
        boolean boolean59 = color57.equals((java.lang.Object) 10);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color57);
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor64 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str65 = textBlockAnchor64.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition66 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor63, textBlockAnchor64);
        legendTitle62.setLegendItemGraphicAnchor(rectangleAnchor63);
        java.awt.Font font68 = legendTitle62.getItemFont();
        categoryPlot0.setNoDataMessageFont(font68);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.0d + "'", number36.equals(1.0d));
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(textBlockAnchor64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "TextBlockAnchor.CENTER" + "'", str65.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(font68);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedHeight((double) (-6553600));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint11.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D15 = legendTitle1.arrange(graphics2D7, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition29);
        boolean boolean31 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setFixedDimension(100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        java.lang.String str9 = numberTickUnit7.valueToString(10.0d);
        double double10 = numberTickUnit7.getSize();
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) numberTickUnit7, font11);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str15 = textBlockAnchor14.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14);
        java.awt.Shape shape20 = textBlock0.calculateBounds(graphics2D10, 0.0f, (float) (byte) 100, textBlockAnchor14, (float) (short) -1, (float) 10L, 4.0d);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = textBlock0.calculateDimensions(graphics2D21);
        java.lang.String str23 = size2D22.toString();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextBlockAnchor.CENTER" + "'", str15.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str23.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray11, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "ClassContext", numberArray18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "Category Plot", numberArray18);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis19.setCategoryLabelPositions(categoryLabelPositions20);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape36 = null;
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape27, false, (java.awt.Paint) color31, false, paint33, stroke34, false, shape36, stroke37, paint39);
        categoryAxis19.setTickMarkStroke(stroke37);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis19.getCategoryEnd((int) (byte) 1, (int) (short) 1, rectangle2D44, rectangleEdge45);
        boolean boolean47 = standardCategorySeriesLabelGenerator17.equals((java.lang.Object) rectangle2D44);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot0.getDomainAxisForDataset((-16777216));
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range6 = numberAxis5.getRange();
        java.awt.Shape shape7 = numberAxis5.getDownArrow();
        numberAxis1.setDownArrow(shape7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) numberAxis1);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("CategoryAnchor.END");
        textBlock0.addLine(textLine11);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(true);
        java.lang.Object obj4 = legendTitle1.clone();
        legendTitle1.setHeight(0.0d);
        legendTitle1.setWidth((double) (-1.0f));
        org.jfree.chart.block.BlockFrame blockFrame9 = null;
        try {
            legendTitle1.setFrame(blockFrame9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE1", font1, (java.awt.Paint) color2);
        java.lang.Object obj6 = labelBlock5.clone();
        java.awt.Paint paint7 = labelBlock5.getPaint();
        java.lang.String str8 = labelBlock5.getURLText();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis11.setCategoryLabelPositions(categoryLabelPositions12);
        org.jfree.chart.event.AxisChangeListener axisChangeListener14 = null;
        categoryAxis11.addChangeListener(axisChangeListener14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        axisState17.cursorRight(1.0E-8d);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        legendTitle21.setNotify(true);
        java.lang.Object obj24 = legendTitle21.clone();
        legendTitle21.setHeight(0.0d);
        legendTitle21.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent29 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle21);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendTitle21.equals(obj30);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle21.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.util.List list34 = categoryAxis11.refreshTicks(graphics2D16, axisState17, rectangle2D32, rectangleEdge33);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint40 = defaultDrawingSupplier39.getNextOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 1, (double) (short) 100, (double) 10, paint40);
        try {
            java.lang.Object obj42 = labelBlock5.draw(graphics2D9, rectangle2D32, (java.lang.Object) blockBorder41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str3.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE1", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font3, (java.awt.Paint) color5, (float) 10);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape13, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextOutlinePaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER", "", "", "TextBlockAnchor.CENTER", false, shape13, false, (java.awt.Paint) color17, false, paint19, stroke20, false, shape22, stroke23, paint25);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray41);
        legendItem26.setDataset((org.jfree.data.general.Dataset) categoryDataset42);
        java.awt.Paint paint44 = legendItem26.getLinePaint();
        org.jfree.chart.text.TextLine textLine45 = new org.jfree.chart.text.TextLine("RectangleEdge.BOTTOM", font3, paint44);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.Object obj1 = null;
        boolean boolean2 = chartChangeEventType0.equals(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.removeObject((java.lang.Comparable) "EXPAND", (java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable7 = null;
        keyedObjects2D0.removeObject(comparable7, (java.lang.Comparable) 128);
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range11);
        keyedObjects2D0.setObject((java.lang.Object) range11, (java.lang.Comparable) false, (java.lang.Comparable) 'a');
        try {
            java.lang.Comparable comparable17 = keyedObjects2D0.getColumnKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle3.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str8 = textBlockAnchor7.toString();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7, textAnchor9, (double) (short) 0, categoryLabelWidthType11, 0.0f);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor17);
        java.lang.Class<?> wildcardClass19 = textAnchor17.getClass();
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.NumberTick numberTick22 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-6553600), "", textAnchor17, textAnchor20, (double) (-1));
        org.jfree.chart.axis.CategoryTick categoryTick24 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "10", textBlock1, textBlockAnchor7, textAnchor17, 97.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER" + "'", str8.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.chart.block.Arrangement) flowArrangement8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart13.getPadding();
        double double15 = rectangleInsets14.getRight();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(10, categoryToolTipGenerator3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(false);
        java.lang.Object obj8 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range10 = numberAxis9.getRange();
        java.awt.Shape shape11 = numberAxis9.getDownArrow();
        numberAxis5.setDownArrow(shape11);
        statisticalBarRenderer0.setBaseShape(shape11, true);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot17.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot17.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        boolean boolean26 = textLine16.equals((java.lang.Object) categoryPlot17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        java.awt.Shape shape28 = statisticalBarRenderer0.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition29);
        boolean boolean31 = statisticalBarRenderer0.getIncludeBaseInRange();
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        legendTitle36.setNotify(true);
        java.lang.Object obj39 = legendTitle36.clone();
        legendTitle36.setHeight(0.0d);
        legendTitle36.setHeight((double) (-15423));
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent44 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle36);
        java.lang.Object obj45 = null;
        boolean boolean46 = legendTitle36.equals(obj45);
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle36.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot48.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation52 = axisLocation51.getOpposite();
        categoryPlot48.setRangeAxisLocation(axisLocation52, false);
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray63, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray70);
        org.jfree.data.Range range72 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset71);
        java.lang.Number number73 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset71);
        categoryPlot48.setDataset(0, categoryDataset71);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = categoryPlot48.getRenderer();
        boolean boolean76 = categoryPlot48.isOutlineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState79 = statisticalBarRenderer0.initialise(graphics2D34, rectangle2D47, categoryPlot48, 100, plotRenderingInfo78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 200.0d + "'", number73.equals(200.0d));
        org.junit.Assert.assertNull(categoryItemRenderer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation6 = axisLocation5.getOpposite();
        categoryPlot2.setRangeAxisLocation(axisLocation6, false);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot10 = categoryPlot2.getParent();
        boolean boolean11 = textLine1.equals((java.lang.Object) categoryPlot2);
        java.awt.Paint paint12 = categoryPlot2.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets4);
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D8 = legendTitle1.getBounds();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray15, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset23);
        categoryPlot0.setDataset(0, categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.lang.String str29 = color28.toString();
        int int30 = color28.getBlue();
        java.awt.Color color31 = java.awt.Color.DARK_GRAY;
        float[] floatArray36 = new float[] { 1L, 10, 100.0f, 0L };
        float[] floatArray37 = color31.getRGBComponents(floatArray36);
        float[] floatArray38 = color28.getRGBColorComponents(floatArray37);
        jFreeChart27.setBorderPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart27.getCategoryPlot();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 200.0d + "'", number25.equals(200.0d));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=128,g=255,b=128]" + "'", str29.equals("java.awt.Color[r=128,g=255,b=128]"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 128 + "'", int30 == 128);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(categoryPlot40);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.lang.Object obj3 = numberAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = numberAxis4.getRange();
        java.awt.Shape shape6 = numberAxis4.getDownArrow();
        numberAxis0.setDownArrow(shape6);
        numberAxis0.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis5.setAxisLineStroke(stroke10);
        boolean boolean12 = rectangleAnchor3.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryAxis5.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape25 = numberAxis24.getLeftArrow();
        org.jfree.data.RangeType rangeType26 = numberAxis24.getRangeType();
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot13.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertNotNull(valueAxis28);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d, (byte) 1, 100.0f, 3, 100L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray7, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent26);
        categoryPlot21.setRangeCrosshairValue((double) 10, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = new org.jfree.chart.LegendItemCollection();
        boolean boolean35 = legendItemCollection33.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.TickType tickType36 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean37 = legendItemCollection33.equals((java.lang.Object) tickType36);
        categoryPlot21.setFixedLegendItems(legendItemCollection33);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(tickType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation4, false);
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot0.getDrawingSupplier();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        boolean boolean13 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER");
        org.jfree.chart.axis.TickType tickType16 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean17 = categoryAxis15.equals((java.lang.Object) tickType16);
        categoryAxis15.clearCategoryLabelToolTips();
        java.awt.Paint paint19 = categoryAxis15.getTickLabelPaint();
        categoryPlot0.setBackgroundPaint(paint19);
        int int21 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        java.lang.Object obj24 = defaultDrawingSupplier22.clone();
        java.awt.Stroke stroke25 = defaultDrawingSupplier22.getNextStroke();
        categoryPlot0.setDomainGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(tickType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement6 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj7 = textTitle2.draw(graphics2D4, rectangle2D5, (java.lang.Object) borderArrangement6);
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str13 = textBlockAnchor12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        java.lang.Object obj15 = textTitle2.draw(graphics2D9, rectangle2D10, (java.lang.Object) textBlockAnchor12);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        textTitle2.draw(graphics2D16, rectangle2D17);
        java.awt.Font font19 = textTitle2.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint21 = statisticalBarRenderer20.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        statisticalBarRenderer20.setSeriesToolTipGenerator(10, categoryToolTipGenerator23);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(false);
        java.lang.Object obj28 = numberAxis25.clone();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range30 = numberAxis29.getRange();
        java.awt.Shape shape31 = numberAxis29.getDownArrow();
        numberAxis25.setDownArrow(shape31);
        statisticalBarRenderer20.setBaseShape(shape31, true);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("Range[0.0,0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation41 = axisLocation40.getOpposite();
        categoryPlot37.setRangeAxisLocation(axisLocation41, false);
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot37.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot45 = categoryPlot37.getParent();
        boolean boolean46 = textLine36.equals((java.lang.Object) categoryPlot37);
        statisticalBarRenderer20.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot37);
        java.awt.Shape shape48 = statisticalBarRenderer20.getBaseShape();
        java.awt.Stroke stroke50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        statisticalBarRenderer20.setSeriesOutlineStroke(53, stroke50);
        java.awt.Font font52 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        statisticalBarRenderer20.setBaseItemLabelFont(font52);
        textTitle2.setFont(font52);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextBlockAnchor.CENTER" + "'", str13.equals("TextBlockAnchor.CENTER"));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(font52);
    }
}

