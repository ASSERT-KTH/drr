import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            boolean boolean8 = categoryPlot4.removeRangeMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        try {
            int int15 = categoryPlot4.getRangeAxisIndex(valueAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray4 = new float[] { (-1L), 100.0f, 100.0f };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        try {
            categoryPlot4.setDomainGridlineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke2 = null;
        java.awt.Paint paint3 = null;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100L, (java.awt.Paint) color1, stroke2, paint3, stroke4, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        try {
            int int10 = categoryPlot4.getRangeAxisIndex(valueAxis9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer();
        java.awt.Stroke stroke9 = null;
        try {
            categoryPlot4.setDomainGridlineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            categoryPlot4.drawBackground(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = null;
        try {
            dateAxis1.setRightArrow(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.clearDomainMarkers(0);
        java.awt.Stroke stroke11 = null;
        try {
            categoryPlot4.setRangeGridlineStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            categoryPlot4.setInsets(rectangleInsets9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Shape shape3 = null;
        try {
            dateAxis1.setUpArrow(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        org.jfree.data.Range range5 = null;
        try {
            dateAxis1.setRangeWithMargins(range5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Shape shape11 = null;
        try {
            dateAxis1.setDownArrow(shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        java.awt.Paint paint15 = null;
        try {
            valueMarker12.setLabelPaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        categoryPlot39.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis34.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        dateAxis34.setLowerMargin((double) (short) 10);
        try {
            categoryPlot4.setRangeAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) dateAxis34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        try {
            dateAxis1.setAutoRangeMinimumSize((double) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12, false, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
        try {
            dateAxis1.zoomRange((double) (byte) 1, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit16);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.CENTER]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            org.jfree.chart.axis.AxisState axisState19 = dateAxis1.draw(graphics2D13, (double) 100L, rectangle2D15, rectangle2D16, rectangleEdge17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        boolean boolean4 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        try {
            int int12 = categoryPlot4.getDomainAxisIndex(categoryAxis11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        try {
            dateAxis1.zoomRange((double) '4', (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = new float[] { (short) -1, 1.0f, 10 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        dateAxis11.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke23 = dateAxis11.getAxisLineStroke();
        valueMarker9.setStroke(stroke23);
        dateAxis1.setAxisLineStroke(stroke23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot32.getDomainAxisEdge((int) (short) 0);
        try {
            double double35 = dateAxis1.java2DToValue(0.0d, rectangle2D27, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        dateAxis1.setInverted(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker14.setPaint((java.awt.Paint) color16);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        boolean boolean19 = dateAxis1.isInverted();
        org.jfree.data.Range range20 = null;
        try {
            dateAxis1.setRange(range20, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        boolean boolean11 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = null;
        try {
            categoryPlot4.setDomainAxes(categoryAxisArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        java.text.DateFormat dateFormat5 = null;
        dateAxis1.setDateFormatOverride(dateFormat5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis(1, categoryAxis15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getDomainAxisEdge();
        try {
            double double18 = dateAxis1.java2DToValue((double) (short) 0, rectangle2D8, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot17.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot17.zoomDomainAxes(0.05d, plotRenderingInfo24, point2D25);
        java.lang.Object obj27 = null;
        boolean boolean28 = categoryPlot17.equals(obj27);
        boolean boolean29 = categoryPlot4.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            categoryPlot17.handleClick((int) 'a', 0, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        dateAxis11.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke23 = dateAxis11.getAxisLineStroke();
        valueMarker9.setStroke(stroke23);
        dateAxis1.setAxisLineStroke(stroke23);
        try {
            dateAxis1.setRange((double) '4', (double) (-12566273));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot4.setRenderer((int) ' ', categoryItemRenderer16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot23.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot23.getRangeMarkers(layer26);
        org.jfree.chart.plot.Plot plot28 = categoryPlot23.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot23.setRangeAxisLocation((int) '#', axisLocation30);
        categoryPlot4.setRangeAxisLocation(500, axisLocation30, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot4.setDomainAxis(categoryAxis34);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.removeChangeListener(plotChangeListener8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot4.setDataset((int) (short) 10, categoryDataset11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 1, (float) (byte) 10, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            categoryPlot4.draw(graphics2D10, rectangle2D11, point2D12, plotState13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        java.lang.Class class15 = null;
        try {
            java.util.EventListener[] eventListenerArray16 = valueMarker11.getListeners(class15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke12 = categoryPlot4.getRangeCrosshairStroke();
        try {
            categoryPlot4.zoom((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0L, (float) 0, (float) 9);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 10.0f);
        double double4 = rectangleInsets0.calculateRightInset((double) ' ');
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        valueMarker7.setStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str26 = lengthAdjustmentType25.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType23, lengthAdjustmentType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "EXPAND" + "'", str26.equals("EXPAND"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.zoomRange((double) 0, 0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.GRAY;
        java.awt.Color color3 = java.awt.Color.orange;
        float[] floatArray7 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        float[] floatArray9 = color2.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray10 = color0.getComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        java.util.TimeZone timeZone5 = null;
        try {
            dateAxis1.setTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot7.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        categoryPlot7.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot7.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot21.getRangeMarkers(layer24);
        boolean boolean26 = categoryPlot21.isDomainZoomable();
        categoryPlot21.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot21.getDomainAxisLocation((-1));
        categoryPlot7.setDomainAxisLocation(axisLocation30, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot39.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot39.getRangeMarkers(layer42);
        org.jfree.chart.plot.Plot plot44 = categoryPlot39.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = categoryPlot39.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker47, layer48);
        org.jfree.chart.text.TextAnchor textAnchor50 = valueMarker47.getLabelTextAnchor();
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47);
        objectList1.set(500, (java.lang.Object) categoryPlot7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent53 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent53);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(textAnchor50);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot36.getRangeMarkers(layer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot36.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot36.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker44.getLabelTextAnchor();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        categoryPlot4.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape19 = dateAxis18.getLeftArrow();
        dateAxis1.setRightArrow(shape19);
        java.awt.Paint paint21 = null;
        try {
            dateAxis1.setTickMarkPaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        dateAxis3.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint17 = valueMarker16.getPaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker16.setPaint((java.awt.Paint) color18);
        dateAxis3.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot26.getRangeMarkers(layer29);
        boolean boolean31 = categoryPlot26.isDomainZoomable();
        categoryPlot26.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot26.getDomainAxisLocation((-1));
        java.awt.Stroke stroke36 = categoryPlot26.getRangeGridlineStroke();
        boolean boolean37 = plotOrientation21.equals((java.lang.Object) stroke36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        int int39 = color38.getRGB();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getFixedDimension();
        boolean boolean44 = dateAxis41.isHiddenValue((-1L));
        dateAxis41.setAutoTickUnitSelection(true, true);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot52.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer55 = null;
        java.util.Collection collection56 = categoryPlot52.getRangeMarkers(layer55);
        boolean boolean57 = categoryPlot52.isDomainZoomable();
        categoryPlot52.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke60 = categoryPlot52.getRangeCrosshairStroke();
        boolean boolean61 = dateAxis41.equals((java.lang.Object) stroke60);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker63 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 128, (java.awt.Paint) color18, stroke36, (java.awt.Paint) color38, stroke60, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-12566273) + "'", int39 == (-12566273));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) (byte) -1, (double) 2, 2.0d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets5.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        dateAxis1.setPositiveArrowVisible(true);
        try {
            dateAxis1.setRange((double) (byte) 100, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) 1, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot12.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot12.setRangeAxisLocation((int) '#', axisLocation19);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str22 = plotOrientation21.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation21);
        try {
            double double24 = categoryAxis0.getCategoryEnd((int) (byte) 0, (int) (byte) 100, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str22.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean15 = categoryPlot5.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker12, layer13, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker12.getLabelOffset();
        double double17 = rectangleInsets16.getRight();
        double double18 = rectangleInsets16.getRight();
        boolean boolean19 = sortOrder0.equals((java.lang.Object) double18);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12, false, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
        java.util.TimeZone timeZone17 = null;
        try {
            dateAxis1.setTimeZone(timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit16);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        dateAxis3.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke15 = dateAxis3.getAxisLineStroke();
        valueMarker1.setStroke(stroke15);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType17);
        java.awt.Paint paint19 = null;
        try {
            valueMarker1.setLabelPaint(paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke13 = dateAxis1.getAxisLineStroke();
        dateAxis1.setAutoRange(false);
        java.awt.Shape shape16 = dateAxis1.getUpArrow();
        dateAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        dateAxis11.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke23 = dateAxis11.getAxisLineStroke();
        valueMarker9.setStroke(stroke23);
        dateAxis1.setAxisLineStroke(stroke23);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        double double30 = dateAxis29.getFixedDimension();
        boolean boolean31 = dateAxis29.isAxisLineVisible();
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRangeWithMargins(range32);
        dateAxis1.setRangeWithMargins(range32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset((double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        java.text.DateFormat dateFormat5 = null;
        dateAxis1.setDateFormatOverride(dateFormat5);
        try {
            dateAxis1.zoomRange((double) ' ', (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (7.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot16.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation25);
        categoryPlot4.setBackgroundAlpha((float) (short) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = null;
        try {
            categoryPlot4.setOrientation(plotOrientation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-65281) + "'", int1 == (-65281));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560538799999L + "'", long4 == 1560538799999L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setAutoTickUnitSelection(true, true);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setLabelFont(font16);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getDomainAxisEdge((int) (short) 0);
        categoryPlot24.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot24.getRangeAxisEdge((int) (byte) -1);
        try {
            double double31 = dateAxis1.lengthToJava2D((double) (-16777216), rectangle2D19, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot4.getRangeAxis();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 10.0f);
        double double4 = rectangleInsets0.extendHeight((double) 1560452399999L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.560452400007E12d + "'", double4 == 1.560452400007E12d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        valueMarker1.setValue((double) 0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot8.getRangeMarkers(layer11);
        categoryPlot8.setOutlineVisible(false);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        try {
            valueMarker1.setAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.orange;
        float[] floatArray7 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace2, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12, false, true);
        java.awt.Shape shape16 = null;
        try {
            dateAxis1.setUpArrow(shape16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabel("");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color1 = java.awt.Color.getColor("UnitType.RELATIVE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getFixedDimension();
        dateAxis1.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets6.extendHeight((double) 10.0f);
        double double10 = rectangleInsets6.calculateRightInset((double) ' ');
        double double11 = rectangleInsets6.getTop();
        dateAxis1.setLabelInsets(rectangleInsets6);
        dateAxis1.setLowerMargin(4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 18.0d + "'", double8 == 18.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis1.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        dateAxis6.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke18 = dateAxis6.getAxisLineStroke();
        dateAxis6.setAutoRange(false);
        boolean boolean21 = dateAxis1.equals((java.lang.Object) dateAxis6);
        dateAxis1.configure();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot29.getRangeMarkers(layer32);
        org.jfree.chart.plot.Plot plot34 = categoryPlot29.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot29.setRangeAxisLocation((int) '#', axisLocation36);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str39 = plotOrientation38.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation36, plotOrientation38);
        try {
            double double41 = dateAxis1.java2DToValue((double) 10L, rectangle2D24, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(plot34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str39.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(1, categoryAxis7);
        boolean boolean9 = color0.equals((java.lang.Object) categoryAxis7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            categoryPlot4.drawBackground(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getBlue();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor2, jFreeChart3);
        boolean boolean5 = color0.equals((java.lang.Object) textAnchor2);
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray8 = new float[] { (byte) 1 };
        try {
            float[] floatArray9 = color0.getComponents(colorSpace6, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis0.getLabelInsets();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker11.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets15.createInsetRectangle(rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin(8.0d);
        categoryPlot4.setDomainAxis(categoryAxis9);
        categoryAxis9.setCategoryMargin(100.0d);
        java.lang.String str16 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot7.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        categoryPlot7.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot7.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot21.getRangeMarkers(layer24);
        boolean boolean26 = categoryPlot21.isDomainZoomable();
        categoryPlot21.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot21.getDomainAxisLocation((-1));
        categoryPlot7.setDomainAxisLocation(axisLocation30, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot39.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot39.getRangeMarkers(layer42);
        org.jfree.chart.plot.Plot plot44 = categoryPlot39.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = categoryPlot39.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker47, layer48);
        org.jfree.chart.text.TextAnchor textAnchor50 = valueMarker47.getLabelTextAnchor();
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47);
        objectList1.set(500, (java.lang.Object) categoryPlot7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent53 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation54 = null;
        try {
            categoryPlot7.addAnnotation(categoryAnnotation54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(textAnchor50);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = dateAxis1.getTickMarkPosition();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot17.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray23 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot17.setDomainAxes(categoryAxisArray23);
        int int25 = categoryPlot17.getDatasetCount();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace35 = dateAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot17, rectangle2D26, rectangleEdge33, axisSpace34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str1.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier16);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        int int11 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets12.calculateLeftInset((double) (short) 100);
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets12.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertNotNull(unitType15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot17.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot17.zoomDomainAxes(0.05d, plotRenderingInfo24, point2D25);
        java.lang.Object obj27 = null;
        boolean boolean28 = categoryPlot17.equals(obj27);
        boolean boolean29 = categoryPlot4.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            boolean boolean32 = categoryPlot4.removeAnnotation(categoryAnnotation30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        int int11 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray12);
        categoryPlot4.setForegroundAlpha((float) 0);
        java.lang.String str16 = categoryPlot4.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        categoryPlot23.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        double double28 = dateAxis18.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis18.setTickUnit(dateTickUnit29, false, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis18.getTickUnit();
        org.jfree.chart.plot.Plot plot34 = null;
        dateAxis18.setPlot(plot34);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation37 = null;
        try {
            boolean boolean38 = categoryPlot4.removeAnnotation(categoryAnnotation37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit33);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getFixedDimension();
        dateAxis1.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets6.extendHeight((double) 10.0f);
        double double10 = rectangleInsets6.calculateRightInset((double) ' ');
        double double11 = rectangleInsets6.getTop();
        dateAxis1.setLabelInsets(rectangleInsets6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis1.setTickUnit(dateTickUnit13);
        dateAxis1.setLowerBound((double) 10.0f);
        try {
            dateAxis1.setRangeAboutValue((double) 0L, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.5) <= upper (-0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 18.0d + "'", double8 == 18.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color1 = java.awt.Color.getColor("Category Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "UnitType.RELATIVE", "TextAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.resizeRange((double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot4.setRenderer((int) ' ', categoryItemRenderer16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot23.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot23.getRangeMarkers(layer26);
        org.jfree.chart.plot.Plot plot28 = categoryPlot23.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot23.setRangeAxisLocation((int) '#', axisLocation30);
        categoryPlot4.setRangeAxisLocation(500, axisLocation30, true);
        categoryPlot4.mapDatasetToDomainAxis((int) (short) 10, (int) (byte) -1);
        java.awt.Paint paint37 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot4.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke12 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        float float14 = categoryPlot4.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot4.getDataset(0);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNull(categoryDataset10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        int int23 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint24 = categoryPlot4.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("SortOrder.ASCENDING");
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.data.Range range12 = dateAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        java.lang.Object obj15 = null;
        boolean boolean16 = categoryPlot4.equals(obj15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot4.getRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            boolean boolean20 = categoryPlot4.removeAnnotation(categoryAnnotation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryItemRenderer17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.darker();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.orange;
        float[] floatArray7 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace2, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot4.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.data.Range range12 = dateAxis1.getDefaultAutoRange();
        java.util.Date date13 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        double double16 = dateAxis15.getFixedDimension();
        boolean boolean18 = dateAxis15.isHiddenValue((-1L));
        double double19 = dateAxis15.getLowerBound();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis15.setMinimumDate(date20);
        java.util.Date date22 = null;
        try {
            dateAxis1.setRange(date20, date22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot36.getRangeMarkers(layer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot36.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot36.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker44.getLabelTextAnchor();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        categoryPlot4.clearDomainMarkers();
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        categoryPlot4.drawBackgroundImage(graphics2D50, rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        java.lang.Class<?> wildcardClass16 = categoryPlot4.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        double double20 = dateAxis19.getFixedDimension();
        boolean boolean22 = dateAxis19.isHiddenValue((-1L));
        dateAxis19.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        categoryPlot34.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        dateAxis29.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke41 = dateAxis29.getAxisLineStroke();
        valueMarker27.setStroke(stroke41);
        dateAxis19.setAxisLineStroke(stroke41);
        categoryAxis17.setAxisLineStroke(stroke41);
        categoryPlot4.setRangeCrosshairStroke(stroke41);
        categoryPlot4.setForegroundAlpha((float) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke41);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.awt.Color color4 = java.awt.Color.magenta;
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
//        categoryPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
//        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
//        dateAxis6.setLowerMargin((double) (short) 10);
//        dateAxis6.setAutoTickUnitSelection(true, true);
//        dateAxis6.centerRange((double) (-1));
//        java.awt.Stroke stroke23 = dateAxis6.getTickMarkStroke();
//        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
//        boolean boolean27 = dateAxis25.isHiddenValue((long) (short) -1);
//        java.awt.Paint paint28 = dateAxis25.getLabelPaint();
//        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
//        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer37 = null;
//        java.util.Collection collection38 = categoryPlot34.getRangeMarkers(layer37);
//        boolean boolean39 = categoryPlot34.isDomainZoomable();
//        categoryPlot34.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot34.getDomainAxisLocation((-1));
//        java.awt.Stroke stroke44 = categoryPlot34.getRangeGridlineStroke();
//        boolean boolean45 = plotOrientation29.equals((java.lang.Object) stroke44);
//        try {
//            org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color4, stroke23, paint28, stroke44, (float) (-65281));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(paint28);
//        org.junit.Assert.assertNotNull(plotOrientation29);
//        org.junit.Assert.assertNotNull(rectangleEdge36);
//        org.junit.Assert.assertNull(collection38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(axisLocation43);
//        org.junit.Assert.assertNotNull(stroke44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        dateAxis9.setAutoRange(false);
        java.awt.Shape shape24 = dateAxis9.getUpArrow();
        dateAxis1.setDownArrow(shape24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot4.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        boolean boolean33 = categoryPlot28.isDomainZoomable();
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot28.getDomainAxisLocation((-1));
        categoryPlot16.setDomainAxisLocation(axisLocation37);
        categoryPlot4.setDomainAxisLocation(1, axisLocation37);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        categoryPlot48.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis43.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot48);
        dateAxis43.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke55 = dateAxis43.getAxisLineStroke();
        valueMarker41.setStroke(stroke55);
        categoryPlot4.setRangeCrosshairStroke(stroke55);
        java.lang.String str58 = categoryPlot4.getNoDataMessage();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setAutoTickUnitSelection(true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        java.awt.Color color18 = color16.brighter();
        java.awt.color.ColorSpace colorSpace19 = null;
        java.awt.Color color20 = java.awt.Color.GRAY;
        java.awt.Color color21 = java.awt.Color.orange;
        float[] floatArray25 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray26 = color21.getRGBColorComponents(floatArray25);
        float[] floatArray27 = color20.getRGBColorComponents(floatArray25);
        try {
            float[] floatArray28 = color16.getColorComponents(colorSpace19, floatArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes(0.05d, plotRenderingInfo11, point2D12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryPlot22.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        dateAxis17.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke29 = dateAxis17.getAxisLineStroke();
        valueMarker15.setStroke(stroke29);
        categoryPlot4.setRangeCrosshairStroke(stroke29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        int int33 = categoryPlot4.getIndexOf(categoryItemRenderer32);
        float float34 = categoryPlot4.getForegroundAlpha();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        dateAxis3.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint17 = valueMarker16.getPaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker16.setPaint((java.awt.Paint) color18);
        dateAxis3.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis3.getLabelInsets();
        boolean boolean22 = sortOrder0.equals((java.lang.Object) rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets21.createOutsetRectangle(rectangle2D23, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        chartChangeEvent1.setType(chartChangeEventType2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLabelURL("Layer.FOREGROUND");
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot6.getRangeMarkers(layer9);
        org.jfree.chart.plot.Plot plot11 = categoryPlot6.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setRangeAxisLocation((int) '#', axisLocation13);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str16 = plotOrientation15.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation15);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str16.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin(8.0d);
        categoryPlot4.setDomainAxis(categoryAxis9);
        categoryAxis9.setCategoryMargin(100.0d);
        java.lang.String str16 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) 10.0f);
        double double17 = categoryAxis9.getLabelAngle();
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot36.getRangeMarkers(layer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot36.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot36.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker44.getLabelTextAnchor();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, categoryItemRenderer52);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot53.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = categoryPlot53.getRangeMarkers(layer56);
        org.jfree.chart.plot.Plot plot58 = categoryPlot53.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer62 = null;
        boolean boolean63 = categoryPlot53.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker61, layer62);
        categoryPlot53.clearRangeMarkers();
        java.lang.Class<?> wildcardClass65 = categoryPlot53.getClass();
        java.util.EventListener[] eventListenerArray66 = valueMarker44.getListeners((java.lang.Class) wildcardClass65);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(eventListenerArray66);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.configureDomainAxes();
        java.util.List list6 = categoryPlot4.getAnnotations();
        boolean boolean7 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot4.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getBlue();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor2, jFreeChart3);
        boolean boolean5 = color0.equals((java.lang.Object) textAnchor2);
        java.awt.Color color6 = java.awt.Color.orange;
        float[] floatArray10 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray11 = color6.getRGBColorComponents(floatArray10);
        try {
            float[] floatArray12 = color0.getComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis1.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        dateAxis6.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke18 = dateAxis6.getAxisLineStroke();
        dateAxis6.setAutoRange(false);
        boolean boolean21 = dateAxis1.equals((java.lang.Object) dateAxis6);
        double double22 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        dateAxis9.setAutoRange(false);
        java.awt.Shape shape24 = dateAxis9.getUpArrow();
        dateAxis1.setDownArrow(shape24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot34.getRangeMarkers(layer37);
        org.jfree.chart.plot.Plot plot39 = categoryPlot34.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot34.setRangeAxisLocation((int) '#', axisLocation41);
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str44 = plotOrientation43.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation41, plotOrientation43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation43);
        try {
            java.util.List list47 = dateAxis1.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(plot39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str44.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getDomainAxisEdge((int) (short) 0);
        categoryPlot20.setRangeGridlinesVisible(true);
        categoryPlot20.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot20.render(graphics2D27, rectangle2D28, (int) (short) -1, plotRenderingInfo30);
        java.lang.String str32 = categoryPlot20.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot20.setAxisOffset(rectangleInsets33);
        categoryPlot5.setInsets(rectangleInsets33, true);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Category Plot" + "'", str32.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot5.setRenderer(categoryItemRenderer13, false);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "EXPAND");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot14.getRangeMarkers(layer17);
        boolean boolean19 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot26.getRangeMarkers(layer29);
        org.jfree.chart.plot.Plot plot31 = categoryPlot26.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot26.getDomainAxisLocation((int) (short) 10);
        categoryPlot14.setDomainAxisLocation(axisLocation33, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot14.getDomainAxisEdge();
        try {
            java.util.List list37 = categoryAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = categoryPlot27.getRangeCrosshairPaint();
        categoryPlot4.setDomainGridlinePaint(paint32);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation36 = null;
        try {
            boolean boolean38 = categoryPlot4.removeAnnotation(categoryAnnotation36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint32);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        categoryPlot4.configureDomainAxes();
//        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
//        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer16 = null;
//        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
//        org.jfree.chart.plot.Plot plot18 = categoryPlot13.getRootPlot();
//        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
//        org.jfree.chart.util.Layer layer22 = null;
//        boolean boolean23 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker21, layer22);
//        categoryPlot13.clearRangeMarkers();
//        org.jfree.chart.plot.Marker marker25 = null;
//        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean27 = categoryPlot13.removeDomainMarker(marker25, layer26);
//        boolean boolean28 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer26);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
//        intervalMarker8.setLabelOffsetType(lengthAdjustmentType29);
//        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER;
//        org.jfree.chart.JFreeChart jFreeChart32 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor31, jFreeChart32);
//        intervalMarker8.setLabelTextAnchor(textAnchor31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getSerialIndex();
//        long long37 = day35.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day35.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day35.previous();
//        boolean boolean40 = textAnchor31.equals((java.lang.Object) day35);
//        java.util.Calendar calendar41 = null;
//        try {
//            long long42 = day35.getLastMillisecond(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(rectangleEdge15);
//        org.junit.Assert.assertNull(collection17);
//        org.junit.Assert.assertNotNull(plot18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(layer26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
//        org.junit.Assert.assertNotNull(textAnchor31);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43629L + "'", long37 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        java.awt.Image image7 = null;
        categoryPlot4.setBackgroundImage(image7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
        boolean boolean18 = categoryPlot13.isDomainZoomable();
        categoryPlot13.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke21 = categoryPlot13.getRangeCrosshairStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.plot.Plot plot23 = plotChangeEvent22.getPlot();
        categoryPlot4.notifyListeners(plotChangeEvent22);
        double double25 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 0, plotRenderingInfo33, point2D34, false);
        float float37 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot36.getRangeMarkers(layer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot36.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot36.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker44.getLabelTextAnchor();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        categoryPlot4.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace50 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNull(axisSpace50);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot16.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation25);
        int int27 = categoryPlot4.getWeight();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        java.lang.Class<?> wildcardClass16 = categoryPlot4.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        double double20 = dateAxis19.getFixedDimension();
        boolean boolean22 = dateAxis19.isHiddenValue((-1L));
        dateAxis19.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        categoryPlot34.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        dateAxis29.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke41 = dateAxis29.getAxisLineStroke();
        valueMarker27.setStroke(stroke41);
        dateAxis19.setAxisLineStroke(stroke41);
        categoryAxis17.setAxisLineStroke(stroke41);
        categoryPlot4.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer47);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range4);
        java.awt.Color color6 = java.awt.Color.WHITE;
        dateAxis1.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis1.getTickUnit();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot15.getDomainAxisEdge((int) (short) 0);
        categoryPlot15.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge((int) (byte) -1);
        try {
            double double22 = dateAxis1.lengthToJava2D((double) (-1L), rectangle2D10, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getLastMillisecond();
//        boolean boolean4 = day0.equals((java.lang.Object) 2.0d);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot22.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot22.getRangeMarkers(layer25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot22.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation((int) '#', axisLocation29);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str32 = plotOrientation31.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation29, plotOrientation31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation31);
        categoryPlot4.setRangeAxisLocation(0, axisLocation17);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str32.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.ASCENDING" + "'", str2.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape19 = dateAxis18.getLeftArrow();
        dateAxis1.setRightArrow(shape19);
        boolean boolean21 = dateAxis1.isInverted();
        java.awt.Paint paint22 = null;
        try {
            dateAxis1.setLabelPaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setAutoTickUnitSelection(true, true);
        dateAxis1.centerRange((double) (-1));
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot25.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot25.getRangeMarkers(layer28);
        org.jfree.chart.plot.Plot plot30 = categoryPlot25.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot25.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker33, layer34);
        categoryPlot25.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot43.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot43.getRangeMarkers(layer46);
        org.jfree.chart.plot.Plot plot48 = categoryPlot43.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot43.setRangeAxisLocation((int) '#', axisLocation50);
        org.jfree.chart.plot.PlotOrientation plotOrientation52 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str53 = plotOrientation52.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation50, plotOrientation52);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation38, plotOrientation52);
        categoryPlot25.setRangeAxisLocation(0, axisLocation38);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot25.getRangeAxisEdge();
        try {
            double double58 = dateAxis1.lengthToJava2D((double) (-12566273), rectangle2D20, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNotNull(plot48);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(plotOrientation52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str53.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot16.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation25);
        categoryPlot4.setBackgroundAlpha((float) (short) 1);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot35.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot35.getRangeMarkers(layer38);
        boolean boolean40 = categoryPlot35.isDomainZoomable();
        categoryPlot35.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, categoryItemRenderer50);
        categoryPlot51.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis46.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot51);
        dateAxis46.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke58 = dateAxis46.getAxisLineStroke();
        valueMarker44.setStroke(stroke58);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker44.setLabelOffsetType(lengthAdjustmentType60);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, valueAxis64, categoryItemRenderer65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot66.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer69 = null;
        java.util.Collection collection70 = categoryPlot66.getRangeMarkers(layer69);
        org.jfree.chart.plot.Plot plot71 = categoryPlot66.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker74 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer75 = null;
        boolean boolean76 = categoryPlot66.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker74, layer75);
        categoryPlot66.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker78 = null;
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean80 = categoryPlot66.removeDomainMarker(marker78, layer79);
        boolean boolean81 = categoryPlot35.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker44, layer79);
        try {
            categoryPlot4.addDomainMarker(12, categoryMarker30, layer79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType60);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNull(collection70);
        org.junit.Assert.assertNotNull(plot71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(layer79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot16.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot16.getDomainAxisLocation((int) (short) 10);
        categoryPlot4.setDomainAxisLocation(axisLocation23, true);
        categoryPlot4.clearRangeMarkers((-1));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot7.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot7.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot19.getRangeMarkers(layer22);
        boolean boolean24 = categoryPlot19.isDomainZoomable();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot31.getRangeMarkers(layer34);
        boolean boolean36 = categoryPlot31.isDomainZoomable();
        categoryPlot31.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getDomainAxisLocation((-1));
        categoryPlot19.setDomainAxisLocation(axisLocation40);
        categoryPlot7.setDomainAxisLocation(1, axisLocation40);
        objectList1.set(128, (java.lang.Object) categoryPlot7);
        java.lang.Object obj44 = objectList1.clone();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis0.getLabelInsets();
        java.lang.String str4 = categoryAxis0.getLabelURL();
        categoryAxis0.setCategoryLabelPositionOffset(128);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) '4', "UnitType.RELATIVE");
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        java.awt.Paint paint23 = null;
        try {
            xYPlot22.setDomainCrosshairPaint(paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot5.setRangeAxisLocation((int) '#', axisLocation12);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str15 = plotOrientation14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation14);
        boolean boolean19 = plotOrientation14.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str15.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            xYPlot22.drawBackground(graphics2D23, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot4.markerChanged(markerChangeEvent12);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        java.lang.Object obj15 = null;
        boolean boolean16 = categoryPlot4.equals(obj15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            categoryPlot4.handleClick(500, (int) (short) 1, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        java.util.Date date15 = dateAxis1.getMinimumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets16.calculateLeftInset((double) (short) 100);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets16.getUnitType();
        dateAxis1.setLabelInsets(rectangleInsets16);
        double double22 = rectangleInsets16.trimWidth((double) (short) 100);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 84.0d + "'", double22 == 84.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot4.getDomainAxis(100);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        valueMarker12.setAlpha(0.0f);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker12, layer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setCategoryMargin(8.0d);
        categoryAxis19.setMaximumCategoryLabelLines(0);
        int int24 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.clearCategoryLabelToolTips();
        java.lang.String str26 = categoryAxis19.getLabelURL();
        categoryPlot4.setDomainAxis((int) (byte) 10, categoryAxis19, false);
        categoryAxis19.removeCategoryLabelToolTip((java.lang.Comparable) 0.05d);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 4, (double) (short) 10, plotRenderingInfo13, point2D14);
        java.awt.Paint paint16 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot4.mapDatasetToDomainAxis(255, 500);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        java.awt.Image image13 = null;
        categoryPlot5.setBackgroundImage(image13);
        categoryPlot5.clearDomainAxes();
        try {
            categoryPlot5.mapDatasetToRangeAxis((-65281), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis12);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.removeChangeListener(plotChangeListener8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(0, categoryItemRenderer11, false);
        float float14 = categoryPlot4.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setAutoTickUnitSelection(true, true);
        dateAxis1.setVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        categoryPlot24.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis19.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot24);
        java.util.Date date29 = dateAxis19.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot36.getRangeMarkers(layer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot36.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot36.setRangeAxisLocation((int) '#', axisLocation43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str46 = plotOrientation45.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation43, plotOrientation45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation45);
        try {
            double double49 = dateAxis1.dateToJava2D(date29, rectangle2D30, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str46.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        org.jfree.data.general.DatasetGroup datasetGroup13 = categoryPlot5.getDatasetGroup();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(datasetGroup13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        org.jfree.chart.text.TextAnchor textAnchor3 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 500, (double) 5, 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        dateAxis9.setAutoRange(false);
        java.awt.Shape shape24 = dateAxis9.getUpArrow();
        dateAxis1.setDownArrow(shape24);
        java.util.Date date26 = dateAxis1.getMaximumDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setUpperBound((double) (short) 0);
        boolean boolean8 = dateAxis1.isAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            categoryPlot4.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace11);
        java.awt.Paint paint13 = categoryPlot8.getRangeCrosshairPaint();
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) categoryPlot8);
        dateAxis1.setTickMarkOutsideLength((float) '4');
        dateAxis1.resizeRange((double) (short) 100);
        boolean boolean19 = dateAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        valueMarker7.setStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str26 = lengthAdjustmentType25.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType23, lengthAdjustmentType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "EXPAND" + "'", str26.equals("EXPAND"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        double double5 = dateAxis1.getLowerBound();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange22);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange22, false, true);
        java.text.DateFormat dateFormat27 = null;
        dateAxis1.setDateFormatOverride(dateFormat27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        categoryPlot33.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot33.setRangeCrosshairPaint((java.awt.Paint) color37);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray9 = new float[] { 3, 100, (byte) 10, (short) 0, 500, (-1L) };
        try {
            float[] floatArray10 = color0.getComponents(colorSpace2, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot4.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) date1, "hi!");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        boolean boolean17 = categoryPlot12.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray18 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot12.setDomainAxes(categoryAxisArray18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot24.getRangeMarkers(layer27);
        org.jfree.chart.plot.Plot plot29 = categoryPlot24.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot24.getDomainAxisLocation((int) (short) 10);
        categoryPlot12.setDomainAxisLocation(axisLocation31, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot12.getDomainAxisEdge();
        try {
            double double35 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor4, 4, 8, rectangle2D7, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(plot29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot7.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        categoryPlot7.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot7.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot21.getRangeMarkers(layer24);
        boolean boolean26 = categoryPlot21.isDomainZoomable();
        categoryPlot21.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot21.getDomainAxisLocation((-1));
        categoryPlot7.setDomainAxisLocation(axisLocation30, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot39.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot39.getRangeMarkers(layer42);
        org.jfree.chart.plot.Plot plot44 = categoryPlot39.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = categoryPlot39.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker47, layer48);
        org.jfree.chart.text.TextAnchor textAnchor50 = valueMarker47.getLabelTextAnchor();
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47);
        objectList1.set(500, (java.lang.Object) categoryPlot7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent53 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        java.lang.Object obj54 = plotChangeEvent53.getSource();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(textAnchor50);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot13.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker21, layer22);
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = categoryPlot13.removeDomainMarker(marker25, layer26);
        boolean boolean28 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer26);
        double double29 = intervalMarker8.getStartValue();
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray6 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        double double11 = dateAxis10.getFixedDimension();
        boolean boolean12 = dateAxis10.isAxisLineVisible();
        dateAxis10.setFixedDimension((double) (short) -1);
        dateAxis10.setVerticalTickLabels(false);
        java.awt.Shape shape17 = dateAxis10.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape20 = dateAxis19.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        categoryPlot27.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis22.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        dateAxis22.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis22.setStandardTickUnits(tickUnitSource34);
        dateAxis22.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape40 = dateAxis39.getLeftArrow();
        dateAxis22.setRightArrow(shape40);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape44 = dateAxis43.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        double double47 = dateAxis46.getFixedDimension();
        boolean boolean48 = dateAxis46.isAxisLineVisible();
        dateAxis46.setFixedDimension((double) (short) -1);
        dateAxis46.setUpperBound((double) (short) 0);
        java.awt.Shape shape53 = dateAxis46.getLeftArrow();
        java.awt.Shape[] shapeArray54 = new java.awt.Shape[] { shape17, shape20, shape40, shape44, shape53 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray6, strokeArray7, strokeArray8, shapeArray54);
        java.awt.Shape[] shapeArray56 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier57 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray4, strokeArray8, shapeArray56);
        boolean boolean58 = textAnchor0.equals((java.lang.Object) paintArray3);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(tickUnitSource34);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(shapeArray54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker11.getLabelOffset();
        valueMarker11.setValue((double) (-16777216));
        java.awt.Paint paint18 = valueMarker11.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) date1, "hi!");
        double double4 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setUpperMargin(10.0d);
        float float7 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setRangeAxisLocation((int) '#', axisLocation11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        categoryPlot19.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        dateAxis14.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke26 = dateAxis14.getAxisLineStroke();
        int int27 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        try {
            dateAxis14.setRange((double) '4', (double) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.clearAnnotations();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        try {
            xYPlot22.setDataset((-65281), xYDataset46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot22.getDomainAxisForDataset((-12566273));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -12566273 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12, false, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
        double double17 = dateAxis1.getUpperBound();
        dateAxis1.setLowerMargin(1.560538800005E12d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer7 = null;
//        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
//        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
//        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
//        org.jfree.chart.util.Layer layer13 = null;
//        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
//        categoryPlot4.clearRangeMarkers();
//        java.lang.Class<?> wildcardClass16 = categoryPlot4.getClass();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        long long19 = day17.getLastMillisecond();
//        java.util.Date date20 = day17.getEnd();
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
//        categoryPlot27.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
//        dateAxis22.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
//        dateAxis22.setLowerMargin((double) (short) 10);
//        java.util.TimeZone timeZone34 = dateAxis22.getTimeZone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone34);
//        try {
//            org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) regularTimePeriod35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(rectangleEdge6);
//        org.junit.Assert.assertNull(collection8);
//        org.junit.Assert.assertNotNull(plot9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin(8.0d);
        categoryPlot4.setDomainAxis(categoryAxis9);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        dateAxis15.setLowerMargin((double) (short) 10);
        dateAxis15.setAutoTickUnitSelection(true, true);
        dateAxis15.centerRange((double) (-1));
        java.util.Date date32 = dateAxis15.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot40.getDomainAxisEdge((int) (short) 0);
        categoryPlot40.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot40.getRangeAxisEdge((int) (byte) -1);
        try {
            double double47 = categoryAxis9.getCategorySeriesMiddle((java.lang.Comparable) 8.0d, (java.lang.Comparable) date32, categoryDataset33, (double) 9, rectangle2D35, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        boolean boolean9 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            categoryPlot4.drawOutline(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        dateAxis1.setTickMarkOutsideLength(10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getDomainAxisLocation((int) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot19.getRangeMarkers(layer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot19.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot19.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker27, layer28);
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot19.removeDomainMarker(marker31, layer32);
        categoryPlot4.addRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer32);
        java.lang.String str35 = valueMarker14.getLabel();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createInsetRectangle(rectangle2D6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot13.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker21, layer22);
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = categoryPlot13.removeDomainMarker(marker25, layer26);
        boolean boolean28 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer26);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker8.setLabelOffsetType(lengthAdjustmentType29);
        java.awt.Stroke stroke31 = null;
        try {
            intervalMarker8.setStroke(stroke31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot4.getDomainAxis(100);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        valueMarker12.setAlpha(0.0f);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker12, layer16);
        float float18 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot32.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot32.setFixedRangeAxisSpace(axisSpace35);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean42 = categoryPlot32.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker39, layer40, true);
        try {
            boolean boolean44 = xYPlot22.removeRangeMarker(0, marker27, layer40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 10.0f);
        double double4 = rectangleInsets0.calculateRightInset((double) ' ');
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.clearCategoryLabelToolTips();
        double double7 = categoryAxis0.getUpperMargin();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge((int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        boolean boolean33 = categoryPlot28.isDomainZoomable();
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot28.getDomainAxisLocation((-1));
        categoryPlot16.setDomainAxisLocation(axisLocation37);
        categoryPlot4.setRangeAxisLocation((int) '4', axisLocation37, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot4.getOrientation();
        categoryPlot4.clearDomainMarkers(0);
        boolean boolean44 = categoryPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) (byte) -1, (double) 2, 2.0d);
        java.lang.String str6 = unitType0.toString();
        boolean boolean8 = unitType0.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot17.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot17.zoomDomainAxes(0.05d, plotRenderingInfo24, point2D25);
        java.lang.Object obj27 = null;
        boolean boolean28 = categoryPlot17.equals(obj27);
        boolean boolean29 = categoryPlot4.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot17.zoomDomainAxes((double) 11, plotRenderingInfo31, point2D32);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairValue(0.0d, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot4.getDomainAxisForDataset(7);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNull(categoryAxis21);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Shape shape8 = dateAxis1.getRightArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis1.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getFixedDimension();
        boolean boolean7 = dateAxis5.isAxisLineVisible();
        dateAxis5.setFixedDimension((double) (short) -1);
        dateAxis5.setVerticalTickLabels(false);
        java.awt.Shape shape12 = dateAxis5.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape15 = dateAxis14.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryPlot22.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        dateAxis17.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis17.setStandardTickUnits(tickUnitSource29);
        dateAxis17.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape35 = dateAxis34.getLeftArrow();
        dateAxis17.setRightArrow(shape35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape39 = dateAxis38.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getFixedDimension();
        boolean boolean43 = dateAxis41.isAxisLineVisible();
        dateAxis41.setFixedDimension((double) (short) -1);
        dateAxis41.setUpperBound((double) (short) 0);
        java.awt.Shape shape48 = dateAxis41.getLeftArrow();
        java.awt.Shape[] shapeArray49 = new java.awt.Shape[] { shape12, shape15, shape35, shape39, shape48 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray49);
        java.awt.Paint paint51 = defaultDrawingSupplier50.getNextFillPaint();
        java.awt.Shape shape52 = defaultDrawingSupplier50.getNextShape();
        java.awt.Stroke stroke53 = defaultDrawingSupplier50.getNextStroke();
        java.awt.Paint paint54 = defaultDrawingSupplier50.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shapeArray49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = java.awt.Color.orange;
        float[] floatArray6 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray7 = color2.getRGBColorComponents(floatArray6);
        float[] floatArray8 = color1.getRGBColorComponents(floatArray6);
        try {
            float[] floatArray9 = color0.getRGBComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot22.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        double double29 = xYPlot22.getRangeCrosshairValue();
        boolean boolean30 = xYPlot22.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        dateAxis1.zoomRange((double) (short) 1, (double) 128);
        java.util.TimeZone timeZone15 = null;
        try {
            dateAxis1.setTimeZone(timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint13 = null;
        try {
            categoryPlot5.setDomainGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        int int11 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray12);
        categoryPlot4.setForegroundAlpha((float) 0);
        java.lang.String str16 = categoryPlot4.getPlotType();
        int int17 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        try {
            java.awt.Color color1 = java.awt.Color.decode("UnitType.RELATIVE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UnitType.RELATIVE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.clearAnnotations();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = xYPlot22.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46, layer47);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16777024) + "'", int1 == (-16777024));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot22.getAxisOffset();
        boolean boolean26 = xYPlot22.isRangeGridlinesVisible();
        xYPlot22.mapDatasetToDomainAxis((int) '4', (int) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        categoryPlot37.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis32.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot37);
        dateAxis32.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis32.setStandardTickUnits(tickUnitSource44);
        dateAxis32.setPositiveArrowVisible(true);
        org.jfree.data.time.DateRange dateRange48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis32.setDefaultAutoRange((org.jfree.data.Range) dateRange48);
        try {
            xYPlot22.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) dateAxis32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(dateRange48);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) (byte) -1, (double) 2, 2.0d);
        java.lang.String str6 = unitType0.toString();
        java.lang.String str7 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, (double) 10L, (double) (short) 10, (double) 13);
        double double14 = rectangleInsets12.calculateRightInset((double) 'a');
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.RELATIVE" + "'", str7.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1261.0d + "'", double14 == 1261.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot22.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot22.getDomainAxisLocation();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation36 = null;
        try {
            xYPlot22.addAnnotation(xYAnnotation36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.clearAnnotations();
        xYPlot22.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        xYPlot22.setFixedDomainAxisSpace(axisSpace47, true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot7.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot7.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot19.getRangeMarkers(layer22);
        boolean boolean24 = categoryPlot19.isDomainZoomable();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot31.getRangeMarkers(layer34);
        boolean boolean36 = categoryPlot31.isDomainZoomable();
        categoryPlot31.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getDomainAxisLocation((-1));
        categoryPlot19.setDomainAxisLocation(axisLocation40);
        categoryPlot7.setDomainAxisLocation(1, axisLocation40);
        objectList1.set(128, (java.lang.Object) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot49.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = categoryPlot49.getRangeMarkers(layer52);
        org.jfree.chart.plot.Plot plot54 = categoryPlot49.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot49.setRangeAxisLocation((int) '#', axisLocation56);
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str59 = plotOrientation58.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation56, plotOrientation58);
        try {
            objectList1.set((-65281), (java.lang.Object) plotOrientation58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNotNull(plot54);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str59.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot4.getRendererForDataset(categoryDataset9);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        int int11 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        double double16 = dateAxis15.getFixedDimension();
        boolean boolean18 = dateAxis15.isHiddenValue((-1L));
        dateAxis15.setAutoTickUnitSelection(true, true);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot26.getRangeMarkers(layer29);
        boolean boolean31 = categoryPlot26.isDomainZoomable();
        categoryPlot26.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke34 = categoryPlot26.getRangeCrosshairStroke();
        boolean boolean35 = dateAxis15.equals((java.lang.Object) stroke34);
        categoryPlot4.setOutlineStroke(stroke34);
        org.jfree.chart.plot.Plot plot37 = null;
        categoryPlot4.setParent(plot37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot43.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot43.getRangeMarkers(layer46);
        org.jfree.chart.plot.Plot plot48 = categoryPlot43.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer52 = null;
        boolean boolean53 = categoryPlot43.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker51, layer52);
        categoryPlot43.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker55 = null;
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot43.removeDomainMarker(marker55, layer56);
        java.util.Collection collection58 = categoryPlot4.getDomainMarkers(layer56);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNotNull(plot48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getFixedDimension();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot11.getRangeMarkers(layer14);
        boolean boolean16 = categoryPlot11.isDomainZoomable();
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot11.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot25.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot25.getRangeMarkers(layer28);
        boolean boolean30 = categoryPlot25.isDomainZoomable();
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot25.getDomainAxisLocation((-1));
        categoryPlot11.setDomainAxisLocation(axisLocation34, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot43.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot43.getRangeMarkers(layer46);
        org.jfree.chart.plot.Plot plot48 = categoryPlot43.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer52 = null;
        boolean boolean53 = categoryPlot43.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker51, layer52);
        org.jfree.chart.text.TextAnchor textAnchor54 = valueMarker51.getLabelTextAnchor();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker51);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot11.getRangeAxisEdge();
        try {
            java.util.List list57 = dateAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNotNull(plot48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker14.setPaint((java.awt.Paint) color16);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        boolean boolean19 = dateAxis1.isInverted();
        java.awt.Stroke stroke20 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot4.render(graphics2D11, rectangle2D12, (int) (short) -1, plotRenderingInfo14);
        java.lang.String str16 = categoryPlot4.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot4.setAxisOffset(rectangleInsets17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            categoryPlot4.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker14.setPaint((java.awt.Paint) color16);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis1.getLabelInsets();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            org.jfree.chart.axis.AxisState axisState32 = dateAxis1.draw(graphics2D20, (double) (byte) 1, rectangle2D22, rectangle2D23, rectangleEdge30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        java.awt.Image image7 = null;
        categoryPlot4.setBackgroundImage(image7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
        boolean boolean18 = categoryPlot13.isDomainZoomable();
        categoryPlot13.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke21 = categoryPlot13.getRangeCrosshairStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.plot.Plot plot23 = plotChangeEvent22.getPlot();
        categoryPlot4.notifyListeners(plotChangeEvent22);
        java.lang.String str25 = plotChangeEvent22.toString();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(plot23);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        int int11 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        categoryPlot4.drawOutline(graphics2D14, rectangle2D15);
        try {
            categoryPlot4.setBackgroundImageAlpha((float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        java.lang.String str5 = dateAxis1.getLabel();
        java.awt.Paint paint6 = dateAxis1.getAxisLinePaint();
        dateAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12, false, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
        org.jfree.chart.plot.Plot plot17 = null;
        dateAxis1.setPlot(plot17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot25.getDomainAxisEdge((int) (short) 0);
        categoryPlot25.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot25.getRangeAxisEdge((int) (byte) -1);
        try {
            double double32 = dateAxis1.java2DToValue((double) 3, rectangle2D20, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot4.render(graphics2D11, rectangle2D12, (int) (short) -1, plotRenderingInfo14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getRangeMarkers(layer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot20.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean31 = categoryPlot20.removeRangeMarker(7, (org.jfree.chart.plot.Marker) valueMarker28, layer29, true);
        java.util.Collection collection32 = categoryPlot4.getDomainMarkers(layer29);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        double double35 = dateAxis34.getFixedDimension();
        boolean boolean36 = dateAxis34.isAxisLineVisible();
        dateAxis34.setFixedDimension((double) (short) -1);
        dateAxis34.setUpperBound((double) (short) 0);
        java.awt.Shape shape41 = dateAxis34.getLeftArrow();
        int int42 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        double double12 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot4.setDomainAxis(192, categoryAxis12);
        categoryPlot4.setAnchorValue((double) 0L, true);
        java.lang.String str17 = categoryPlot4.getPlotType();
        categoryPlot4.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(categoryItemRenderer13, false);
        java.lang.Class<?> wildcardClass16 = categoryPlot4.getClass();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot5.getRootPlot();
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.lang.String str15 = datasetRenderingOrder13.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str15.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot17.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot17.zoomDomainAxes(0.05d, plotRenderingInfo24, point2D25);
        java.lang.Object obj27 = null;
        boolean boolean28 = categoryPlot17.equals(obj27);
        boolean boolean29 = categoryPlot4.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            boolean boolean32 = categoryPlot17.removeAnnotation(categoryAnnotation30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke13 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.event.AxisChangeListener axisChangeListener14 = null;
        dateAxis1.removeChangeListener(axisChangeListener14);
        org.jfree.data.Range range16 = null;
        try {
            dateAxis1.setRangeWithMargins(range16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot4.getDomainAxis(100);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        valueMarker12.setAlpha(0.0f);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker12, layer16);
        int int18 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis20.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot25);
        dateAxis20.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis20.setStandardTickUnits(tickUnitSource32);
        dateAxis20.setPositiveArrowVisible(true);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis20.setDefaultAutoRange((org.jfree.data.Range) dateRange36);
        java.awt.Font font38 = dateAxis20.getTickLabelFont();
        categoryPlot4.setNoDataMessageFont(font38);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot22.getRenderer();
        java.awt.Stroke stroke24 = xYPlot22.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList1.clear();
        objectList1.clear();
        int int4 = objectList1.size();
        objectList1.clear();
        java.lang.Object obj6 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.clearAnnotations();
        xYPlot22.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = xYPlot22.getAxisOffset();
        org.jfree.chart.plot.Marker marker49 = null;
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot54.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer57 = null;
        java.util.Collection collection58 = categoryPlot54.getRangeMarkers(layer57);
        org.jfree.chart.plot.Plot plot59 = categoryPlot54.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation61 = categoryPlot54.getDomainAxisLocation((int) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset65 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset65, categoryAxis66, valueAxis67, categoryItemRenderer68);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = categoryPlot69.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer72 = null;
        java.util.Collection collection73 = categoryPlot69.getRangeMarkers(layer72);
        org.jfree.chart.plot.Plot plot74 = categoryPlot69.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer78 = null;
        boolean boolean79 = categoryPlot69.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker77, layer78);
        categoryPlot69.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker81 = null;
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean83 = categoryPlot69.removeDomainMarker(marker81, layer82);
        categoryPlot54.addRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker64, layer82);
        try {
            boolean boolean86 = xYPlot22.removeRangeMarker((int) '#', marker49, layer82, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNotNull(plot59);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertNotNull(plot74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        int int23 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint24 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot30.getRangeMarkers(layer33);
        boolean boolean35 = categoryPlot30.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray36 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot30.setDomainAxes(categoryAxisArray36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot42.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot42.getRangeMarkers(layer45);
        org.jfree.chart.plot.Plot plot47 = categoryPlot42.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot42.getDomainAxisLocation((int) (short) 10);
        categoryPlot30.setDomainAxisLocation(axisLocation49, true);
        org.jfree.chart.JFreeChart jFreeChart52 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) axisLocation49, jFreeChart52);
        try {
            categoryPlot4.setDomainAxisLocation((int) (byte) -1, axisLocation49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray36);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(plot47);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setAutoTickUnitSelection(true, true);
        dateAxis1.centerRange((double) (-1));
        java.util.Date date18 = dateAxis1.getMinimumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot20 = dateAxis1.getPlot();
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(plot20);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        dateAxis15.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke27 = dateAxis15.getAxisLineStroke();
        valueMarker13.setStroke(stroke27);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker13.setLabelOffsetType(lengthAdjustmentType29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot35.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot35.getRangeMarkers(layer38);
        org.jfree.chart.plot.Plot plot40 = categoryPlot35.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot35.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker43, layer44);
        categoryPlot35.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker47 = null;
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean49 = categoryPlot35.removeDomainMarker(marker47, layer48);
        boolean boolean50 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker13, layer48);
        double double51 = valueMarker13.getValue();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener52 = null;
        valueMarker13.removeChangeListener(markerChangeListener52);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(plot40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        dateAxis3.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint17 = valueMarker16.getPaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker16.setPaint((java.awt.Paint) color18);
        dateAxis3.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis3.getLabelInsets();
        boolean boolean22 = sortOrder0.equals((java.lang.Object) rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets21.createInsetRectangle(rectangle2D23, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis0.getLabelInsets();
        double double5 = rectangleInsets3.calculateBottomInset((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot22.getDataset();
        java.awt.Stroke stroke35 = xYPlot22.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot22.zoomDomainAxes((double) 10.0f, plotRenderingInfo37, point2D38);
        java.awt.geom.Point2D point2D40 = null;
        try {
            xYPlot22.setQuadrantOrigin(point2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        double double10 = dateAxis9.getFixedDimension();
        boolean boolean11 = dateAxis9.isAxisLineVisible();
        dateAxis9.setFixedDimension((double) (short) -1);
        dateAxis9.setVerticalTickLabels(false);
        java.awt.Shape shape16 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape19 = dateAxis18.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        categoryPlot26.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis21.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        dateAxis21.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis21.setStandardTickUnits(tickUnitSource33);
        dateAxis21.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape39 = dateAxis38.getLeftArrow();
        dateAxis21.setRightArrow(shape39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape43 = dateAxis42.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        double double46 = dateAxis45.getFixedDimension();
        boolean boolean47 = dateAxis45.isAxisLineVisible();
        dateAxis45.setFixedDimension((double) (short) -1);
        dateAxis45.setUpperBound((double) (short) 0);
        java.awt.Shape shape52 = dateAxis45.getLeftArrow();
        java.awt.Shape[] shapeArray53 = new java.awt.Shape[] { shape16, shape19, shape39, shape43, shape52 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray5, strokeArray6, strokeArray7, shapeArray53);
        java.awt.Shape[] shapeArray55 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray7, shapeArray55);
        java.lang.Object obj57 = defaultDrawingSupplier56.clone();
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource33);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shapeArray53);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        xYPlot22.setDomainGridlinesVisible(true);
        boolean boolean36 = xYPlot22.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        int int11 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getDomainAxisLocation((int) (short) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot4.getDatasetRenderingOrder();
        java.lang.Object obj13 = null;
        boolean boolean14 = datasetRenderingOrder12.equals(obj13);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        java.awt.Stroke stroke14 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot4.setAxisOffset(rectangleInsets15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            categoryPlot4.drawOutline(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DatasetRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getDomainAxisEdge((int) (short) 0);
        categoryPlot29.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot29.getRangeAxisEdge((int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot41.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot41.getRangeMarkers(layer44);
        boolean boolean46 = categoryPlot41.isDomainZoomable();
        categoryPlot41.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, categoryItemRenderer52);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot53.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = categoryPlot53.getRangeMarkers(layer56);
        boolean boolean58 = categoryPlot53.isDomainZoomable();
        categoryPlot53.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot53.getDomainAxisLocation((-1));
        categoryPlot41.setDomainAxisLocation(axisLocation62);
        categoryPlot29.setRangeAxisLocation((int) '4', axisLocation62, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation66 = categoryPlot29.getOrientation();
        xYPlot22.setOrientation(plotOrientation66);
        double double68 = xYPlot22.getRangeCrosshairValue();
        java.awt.Paint paint69 = xYPlot22.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(plotOrientation66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setRangeAboutValue(1.0d, (double) 501);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.Object obj1 = null;
        boolean boolean2 = lengthAdjustmentType0.equals(obj1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        java.util.List list44 = xYPlot22.getAnnotations();
        java.awt.Paint paint45 = xYPlot22.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-12566273));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1560452399999L, (double) 'a');
        double double3 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        java.awt.Paint paint23 = null;
        try {
            dateAxis2.setTickMarkPaint(paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 4, (double) (short) 10, plotRenderingInfo13, point2D14);
        java.awt.Paint paint16 = categoryPlot4.getRangeGridlinePaint();
        double double17 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot4.setRenderer((int) ' ', categoryItemRenderer16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot23.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot23.getRangeMarkers(layer26);
        org.jfree.chart.plot.Plot plot28 = categoryPlot23.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot23.setRangeAxisLocation((int) '#', axisLocation30);
        categoryPlot4.setRangeAxisLocation(500, axisLocation30, true);
        categoryPlot4.mapDatasetToDomainAxis((int) (short) 10, (int) (byte) -1);
        java.awt.Paint paint37 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot4.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = categoryPlot27.getRangeCrosshairPaint();
        categoryPlot4.setDomainGridlinePaint(paint32);
        categoryPlot4.setRangeCrosshairVisible(false);
        boolean boolean36 = categoryPlot4.isDomainGridlinesVisible();
        categoryPlot4.setForegroundAlpha(100.0f);
        categoryPlot4.setRangeCrosshairValue(0.05d, true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        java.lang.String str5 = dateAxis1.getLabel();
        dateAxis1.setLowerMargin((double) 8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        java.text.DateFormat dateFormat5 = null;
        dateAxis1.setDateFormatOverride(dateFormat5);
        dateAxis1.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "EXPAND");
        java.awt.Font font7 = categoryAxis0.getTickLabelFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        categoryPlot18.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        dateAxis13.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke25 = dateAxis13.getAxisLineStroke();
        double double26 = dateAxis13.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape29 = dateAxis28.getLeftArrow();
        dateAxis28.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer32);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        double double36 = dateAxis35.getFixedDimension();
        boolean boolean37 = dateAxis35.isAxisLineVisible();
        dateAxis35.setFixedDimension((double) (short) -1);
        dateAxis35.setVerticalTickLabels(false);
        java.awt.Shape shape42 = dateAxis35.getRightArrow();
        java.awt.Paint paint43 = dateAxis35.getAxisLinePaint();
        int int44 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        xYPlot33.setRangeCrosshairValue((double) 2);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = xYPlot33.getRangeAxisEdge((int) (byte) -1);
        try {
            java.util.List list49 = categoryAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot22.zoomDomainAxes(0.0d, (double) (byte) 0, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot22.setFixedRangeAxisSpace(axisSpace28, false);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot22.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        try {
            boolean boolean35 = xYPlot22.removeRangeMarker(marker33, layer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 9);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.chart.plot.Marker marker14 = null;
        boolean boolean15 = categoryPlot4.removeDomainMarker(marker14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint18 = valueMarker17.getPaint();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker17.setPaint((java.awt.Paint) color19);
        categoryPlot4.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color26 = java.awt.Color.orange;
        float[] floatArray30 = new float[] { 1, 10L, (short) 0 };
        float[] floatArray31 = color26.getRGBColorComponents(floatArray30);
        float[] floatArray32 = java.awt.Color.RGBtoHSB((-12566273), 12, (int) (short) 0, floatArray30);
        float[] floatArray33 = color22.getColorComponents(floatArray30);
        float[] floatArray34 = color19.getColorComponents(floatArray33);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setRangeAxisLocation((int) '#', axisLocation11);
        java.awt.Paint paint13 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double16 = rectangleInsets14.extendHeight((double) 10.0f);
        double double18 = rectangleInsets14.calculateRightInset((double) ' ');
        double double19 = rectangleInsets14.getTop();
        categoryPlot4.setAxisOffset(rectangleInsets14);
        categoryPlot4.setAnchorValue((double) 0.0f);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        categoryPlot4.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 18.0d + "'", double16 == 18.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape2 = dateAxis1.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        dateAxis4.setLowerMargin((double) (short) 10);
        dateAxis4.setAutoTickUnitSelection(true, true);
        dateAxis4.centerRange((double) (-1));
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis4.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource21);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(tickUnitSource21);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList1.clear();
        int int3 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setWeight(5);
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str8 = sortOrder7.toString();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        categoryPlot15.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        dateAxis10.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint24 = valueMarker23.getPaint();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker23.setPaint((java.awt.Paint) color25);
        dateAxis10.setTickMarkPaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis10.getLabelInsets();
        boolean boolean29 = sortOrder7.equals((java.lang.Object) rectangleInsets28);
        categoryPlot4.setColumnRenderingOrder(sortOrder7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot4.getRenderer();
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SortOrder.ASCENDING" + "'", str8.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot16.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot4.getOrientation();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryPlot4.setOutlinePaint(paint28);
        categoryPlot4.setNoDataMessage("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        java.lang.Class<?> wildcardClass16 = categoryPlot4.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        double double20 = dateAxis19.getFixedDimension();
        boolean boolean22 = dateAxis19.isHiddenValue((-1L));
        dateAxis19.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        categoryPlot34.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        dateAxis29.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke41 = dateAxis29.getAxisLineStroke();
        valueMarker27.setStroke(stroke41);
        dateAxis19.setAxisLineStroke(stroke41);
        categoryAxis17.setAxisLineStroke(stroke41);
        categoryPlot4.setRangeCrosshairStroke(stroke41);
        java.util.List list46 = categoryPlot4.getCategories();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(list46);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Color color3 = java.awt.Color.lightGray;
        int int4 = color3.getBlue();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor5, jFreeChart6);
        boolean boolean8 = color3.equals((java.lang.Object) textAnchor5);
        valueMarker1.setPaint((java.awt.Paint) color3);
        java.lang.Object obj10 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot22.getDataset();
        java.awt.Stroke stroke35 = xYPlot22.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot22.zoomDomainAxes((double) 10.0f, plotRenderingInfo37, point2D38);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getFixedDimension();
        double double43 = dateAxis41.getFixedDimension();
        dateAxis41.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double48 = rectangleInsets46.extendHeight((double) 10.0f);
        double double50 = rectangleInsets46.calculateRightInset((double) ' ');
        double double51 = rectangleInsets46.getTop();
        dateAxis41.setLabelInsets(rectangleInsets46);
        xYPlot22.setAxisOffset(rectangleInsets46);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        xYPlot22.setDomainAxis(5, valueAxis55, false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 18.0d + "'", double48 == 18.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 8.0d + "'", double50 == 8.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        java.lang.Class<?> wildcardClass16 = categoryPlot4.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        double double20 = dateAxis19.getFixedDimension();
        boolean boolean22 = dateAxis19.isHiddenValue((-1L));
        dateAxis19.setAutoTickUnitSelection(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        categoryPlot34.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        dateAxis29.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke41 = dateAxis29.getAxisLineStroke();
        valueMarker27.setStroke(stroke41);
        dateAxis19.setAxisLineStroke(stroke41);
        categoryAxis17.setAxisLineStroke(stroke41);
        categoryPlot4.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot4.zoomRangeAxes(18.0d, plotRenderingInfo47, point2D48);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        try {
            int int51 = categoryPlot4.getRangeAxisIndex(valueAxis50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean15 = categoryPlot4.removeRangeMarker(7, (org.jfree.chart.plot.Marker) valueMarker12, layer13, true);
        java.util.List list16 = categoryPlot4.getCategories();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(list16);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        java.awt.Paint paint15 = dateAxis1.getTickMarkPaint();
        dateAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.removeChangeListener(plotChangeListener8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(0, categoryItemRenderer11, false);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getRangeMarkers(layer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot20.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot20.setRangeAxisLocation((int) '#', axisLocation27);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str30 = plotOrientation29.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation27, plotOrientation29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation29);
        categoryPlot4.setRangeAxisLocation((int) (short) 1, axisLocation15, true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str30.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot22.zoomDomainAxes(0.0d, plotRenderingInfo26, point2D27);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot22.setRenderers(xYItemRendererArray29);
        java.awt.Paint paint31 = xYPlot22.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = null;
        categoryPlot4.setFixedLegendItems(legendItemCollection13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        double double17 = dateAxis16.getFixedDimension();
        boolean boolean19 = dateAxis16.isHiddenValue((-1L));
        dateAxis16.setAutoTickUnitSelection(true, true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot27.getRangeMarkers(layer30);
        boolean boolean32 = categoryPlot27.isDomainZoomable();
        categoryPlot27.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke35 = categoryPlot27.getRangeCrosshairStroke();
        boolean boolean36 = dateAxis16.equals((java.lang.Object) stroke35);
        int int37 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        double double38 = dateAxis16.getFixedAutoRange();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer();
        java.awt.Font font9 = null;
        try {
            categoryPlot4.setNoDataMessageFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getLastMillisecond();
//        java.util.Date date3 = day0.getEnd();
//        int int4 = day0.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Shape shape2 = dateAxis1.getLeftArrow();
//        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis1.getTickLabelInsets();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        long long6 = day4.getLastMillisecond();
//        java.util.Date date7 = day4.getEnd();
//        java.awt.geom.Rectangle2D rectangle2D8 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer16 = null;
//        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
//        org.jfree.chart.plot.Plot plot18 = categoryPlot13.getRootPlot();
//        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
//        org.jfree.chart.util.Layer layer22 = null;
//        boolean boolean23 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker21, layer22);
//        categoryPlot13.clearRangeMarkers();
//        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
//        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer34 = null;
//        java.util.Collection collection35 = categoryPlot31.getRangeMarkers(layer34);
//        org.jfree.chart.plot.Plot plot36 = categoryPlot31.getRootPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot31.setRangeAxisLocation((int) '#', axisLocation38);
//        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        java.lang.String str41 = plotOrientation40.toString();
//        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation38, plotOrientation40);
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation40);
//        categoryPlot13.setRangeAxisLocation(0, axisLocation26);
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot13.getRangeAxisEdge();
//        try {
//            double double46 = dateAxis1.dateToJava2D(date7, rectangle2D8, rectangleEdge45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(shape2);
//        org.junit.Assert.assertNotNull(rectangleInsets3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(rectangleEdge15);
//        org.junit.Assert.assertNull(collection17);
//        org.junit.Assert.assertNotNull(plot18);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(axisLocation26);
//        org.junit.Assert.assertNotNull(rectangleEdge33);
//        org.junit.Assert.assertNull(collection35);
//        org.junit.Assert.assertNotNull(plot36);
//        org.junit.Assert.assertNotNull(axisLocation38);
//        org.junit.Assert.assertNotNull(plotOrientation40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str41.equals("PlotOrientation.HORIZONTAL"));
//        org.junit.Assert.assertNotNull(rectangleEdge42);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertNotNull(rectangleEdge45);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape19 = dateAxis18.getLeftArrow();
        dateAxis1.setRightArrow(shape19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        double double23 = dateAxis22.getFixedDimension();
        double double24 = dateAxis22.getFixedDimension();
        dateAxis22.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double29 = rectangleInsets27.extendHeight((double) 10.0f);
        double double31 = rectangleInsets27.calculateRightInset((double) ' ');
        double double32 = rectangleInsets27.getTop();
        dateAxis22.setLabelInsets(rectangleInsets27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = null;
        dateAxis22.setTickUnit(dateTickUnit34);
        dateAxis22.setLowerBound((double) 10.0f);
        java.awt.Font font38 = dateAxis22.getLabelFont();
        dateAxis1.setTickLabelFont(font38);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 18.0d + "'", double29 == 18.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 8.0d + "'", double31 == 8.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        int int12 = categoryPlot4.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot17.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot17.zoomDomainAxes(0.05d, plotRenderingInfo24, point2D25);
        java.lang.Object obj27 = null;
        boolean boolean28 = categoryPlot17.equals(obj27);
        boolean boolean29 = categoryPlot4.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot17.getRenderer();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot4.getDomainAxis((-1));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        java.lang.String str5 = dateAxis1.getLabel();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        dateAxis11.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke23 = dateAxis11.getAxisLineStroke();
        double double24 = dateAxis11.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape27 = dateAxis26.getLeftArrow();
        dateAxis26.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        xYPlot31.clearDomainMarkers(0);
        java.awt.Color color36 = java.awt.Color.lightGray;
        int int37 = color36.getBlue();
        xYPlot31.setRangeTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot31.getRangeAxisEdge();
        try {
            java.util.List list40 = dateAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 192 + "'", int37 == 192);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot22.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        xYPlot22.setDomainCrosshairVisible(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation31 = null;
        try {
            boolean boolean33 = xYPlot22.removeAnnotation(xYAnnotation31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot4.setRenderer((int) ' ', categoryItemRenderer16);
        categoryPlot4.clearDomainMarkers();
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        java.awt.Stroke stroke15 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        int int23 = categoryPlot4.getDomainAxisCount();
        java.awt.Paint paint24 = categoryPlot4.getDomainGridlinePaint();
        categoryPlot4.setRangeCrosshairValue((double) 1L, true);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis29.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline32 = dateAxis29.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        categoryPlot39.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis34.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        dateAxis34.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke46 = dateAxis34.getAxisLineStroke();
        dateAxis34.setAutoRange(false);
        boolean boolean49 = dateAxis29.equals((java.lang.Object) dateAxis34);
        java.lang.Object obj50 = dateAxis29.clone();
        int int51 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeline32);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setRangeAxisLocation((int) '#', axisLocation11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        categoryPlot19.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        dateAxis14.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke26 = dateAxis14.getAxisLineStroke();
        int int27 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        categoryPlot4.mapDatasetToRangeAxis(192, 0);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
//        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
//        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
//        double double11 = dateAxis1.getLabelAngle();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
//        dateAxis1.setTickUnit(dateTickUnit12, false, true);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
//        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer24 = null;
//        java.util.Collection collection25 = categoryPlot21.getRangeMarkers(layer24);
//        org.jfree.chart.plot.Plot plot26 = categoryPlot21.getRootPlot();
//        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
//        org.jfree.chart.util.Layer layer30 = null;
//        boolean boolean31 = categoryPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker29, layer30);
//        categoryPlot21.clearRangeMarkers();
//        java.lang.Class<?> wildcardClass33 = categoryPlot21.getClass();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getSerialIndex();
//        long long36 = day34.getLastMillisecond();
//        java.util.Date date37 = day34.getEnd();
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
//        categoryPlot44.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
//        dateAxis39.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot44);
//        dateAxis39.setLowerMargin((double) (short) 10);
//        java.util.TimeZone timeZone51 = dateAxis39.getTimeZone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone51);
//        java.awt.geom.Rectangle2D rectangle2D53 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, valueAxis56, categoryItemRenderer57);
//        categoryPlot58.configureDomainAxes();
//        org.jfree.chart.plot.IntervalMarker intervalMarker62 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
//        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, valueAxis65, categoryItemRenderer66);
//        org.jfree.chart.util.RectangleEdge rectangleEdge69 = categoryPlot67.getDomainAxisEdge((int) (short) 0);
//        org.jfree.chart.util.Layer layer70 = null;
//        java.util.Collection collection71 = categoryPlot67.getRangeMarkers(layer70);
//        org.jfree.chart.plot.Plot plot72 = categoryPlot67.getRootPlot();
//        org.jfree.chart.plot.ValueMarker valueMarker75 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
//        org.jfree.chart.util.Layer layer76 = null;
//        boolean boolean77 = categoryPlot67.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker75, layer76);
//        categoryPlot67.clearRangeMarkers();
//        org.jfree.chart.plot.Marker marker79 = null;
//        org.jfree.chart.util.Layer layer80 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean81 = categoryPlot67.removeDomainMarker(marker79, layer80);
//        boolean boolean82 = categoryPlot58.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker62, layer80);
//        org.jfree.chart.util.RectangleEdge rectangleEdge84 = categoryPlot58.getRangeAxisEdge((int) (byte) 1);
//        try {
//            double double85 = dateAxis1.dateToJava2D(date37, rectangle2D53, rectangleEdge84);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertNull(dateTickUnit16);
//        org.junit.Assert.assertNotNull(rectangleEdge23);
//        org.junit.Assert.assertNull(collection25);
//        org.junit.Assert.assertNotNull(plot26);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43629L + "'", long35 == 43629L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560495599999L + "'", long36 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(rectangleEdge69);
//        org.junit.Assert.assertNull(collection71);
//        org.junit.Assert.assertNotNull(plot72);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(layer80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge84);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder23);
        xYPlot22.clearDomainMarkers(0);
        xYPlot22.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot22.setRenderer(xYItemRenderer29);
        java.awt.Color color31 = java.awt.Color.white;
        java.awt.Color color32 = color31.darker();
        xYPlot22.setDomainZeroBaselinePaint((java.awt.Paint) color31);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        try {
            xYPlot22.addAnnotation(xYAnnotation34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        java.awt.Font font23 = categoryPlot4.getNoDataMessageFont();
        categoryPlot4.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        dateAxis1.zoomRange((double) 0, 0.0d);
        dateAxis1.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        java.lang.String str5 = dateAxis1.getLabel();
        double double6 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Shape shape8 = dateAxis1.getRightArrow();
        dateAxis1.setAutoRangeMinimumSize((double) 1560495599999L, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        double double7 = rectangleInsets5.extendHeight((double) 1560538799999L);
        double double9 = rectangleInsets5.calculateBottomInset((double) 10.0f);
        double double11 = rectangleInsets5.calculateRightOutset(84.0d);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            rectangleInsets5.trim(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.560538800005E12d + "'", double7 == 1.560538800005E12d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList1.clear();
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, 1.0d, (double) (byte) -1, (double) 2, 2.0d);
        java.lang.String str10 = unitType4.toString();
        java.lang.String str11 = unitType4.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) 100, (double) 10L, (double) (short) 10, (double) 13);
        objectList1.set((int) 'a', (java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.RELATIVE" + "'", str10.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.RELATIVE" + "'", str11.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        categoryPlot4.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot4.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        double double3 = dateAxis1.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace11);
        java.awt.Paint paint13 = categoryPlot8.getRangeCrosshairPaint();
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) categoryPlot8);
        java.awt.Paint paint15 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot8.setRenderer((int) (short) 0, categoryItemRenderer17, false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace20, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        java.awt.Stroke stroke23 = dateAxis2.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        xYPlot22.mapDatasetToRangeAxis((-1), (int) (short) 100);
        java.awt.Paint paint26 = xYPlot22.getOutlinePaint();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot22.getDomainAxisForDataset(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 6 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getLabelPaint();
        java.lang.String str5 = dateAxis1.getLabel();
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot4.render(graphics2D11, rectangle2D12, (int) (short) -1, plotRenderingInfo14);
        java.lang.String str16 = categoryPlot4.getPlotType();
        boolean boolean17 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setWeight(2019);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot22.zoomDomainAxes((double) (short) -1, plotRenderingInfo46, point2D47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.CrosshairState crosshairState53 = null;
        boolean boolean54 = xYPlot22.render(graphics2D49, rectangle2D50, (int) (byte) -1, plotRenderingInfo52, crosshairState53);
        java.awt.Stroke stroke55 = xYPlot22.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        double double4 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        boolean boolean9 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder23);
        xYPlot22.clearDomainMarkers(0);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            xYPlot22.drawBackground(graphics2D27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean6 = dateAxis4.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        dateAxis9.setAutoRange(false);
        boolean boolean24 = dateAxis4.equals((java.lang.Object) dateAxis9);
        java.awt.Shape shape25 = dateAxis4.getLeftArrow();
        dateAxis1.setRightArrow(shape25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 4, (double) (short) 10, plotRenderingInfo13, point2D14);
        java.awt.Paint paint16 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        valueMarker18.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = valueMarker18.getLabelOffset();
        categoryPlot4.setInsets(rectangleInsets22);
        java.awt.Color color24 = java.awt.Color.WHITE;
        float[] floatArray31 = new float[] { 5, 1, '#', (short) 100, 8, 1L };
        float[] floatArray32 = color24.getRGBColorComponents(floatArray31);
        boolean boolean33 = categoryPlot4.equals((java.lang.Object) floatArray32);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = categoryPlot27.getRangeCrosshairPaint();
        categoryPlot4.setDomainGridlinePaint(paint32);
        categoryPlot4.setRangeCrosshairVisible(false);
        boolean boolean36 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(axisSpace39);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        double double7 = rectangleInsets5.extendHeight((double) 1560538799999L);
        double double9 = rectangleInsets5.calculateBottomInset((double) 10.0f);
        java.lang.String str10 = rectangleInsets5.toString();
        double double12 = rectangleInsets5.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.560538800005E12d + "'", double7 == 1.560538800005E12d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str10.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        int int11 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setCategoryMargin(8.0d);
        categoryAxis13.setMaximumCategoryLabelLines(0);
        int int18 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.clearCategoryLabelToolTips();
        double double20 = categoryAxis13.getUpperMargin();
        categoryPlot4.setDomainAxis(1, categoryAxis13, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot4.getDomainAxisEdge();
        float float24 = categoryPlot4.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color2 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) (byte) -1, (double) 2, 2.0d);
        java.lang.String str6 = unitType0.toString();
        java.lang.String str7 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, (double) 10L, (double) (short) 10, (double) 13);
        java.lang.String str13 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.RELATIVE" + "'", str7.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.RELATIVE" + "'", str13.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        int int11 = categoryPlot4.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray12);
        categoryPlot4.setForegroundAlpha((float) 0);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        double double18 = dateAxis17.getFixedDimension();
        double double19 = dateAxis17.getFixedDimension();
        dateAxis17.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double24 = rectangleInsets22.extendHeight((double) 10.0f);
        double double26 = rectangleInsets22.calculateRightInset((double) ' ');
        double double27 = rectangleInsets22.getTop();
        dateAxis17.setLabelInsets(rectangleInsets22);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis17.setTickUnit(dateTickUnit29);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot4.getLegendItems();
        boolean boolean33 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        try {
            boolean boolean36 = categoryPlot4.removeAnnotation(categoryAnnotation34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 18.0d + "'", double24 == 18.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis1.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        dateAxis6.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke18 = dateAxis6.getAxisLineStroke();
        dateAxis6.setAutoRange(false);
        boolean boolean21 = dateAxis1.equals((java.lang.Object) dateAxis6);
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = dateAxis1.getTickMarkPosition();
        dateAxis1.setLabelAngle(0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot4.zoomRangeAxes((double) (short) 0, plotRenderingInfo33, point2D34, false);
        float float37 = categoryPlot4.getBackgroundImageAlpha();
        java.awt.Paint paint38 = categoryPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot6.getRangeMarkers(layer9);
        org.jfree.chart.plot.Plot plot11 = categoryPlot6.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker14, layer15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str18 = layer17.toString();
        java.util.Collection collection19 = categoryPlot6.getRangeMarkers(layer17);
        java.awt.Paint paint20 = categoryPlot6.getRangeCrosshairPaint();
        valueMarker1.setOutlinePaint(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Layer.FOREGROUND" + "'", str18.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(paint20);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double2 = dateAxis1.getFixedDimension();
//        double double3 = dateAxis1.getFixedDimension();
//        dateAxis1.setAutoRange(true);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        long long8 = day6.getLastMillisecond();
//        java.util.Date date9 = day6.getEnd();
//        dateAxis1.setMaximumDate(date9);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot7.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot7.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot19.getRangeMarkers(layer22);
        boolean boolean24 = categoryPlot19.isDomainZoomable();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot31.getRangeMarkers(layer34);
        boolean boolean36 = categoryPlot31.isDomainZoomable();
        categoryPlot31.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getDomainAxisLocation((-1));
        categoryPlot19.setDomainAxisLocation(axisLocation40);
        categoryPlot7.setDomainAxisLocation(1, axisLocation40);
        objectList1.set(128, (java.lang.Object) categoryPlot7);
        java.awt.Stroke stroke44 = categoryPlot7.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        java.util.Date date15 = dateAxis1.getMinimumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets16.calculateLeftInset((double) (short) 100);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets16.getUnitType();
        dateAxis1.setLabelInsets(rectangleInsets16);
        boolean boolean22 = rectangleInsets16.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getFixedDimension();
        boolean boolean7 = dateAxis5.isAxisLineVisible();
        dateAxis5.setFixedDimension((double) (short) -1);
        dateAxis5.setVerticalTickLabels(false);
        java.awt.Shape shape12 = dateAxis5.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape15 = dateAxis14.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryPlot22.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        dateAxis17.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis17.setStandardTickUnits(tickUnitSource29);
        dateAxis17.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape35 = dateAxis34.getLeftArrow();
        dateAxis17.setRightArrow(shape35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape39 = dateAxis38.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getFixedDimension();
        boolean boolean43 = dateAxis41.isAxisLineVisible();
        dateAxis41.setFixedDimension((double) (short) -1);
        dateAxis41.setUpperBound((double) (short) 0);
        java.awt.Shape shape48 = dateAxis41.getLeftArrow();
        java.awt.Shape[] shapeArray49 = new java.awt.Shape[] { shape12, shape15, shape35, shape39, shape48 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray49);
        java.awt.Paint paint51 = defaultDrawingSupplier50.getNextFillPaint();
        java.lang.Object obj52 = defaultDrawingSupplier50.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shapeArray49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot22.setDomainTickBandPaint((java.awt.Paint) color24);
        java.awt.Color color27 = java.awt.Color.orange;
        try {
            xYPlot22.setQuadrantPaint((int) (byte) 10, (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot4.getDomainAxis(100);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        valueMarker12.setAlpha(0.0f);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker12, layer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setCategoryMargin(8.0d);
        categoryAxis19.setMaximumCategoryLabelLines(0);
        int int24 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.clearCategoryLabelToolTips();
        java.lang.String str26 = categoryAxis19.getLabelURL();
        categoryPlot4.setDomainAxis((int) (byte) 10, categoryAxis19, false);
        java.lang.Object obj29 = categoryAxis19.clone();
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) 4, (double) (short) 10, plotRenderingInfo13, point2D14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean19 = dateAxis17.isHiddenValue((long) (short) -1);
        java.awt.Paint paint20 = dateAxis17.getLabelPaint();
        java.lang.String str21 = dateAxis17.getLabel();
        org.jfree.data.Range range22 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis17);
        try {
            dateAxis17.setAutoRangeMinimumSize((double) (-12566273), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker11.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets15.createOutsetRectangle(rectangle2D16, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double11 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis1.setTickUnit(dateTickUnit12, false, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis1.getTickUnit();
        double double17 = dateAxis1.getUpperBound();
        double double18 = dateAxis1.getLowerMargin();
        dateAxis1.setLabelToolTip("SortOrder.ASCENDING");
        float float21 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.setDomainCrosshairValue((double) 11);
        xYPlot22.clearRangeAxes();
        java.awt.Stroke stroke47 = xYPlot22.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setAutoTickUnitSelection(true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date19 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit18);
        java.awt.Paint paint20 = dateAxis1.getTickLabelPaint();
        boolean boolean21 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        dateAxis6.setLowerMargin((double) (short) 10);
        dateAxis6.setAutoTickUnitSelection(true, true);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis6.setLabelFont(font21);
        categoryAxis0.setTickLabelFont(font21);
        int int24 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        categoryPlot32.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot41.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot41.getRangeMarkers(layer44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot41.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean51 = categoryPlot41.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker49, layer50);
        categoryPlot41.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker53 = null;
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean55 = categoryPlot41.removeDomainMarker(marker53, layer54);
        boolean boolean56 = categoryPlot32.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker36, layer54);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot32.getRangeAxisEdge((int) (byte) 1);
        try {
            java.util.List list59 = categoryAxis0.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        xYPlot22.mapDatasetToRangeAxis((-1), (int) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot30.getRangeMarkers(layer33);
        categoryPlot30.setOutlineVisible(false);
        int int37 = categoryPlot30.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray38 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray38);
        categoryPlot30.setForegroundAlpha((float) 0);
        java.lang.String str42 = categoryPlot30.getPlotType();
        org.jfree.data.general.Dataset dataset43 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot30, dataset43);
        xYPlot22.datasetChanged(datasetChangeEvent44);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = xYPlot22.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, categoryItemRenderer50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot51.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer54 = null;
        java.util.Collection collection55 = categoryPlot51.getRangeMarkers(layer54);
        categoryPlot51.setOutlineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis58 = categoryPlot51.getRangeAxis();
        java.awt.Paint paint59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot51.setOutlinePaint(paint59);
        xYPlot22.setRangeCrosshairPaint(paint59);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
        org.junit.Assert.assertNull(xYItemRenderer46);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((double) (short) 100);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 100.0f, (double) (short) 0, (double) (short) -1, 4.0d);
        double double10 = rectangleInsets8.calculateTopInset((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot16.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean26 = categoryPlot16.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker23, layer24, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker23.getLabelOffset();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = valueMarker23.getLabelOffsetType();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        valueMarker30.setLabel("");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = valueMarker30.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets8.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType28, lengthAdjustmentType34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(lengthAdjustmentType28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        java.lang.String str3 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getRangeMarkers(layer8);
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot5.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot19.getRangeMarkers(layer22);
        boolean boolean24 = categoryPlot19.isDomainZoomable();
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot19.getDomainAxisLocation((-1));
        categoryPlot5.setDomainAxisLocation(axisLocation28, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot5.setDomainAxis((int) (short) 10, categoryAxis32, true);
        boolean boolean35 = rectangleAnchor0.equals((java.lang.Object) categoryAxis32);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d, jFreeChart1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor3, jFreeChart4);
        java.lang.String str6 = chartChangeEvent5.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent5.setType(chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent5.getType();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor10, jFreeChart11);
        java.lang.String str13 = chartChangeEvent12.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent12.setType(chartChangeEventType14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot20.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker27, layer28, true);
        boolean boolean31 = chartChangeEventType14.equals((java.lang.Object) boolean30);
        chartChangeEvent5.setType(chartChangeEventType14);
        chartChangeEvent2.setType(chartChangeEventType14);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.CENTER]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.CENTER]"));
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.CENTER]" + "'", str13.equals("org.jfree.chart.event.ChartChangeEvent[source=TextAnchor.CENTER]"));
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        java.awt.Paint paint4 = dateAxis1.getTickLabelPaint();
        try {
            dateAxis1.setRangeWithMargins((double) 192, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (192.0) <= upper (35.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        java.awt.Paint paint6 = valueMarker1.getOutlinePaint();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot12.getRootPlot();
        boolean boolean18 = chartChangeEventType7.equals((java.lang.Object) categoryPlot12);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot12.getDomainAxis();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryAxis19);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot4.setDataset((int) (short) 1, categoryDataset11);
        categoryPlot4.clearRangeMarkers(255);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        java.lang.String str3 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str3.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1560495599999L, (double) 255, 18.0d, (double) 0.5f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        xYPlot22.mapDatasetToRangeAxis((-1), (int) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot30.getRangeMarkers(layer33);
        categoryPlot30.setOutlineVisible(false);
        int int37 = categoryPlot30.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray38 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray38);
        categoryPlot30.setForegroundAlpha((float) 0);
        java.lang.String str42 = categoryPlot30.getPlotType();
        org.jfree.data.general.Dataset dataset43 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot30, dataset43);
        xYPlot22.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = xYPlot22.isRangeZoomable();
        boolean boolean47 = xYPlot22.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker11.getLabelOffset();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = valueMarker11.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot21.setDomainAxis((int) (short) 1, categoryAxis25, false);
        int int28 = categoryPlot21.getDomainAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot21.setRenderer(100, categoryItemRenderer30);
        valueMarker11.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot21);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge((int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot16.getRangeMarkers(layer19);
        boolean boolean21 = categoryPlot16.isDomainZoomable();
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        boolean boolean33 = categoryPlot28.isDomainZoomable();
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot28.getDomainAxisLocation((-1));
        categoryPlot16.setDomainAxisLocation(axisLocation37);
        categoryPlot4.setRangeAxisLocation((int) '4', axisLocation37, false);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot45.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot45.getRangeMarkers(layer48);
        org.jfree.chart.plot.Plot plot50 = categoryPlot45.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation52 = categoryPlot45.getDomainAxisLocation((int) (short) 10);
        categoryPlot4.setDomainAxisLocation(axisLocation52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot4.setRenderer(categoryItemRenderer54, false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(plot50);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot4.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer12, true);
        java.lang.Object obj15 = null;
        boolean boolean16 = categoryPlot4.equals(obj15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot4.getRenderer();
        java.awt.Paint paint18 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        categoryPlot28.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        dateAxis23.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke35 = dateAxis23.getAxisLineStroke();
        double double36 = dateAxis23.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape39 = dateAxis38.getLeftArrow();
        dateAxis38.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer42);
        double double44 = xYPlot43.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot49.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = categoryPlot49.getRangeMarkers(layer52);
        org.jfree.chart.plot.Plot plot54 = categoryPlot49.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer58 = null;
        boolean boolean59 = categoryPlot49.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker57, layer58);
        categoryPlot49.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker61 = null;
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean63 = categoryPlot49.removeDomainMarker(marker61, layer62);
        java.util.Collection collection64 = xYPlot43.getRangeMarkers(layer62);
        try {
            categoryPlot4.addRangeMarker((int) (byte) 10, marker20, layer62, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNotNull(plot54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(collection64);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        java.text.DateFormat dateFormat5 = null;
        dateAxis1.setDateFormatOverride(dateFormat5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        categoryAxis7.addCategoryLabelToolTip((java.lang.Comparable) date8, "hi!");
        double double11 = categoryAxis7.getCategoryMargin();
        boolean boolean12 = dateAxis1.equals((java.lang.Object) categoryAxis7);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        java.awt.Color color16 = java.awt.Color.lightGray;
        int int17 = color16.getBlue();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor18, jFreeChart19);
        boolean boolean21 = color16.equals((java.lang.Object) textAnchor18);
        valueMarker14.setPaint((java.awt.Paint) color16);
        boolean boolean23 = dateAxis1.equals((java.lang.Object) valueMarker14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 192 + "'", int17 == 192);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot22.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot30.getRangeMarkers(layer33);
        categoryPlot30.setOutlineVisible(false);
        int int37 = categoryPlot30.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray38 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray38);
        categoryPlot30.setForegroundAlpha((float) 0);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        double double44 = dateAxis43.getFixedDimension();
        double double45 = dateAxis43.getFixedDimension();
        dateAxis43.setAutoRange(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double50 = rectangleInsets48.extendHeight((double) 10.0f);
        double double52 = rectangleInsets48.calculateRightInset((double) ' ');
        double double53 = rectangleInsets48.getTop();
        dateAxis43.setLabelInsets(rectangleInsets48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = null;
        dateAxis43.setTickUnit(dateTickUnit55);
        categoryPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot30.getLegendItems();
        xYPlot22.setFixedLegendItems(legendItemCollection58);
        org.jfree.chart.axis.ValueAxis valueAxis61 = xYPlot22.getRangeAxis((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray38);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 18.0d + "'", double50 == 18.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 8.0d + "'", double52 == 8.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 4.0d + "'", double53 == 4.0d);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertNull(valueAxis61);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot4.render(graphics2D11, rectangle2D12, (int) (short) -1, plotRenderingInfo14);
        java.lang.String str16 = categoryPlot4.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot4.setAxisOffset(rectangleInsets17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        categoryPlot28.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        dateAxis23.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke35 = dateAxis23.getAxisLineStroke();
        valueMarker21.setStroke(stroke35);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker21.setLabelOffsetType(lengthAdjustmentType37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        categoryPlot43.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot52.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer55 = null;
        java.util.Collection collection56 = categoryPlot52.getRangeMarkers(layer55);
        org.jfree.chart.plot.Plot plot57 = categoryPlot52.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer61 = null;
        boolean boolean62 = categoryPlot52.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker60, layer61);
        categoryPlot52.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker64 = null;
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean66 = categoryPlot52.removeDomainMarker(marker64, layer65);
        boolean boolean67 = categoryPlot43.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker47, layer65);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType68 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker47.setLabelOffsetType(lengthAdjustmentType68);
        try {
            java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets17.createAdjustedRectangle(rectangle2D19, lengthAdjustmentType37, lengthAdjustmentType68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertNotNull(plot57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType68);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        boolean boolean15 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str12 = categoryAnchor11.toString();
        categoryPlot4.setDomainGridlinePosition(categoryAnchor11);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str12.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        java.util.Date date4 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke13 = dateAxis1.getAxisLineStroke();
        dateAxis1.setAutoRange(false);
        java.awt.Shape shape16 = dateAxis1.getUpArrow();
        java.util.Date date17 = dateAxis1.getMaximumDate();
        java.awt.Color color18 = java.awt.Color.YELLOW;
        dateAxis1.setLabelPaint((java.awt.Paint) color18);
        int int20 = color18.getTransparency();
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        categoryPlot4.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace23);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot20.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker27, layer28, true);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        valueMarker27.setLabelPaint(paint31);
        boolean boolean33 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint36 = valueMarker35.getPaint();
        valueMarker35.setLabel("");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = valueMarker35.getLabelOffsetType();
        java.lang.Class<?> wildcardClass40 = lengthAdjustmentType39.getClass();
        valueMarker27.setLabelOffsetType(lengthAdjustmentType39);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType39);
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        dateAxis1.setFixedDimension((double) (short) -1);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Shape shape8 = dateAxis1.getRightArrow();
        java.awt.Paint paint9 = dateAxis1.getAxisLinePaint();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = dateAxis1.draw(graphics2D10, (double) 8, rectangle2D12, rectangle2D13, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        double double3 = dateAxis2.getFixedDimension();
        boolean boolean4 = dateAxis2.isAxisLineVisible();
        dateAxis2.setFixedDimension((double) (short) -1);
        dateAxis2.setVerticalTickLabels(false);
        java.awt.Shape shape9 = dateAxis2.getRightArrow();
        java.awt.Paint paint10 = dateAxis2.getAxisLinePaint();
        dateAxis2.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        categoryPlot19.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        double double24 = dateAxis14.getLabelAngle();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis14.setTickUnit(dateTickUnit25, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition29 = dateAxis14.getTickMarkPosition();
        double double30 = dateAxis14.getLowerBound();
        boolean boolean31 = dateAxis14.isAutoTickUnitSelection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot13.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker21, layer22);
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = categoryPlot13.removeDomainMarker(marker25, layer26);
        boolean boolean28 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer26);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker8.setLabelOffsetType(lengthAdjustmentType29);
        intervalMarker8.setEndValue((double) (byte) -1);
        double double33 = intervalMarker8.getStartValue();
        intervalMarker8.setStartValue(0.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer36 = null;
        intervalMarker8.setGradientPaintTransformer(gradientPaintTransformer36);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot22.getDomainAxisLocation();
        int int26 = xYPlot22.getDatasetCount();
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot22.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot22.getLegendItems();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.Class<?> wildcardClass2 = datasetRenderingOrder0.getClass();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot22.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot22.zoomDomainAxes((double) (short) 1, plotRenderingInfo30, point2D31, false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getDomainAxisLocation((-1));
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot18.getRangeMarkers(layer21);
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((-1));
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot36.getRangeMarkers(layer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot36.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot36.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker44, layer45);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker44.getLabelTextAnchor();
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        categoryPlot4.clearDomainMarkers();
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection51 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation52 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNull(legendItemCollection51);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot4.setDomainAxis((int) (short) 1, categoryAxis8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot4.setDomainAxis(192, categoryAxis12);
        categoryPlot4.setAnchorValue((double) 0L, true);
        java.lang.String str17 = categoryPlot4.getPlotType();
        java.awt.Image image18 = null;
        categoryPlot4.setBackgroundImage(image18);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot22.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.05d);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot13.getRangeMarkers(layer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot13.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker21, layer22);
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = categoryPlot13.removeDomainMarker(marker25, layer26);
        boolean boolean28 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer26);
        double double29 = intervalMarker8.getEndValue();
        intervalMarker8.setEndValue(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Color color2 = java.awt.Color.getColor("Layer.FOREGROUND", 0);
        int int3 = color2.getBlue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot22.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        xYPlot22.clearRangeMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot22.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(legendItemCollection30);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        valueMarker1.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis0.getLabelInsets();
        categoryAxis0.setLabelToolTip("Category Plot");
        categoryAxis0.setFixedDimension((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        dateAxis1.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource13);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape19 = dateAxis18.getLeftArrow();
        dateAxis1.setRightArrow(shape19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis22.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline25 = dateAxis22.getTimeline();
        dateAxis1.setTimeline(timeline25);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeline25);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        dateAxis3.setLowerMargin((double) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint17 = valueMarker16.getPaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker16.setPaint((java.awt.Paint) color18);
        dateAxis3.setTickMarkPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        categoryPlot27.setWeight(5);
        java.awt.Stroke stroke30 = categoryPlot27.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) 3, (java.awt.Paint) color18, stroke21, (java.awt.Paint) color22, stroke30, (float) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean4 = dateAxis1.isHiddenValue((-1L));
        double double5 = dateAxis1.getLowerBound();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        dateAxis9.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke21 = dateAxis9.getAxisLineStroke();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange22);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange22, false, true);
        java.lang.String str27 = dateAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        boolean boolean9 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setDrawSharedDomainAxis(true);
        java.awt.Stroke stroke12 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.05d);
        boolean boolean15 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker14);
        try {
            valueMarker14.setAlpha((float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        double double23 = xYPlot22.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot28.getRangeMarkers(layer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot28.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot28.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer37);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot28.removeDomainMarker(marker40, layer41);
        java.util.Collection collection43 = xYPlot22.getRangeMarkers(layer41);
        xYPlot22.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot22.zoomDomainAxes((double) (short) -1, plotRenderingInfo46, point2D47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.CrosshairState crosshairState53 = null;
        boolean boolean54 = xYPlot22.render(graphics2D49, rectangle2D50, (int) (byte) -1, plotRenderingInfo52, crosshairState53);
        xYPlot22.setDomainCrosshairValue((double) 10.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomRangeAxes((double) 0L, plotRenderingInfo24, point2D25);
        xYPlot22.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setCategoryMargin(8.0d);
        categoryPlot4.setDomainAxis(categoryAxis9);
        categoryAxis9.setCategoryMargin(100.0d);
        java.lang.String str16 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) 10.0f);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        categoryPlot29.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis24.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        dateAxis24.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke36 = dateAxis24.getAxisLineStroke();
        double double37 = dateAxis24.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape40 = dateAxis39.getLeftArrow();
        dateAxis39.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        xYPlot44.zoomDomainAxes(0.0d, (double) (byte) 0, plotRenderingInfo47, point2D48);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYPlot44.rendererChanged(rendererChangeEvent50);
        java.awt.geom.Point2D point2D52 = xYPlot44.getQuadrantOrigin();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot44.getDomainAxisEdge((-1));
        try {
            double double55 = categoryAxis9.getCategorySeriesMiddle((java.lang.Comparable) 0.2d, (java.lang.Comparable) 192, categoryDataset19, 1.560452399991E12d, rectangle2D21, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot22.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        double double29 = xYPlot22.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot22.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot22.setRenderer(xYItemRenderer31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot22.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        boolean boolean2 = seriesRenderingOrder0.equals((java.lang.Object) 1L);
        java.lang.String str3 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str3.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot22.getRangeAxisLocation(10);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot22.getDomainAxisLocation();
        int int26 = xYPlot22.getDatasetCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot22.getRenderer((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot22.getRangeAxis(11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNull(valueAxis30);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getFixedDimension();
        boolean boolean26 = dateAxis24.isAxisLineVisible();
        dateAxis24.setFixedDimension((double) (short) -1);
        dateAxis24.setVerticalTickLabels(false);
        java.awt.Shape shape31 = dateAxis24.getRightArrow();
        java.awt.Paint paint32 = dateAxis24.getAxisLinePaint();
        int int33 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot22.getDataset();
        java.awt.Stroke stroke35 = xYPlot22.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot22.zoomDomainAxes((double) 10.0f, plotRenderingInfo37, point2D38);
        boolean boolean40 = xYPlot22.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot22.indexOf(xYDataset41);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        dateAxis2.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke14 = dateAxis2.getAxisLineStroke();
        double double15 = dateAxis2.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape18 = dateAxis17.getLeftArrow();
        dateAxis17.resizeRange((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot22.zoomDomainAxes(0.0d, (double) (byte) 0, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot22.setFixedRangeAxisSpace(axisSpace28, false);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            xYPlot22.drawBackground(graphics2D31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin(8.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        double double4 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(1, categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot12.getRangeMarkers(layer15);
        categoryPlot12.setOutlineVisible(false);
        int int19 = categoryPlot12.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray20);
        categoryPlot4.setRenderers(categoryItemRendererArray20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = categoryPlot27.getRangeCrosshairPaint();
        categoryPlot4.setDomainGridlinePaint(paint32);
        java.awt.Font font34 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot4.getDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        categoryPlot4.addChangeListener(plotChangeListener36);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(categoryAxis35);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot4.render(graphics2D11, rectangle2D12, (int) (short) -1, plotRenderingInfo14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot20.getRangeMarkers(layer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot20.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean31 = categoryPlot20.removeRangeMarker(7, (org.jfree.chart.plot.Marker) valueMarker28, layer29, true);
        java.util.Collection collection32 = categoryPlot4.getDomainMarkers(layer29);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot4.getOrientation();
        java.lang.String str34 = categoryPlot4.getPlotType();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Category Plot" + "'", str34.equals("Category Plot"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getFixedDimension();
        boolean boolean7 = dateAxis5.isAxisLineVisible();
        dateAxis5.setFixedDimension((double) (short) -1);
        dateAxis5.setVerticalTickLabels(false);
        java.awt.Shape shape12 = dateAxis5.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape15 = dateAxis14.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryPlot22.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        dateAxis17.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis17.setStandardTickUnits(tickUnitSource29);
        dateAxis17.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape35 = dateAxis34.getLeftArrow();
        dateAxis17.setRightArrow(shape35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Shape shape39 = dateAxis38.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getFixedDimension();
        boolean boolean43 = dateAxis41.isAxisLineVisible();
        dateAxis41.setFixedDimension((double) (short) -1);
        dateAxis41.setUpperBound((double) (short) 0);
        java.awt.Shape shape48 = dateAxis41.getLeftArrow();
        java.awt.Shape[] shapeArray49 = new java.awt.Shape[] { shape12, shape15, shape35, shape39, shape48 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray49);
        java.awt.Paint paint51 = defaultDrawingSupplier50.getNextFillPaint();
        java.awt.Shape shape52 = defaultDrawingSupplier50.getNextShape();
        java.awt.Stroke stroke53 = defaultDrawingSupplier50.getNextStroke();
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, valueAxis56, categoryItemRenderer57);
        categoryPlot58.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot58.setRangeCrosshairPaint((java.awt.Paint) color62);
        boolean boolean64 = defaultDrawingSupplier50.equals((java.lang.Object) color62);
        java.awt.Paint paint65 = defaultDrawingSupplier50.getNextPaint();
        try {
            java.awt.Stroke stroke66 = defaultDrawingSupplier50.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shapeArray49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis1.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) (short) 10);
        dateAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        dateAxis6.setLowerMargin((double) (short) 10);
        java.awt.Stroke stroke18 = dateAxis6.getAxisLineStroke();
        dateAxis6.setAutoRange(false);
        boolean boolean21 = dateAxis1.equals((java.lang.Object) dateAxis6);
        dateAxis1.setUpperBound((double) (short) 10);
        dateAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        categoryPlot4.setOutlineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot4.getRangeAxis();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot4.setOutlinePaint(paint12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot19.getRangeMarkers(layer22);
        boolean boolean24 = categoryPlot19.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray25 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot19.setDomainAxes(categoryAxisArray25);
        int int27 = categoryPlot19.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        categoryPlot19.setFixedLegendItems(legendItemCollection28);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot19.setColumnRenderingOrder(sortOrder30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot19.getRangeAxisLocation((-16777216));
        categoryPlot4.setDomainAxisLocation((int) (short) 10, axisLocation33, false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot4.getRangeMarkers(layer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setRangeAxisLocation((int) '#', axisLocation11);
        java.awt.Paint paint13 = categoryPlot4.getBackgroundPaint();
        int int14 = categoryPlot4.getWeight();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList1.clear();
        objectList1.clear();
        int int4 = objectList1.size();
        objectList1.clear();
        java.lang.Object obj7 = objectList1.get(6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(obj7);
    }
}

