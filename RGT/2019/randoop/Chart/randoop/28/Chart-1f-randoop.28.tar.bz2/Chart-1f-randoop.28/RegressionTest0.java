import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity2 = new org.jfree.chart.entity.PlotEntity(shape0, plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float[] floatArray5 = new float[] { 0L, (-1L) };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB(0, (int) (short) 10, (int) (byte) 0, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo2 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) 1.0d, dataset1, datasetChangeInfo2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.lang.Class<?> wildcardClass1 = paintArray0.getClass();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            barRenderer0.drawBackground(graphics2D1, categoryPlot2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        try {
            java.lang.Number number7 = defaultCategoryDataset0.getValue((java.lang.Comparable) 100.0f, (java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            defaultCategoryDataset0.removeRow(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.setValue((double) 1.0f, (java.lang.Comparable) (byte) 0, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        barRenderer0.setItemLabelAnchorOffset(0.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((-14336), categoryItemLabelGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            double double14 = barRenderer0.getItemMiddle((java.lang.Comparable) 0, (java.lang.Comparable) 100L, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Paint paint20 = null;
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "", shape19, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer12.drawRangeMarker(graphics2D13, categoryPlot14, valueAxis15, marker16, rectangle2D17);
        java.awt.Stroke stroke22 = barRenderer12.getItemStroke((-1), 100, true);
        try {
            barRenderer0.setSeriesOutlineStroke((-1), stroke22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getShadowsVisible();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D8, rectangle2D9, categoryAxis10, valueAxis11, layer12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        boolean boolean14 = barRenderer0.isItemLabelVisible(8, (int) (short) 0, true);
        boolean boolean15 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            barRenderer0.drawOutline(graphics2D11, categoryPlot12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        try {
            defaultCategoryDataset0.removeRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(0, (int) '#', false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getSeriesToolTipGenerator(8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        try {
            barRenderer0.setSeriesItemLabelFont((-1), font13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        java.awt.Paint paint5 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer0.getSeriesToolTipGenerator((-14336));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color3 = java.awt.Color.orange;
        float[] floatArray10 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray11 = color3.getColorComponents(floatArray10);
        float[] floatArray12 = color2.getComponents(floatArray10);
        try {
            float[] floatArray13 = color0.getComponents(colorSpace1, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean4 = datasetGroup1.equals((java.lang.Object) standardGradientPaintTransformer3);
        java.awt.GradientPaint gradientPaint5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        try {
            java.awt.GradientPaint gradientPaint25 = standardGradientPaintTransformer3.transform(gradientPaint5, shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj5 = defaultCategoryDataset0.clone();
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj5 = defaultCategoryDataset0.clone();
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((java.lang.Comparable) 8.0d, (java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (8.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible(8, true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D6, rectangle2D7, categoryAxis8, valueAxis9, layer10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer6.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        barRenderer10.drawRangeMarker(graphics2D11, categoryPlot12, valueAxis13, marker14, rectangle2D15);
        boolean boolean20 = barRenderer10.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean21 = barRenderer10.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape25 = barRenderer10.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape25, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer6.setSeriesShape((int) '4', shape25, true);
        java.awt.Color color31 = java.awt.Color.gray;
        java.awt.Stroke stroke32 = null;
        java.awt.Color color36 = java.awt.Color.getHSBColor((float) ' ', (float) '#', (float) (short) 1);
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "rect", "rect", "", shape25, (java.awt.Paint) color31, stroke32, (java.awt.Paint) color36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 10L, 0.0f, (float) ' ');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        boolean boolean5 = barRenderer0.getShadowsVisible();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape14 = barRenderer0.getLegendShape(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition(1, itemLabelPosition17, false);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D31 = barRenderer0.createHotSpotBounds(graphics2D20, rectangle2D21, categoryPlot22, categoryAxis23, valueAxis24, categoryDataset25, 64, (int) (short) 10, true, categoryItemRendererState29, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer2.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint8 = barRenderer2.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        boolean boolean19 = barRenderer9.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean20 = barRenderer9.getBaseSeriesVisibleInLegend();
        boolean boolean21 = barRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        barRenderer22.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis25, marker26, rectangle2D27);
        java.awt.Shape shape30 = barRenderer22.getLegendShape((int) (short) 0);
        barRenderer22.setShadowXOffset((double) 100.0f);
        boolean boolean36 = barRenderer22.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer22.setBaseLegendTextFont(font37);
        barRenderer9.setBaseLegendTextFont(font37);
        barRenderer2.setBaseItemLabelFont(font37, true);
        try {
            renderAttributes0.setSeriesLabelFont((int) (short) 10, font37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.removeColumn((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            double double5 = categoryAxis0.getCategoryMiddle(255, 0, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 255");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation4, plotOrientation5);
        try {
            java.util.List list7 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color22 = color21.darker();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color22);
        barRenderer0.setShadowPaint((java.awt.Paint) color22);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation25, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation4, plotOrientation5);
        try {
            double double7 = categoryAxis0.getCategoryStart((int) (short) 10, 8, rectangle2D3, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        barRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis11, marker12, rectangle2D13);
        boolean boolean18 = barRenderer8.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint20 = barRenderer8.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape22 = barRenderer8.getLegendShape(100);
        java.awt.Shape shape23 = barRenderer8.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color25 = java.awt.Color.orange;
        float[] floatArray32 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray33 = color25.getColorComponents(floatArray32);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape23, stroke24, (java.awt.Paint) color25);
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color36 = color35.darker();
        int int37 = color35.getAlpha();
        try {
            org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem(attributedString0, "", "rect", "DatasetRenderingOrder.FORWARD", shape23, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer10.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        barRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis17, marker18, rectangle2D19);
        boolean boolean24 = barRenderer14.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean25 = barRenderer14.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape29 = barRenderer14.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape29, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer10.setSeriesShape((int) '4', shape29, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        barRenderer35.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition37, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = barRenderer35.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer35.setBaseStroke(stroke41);
        java.awt.Color color44 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color45 = color44.darker();
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color45);
        java.awt.Paint paint47 = legendItem46.getFillPaint();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "", "rect", "TextAnchor.TOP_CENTER", shape29, stroke41, paint47);
        java.awt.Color color49 = java.awt.Color.GREEN;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Color color54 = java.awt.Color.getHSBColor((float) ' ', (float) '#', (float) (short) 1);
        try {
            org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "GradientPaintTransformType.CENTER_HORIZONTAL", "DatasetRenderingOrder.FORWARD", shape29, (java.awt.Paint) color49, stroke50, (java.awt.Paint) color54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color1 = java.awt.Color.getColor("TextAnchor.TOP_CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setUseSeriesOffset(false);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        barRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis11, marker12, rectangle2D13);
        boolean boolean18 = barRenderer8.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean19 = barRenderer8.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset20.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj25 = defaultCategoryDataset20.clone();
        org.jfree.data.Range range26 = barRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer2.initialise(graphics2D5, rectangle2D6, categoryPlot7, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((java.lang.Comparable) false, (java.lang.Comparable) (-14336));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (false) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color2 = java.awt.Color.getColor("", 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape19, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer29.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.Marker marker37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        barRenderer33.drawRangeMarker(graphics2D34, categoryPlot35, valueAxis36, marker37, rectangle2D38);
        boolean boolean43 = barRenderer33.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean44 = barRenderer33.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape48 = barRenderer33.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity(shape48, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer29.setSeriesShape((int) '4', shape48, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer54 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = null;
        barRenderer54.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition56, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = barRenderer54.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer54.setBaseStroke(stroke60);
        java.awt.Color color63 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color64 = color63.darker();
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color64);
        java.awt.Paint paint66 = legendItem65.getFillPaint();
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "", "rect", "TextAnchor.TOP_CENTER", shape48, stroke60, paint66);
        org.jfree.chart.renderer.category.BarRenderer barRenderer68 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        barRenderer68.drawRangeMarker(graphics2D69, categoryPlot70, valueAxis71, marker72, rectangle2D73);
        java.awt.Color color75 = java.awt.Color.orange;
        int int76 = color75.getRGB();
        barRenderer68.setBaseFillPaint((java.awt.Paint) color75, false);
        org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "TextAnchor.TOP_CENTER", shape19, stroke60, (java.awt.Paint) color75);
        org.jfree.chart.plot.Plot plot80 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity82 = new org.jfree.chart.entity.PlotEntity(shape19, plot80, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(itemLabelPosition59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-14336) + "'", int76 == (-14336));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("org.jfree.data.UnknownKeyException: ");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape21 = barRenderer13.getLegendShape((int) (short) 0);
        barRenderer13.setShadowXOffset((double) 100.0f);
        boolean boolean27 = barRenderer13.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer13.setBaseLegendTextFont(font28);
        barRenderer0.setBaseLegendTextFont(font28);
        int int31 = barRenderer0.getRowCount();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener32 = null;
        try {
            barRenderer0.removeChangeListener(rendererChangeListener32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        boolean boolean16 = barRenderer0.isSeriesVisible(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        barRenderer17.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition19, true);
        barRenderer17.setItemLabelAnchorOffset(0.0d);
        java.awt.Font font27 = barRenderer17.getItemLabelFont((int) '4', (int) (short) -1, false);
        barRenderer0.setBaseItemLabelFont(font27);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        boolean boolean2 = paintList0.equals((java.lang.Object) (-1.0d));
        java.awt.Color color4 = java.awt.Color.orange;
        int int5 = color4.getRGB();
        paintList0.setPaint((int) (short) 10, (java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-14336) + "'", int5 == (-14336));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer31.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        barRenderer35.drawRangeMarker(graphics2D36, categoryPlot37, valueAxis38, marker39, rectangle2D40);
        boolean boolean45 = barRenderer35.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean46 = barRenderer35.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape50 = barRenderer35.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity(shape50, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer31.setSeriesShape((int) '4', shape50, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = null;
        barRenderer56.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition58, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = barRenderer56.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer56.setBaseStroke(stroke62);
        java.awt.Color color65 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color66 = color65.darker();
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color66);
        java.awt.Paint paint68 = legendItem67.getFillPaint();
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "", "rect", "TextAnchor.TOP_CENTER", shape50, stroke62, paint68);
        org.jfree.chart.renderer.category.BarRenderer barRenderer70 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.plot.Marker marker74 = null;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        barRenderer70.drawRangeMarker(graphics2D71, categoryPlot72, valueAxis73, marker74, rectangle2D75);
        java.awt.Color color77 = java.awt.Color.orange;
        int int78 = color77.getRGB();
        barRenderer70.setBaseFillPaint((java.awt.Paint) color77, false);
        org.jfree.chart.LegendItem legendItem81 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "TextAnchor.TOP_CENTER", shape21, stroke62, (java.awt.Paint) color77);
        try {
            shapeList0.setShape((int) (byte) -1, shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(itemLabelPosition61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-14336) + "'", int78 == (-14336));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint13 = barRenderer0.lookupSeriesPaint((int) '#');
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setUpperMargin((double) (byte) 0);
        categoryAxis18.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            barRenderer0.drawItem(graphics2D14, categoryItemRendererState15, rectangle2D16, categoryPlot17, categoryAxis18, valueAxis23, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, 255, (int) 'a', false, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer0.getSeriesURLGenerator(0);
        org.jfree.chart.LegendItem legendItem16 = barRenderer0.getLegendItem(1, (int) ' ');
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNull(legendItem16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        barRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis11, marker12, rectangle2D13);
        boolean boolean18 = barRenderer8.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean19 = barRenderer8.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape23 = barRenderer8.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "TextAnchor.TOP_CENTER", "");
        try {
            barRenderer0.setSeriesShape((-1), shape23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(8);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        java.lang.Comparable comparable3 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getBlue();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("org.jfree.data.UnknownKeyException: ", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean21 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setSeriesShapesFilled(8, (java.lang.Boolean) false);
        java.util.EventListener eventListener25 = null;
        boolean boolean26 = lineAndShapeRenderer2.hasListener(eventListener25);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer0.getSeriesURLGenerator((-1));
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        boolean boolean23 = barRenderer13.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean24 = barRenderer13.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape28 = barRenderer13.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape28, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer38.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.plot.Marker marker46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        barRenderer42.drawRangeMarker(graphics2D43, categoryPlot44, valueAxis45, marker46, rectangle2D47);
        boolean boolean52 = barRenderer42.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean53 = barRenderer42.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape57 = barRenderer42.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity60 = new org.jfree.chart.entity.ChartEntity(shape57, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer38.setSeriesShape((int) '4', shape57, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        barRenderer63.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition65, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = barRenderer63.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer63.setBaseStroke(stroke69);
        java.awt.Color color72 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color73 = color72.darker();
        org.jfree.chart.LegendItem legendItem74 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color73);
        java.awt.Paint paint75 = legendItem74.getFillPaint();
        org.jfree.chart.LegendItem legendItem76 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "", "rect", "TextAnchor.TOP_CENTER", shape57, stroke69, paint75);
        org.jfree.chart.renderer.category.BarRenderer barRenderer77 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = null;
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.plot.Marker marker81 = null;
        java.awt.geom.Rectangle2D rectangle2D82 = null;
        barRenderer77.drawRangeMarker(graphics2D78, categoryPlot79, valueAxis80, marker81, rectangle2D82);
        java.awt.Color color84 = java.awt.Color.orange;
        int int85 = color84.getRGB();
        barRenderer77.setBaseFillPaint((java.awt.Paint) color84, false);
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "TextAnchor.TOP_CENTER", shape28, stroke69, (java.awt.Paint) color84);
        barRenderer0.setShadowPaint((java.awt.Paint) color84);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNull(itemLabelPosition68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-14336) + "'", int85 == (-14336));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        boolean boolean13 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean14 = barRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape18 = barRenderer3.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "TextAnchor.TOP_CENTER", "");
        renderAttributes0.setDefaultShape(shape18);
        org.jfree.chart.plot.Plot plot23 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape18, plot23, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        java.lang.String str19 = chartEntity18.getShapeType();
        java.lang.Object obj20 = chartEntity18.clone();
        chartEntity18.setURLText("GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer7.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer11.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        boolean boolean21 = barRenderer11.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean22 = barRenderer11.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape26 = barRenderer11.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape26, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer7.setSeriesShape((int) '4', shape26, true);
        java.awt.Paint paint33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        barRenderer35.drawRangeMarker(graphics2D36, categoryPlot37, valueAxis38, marker39, rectangle2D40);
        boolean boolean45 = barRenderer35.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean46 = barRenderer35.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape50 = barRenderer35.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer35.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer35.setSeriesPaint(0, (java.awt.Paint) color56, false);
        java.awt.Stroke stroke59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer61 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.plot.Marker marker65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        barRenderer61.drawRangeMarker(graphics2D62, categoryPlot63, valueAxis64, marker65, rectangle2D66);
        boolean boolean71 = barRenderer61.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint73 = barRenderer61.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape75 = barRenderer61.getLegendShape(100);
        java.awt.Shape shape76 = barRenderer61.getBaseShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer77 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition79 = null;
        barRenderer77.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition79, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition82 = barRenderer77.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke83 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer77.setBaseStroke(stroke83);
        java.awt.Color color85 = java.awt.Color.orange;
        float[] floatArray92 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray93 = color85.getColorComponents(floatArray92);
        try {
            org.jfree.chart.LegendItem legendItem94 = new org.jfree.chart.LegendItem(attributedString0, "rect", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", false, shape26, true, paint33, false, (java.awt.Paint) color56, stroke59, false, shape76, stroke83, (java.awt.Paint) color85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(paint73);
        org.junit.Assert.assertNull(shape75);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNull(itemLabelPosition82);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(floatArray92);
        org.junit.Assert.assertNotNull(floatArray93);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        try {
            barRenderer0.setMinimumBarLength((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'min' >= 0.0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color2 = color1.brighter();
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint6 = renderAttributes0.getItemOutlinePaint(8, 0);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        try {
            renderAttributes0.setSeriesFillPaint((-14336), (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint16 = barRenderer4.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape18 = barRenderer4.getLegendShape(100);
        java.awt.Shape shape19 = barRenderer4.getBaseShape();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color21 = java.awt.Color.orange;
        float[] floatArray28 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray29 = color21.getColorComponents(floatArray28);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape19, stroke20, (java.awt.Paint) color21);
        org.jfree.chart.plot.Plot plot31 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity(shape19, plot31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        boolean boolean18 = barRenderer6.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        barRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis22, marker23, rectangle2D24);
        java.awt.Shape shape27 = barRenderer19.getLegendShape((int) (short) 0);
        barRenderer19.setShadowXOffset((double) 100.0f);
        boolean boolean33 = barRenderer19.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer19.setBaseLegendTextFont(font34);
        barRenderer6.setBaseLegendTextFont(font34);
        try {
            renderAttributes0.setSeriesLabelFont((int) (short) -1, font34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        java.lang.String str19 = chartEntity18.getShapeType();
        java.lang.String str20 = chartEntity18.getShapeType();
        java.lang.String str21 = chartEntity18.toString();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartEntity: tooltip = TextAnchor.TOP_CENTER" + "'", str21.equals("ChartEntity: tooltip = TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer0.getItemCreateEntity((int) ' ', (int) ' ', false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        boolean boolean15 = barRenderer0.getItemCreateEntity(255, (int) (byte) -1, true);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getShadowsVisible();
        barRenderer0.setSeriesItemLabelsVisible(0, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset14.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = barRenderer0.initialise(graphics2D11, rectangle2D12, categoryPlot13, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "rect");
        boolean boolean5 = categoryAxis0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer0.getSeriesURLGenerator(0);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        int int20 = categoryAxis19.getMaximumCategoryLabelLines();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 64);
        java.awt.Paint paint24 = categoryAxis19.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        barRenderer25.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition27, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = barRenderer25.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer25.setBaseStroke(stroke31);
        try {
            barRenderer0.drawRangeLine(graphics2D14, categoryPlot15, valueAxis16, rectangle2D17, (double) (byte) 0, paint24, stroke31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color3 = color2.darker();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendItem4.getFillPaint();
        java.lang.Object obj6 = legendItem4.clone();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem4.setLinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator12 = new org.jfree.chart.util.DefaultShadowGenerator(0, color7, (float) 8, (int) (short) -1, (double) (byte) 100);
        java.awt.image.BufferedImage bufferedImage13 = null;
        try {
            java.awt.image.BufferedImage bufferedImage14 = defaultShadowGenerator12.createDropShadow(bufferedImage13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            defaultCategoryDataset0.setSelected(100, (int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        double double13 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator14);
        java.awt.Stroke stroke16 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightOutset((double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        boolean boolean13 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean14 = barRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape18 = barRenderer3.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "TextAnchor.TOP_CENTER", "");
        renderAttributes0.setDefaultShape(shape18);
        java.awt.Color color23 = java.awt.Color.blue;
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color23);
        try {
            java.awt.Paint paint26 = renderAttributes0.getSeriesLabelPaint((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Stroke stroke13 = barRenderer0.getSeriesStroke(0);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        barRenderer0.setShadowYOffset(1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        int int27 = lineAndShapeRenderer2.getDefaultEntityRadius();
        boolean boolean30 = lineAndShapeRenderer2.getItemLineVisible(0, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 100, stroke8);
        java.awt.Paint paint13 = barRenderer0.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis18, marker19, rectangle2D20);
        boolean boolean25 = barRenderer15.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean26 = barRenderer15.getBaseSeriesVisibleInLegend();
        barRenderer15.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer15.getSeriesNegativeItemLabelPosition((int) 'a');
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition32);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean35 = itemLabelPosition32.equals((java.lang.Object) itemLabelAnchor34);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        java.lang.Boolean boolean17 = barRenderer0.getSeriesCreateEntities(2);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisible((int) '#', (java.lang.Boolean) false);
        barRenderer0.clearSeriesPaints(true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color1 = java.awt.Color.getColor("GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getShadowsVisible();
        barRenderer0.setBaseCreateEntities(true, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener20 = null;
        try {
            lineAndShapeRenderer2.addChangeListener(rendererChangeListener20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ChartEntity: tooltip = TextAnchor.TOP_CENTER", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisible((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener15 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setUseSeriesOffset(false);
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesLinesVisible((int) ' ');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        java.lang.String str3 = unknownKeyException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: " + "'", str3.equals("org.jfree.data.UnknownKeyException: "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer10.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        barRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis17, marker18, rectangle2D19);
        boolean boolean24 = barRenderer14.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean25 = barRenderer14.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape29 = barRenderer14.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape29, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer10.setSeriesShape((int) '4', shape29, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        barRenderer35.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition37, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = barRenderer35.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer35.setBaseStroke(stroke41);
        java.awt.Color color43 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("", "", "TextAnchor.TOP_CENTER", "GradientPaintTransformType.CENTER_HORIZONTAL", shape29, stroke41, (java.awt.Paint) color43);
        legendItem3.setLine(shape29);
        org.jfree.chart.plot.Plot plot46 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity49 = new org.jfree.chart.entity.PlotEntity(shape29, plot46, "TextAnchor.TOP_CENTER", "rect");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.orange;
        int int8 = color7.getRGB();
        barRenderer0.setBaseFillPaint((java.awt.Paint) color7, false);
        barRenderer0.setBaseSeriesVisible(true, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis26, marker27, rectangle2D28);
        boolean boolean33 = barRenderer23.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean34 = barRenderer23.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape38 = barRenderer23.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity(shape38, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer48.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer52 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.plot.Marker marker56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        barRenderer52.drawRangeMarker(graphics2D53, categoryPlot54, valueAxis55, marker56, rectangle2D57);
        boolean boolean62 = barRenderer52.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean63 = barRenderer52.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape67 = barRenderer52.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity70 = new org.jfree.chart.entity.ChartEntity(shape67, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer48.setSeriesShape((int) '4', shape67, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer73 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition75 = null;
        barRenderer73.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition75, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = barRenderer73.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke79 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer73.setBaseStroke(stroke79);
        java.awt.Color color82 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color83 = color82.darker();
        org.jfree.chart.LegendItem legendItem84 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color83);
        java.awt.Paint paint85 = legendItem84.getFillPaint();
        org.jfree.chart.LegendItem legendItem86 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "", "rect", "TextAnchor.TOP_CENTER", shape67, stroke79, paint85);
        org.jfree.chart.renderer.category.BarRenderer barRenderer87 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D88 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot89 = null;
        org.jfree.chart.axis.ValueAxis valueAxis90 = null;
        org.jfree.chart.plot.Marker marker91 = null;
        java.awt.geom.Rectangle2D rectangle2D92 = null;
        barRenderer87.drawRangeMarker(graphics2D88, categoryPlot89, valueAxis90, marker91, rectangle2D92);
        java.awt.Color color94 = java.awt.Color.orange;
        int int95 = color94.getRGB();
        barRenderer87.setBaseFillPaint((java.awt.Paint) color94, false);
        org.jfree.chart.LegendItem legendItem98 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "TextAnchor.TOP_CENTER", shape38, stroke79, (java.awt.Paint) color94);
        try {
            barRenderer0.drawDomainLine(graphics2D14, categoryPlot15, rectangle2D16, 8.0d, (java.awt.Paint) color18, stroke79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-14336) + "'", int8 == (-14336));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNull(itemLabelPosition78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(color94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-14336) + "'", int95 == (-14336));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean3 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) standardCategorySeriesLabelGenerator2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number5 = null;
        defaultCategoryDataset4.setValue(number5, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        java.util.List list9 = defaultCategoryDataset4.getRowKeys();
        try {
            java.lang.String str11 = standardCategorySeriesLabelGenerator1.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        java.util.List list6 = defaultCategoryDataset0.getRowKeys();
        java.lang.Comparable comparable8 = null;
        java.lang.Comparable comparable9 = null;
        try {
            defaultCategoryDataset0.setValue((double) 1, comparable8, comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        barRenderer0.setSeriesToolTipGenerator(3, categoryToolTipGenerator13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16);
        java.lang.Boolean boolean19 = barRenderer0.getSeriesItemLabelsVisible((int) ' ');
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Font font5 = barRenderer0.getBaseLegendTextFont();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number10 = null;
        defaultCategoryDataset9.setValue(number10, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset9.fireSelectionEvent();
        java.util.List list15 = defaultCategoryDataset9.getRowKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        int int17 = defaultCategoryDataset16.getRowCount();
        defaultCategoryDataset9.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset16);
        try {
            java.lang.String str20 = standardCategorySeriesLabelGenerator7.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        java.awt.Shape shape28 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        java.util.EventListener eventListener29 = null;
        boolean boolean30 = lineAndShapeRenderer2.hasListener(eventListener29);
        boolean boolean31 = lineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        double double2 = categoryAxis0.getFixedDimension();
        java.awt.Font font3 = categoryAxis0.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation8 = axisLocation7.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str13 = textAnchor12.toString();
        boolean boolean14 = plotOrientation10.equals((java.lang.Object) str13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation7, plotOrientation10);
        try {
            double double16 = categoryAxis0.getCategoryEnd((int) (short) -1, (int) (short) 1, rectangle2D6, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str13.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        boolean boolean13 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean14 = barRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape18 = barRenderer3.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "TextAnchor.TOP_CENTER", "");
        renderAttributes0.setDefaultShape(shape18);
        java.awt.Color color23 = java.awt.Color.blue;
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_YELLOW;
        renderAttributes0.setSeriesFillPaint(100, (java.awt.Paint) color26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.Marker marker33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        barRenderer29.drawRangeMarker(graphics2D30, categoryPlot31, valueAxis32, marker33, rectangle2D34);
        java.awt.Stroke stroke39 = barRenderer29.getItemStroke((-1), 100, true);
        java.awt.Shape shape43 = barRenderer29.getItemShape((int) (byte) 10, (int) (short) 0, false);
        try {
            renderAttributes0.setSeriesShape((int) (byte) -1, shape43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(0);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke(0);
        java.awt.Stroke stroke5 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Stroke stroke6 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        try {
            defaultCategoryDataset0.setSelected((int) (byte) 1, (int) (byte) 1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        double double2 = categoryAxis0.getFixedDimension();
        java.awt.Font font3 = categoryAxis0.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation8 = axisLocation7.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str13 = textAnchor12.toString();
        boolean boolean14 = plotOrientation10.equals((java.lang.Object) str13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation7, plotOrientation10);
        try {
            double double16 = categoryAxis0.getCategoryEnd(3, 8, rectangle2D6, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str13.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer0.getSeriesURLGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        int int21 = categoryAxis20.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke22 = categoryAxis20.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType24 = rectangleInsets23.getUnitType();
        categoryAxis20.setLabelInsets(rectangleInsets23);
        java.lang.String str26 = categoryAxis20.getLabel();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D34 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis20, valueAxis27, categoryDataset28, (int) (short) 1, 2, true, categoryItemRendererState32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        barRenderer0.setSeriesToolTipGenerator(3, categoryToolTipGenerator13);
        barRenderer0.setShadowVisible(false);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Stroke stroke13 = barRenderer0.getSeriesStroke(0);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        barRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color15, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.incrementValue((double) (-1.0f), (java.lang.Comparable) "ChartEntity: tooltip = TextAnchor.TOP_CENTER", (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (ChartEntity: tooltip = TextAnchor.TOP_CENTER) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        java.awt.Paint paint22 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 10);
        boolean boolean23 = lineAndShapeRenderer2.getUseSeriesOffset();
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible((-14336));
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(boolean25);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer0.setSeriesPaint(0, (java.awt.Paint) color21, false);
        int int24 = color21.getAlpha();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        barRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean23 = barRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((-1.0f));
        boolean boolean4 = categoryAxis0.isVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color2 = color1.brighter();
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = renderAttributes0.getDefaultLabelPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        barRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis8, marker9, rectangle2D10);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer5.setSeriesOutlineStroke((int) (short) 100, stroke13);
        renderAttributes0.setDefaultStroke(stroke13);
        try {
            java.awt.Font font18 = renderAttributes0.getItemLabelFont(64, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number22 = null;
        defaultCategoryDataset21.setValue(number22, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset21.fireSelectionEvent();
        java.util.List list27 = defaultCategoryDataset21.getRowKeys();
        java.lang.Comparable comparable29 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) 10.0d, comparable29);
        java.lang.String str31 = categoryItemEntity30.toString();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        java.awt.Shape shape28 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        java.lang.Boolean boolean30 = lineAndShapeRenderer2.getSeriesShapesVisible((int) '#');
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            lineAndShapeRenderer2.drawOutline(graphics2D31, categoryPlot32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNull(boolean30);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        java.util.List list6 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        int int8 = defaultCategoryDataset7.getRowCount();
        defaultCategoryDataset0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset7);
        try {
            java.lang.Comparable comparable11 = defaultCategoryDataset7.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape21 = barRenderer13.getLegendShape((int) (short) 0);
        barRenderer13.setShadowXOffset((double) 100.0f);
        boolean boolean27 = barRenderer13.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer13.setBaseLegendTextFont(font28);
        barRenderer0.setBaseLegendTextFont(font28);
        boolean boolean33 = barRenderer0.getItemVisible((int) (short) 0, 64);
        java.awt.Paint paint35 = null;
        barRenderer0.setSeriesItemLabelPaint(10, paint35, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets3);
        double double6 = rectangleInsets3.calculateTopInset(0.0d);
        double double7 = rectangleInsets3.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Font font5 = barRenderer0.getBaseLegendTextFont();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        int int10 = categoryAxis9.getMaximumCategoryLabelLines();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 64);
        java.awt.Paint paint14 = categoryAxis9.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        float float15 = categoryAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis9.setTickLabelInsets(rectangleInsets16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color21 = color20.darker();
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color21);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis26, marker27, rectangle2D28);
        boolean boolean33 = barRenderer23.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean34 = barRenderer23.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset35 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset35.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj40 = defaultCategoryDataset35.clone();
        org.jfree.data.Range range41 = barRenderer23.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset35);
        legendItem22.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset35);
        java.lang.Object obj43 = null;
        boolean boolean44 = defaultCategoryDataset35.equals(obj43);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D50 = barRenderer0.createHotSpotBounds(graphics2D6, rectangle2D7, categoryPlot8, categoryAxis9, valueAxis18, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset35, (int) (byte) 100, 2, true, categoryItemRendererState48, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke19 = barRenderer0.getItemOutlineStroke((int) '#', (int) (byte) 0, true);
        java.awt.Paint paint23 = barRenderer0.getItemFillPaint(0, (int) (short) 10, false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.lang.String str4 = legendItem3.getURLText();
        java.lang.Comparable comparable5 = legendItem3.getSeriesKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str4 = textAnchor3.toString();
        boolean boolean5 = plotOrientation1.equals((java.lang.Object) str4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number7 = null;
        defaultCategoryDataset6.setValue(number7, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset6.fireSelectionEvent();
        java.util.List list12 = defaultCategoryDataset6.getRowKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        int int14 = defaultCategoryDataset13.getRowCount();
        defaultCategoryDataset6.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset13);
        java.util.List list16 = defaultCategoryDataset6.getRowKeys();
        boolean boolean17 = plotOrientation1.equals((java.lang.Object) list16);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str4.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        java.awt.Font font15 = null;
        barRenderer0.setBaseItemLabelFont(font15, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = barRenderer0.getItemLabelGenerator(3, 10, false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset16.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj21 = defaultCategoryDataset16.clone();
        org.jfree.data.Range range22 = barRenderer4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset16);
        defaultCategoryDataset16.clearSelection();
        java.lang.Comparable comparable25 = null;
        try {
            java.lang.Number number27 = defaultCategoryDataset16.getValue(comparable25, (java.lang.Comparable) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(0);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        boolean boolean19 = barRenderer9.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint21 = barRenderer9.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape23 = barRenderer9.getLegendShape(100);
        java.awt.Shape shape24 = barRenderer9.getBaseShape();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color26 = java.awt.Color.orange;
        float[] floatArray33 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray34 = color26.getColorComponents(floatArray33);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape24, stroke25, (java.awt.Paint) color26);
        java.awt.Shape shape36 = legendItem35.getLine();
        renderAttributes0.setDefaultShape(shape36);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible(8, true);
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesShapesFilled(8);
        try {
            lineAndShapeRenderer2.setItemMargin((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.setShadowYOffset(0.0d);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color17 = color16.darker();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color17);
        boolean boolean19 = barRenderer0.equals((java.lang.Object) color17);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor20 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean21 = color17.equals((java.lang.Object) itemLabelAnchor20);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Paint paint4 = legendItem3.getFillPaint();
        java.lang.Object obj5 = legendItem3.clone();
        java.lang.String str6 = legendItem3.getToolTipText();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        barRenderer0.setItemLabelAnchorOffset(0.0d);
        java.awt.Paint paint8 = barRenderer0.getLegendTextPaint((int) 'a');
        barRenderer0.setItemLabelAnchorOffset(0.0d);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape14 = barRenderer0.getLegendShape(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getBaseNegativeItemLabelPosition();
        double double16 = barRenderer0.getShadowYOffset();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean21 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 100, false);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint6 = renderAttributes4.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        barRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis10, marker11, rectangle2D12);
        boolean boolean17 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean18 = barRenderer7.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape22 = barRenderer7.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape22, "TextAnchor.TOP_CENTER", "");
        renderAttributes4.setDefaultShape(shape22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer29.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.Marker marker37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        barRenderer33.drawRangeMarker(graphics2D34, categoryPlot35, valueAxis36, marker37, rectangle2D38);
        boolean boolean43 = barRenderer33.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean44 = barRenderer33.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape48 = barRenderer33.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity(shape48, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer29.setSeriesShape((int) '4', shape48, true);
        java.awt.Shape shape55 = lineAndShapeRenderer29.getSeriesShape((int) (byte) 100);
        java.lang.Boolean boolean57 = lineAndShapeRenderer29.getSeriesShapesVisible((int) '#');
        java.awt.Color color58 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color59 = color58.brighter();
        lineAndShapeRenderer29.setBasePaint((java.awt.Paint) color58, false);
        try {
            org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "", "org.jfree.chart.event.ChartChangeEvent[source=100]", shape22, (java.awt.Paint) color58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(shape55);
        org.junit.Assert.assertNull(boolean57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis18, marker19, rectangle2D20);
        java.awt.Shape shape23 = barRenderer15.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = null;
        barRenderer15.setLegendItemURLGenerator(categorySeriesLabelGenerator24);
        java.awt.Paint paint29 = barRenderer15.getItemLabelPaint(10, 100, true);
        boolean boolean31 = barRenderer15.isSeriesVisible(10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer15.getNegativeItemLabelPosition((int) 'a', (int) (byte) -1, true);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape14 = barRenderer0.getLegendShape(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getBaseNegativeItemLabelPosition();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis18, marker19, rectangle2D20);
        boolean boolean25 = barRenderer15.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean26 = barRenderer15.getBaseSeriesVisibleInLegend();
        barRenderer15.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer15.getSeriesNegativeItemLabelPosition((int) 'a');
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition32);
        barRenderer0.setMaximumBarWidth((double) 64);
        java.lang.Boolean boolean37 = barRenderer0.getSeriesCreateEntities((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNull(boolean37);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        categoryAxis0.setTickMarkOutsideLength((float) 2);
        double double5 = categoryAxis0.getFixedDimension();
        java.lang.Comparable comparable6 = null;
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        try {
            categoryAxis0.setTickLabelFont(comparable6, font7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        java.util.List list6 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        int int8 = defaultCategoryDataset7.getRowCount();
        defaultCategoryDataset0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset7);
        try {
            defaultCategoryDataset0.removeColumn((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        barRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis10, marker11, rectangle2D12);
        boolean boolean17 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean18 = barRenderer7.getBaseSeriesVisibleInLegend();
        barRenderer7.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer7.getSeriesNegativeItemLabelPosition((int) 'a');
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition24, false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            barRenderer0.drawOutline(graphics2D27, categoryPlot28, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getRowCount();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.setValue((java.lang.Number) (-1.0d), comparable3, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 0);
        double double12 = barRenderer0.getBase();
        java.awt.Paint paint16 = barRenderer0.getItemOutlinePaint((int) (byte) 10, (int) (short) 100, true);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean2 = strokeList0.equals((java.lang.Object) rectangleInsets1);
        double double4 = rectangleInsets1.calculateTopInset((double) (byte) 0);
        double double6 = rectangleInsets1.extendWidth((double) (-14336));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-14336.0d) + "'", double6 == (-14336.0d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke19 = barRenderer0.getItemOutlineStroke((int) '#', (int) (byte) 0, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer0.getNegativeItemLabelPositionFallback();
        boolean boolean22 = barRenderer0.isSeriesVisibleInLegend(0);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        barRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis10, marker11, rectangle2D12);
        boolean boolean17 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint19 = barRenderer7.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape21 = barRenderer7.getLegendShape(100);
        java.awt.Shape shape22 = barRenderer7.getBaseShape();
        barRenderer0.setBaseShape(shape22, false);
        boolean boolean25 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        int int30 = categoryAxis29.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke31 = categoryAxis29.getAxisLineStroke();
        java.lang.String str32 = categoryAxis29.getLabelToolTip();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset33.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj38 = defaultCategoryDataset33.clone();
        boolean boolean39 = categoryAxis29.equals((java.lang.Object) defaultCategoryDataset33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState41 = barRenderer0.initialise(graphics2D26, rectangle2D27, categoryPlot28, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis0.setLabelInsets(rectangleInsets8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            rectangleInsets8.trim(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        barRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis10, marker11, rectangle2D12);
        boolean boolean17 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean18 = barRenderer7.getBaseSeriesVisibleInLegend();
        boolean boolean19 = barRenderer7.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        barRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis23, marker24, rectangle2D25);
        java.awt.Shape shape28 = barRenderer20.getLegendShape((int) (short) 0);
        barRenderer20.setShadowXOffset((double) 100.0f);
        boolean boolean34 = barRenderer20.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer20.setBaseLegendTextFont(font35);
        barRenderer7.setBaseLegendTextFont(font35);
        barRenderer0.setBaseItemLabelFont(font35, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint43 = renderAttributes41.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        barRenderer44.drawRangeMarker(graphics2D45, categoryPlot46, valueAxis47, marker48, rectangle2D49);
        boolean boolean54 = barRenderer44.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean55 = barRenderer44.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape59 = barRenderer44.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity(shape59, "TextAnchor.TOP_CENTER", "");
        renderAttributes41.setDefaultShape(shape59);
        java.awt.Color color64 = java.awt.Color.blue;
        renderAttributes41.setDefaultLabelPaint((java.awt.Paint) color64);
        barRenderer0.setSeriesItemLabelPaint((int) (short) 10, (java.awt.Paint) color64, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer68 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        barRenderer68.drawRangeMarker(graphics2D69, categoryPlot70, valueAxis71, marker72, rectangle2D73);
        boolean boolean78 = barRenderer68.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Stroke stroke79 = barRenderer68.getBaseOutlineStroke();
        double double80 = barRenderer68.getShadowXOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition84 = barRenderer68.getNegativeItemLabelPosition(255, (int) (short) 100, true);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition84, false);
        java.awt.Stroke stroke88 = barRenderer0.lookupSeriesStroke((int) (byte) 10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 4.0d + "'", double80 == 4.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition84);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets3);
        categoryAxis0.setFixedDimension((double) 3);
        java.awt.Paint paint7 = null;
        try {
            categoryAxis0.setAxisLinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("TextAnchor.TOP_CENTER");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.String str3 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str2.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str3.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Paint paint4 = legendItem3.getFillPaint();
        java.text.AttributedString attributedString5 = legendItem3.getAttributedLabel();
        legendItem3.setToolTipText("TextAnchor.TOP_CENTER");
        legendItem3.setShapeVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(attributedString5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        barRenderer20.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition22, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer20.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer20.setBaseStroke(stroke26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        barRenderer28.drawRangeMarker(graphics2D29, categoryPlot30, valueAxis31, marker32, rectangle2D33);
        java.awt.Color color35 = java.awt.Color.orange;
        int int36 = color35.getRGB();
        barRenderer28.setBaseFillPaint((java.awt.Paint) color35, false);
        barRenderer20.setBaseLegendTextPaint((java.awt.Paint) color35);
        try {
            org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem(attributedString0, "", "", "TextAnchor.TOP_CENTER", shape19, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-14336) + "'", int36 == (-14336));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        int int16 = barRenderer0.getColumnCount();
        boolean boolean17 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 100, stroke8);
        java.awt.Paint paint13 = barRenderer0.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        int int17 = categoryAxis16.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke18 = categoryAxis16.getAxisLineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        barRenderer19.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition21, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer19.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer19.setBaseStroke(stroke25);
        categoryAxis16.setAxisLineStroke(stroke25);
        categoryAxis16.setUpperMargin((double) 3);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis30, layer31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer5.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer5.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer5.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition14);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightOutset((double) (-1.0f));
        double double5 = rectangleInsets0.calculateBottomOutset((double) 8);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets0.getUnitType();
        double double8 = rectangleInsets0.calculateTopOutset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Paint paint4 = legendItem3.getFillPaint();
        java.lang.Object obj5 = legendItem3.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem3.setLinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.gray;
        legendItem3.setOutlinePaint((java.awt.Paint) color8);
        legendItem3.setURLText("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint(10, (java.awt.Paint) color16);
        java.awt.Paint paint21 = barRenderer0.getItemPaint((int) (short) 1, 64, false);
        java.awt.Font font23 = barRenderer0.lookupLegendTextFont(255);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Font font13 = null;
        barRenderer0.setSeriesItemLabelFont(2, font13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = barRenderer0.getSeriesToolTipGenerator((int) (short) 1);
        barRenderer0.setShadowXOffset((double) 8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets3);
        categoryAxis0.setTickMarkInsideLength((float) (byte) 0);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = plotOrientation13.equals((java.lang.Object) str16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.axis.AxisState axisState20 = categoryAxis0.draw(graphics2D7, 0.0d, rectangle2D9, rectangle2D10, rectangleEdge18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer0.setSeriesPaint(0, (java.awt.Paint) color21, false);
        java.awt.Shape shape25 = barRenderer0.lookupLegendShape(1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        categoryAxis0.setLabelInsets(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets3.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.lang.Object obj3 = objectList1.get((int) ' ');
        java.lang.Object obj5 = objectList1.get((int) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        barRenderer6.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition8, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer6.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer6.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        boolean boolean17 = barRenderer6.isSeriesVisibleInLegend((int) (short) 0);
        double double18 = barRenderer6.getBase();
        int int19 = objectList1.indexOf((java.lang.Object) double18);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        try {
            barRenderer0.setSeriesToolTipGenerator((int) (byte) -1, categoryToolTipGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        java.awt.Paint paint22 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 10);
        boolean boolean23 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        int int25 = defaultCategoryDataset24.getRowCount();
        org.jfree.data.Range range26 = lineAndShapeRenderer2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        try {
            defaultCategoryDataset24.removeColumn((java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (-1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.lang.Object obj3 = objectList1.get((int) ' ');
        java.lang.Object obj5 = objectList1.get((int) (byte) 10);
        java.lang.Object obj7 = objectList1.get(0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        java.awt.Font font15 = null;
        barRenderer0.setBaseItemLabelFont(font15, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        barRenderer19.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator21);
        barRenderer19.setBaseSeriesVisible(false, true);
        java.awt.Stroke stroke29 = barRenderer19.getItemStroke(2, 0, false);
        try {
            barRenderer0.setSeriesStroke((-14336), stroke29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer0.getSeriesURLGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = barRenderer0.getPlot();
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categoryPlot15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        barRenderer2.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        boolean boolean12 = barRenderer2.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean13 = barRenderer2.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape17 = barRenderer2.getItemShape((int) ' ', (int) (short) 0, true);
        boolean boolean18 = strokeList0.equals((java.lang.Object) barRenderer2);
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = barRenderer2.hasListener(eventListener19);
        barRenderer2.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "hi!", "ChartEntity: tooltip = TextAnchor.TOP_CENTER", shape19, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        java.lang.Comparable comparable6 = null;
        try {
            defaultCategoryDataset0.removeColumn(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color2 = color1.brighter();
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint6 = renderAttributes0.getItemFillPaint(0, 100);
        java.awt.Stroke stroke8 = null;
        try {
            renderAttributes0.setSeriesOutlineStroke((int) (byte) -1, stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.Marker marker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        barRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis4, marker5, rectangle2D6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 100, stroke9);
        java.awt.Paint paint14 = barRenderer1.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis0.setAxisLinePaint(paint14);
        java.lang.String str16 = categoryAxis0.getLabel();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0f);
        categoryAxis0.setLabelAngle(0.0d);
        categoryAxis0.setLowerMargin((double) (byte) 100);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color3 = color2.darker();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendItem4.getFillPaint();
        java.lang.Object obj6 = legendItem4.clone();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem4.setLinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator12 = new org.jfree.chart.util.DefaultShadowGenerator(0, color7, (float) 8, (int) (short) -1, (double) (byte) 100);
        int int13 = defaultShadowGenerator12.calculateOffsetY();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getRowCount();
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset4);
        try {
            boolean boolean9 = defaultCategoryDataset4.isSelected(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number22 = null;
        defaultCategoryDataset21.setValue(number22, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset21.fireSelectionEvent();
        java.util.List list27 = defaultCategoryDataset21.getRowKeys();
        java.lang.Comparable comparable29 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) 10.0d, comparable29);
        defaultCategoryDataset21.addValue((java.lang.Number) (-1.0d), (java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        barRenderer2.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        boolean boolean12 = barRenderer2.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean13 = barRenderer2.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape17 = barRenderer2.getItemShape((int) ' ', (int) (short) 0, true);
        boolean boolean18 = strokeList0.equals((java.lang.Object) barRenderer2);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            barRenderer2.addAnnotation(categoryAnnotation19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        java.lang.String str19 = chartEntity18.getShapeType();
        java.lang.Object obj20 = chartEntity18.clone();
        java.lang.String str21 = chartEntity18.getShapeType();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "rect" + "'", str21.equals("rect"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getShadowsVisible();
        barRenderer0.setSeriesItemLabelsVisible(0, false);
        barRenderer0.clearSeriesStrokes(false);
        int int13 = barRenderer0.getRowCount();
        java.awt.Stroke stroke17 = barRenderer0.getItemOutlineStroke(3, 64, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        int int13 = categoryAxis12.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke14 = categoryAxis12.getAxisLineStroke();
        java.lang.String str15 = categoryAxis12.getLabelToolTip();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D10, rectangle2D11, categoryAxis12, valueAxis16, layer17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        java.awt.Shape shape19 = barRenderer0.getLegendShape((int) (short) 10);
        java.awt.Shape shape21 = barRenderer0.getLegendShape((int) 'a');
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        int int27 = categoryAxis26.getMaximumCategoryLabelLines();
        categoryAxis26.setLabelAngle((double) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color33 = color32.darker();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        barRenderer35.drawRangeMarker(graphics2D36, categoryPlot37, valueAxis38, marker39, rectangle2D40);
        boolean boolean45 = barRenderer35.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean46 = barRenderer35.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset47.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj52 = defaultCategoryDataset47.clone();
        org.jfree.data.Range range53 = barRenderer35.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        legendItem34.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset47);
        defaultCategoryDataset47.clearSelection();
        try {
            barRenderer0.drawItem(graphics2D22, categoryItemRendererState23, rectangle2D24, categoryPlot25, categoryAxis26, valueAxis30, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset47, 64, (int) (byte) 100, false, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(range53);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        java.lang.String str3 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str3.equals("TextAnchor.HALF_ASCENT_CENTER"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number4 = null;
        defaultCategoryDataset3.setValue(number4, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset3.fireSelectionEvent();
        java.util.List list9 = defaultCategoryDataset3.getRowKeys();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = plotOrientation13.equals((java.lang.Object) str16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        try {
            double double19 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) 0.2d, list9, rectangle2D10, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean23 = lineAndShapeRenderer2.getItemShapeFilled(255, (int) (short) 0);
        java.awt.Paint paint25 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((int) (short) 0);
        java.lang.Boolean boolean27 = lineAndShapeRenderer2.getSeriesLinesVisible((int) (short) -1);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(boolean27);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        renderAttributes0.setSeriesShape(64, shape21);
        java.awt.Paint paint25 = renderAttributes0.getItemFillPaint(3, (int) '4');
        java.awt.Paint paint26 = null;
        try {
            renderAttributes0.setDefaultOutlinePaint(paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesPaint((-1));
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer4.setSeriesOutlineStroke((int) (short) 100, stroke12);
        java.awt.Paint paint17 = barRenderer4.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        renderAttributes0.setSeriesOutlinePaint((int) (short) 100, paint17);
        try {
            renderAttributes0.setSeriesLabelVisible(64, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        boolean boolean22 = lineAndShapeRenderer2.getItemLineVisible((int) 'a', (int) (byte) 100);
        boolean boolean26 = lineAndShapeRenderer2.getItemCreateEntity(1, (-14336), true);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) booleanList1);
        java.awt.GradientPaint gradientPaint3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape19, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number26 = null;
        defaultCategoryDataset25.setValue(number26, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset25.fireSelectionEvent();
        java.util.List list31 = defaultCategoryDataset25.getRowKeys();
        java.lang.Comparable comparable33 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity34 = new org.jfree.chart.entity.CategoryItemEntity(shape19, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, (java.lang.Comparable) 10.0d, comparable33);
        try {
            java.awt.GradientPaint gradientPaint35 = standardGradientPaintTransformer0.transform(gradientPaint3, shape19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem(2, (int) (byte) 10);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        barRenderer17.drawRangeMarker(graphics2D18, categoryPlot19, valueAxis20, marker21, rectangle2D22);
        boolean boolean27 = barRenderer17.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint29 = barRenderer17.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape31 = barRenderer17.getLegendShape(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer17.getBaseNegativeItemLabelPosition();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(shape31);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        java.awt.Shape shape28 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        lineAndShapeRenderer2.removeAnnotations();
        java.lang.Boolean boolean31 = lineAndShapeRenderer2.getSeriesLinesVisible(10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNull(boolean31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        boolean boolean4 = legendItem3.isShapeFilled();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer0.getSeriesURLGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean18 = standardCategorySeriesLabelGenerator16.equals((java.lang.Object) standardCategorySeriesLabelGenerator17);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator16);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        try {
            barRenderer0.setSeriesStroke((-14336), stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((-1.0f));
        categoryAxis0.setUpperMargin((double) 2);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        barRenderer4.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition6, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        barRenderer9.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition11, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer9.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer9.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer4.setBaseNegativeItemLabelPosition(itemLabelPosition18);
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition18);
        int int21 = lineAndShapeRenderer3.getPassCount();
        java.awt.Paint paint23 = lineAndShapeRenderer3.getSeriesPaint((int) (short) 10);
        boolean boolean24 = lineAndShapeRenderer3.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        int int26 = defaultCategoryDataset25.getRowCount();
        org.jfree.data.Range range27 = lineAndShapeRenderer3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        boolean boolean28 = sortOrder0.equals((java.lang.Object) defaultCategoryDataset25);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset29 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup30 = abstractCategoryDataset29.getGroup();
        defaultCategoryDataset25.setGroup(datasetGroup30);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetGroup30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 64);
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        float float6 = categoryAxis0.getMinorTickMarkInsideLength();
        categoryAxis0.setLabelURL("DatasetRenderingOrder.FORWARD");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer0.getSeriesURLGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean18 = standardCategorySeriesLabelGenerator16.equals((java.lang.Object) standardCategorySeriesLabelGenerator17);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator16);
        barRenderer0.setShadowXOffset((double) 3);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.removeColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke((-1), 100, true);
        java.awt.Shape shape14 = barRenderer0.getItemShape((int) (byte) 10, (int) (short) 0, false);
        org.jfree.chart.plot.Plot plot15 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape14, plot15, "ChartEntity: tooltip = TextAnchor.TOP_CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getSeriesNegativeItemLabelPosition((int) 'a');
        int int18 = barRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint(10, (java.awt.Paint) color16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        barRenderer0.notifyListeners(rendererChangeEvent18);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarksVisible(false);
        java.awt.Paint paint6 = categoryAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape14 = barRenderer0.getLegendShape(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        barRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis23, marker24, rectangle2D25);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer20.setSeriesOutlineStroke((int) (short) 100, stroke28);
        java.awt.Paint paint33 = barRenderer20.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis19.setAxisLinePaint(paint33);
        java.lang.String str35 = categoryAxis19.getLabel();
        java.awt.Paint paint37 = categoryAxis19.getTickLabelPaint((java.lang.Comparable) 1.0f);
        double double38 = categoryAxis19.getCategoryMargin();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number41 = null;
        defaultCategoryDataset40.setValue(number41, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset40.fireSelectionEvent();
        java.util.List list46 = defaultCategoryDataset40.getRowKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        int int48 = defaultCategoryDataset47.getRowCount();
        defaultCategoryDataset40.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset47);
        java.util.List list50 = defaultCategoryDataset40.getRowKeys();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState54 = null;
        try {
            java.awt.Shape shape55 = barRenderer0.createHotSpotShape(graphics2D16, rectangle2D17, categoryPlot18, categoryAxis19, valueAxis39, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, 4, 4, false, categoryItemRendererState54);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.2d + "'", double38 == 0.2d);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean23 = lineAndShapeRenderer2.getItemShapeFilled(255, (int) (short) 0);
        org.jfree.chart.LegendItem legendItem26 = lineAndShapeRenderer2.getLegendItem((int) (short) 0, 0);
        boolean boolean27 = lineAndShapeRenderer2.getBaseLinesVisible();
        java.awt.Stroke stroke29 = lineAndShapeRenderer2.lookupSeriesOutlineStroke((int) (short) 0);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.Marker marker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        barRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis4, marker5, rectangle2D6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 100, stroke9);
        java.awt.Paint paint14 = barRenderer1.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis0.setAxisLinePaint(paint14);
        java.lang.String str16 = categoryAxis0.getLabel();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0f);
        double double19 = categoryAxis0.getCategoryMargin();
        java.awt.Color color20 = java.awt.Color.RED;
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        boolean boolean2 = categoryAxis0.isTickLabelsVisible();
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 64);
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        float float6 = categoryAxis0.getMinorTickMarkInsideLength();
        float float7 = categoryAxis0.getMinorTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = plotOrientation13.equals((java.lang.Object) str16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        try {
            double double19 = categoryAxis0.getCategoryEnd(100, (int) (short) -1, rectangle2D10, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 255, (double) '#', (double) (byte) 100, 1.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem(2, (int) (byte) 10);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Paint paint18 = barRenderer0.getSeriesItemLabelPaint(100);
        barRenderer0.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke((-1), 100, true);
        java.awt.Shape shape14 = barRenderer0.getItemShape((int) (byte) 10, (int) (short) 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getSeriesNegativeItemLabelPosition(2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset16.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj21 = defaultCategoryDataset16.clone();
        org.jfree.data.Range range22 = barRenderer4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset16);
        defaultCategoryDataset16.clearSelection();
        try {
            defaultCategoryDataset16.setSelected(2, (int) (short) -1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        categoryAxis0.setLabelInsets(rectangleInsets4, true);
        double double9 = rectangleInsets4.calculateBottomInset((double) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke6);
        boolean boolean8 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke10 = barRenderer0.lookupSeriesOutlineStroke((int) (short) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer0.setSeriesToolTipGenerator((int) '4', categoryToolTipGenerator12);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean23 = lineAndShapeRenderer2.getItemShapeFilled(255, (int) (short) 0);
        lineAndShapeRenderer2.removeAnnotations();
        int int25 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset16.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj21 = defaultCategoryDataset16.clone();
        org.jfree.data.Range range22 = barRenderer4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset16);
        java.lang.Object obj24 = null;
        boolean boolean25 = defaultCategoryDataset16.equals(obj24);
        int int26 = defaultCategoryDataset16.getColumnCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color3 = java.awt.Color.orange;
        float[] floatArray10 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray11 = color3.getColorComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB(255, 64, 1, floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape14 = barRenderer0.getLegendShape(100);
        java.awt.Paint paint15 = barRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number22 = null;
        defaultCategoryDataset21.setValue(number22, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset21.fireSelectionEvent();
        java.util.List list27 = defaultCategoryDataset21.getRowKeys();
        java.lang.Comparable comparable29 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) 10.0d, comparable29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        barRenderer32.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator34);
        barRenderer32.setBaseSeriesVisible(false, true);
        java.awt.Stroke stroke42 = barRenderer32.getItemStroke(2, 0, false);
        boolean boolean43 = datasetRenderingOrder31.equals((java.lang.Object) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        double double45 = barRenderer44.getShadowYOffset();
        boolean boolean46 = datasetRenderingOrder31.equals((java.lang.Object) barRenderer44);
        boolean boolean47 = categoryItemEntity30.equals((java.lang.Object) datasetRenderingOrder31);
        java.lang.String str48 = categoryItemEntity30.toString();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        barRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis22, marker23, rectangle2D24);
        boolean boolean29 = barRenderer19.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean30 = barRenderer19.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape34 = barRenderer19.getItemShape((int) ' ', (int) (short) 0, true);
        chartEntity18.setArea(shape34);
        chartEntity18.setToolTipText("ChartEntity: tooltip = TextAnchor.TOP_CENTER");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Paint paint4 = legendItem3.getFillPaint();
        java.lang.Object obj5 = legendItem3.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem3.setLinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.gray;
        legendItem3.setOutlinePaint((java.awt.Paint) color8);
        java.lang.String str10 = legendItem3.getDescription();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Font font5 = barRenderer0.getBaseLegendTextFont();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener6 = null;
        try {
            barRenderer0.removeChangeListener(rendererChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(font5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape21 = barRenderer13.getLegendShape((int) (short) 0);
        barRenderer13.setShadowXOffset((double) 100.0f);
        boolean boolean27 = barRenderer13.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer13.setBaseLegendTextFont(font28);
        barRenderer0.setBaseLegendTextFont(font28);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = barRenderer0.getItemLabelGenerator((int) (short) 100, (int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(categoryItemLabelGenerator34);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean23 = lineAndShapeRenderer2.getItemShapeFilled(255, (int) (short) 0);
        lineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean26 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        categoryAxis0.setLabelInsets(rectangleInsets3);
        java.lang.String str6 = categoryAxis0.getLabel();
        boolean boolean7 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.lang.String str4 = legendItem3.getURLText();
        int int5 = legendItem3.getDatasetIndex();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setLabelAngle((double) (short) 1);
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        double double5 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        boolean boolean22 = lineAndShapeRenderer2.getItemLineVisible((int) 'a', (int) (byte) 100);
        java.lang.Object obj23 = lineAndShapeRenderer2.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.Marker marker28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        barRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis27, marker28, rectangle2D29);
        java.awt.Shape shape32 = barRenderer24.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = null;
        barRenderer24.setLegendItemURLGenerator(categorySeriesLabelGenerator33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        barRenderer35.drawRangeMarker(graphics2D36, categoryPlot37, valueAxis38, marker39, rectangle2D40);
        boolean boolean45 = barRenderer35.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint47 = barRenderer35.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape49 = barRenderer35.getLegendShape(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = barRenderer35.getBaseNegativeItemLabelPosition();
        barRenderer24.setNegativeItemLabelPositionFallback(itemLabelPosition50);
        lineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition50);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNull(shape49);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets3);
        java.awt.Stroke stroke5 = null;
        try {
            categoryAxis0.setTickMarkStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color22 = color21.darker();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color22);
        barRenderer0.setShadowPaint((java.awt.Paint) color22);
        barRenderer0.clearSeriesPaints(false);
        java.awt.Paint paint28 = barRenderer0.lookupSeriesPaint(10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape19, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis26, marker27, rectangle2D28);
        boolean boolean33 = barRenderer23.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean34 = barRenderer23.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape38 = barRenderer23.getItemShape((int) ' ', (int) (short) 0, true);
        chartEntity22.setArea(shape38);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator44 = barRenderer40.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint46 = barRenderer40.getSeriesFillPaint(100);
        java.awt.Stroke stroke47 = barRenderer40.getBaseStroke();
        java.awt.Paint paint48 = null;
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("", "TextAnchor.TOP_CENTER", "org.jfree.data.UnknownKeyException: ", "GradientPaintTransformType.CENTER_HORIZONTAL", shape38, stroke47, paint48);
        java.awt.Color color52 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color53 = color52.darker();
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color53);
        java.awt.Paint paint55 = legendItem54.getFillPaint();
        java.lang.Object obj56 = legendItem54.clone();
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem54.setLinePaint((java.awt.Paint) color57);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator62 = new org.jfree.chart.util.DefaultShadowGenerator(0, color57, (float) 8, (int) (short) -1, (double) (byte) 100);
        legendItem49.setFillPaint((java.awt.Paint) color57);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(categoryItemLabelGenerator44);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis0.setLabelInsets(rectangleInsets8);
        java.awt.Paint paint11 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 3);
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = categoryAxis0.hasListener(eventListener12);
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint(10, (java.awt.Paint) color16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = barRenderer19.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint25 = barRenderer19.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        barRenderer26.drawRangeMarker(graphics2D27, categoryPlot28, valueAxis29, marker30, rectangle2D31);
        boolean boolean36 = barRenderer26.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean37 = barRenderer26.getBaseSeriesVisibleInLegend();
        boolean boolean38 = barRenderer26.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        barRenderer39.drawRangeMarker(graphics2D40, categoryPlot41, valueAxis42, marker43, rectangle2D44);
        java.awt.Shape shape47 = barRenderer39.getLegendShape((int) (short) 0);
        barRenderer39.setShadowXOffset((double) 100.0f);
        boolean boolean53 = barRenderer39.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer39.setBaseLegendTextFont(font54);
        barRenderer26.setBaseLegendTextFont(font54);
        barRenderer19.setBaseItemLabelFont(font54, true);
        barRenderer0.setSeriesItemLabelFont(255, font54);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(font54);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        categoryAxis0.setLabelInsets(rectangleInsets3);
        java.lang.String str6 = categoryAxis0.getLabel();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.Marker marker6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        barRenderer2.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, marker6, rectangle2D7);
        java.awt.Shape shape10 = barRenderer2.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer2.setLegendItemURLGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint16 = barRenderer2.getItemLabelPaint(10, 100, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer2.setSeriesItemLabelPaint(10, (java.awt.Paint) color18);
        categoryAxis0.setLabelPaint((java.awt.Paint) color18);
        categoryAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets3.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color3 = color2.darker();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendItem4.getFillPaint();
        java.lang.Object obj6 = legendItem4.clone();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem4.setLinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator12 = new org.jfree.chart.util.DefaultShadowGenerator(0, color7, (float) 8, (int) (short) -1, (double) (byte) 100);
        int int13 = defaultShadowGenerator12.getDistance();
        int int14 = defaultShadowGenerator12.getDistance();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        barRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis11, marker12, rectangle2D13);
        boolean boolean18 = barRenderer8.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint20 = barRenderer8.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape22 = barRenderer8.getLegendShape(100);
        java.awt.Shape shape23 = barRenderer8.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color25 = java.awt.Color.orange;
        float[] floatArray32 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray33 = color25.getColorComponents(floatArray32);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape23, stroke24, (java.awt.Paint) color25);
        renderAttributes0.setSeriesShape((int) (byte) 10, shape23);
        try {
            java.awt.Font font37 = renderAttributes0.getSeriesLabelFont(255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        java.awt.Shape shape19 = barRenderer0.getLegendShape((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer0.notifyListeners(rendererChangeEvent20);
        barRenderer0.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis0.setLabelInsets(rectangleInsets8);
        java.awt.Paint paint11 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 3);
        categoryAxis0.setMinorTickMarksVisible(false);
        boolean boolean14 = categoryAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        categoryAxis0.setTickMarkOutsideLength((float) 2);
        double double5 = categoryAxis0.getFixedDimension();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis0.setUpperMargin((double) (-14336));
        int int10 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = categoryAxis0.getCategoryStart(1, (int) (short) 100, rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ChartEntity: tooltip = TextAnchor.TOP_CENTER");
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightInset((double) 8);
        double double4 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer5.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer5.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer5.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition14);
        barRenderer0.setSeriesCreateEntities((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "rect");
        categoryAxis0.setLabelURL("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getRowCount();
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset4);
        try {
            java.lang.Number number9 = defaultCategoryDataset4.getValue((int) '4', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        try {
            keyedObjects2D0.removeObject(comparable1, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint6 = renderAttributes4.getSeriesFillPaint(0);
        java.awt.Stroke stroke8 = renderAttributes4.getSeriesStroke(0);
        java.awt.Stroke stroke9 = renderAttributes4.getDefaultOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint12 = renderAttributes10.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        boolean boolean23 = barRenderer13.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean24 = barRenderer13.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape28 = barRenderer13.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape28, "TextAnchor.TOP_CENTER", "");
        renderAttributes10.setDefaultShape(shape28);
        renderAttributes4.setDefaultShape(shape28);
        java.awt.Paint paint34 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint37 = renderAttributes35.getSeriesFillPaint(0);
        java.awt.Stroke stroke39 = renderAttributes35.getSeriesStroke(0);
        java.awt.Stroke stroke40 = renderAttributes35.getDefaultOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint43 = renderAttributes41.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        barRenderer44.drawRangeMarker(graphics2D45, categoryPlot46, valueAxis47, marker48, rectangle2D49);
        boolean boolean54 = barRenderer44.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean55 = barRenderer44.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape59 = barRenderer44.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity(shape59, "TextAnchor.TOP_CENTER", "");
        renderAttributes41.setDefaultShape(shape59);
        renderAttributes35.setDefaultShape(shape59);
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition67 = null;
        barRenderer65.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition67, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition70 = barRenderer65.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer65.setBaseStroke(stroke71);
        renderAttributes35.setDefaultOutlineStroke(stroke71);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer75 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer76 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = null;
        barRenderer76.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition78, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition81 = barRenderer76.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition85 = barRenderer76.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        boolean boolean87 = barRenderer76.isSeriesVisibleInLegend((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator89 = null;
        barRenderer76.setSeriesToolTipGenerator(3, categoryToolTipGenerator89);
        java.awt.Color color92 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        barRenderer76.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color92);
        boolean boolean94 = standardGradientPaintTransformer75.equals((java.lang.Object) color92);
        java.awt.Color color95 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: ", color92);
        try {
            org.jfree.chart.LegendItem legendItem96 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "rect", "org.jfree.chart.event.ChartChangeEvent[source=100]", shape28, paint34, stroke71, (java.awt.Paint) color95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNull(stroke39);
        org.junit.Assert.assertNull(stroke40);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNull(itemLabelPosition70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(itemLabelPosition81);
        org.junit.Assert.assertNotNull(itemLabelPosition85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(color92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(color95);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) booleanList1);
        booleanList1.setBoolean((int) '4', (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        barRenderer0.setItemLabelAnchorOffset(0.0d);
        barRenderer0.clearSeriesStrokes(true);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint((int) (short) 1, 0, false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Stroke stroke17 = barRenderer0.getBaseOutlineStroke();
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        java.awt.Paint paint22 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 10);
        boolean boolean23 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        int int25 = defaultCategoryDataset24.getRowCount();
        org.jfree.data.Range range26 = lineAndShapeRenderer2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        try {
            defaultCategoryDataset24.removeColumn((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (100.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color2 = java.awt.Color.orange;
        float[] floatArray9 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray10 = color2.getColorComponents(floatArray9);
        float[] floatArray11 = color1.getRGBComponents(floatArray9);
        float[] floatArray12 = color0.getRGBComponents(floatArray9);
        int int13 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        defaultCategoryDataset0.clear();
        try {
            boolean boolean9 = defaultCategoryDataset0.isSelected((int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        barRenderer11.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition13, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        barRenderer16.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition18, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer16.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer16.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer11.setBaseNegativeItemLabelPosition(itemLabelPosition25);
        lineAndShapeRenderer10.setBasePositiveItemLabelPosition(itemLabelPosition25);
        int int28 = lineAndShapeRenderer10.getPassCount();
        boolean boolean29 = lineAndShapeRenderer10.getDrawOutlines();
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        barRenderer30.drawRangeMarker(graphics2D31, categoryPlot32, valueAxis33, marker34, rectangle2D35);
        boolean boolean40 = barRenderer30.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint42 = barRenderer30.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape44 = barRenderer30.getLegendShape(100);
        java.awt.Shape shape45 = barRenderer30.getBaseShape();
        lineAndShapeRenderer10.setBaseShape(shape45, true);
        lineAndShapeRenderer2.setBaseShape(shape45, false);
        org.junit.Assert.assertNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNull(shape44);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer2.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint8 = barRenderer2.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        boolean boolean19 = barRenderer9.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint21 = barRenderer9.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape23 = barRenderer9.getLegendShape(100);
        java.awt.Shape shape24 = barRenderer9.getBaseShape();
        barRenderer2.setBaseShape(shape24, false);
        shapeList0.setShape(1, shape24);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = new org.jfree.chart.event.DatasetChangeInfo();
        boolean boolean29 = shapeList0.equals((java.lang.Object) datasetChangeInfo28);
        java.awt.Shape shape31 = shapeList0.getShape(0);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(shape31);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.orange;
        int int8 = color7.getRGB();
        barRenderer0.setBaseFillPaint((java.awt.Paint) color7, false);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color13 = color12.brighter();
        try {
            barRenderer0.setLegendTextPaint((-14336), (java.awt.Paint) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-14336) + "'", int8 == (-14336));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateTopInset(0.0d);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) 10, 0.0d, (double) (-1L), (double) '4');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(unitType4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Color color1 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE2");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        barRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis18, marker19, rectangle2D20);
        boolean boolean25 = barRenderer15.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean26 = barRenderer15.getBaseSeriesVisibleInLegend();
        barRenderer15.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer15.getSeriesNegativeItemLabelPosition((int) 'a');
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition32);
        java.awt.Stroke stroke35 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) -1);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color36);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject(comparable1, (java.lang.Comparable) "TextAnchor.TOP_CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets3);
        categoryAxis0.setTickMarkInsideLength((float) (byte) 0);
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.util.ShapeList shapeList9 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer11.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint17 = barRenderer11.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        barRenderer18.drawRangeMarker(graphics2D19, categoryPlot20, valueAxis21, marker22, rectangle2D23);
        boolean boolean28 = barRenderer18.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint30 = barRenderer18.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape32 = barRenderer18.getLegendShape(100);
        java.awt.Shape shape33 = barRenderer18.getBaseShape();
        barRenderer11.setBaseShape(shape33, false);
        shapeList9.setShape(1, shape33);
        org.jfree.chart.util.SortOrder sortOrder39 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        barRenderer43.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition45, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = null;
        barRenderer48.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition50, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = barRenderer48.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = barRenderer48.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer43.setBaseNegativeItemLabelPosition(itemLabelPosition57);
        lineAndShapeRenderer42.setBasePositiveItemLabelPosition(itemLabelPosition57);
        int int60 = lineAndShapeRenderer42.getPassCount();
        java.awt.Paint paint62 = lineAndShapeRenderer42.getSeriesPaint((int) (short) 10);
        boolean boolean63 = lineAndShapeRenderer42.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset64 = new org.jfree.data.category.DefaultCategoryDataset();
        int int65 = defaultCategoryDataset64.getRowCount();
        org.jfree.data.Range range66 = lineAndShapeRenderer42.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset64);
        boolean boolean67 = sortOrder39.equals((java.lang.Object) defaultCategoryDataset64);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset68 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup69 = defaultCategoryDataset68.getGroup();
        defaultCategoryDataset64.setGroup(datasetGroup69);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity73 = new org.jfree.chart.entity.CategoryItemEntity(shape33, "GradientPaintTransformType.CENTER_HORIZONTAL", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset64, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation78 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation77, plotOrientation78);
        org.jfree.chart.text.TextAnchor textAnchor80 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str81 = textAnchor80.toString();
        boolean boolean82 = plotOrientation78.equals((java.lang.Object) str81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation76, plotOrientation78);
        try {
            double double84 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (byte) 10, comparable8, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset64, (double) 'a', rectangle2D75, rectangleEdge83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNull(shape32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(datasetGroup69);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(plotOrientation78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertNotNull(textAnchor80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str81.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(rectangleEdge83);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape21 = barRenderer13.getLegendShape((int) (short) 0);
        barRenderer13.setShadowXOffset((double) 100.0f);
        boolean boolean27 = barRenderer13.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer13.setBaseLegendTextFont(font28);
        barRenderer0.setBaseLegendTextFont(font28);
        int int31 = barRenderer0.getRowCount();
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseOutlinePaint(paint32);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke19 = barRenderer0.getItemOutlineStroke((int) '#', (int) (byte) 0, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range21 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 100, categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset4.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj9 = defaultCategoryDataset4.clone();
        boolean boolean10 = categoryAxis0.equals((java.lang.Object) defaultCategoryDataset4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str20 = textAnchor19.toString();
        boolean boolean21 = plotOrientation17.equals((java.lang.Object) str20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation17);
        try {
            double double23 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor11, (int) (byte) -1, (int) (short) 0, rectangle2D14, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str20.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) (short) 1);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer0.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Font font13 = null;
        barRenderer0.setSeriesItemLabelFont(2, font13, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        int int20 = barRenderer0.getColumnCount();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            barRenderer0.drawBackground(graphics2D21, categoryPlot22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke6);
        boolean boolean8 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Font font10 = barRenderer0.getLegendTextFont((int) (byte) 10);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        java.awt.Stroke stroke19 = barRenderer0.getItemOutlineStroke((int) '#', (int) (byte) 0, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color21);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 64);
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        float float6 = categoryAxis0.getMinorTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setTickLabelInsets(rectangleInsets7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str19 = textAnchor18.toString();
        boolean boolean20 = plotOrientation16.equals((java.lang.Object) str19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = categoryAxis0.draw(graphics2D9, (double) 1L, rectangle2D11, rectangle2D12, rectangleEdge21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str19.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer5.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition7, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer10.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition12, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer10.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer10.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer5.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        lineAndShapeRenderer4.setBasePositiveItemLabelPosition(itemLabelPosition19);
        int int22 = lineAndShapeRenderer4.getPassCount();
        boolean boolean25 = lineAndShapeRenderer4.getItemShapeFilled(255, (int) (short) 0);
        java.awt.Paint paint27 = lineAndShapeRenderer4.lookupSeriesOutlinePaint((int) (short) 0);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        lineAndShapeRenderer4.setSeriesOutlinePaint(0, (java.awt.Paint) color29);
        boolean boolean31 = defaultDrawingSupplier0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = barRenderer0.getPlot();
        double double13 = barRenderer0.getBase();
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setLegendTextFont((int) (byte) 10, font12);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis4.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis4.setLabelInsets(rectangleInsets12);
        double double15 = rectangleInsets12.trimHeight(10.0d);
        categoryAxis0.setLabelInsets(rectangleInsets12, false);
        double double19 = rectangleInsets12.trimWidth((double) 100L);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 98.0d + "'", double19 == 98.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Paint paint4 = legendItem3.getFillPaint();
        java.lang.Object obj5 = legendItem3.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem3.setLinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.gray;
        legendItem3.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.util.ShapeList shapeList10 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = barRenderer12.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint18 = barRenderer12.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        barRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis22, marker23, rectangle2D24);
        boolean boolean29 = barRenderer19.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint31 = barRenderer19.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape33 = barRenderer19.getLegendShape(100);
        java.awt.Shape shape34 = barRenderer19.getBaseShape();
        barRenderer12.setBaseShape(shape34, false);
        shapeList10.setShape(1, shape34);
        legendItem3.setLine(shape34);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNull(shape33);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape21 = barRenderer13.getLegendShape((int) (short) 0);
        barRenderer13.setShadowXOffset((double) 100.0f);
        boolean boolean27 = barRenderer13.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer13.setBaseLegendTextFont(font28);
        barRenderer0.setBaseLegendTextFont(font28);
        boolean boolean33 = barRenderer0.getItemVisible((int) (short) 0, 64);
        boolean boolean34 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Color color36 = java.awt.Color.white;
        try {
            barRenderer0.setSeriesOutlinePaint((int) (byte) -1, (java.awt.Paint) color36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) -1, true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color20 = color19.brighter();
        renderAttributes18.setDefaultLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint22 = renderAttributes18.getDefaultLabelPaint();
        barRenderer0.setSeriesFillPaint((int) (byte) 0, paint22);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        barRenderer24.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition26, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer24.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer24.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape19 = barRenderer4.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape19, "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis26, marker27, rectangle2D28);
        boolean boolean33 = barRenderer23.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean34 = barRenderer23.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape38 = barRenderer23.getItemShape((int) ' ', (int) (short) 0, true);
        chartEntity22.setArea(shape38);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator44 = barRenderer40.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint46 = barRenderer40.getSeriesFillPaint(100);
        java.awt.Stroke stroke47 = barRenderer40.getBaseStroke();
        java.awt.Paint paint48 = null;
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("", "TextAnchor.TOP_CENTER", "org.jfree.data.UnknownKeyException: ", "GradientPaintTransformType.CENTER_HORIZONTAL", shape38, stroke47, paint48);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor50 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.renderer.RenderAttributes renderAttributes51 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint53 = renderAttributes51.getSeriesFillPaint(0);
        java.awt.Font font54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes51.setDefaultLabelFont(font54);
        boolean boolean56 = itemLabelAnchor50.equals((java.lang.Object) font54);
        boolean boolean57 = legendItem49.equals((java.lang.Object) itemLabelAnchor50);
        legendItem49.setDescription("{0}");
        org.jfree.data.general.Dataset dataset60 = legendItem49.getDataset();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(categoryItemLabelGenerator44);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(itemLabelAnchor50);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(dataset60);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) (short) 1);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator2);
        barRenderer0.setBaseSeriesVisible(false, true);
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(2, 0, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        int int15 = categoryAxis14.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke16 = categoryAxis14.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        categoryAxis14.setLabelInsets(rectangleInsets17);
        java.lang.String str20 = categoryAxis14.getLabel();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D28 = barRenderer0.createHotSpotBounds(graphics2D11, rectangle2D12, categoryPlot13, categoryAxis14, valueAxis21, categoryDataset22, 64, (int) (short) 1, true, categoryItemRendererState26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer2.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint8 = barRenderer2.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        boolean boolean19 = barRenderer9.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint21 = barRenderer9.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape23 = barRenderer9.getLegendShape(100);
        java.awt.Shape shape24 = barRenderer9.getBaseShape();
        barRenderer2.setBaseShape(shape24, false);
        shapeList0.setShape(1, shape24);
        org.jfree.chart.util.SortOrder sortOrder30 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        barRenderer34.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition36, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        barRenderer39.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition41, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = barRenderer39.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = barRenderer39.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer34.setBaseNegativeItemLabelPosition(itemLabelPosition48);
        lineAndShapeRenderer33.setBasePositiveItemLabelPosition(itemLabelPosition48);
        int int51 = lineAndShapeRenderer33.getPassCount();
        java.awt.Paint paint53 = lineAndShapeRenderer33.getSeriesPaint((int) (short) 10);
        boolean boolean54 = lineAndShapeRenderer33.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        int int56 = defaultCategoryDataset55.getRowCount();
        org.jfree.data.Range range57 = lineAndShapeRenderer33.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset55);
        boolean boolean58 = sortOrder30.equals((java.lang.Object) defaultCategoryDataset55);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset59 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup60 = defaultCategoryDataset59.getGroup();
        defaultCategoryDataset55.setGroup(datasetGroup60);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "GradientPaintTransformType.CENTER_HORIZONTAL", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset65 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number66 = null;
        defaultCategoryDataset65.setValue(number66, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset65.fireSelectionEvent();
        java.util.List list71 = defaultCategoryDataset65.getRowKeys();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset72 = new org.jfree.data.category.DefaultCategoryDataset();
        int int73 = defaultCategoryDataset72.getRowCount();
        defaultCategoryDataset65.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset72);
        categoryItemEntity64.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset72);
        java.lang.Comparable comparable76 = categoryItemEntity64.getColumnKey();
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(itemLabelPosition44);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(datasetGroup60);
        org.junit.Assert.assertNotNull(list71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + comparable76 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", comparable76.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer4.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        barRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis11, marker12, rectangle2D13);
        boolean boolean18 = barRenderer8.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean19 = barRenderer8.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape23 = barRenderer8.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer4.setSeriesShape((int) '4', shape23, true);
        try {
            java.awt.GradientPaint gradientPaint29 = standardGradientPaintTransformer0.transform(gradientPaint1, shape23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer5.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint11 = barRenderer5.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer12.drawRangeMarker(graphics2D13, categoryPlot14, valueAxis15, marker16, rectangle2D17);
        boolean boolean22 = barRenderer12.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean23 = barRenderer12.getBaseSeriesVisibleInLegend();
        boolean boolean24 = barRenderer12.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        barRenderer25.drawRangeMarker(graphics2D26, categoryPlot27, valueAxis28, marker29, rectangle2D30);
        java.awt.Shape shape33 = barRenderer25.getLegendShape((int) (short) 0);
        barRenderer25.setShadowXOffset((double) 100.0f);
        boolean boolean39 = barRenderer25.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer25.setBaseLegendTextFont(font40);
        barRenderer12.setBaseLegendTextFont(font40);
        barRenderer5.setBaseItemLabelFont(font40, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes46 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint48 = renderAttributes46.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.plot.Marker marker53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        barRenderer49.drawRangeMarker(graphics2D50, categoryPlot51, valueAxis52, marker53, rectangle2D54);
        boolean boolean59 = barRenderer49.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean60 = barRenderer49.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape64 = barRenderer49.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity67 = new org.jfree.chart.entity.ChartEntity(shape64, "TextAnchor.TOP_CENTER", "");
        renderAttributes46.setDefaultShape(shape64);
        java.awt.Color color69 = java.awt.Color.blue;
        renderAttributes46.setDefaultLabelPaint((java.awt.Paint) color69);
        barRenderer5.setSeriesItemLabelPaint((int) (short) 10, (java.awt.Paint) color69, false);
        boolean boolean73 = chartChangeEventType4.equals((java.lang.Object) barRenderer5);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent74 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke2, jFreeChart3, chartChangeEventType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.Marker marker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        barRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis4, marker5, rectangle2D6);
        boolean boolean11 = barRenderer1.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean12 = barRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape16 = barRenderer1.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer1.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer1.setSeriesPaint(0, (java.awt.Paint) color22, false);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", (java.awt.Paint) color22);
        legendItem25.setLineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        barRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis16, marker17, rectangle2D18);
        java.awt.Shape shape21 = barRenderer13.getLegendShape((int) (short) 0);
        barRenderer13.setShadowXOffset((double) 100.0f);
        boolean boolean27 = barRenderer13.isItemLabelVisible(8, (int) (short) 0, true);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        barRenderer13.setBaseLegendTextFont(font28);
        barRenderer0.setBaseLegendTextFont(font28);
        boolean boolean32 = barRenderer0.isSeriesVisible((int) '4');
        boolean boolean33 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        java.awt.Shape shape19 = barRenderer0.getLegendShape((int) (short) 10);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, true);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke6);
        boolean boolean8 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        int int13 = categoryAxis12.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke14 = categoryAxis12.getAxisLineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer15.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition17, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer15.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer15.setBaseStroke(stroke21);
        categoryAxis12.setAxisLineStroke(stroke21);
        categoryAxis12.setUpperMargin((double) 3);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.util.SortOrder sortOrder27 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        barRenderer31.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition33, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        barRenderer36.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition38, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = barRenderer36.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = barRenderer36.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer31.setBaseNegativeItemLabelPosition(itemLabelPosition45);
        lineAndShapeRenderer30.setBasePositiveItemLabelPosition(itemLabelPosition45);
        int int48 = lineAndShapeRenderer30.getPassCount();
        java.awt.Paint paint50 = lineAndShapeRenderer30.getSeriesPaint((int) (short) 10);
        boolean boolean51 = lineAndShapeRenderer30.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset52 = new org.jfree.data.category.DefaultCategoryDataset();
        int int53 = defaultCategoryDataset52.getRowCount();
        org.jfree.data.Range range54 = lineAndShapeRenderer30.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset52);
        boolean boolean55 = sortOrder27.equals((java.lang.Object) defaultCategoryDataset52);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup57 = defaultCategoryDataset56.getGroup();
        defaultCategoryDataset52.setGroup(datasetGroup57);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D64 = barRenderer0.createHotSpotBounds(graphics2D9, rectangle2D10, categoryPlot11, categoryAxis12, valueAxis26, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset52, (int) '#', (int) (short) 1, false, categoryItemRendererState62, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNull(itemLabelPosition41);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(datasetGroup57);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("TextAnchor.TOP_CENTER");
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = abstractCategoryDataset0.getGroup();
        java.lang.Object obj2 = abstractCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) 2.0f, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (2.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        legendItem3.setFillPaint((java.awt.Paint) color4);
        org.jfree.data.general.Dataset dataset6 = legendItem3.getDataset();
        java.awt.Paint paint7 = legendItem3.getFillPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(dataset6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape14 = barRenderer0.getLegendShape(100);
        java.awt.Font font16 = barRenderer0.getSeriesItemLabelFont((-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNull(font16);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        int int16 = barRenderer0.getColumnCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer0.getSeriesNegativeItemLabelPosition(5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer0.setBaseStroke(stroke6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        barRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis11, marker12, rectangle2D13);
        java.awt.Color color15 = java.awt.Color.orange;
        int int16 = color15.getRGB();
        barRenderer8.setBaseFillPaint((java.awt.Paint) color15, false);
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        barRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis23, marker24, rectangle2D25);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer20.setSeriesOutlineStroke((int) (short) 100, stroke28);
        java.awt.Paint paint33 = barRenderer20.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        barRenderer0.setBaseOutlinePaint(paint33, false);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-14336) + "'", int16 == (-14336));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets0.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendItem3.setOutlineStroke(stroke5);
        boolean boolean7 = legendItem3.isLineVisible();
        int int8 = legendItem3.getSeriesIndex();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        barRenderer0.removeAnnotations();
        barRenderer0.setShadowVisible(true);
        try {
            barRenderer0.setSeriesCreateEntities((int) (byte) -1, (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number22 = null;
        defaultCategoryDataset21.setValue(number22, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset21.fireSelectionEvent();
        java.util.List list27 = defaultCategoryDataset21.getRowKeys();
        java.lang.Comparable comparable29 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset21, (java.lang.Comparable) 10.0d, comparable29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        barRenderer32.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator34);
        barRenderer32.setBaseSeriesVisible(false, true);
        java.awt.Stroke stroke42 = barRenderer32.getItemStroke(2, 0, false);
        boolean boolean43 = datasetRenderingOrder31.equals((java.lang.Object) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        double double45 = barRenderer44.getShadowYOffset();
        boolean boolean46 = datasetRenderingOrder31.equals((java.lang.Object) barRenderer44);
        boolean boolean47 = categoryItemEntity30.equals((java.lang.Object) datasetRenderingOrder31);
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.plot.Marker marker52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        barRenderer48.drawRangeMarker(graphics2D49, categoryPlot50, valueAxis51, marker52, rectangle2D53);
        java.awt.Shape shape56 = barRenderer48.getLegendShape((int) (short) 0);
        barRenderer48.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = barRenderer48.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.plot.Marker marker63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        barRenderer48.drawRangeMarker(graphics2D60, categoryPlot61, valueAxis62, marker63, rectangle2D64);
        java.awt.Shape shape67 = barRenderer48.getLegendShape((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent68 = null;
        barRenderer48.notifyListeners(rendererChangeEvent68);
        org.jfree.chart.renderer.category.BarPainter barPainter70 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer48.setBarPainter(barPainter70);
        java.awt.Stroke stroke73 = null;
        barRenderer48.setSeriesOutlineStroke((int) '4', stroke73, false);
        boolean boolean76 = datasetRenderingOrder31.equals((java.lang.Object) barRenderer48);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(shape56);
        org.junit.Assert.assertNull(itemLabelPosition59);
        org.junit.Assert.assertNull(shape67);
        org.junit.Assert.assertNotNull(barPainter70);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean15 = barRenderer4.getBaseSeriesVisibleInLegend();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset16.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj21 = defaultCategoryDataset16.clone();
        org.jfree.data.Range range22 = barRenderer4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset16);
        int int24 = defaultCategoryDataset16.getColumnCount();
        try {
            defaultCategoryDataset16.setSelected(1, 0, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        java.awt.Paint paint5 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean9 = standardCategorySeriesLabelGenerator7.equals((java.lang.Object) standardCategorySeriesLabelGenerator8);
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateTopInset(0.0d);
        double double5 = rectangleInsets0.extendHeight((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 18.0d + "'", double5 == 18.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        barRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean24 = barRenderer0.isSeriesVisibleInLegend((int) ' ');
        java.awt.Paint paint26 = barRenderer0.getSeriesItemLabelPaint((int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        barRenderer27.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition29, true);
        java.awt.Paint paint32 = barRenderer27.getShadowPaint();
        barRenderer0.setBaseOutlinePaint(paint32, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        java.util.List list6 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState7 = defaultCategoryDataset0.getSelectionState();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        defaultCategoryDataset0.setValue(number1, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset0.fireSelectionEvent();
        java.util.List list6 = defaultCategoryDataset0.getRowKeys();
        java.lang.Object obj7 = defaultCategoryDataset0.clone();
        try {
            java.lang.Number number10 = defaultCategoryDataset0.getValue(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) (byte) 0);
        categoryAxis0.setTickMarkOutsideLength((float) 2);
        double double5 = categoryAxis0.getFixedDimension();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis0.setUpperMargin((double) (-14336));
        java.lang.Object obj10 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        boolean boolean16 = barRenderer0.isSeriesVisible(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        boolean boolean13 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean14 = barRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape18 = barRenderer3.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "TextAnchor.TOP_CENTER", "");
        renderAttributes0.setDefaultShape(shape18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = null;
        barRenderer23.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition25, true);
        java.awt.Paint paint28 = barRenderer23.getShadowPaint();
        renderAttributes0.setDefaultPaint(paint28);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        boolean boolean22 = lineAndShapeRenderer2.getItemLineVisible((int) 'a', (int) (byte) 100);
        int int23 = lineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        int int25 = categoryAxis24.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke26 = categoryAxis24.getAxisLineStroke();
        lineAndShapeRenderer2.setBaseStroke(stroke26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator30);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        java.awt.Shape shape28 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        java.lang.Boolean boolean30 = lineAndShapeRenderer2.getSeriesShapesVisible((int) '#');
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color32 = color31.brighter();
        lineAndShapeRenderer2.setBasePaint((java.awt.Paint) color31, false);
        lineAndShapeRenderer2.setDrawOutlines(true);
        java.lang.Boolean boolean38 = lineAndShapeRenderer2.getSeriesShapesVisible((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(boolean38);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Stroke stroke11 = barRenderer0.getBaseOutlineStroke();
        barRenderer0.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint15 = barRenderer0.lookupLegendTextPaint((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        java.awt.Shape shape28 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        java.lang.Boolean boolean30 = lineAndShapeRenderer2.getSeriesShapesVisible((int) '#');
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color32 = color31.brighter();
        lineAndShapeRenderer2.setBasePaint((java.awt.Paint) color31, false);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color35);
        org.jfree.chart.util.SortOrder sortOrder37 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = null;
        barRenderer41.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition43, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = null;
        barRenderer46.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition48, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = barRenderer46.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = barRenderer46.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer41.setBaseNegativeItemLabelPosition(itemLabelPosition55);
        lineAndShapeRenderer40.setBasePositiveItemLabelPosition(itemLabelPosition55);
        int int58 = lineAndShapeRenderer40.getPassCount();
        java.awt.Paint paint60 = lineAndShapeRenderer40.getSeriesPaint((int) (short) 10);
        boolean boolean61 = lineAndShapeRenderer40.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset62 = new org.jfree.data.category.DefaultCategoryDataset();
        int int63 = defaultCategoryDataset62.getRowCount();
        org.jfree.data.Range range64 = lineAndShapeRenderer40.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset62);
        boolean boolean65 = sortOrder37.equals((java.lang.Object) defaultCategoryDataset62);
        org.jfree.data.Range range66 = lineAndShapeRenderer2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset62);
        java.lang.Object obj67 = lineAndShapeRenderer2.clone();
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNull(itemLabelPosition51);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertNotNull(obj67);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition2, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke8 = barRenderer0.getSeriesOutlineStroke(35);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 64);
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.getDistance();
        java.awt.image.BufferedImage bufferedImage2 = null;
        try {
            java.awt.image.BufferedImage bufferedImage3 = defaultShadowGenerator0.createDropShadow(bufferedImage2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 100);
        double double13 = barRenderer0.getShadowXOffset();
        int int14 = barRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightOutset((double) (-1.0f));
        double double5 = rectangleInsets0.calculateBottomOutset((double) 8);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, 1.0d, (double) 0.0f, (double) (short) -1, (double) 8);
        java.lang.String str12 = unitType6.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnitType.ABSOLUTE" + "'", str12.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        double double4 = rectangleInsets1.calculateTopInset(0.0d);
        categoryAxis0.setLabelInsets(rectangleInsets1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation10, plotOrientation11);
        try {
            double double13 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, 10, (int) (short) 10, rectangle2D9, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("TextAnchor.BOTTOM_LEFT", paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        java.awt.Shape shape19 = barRenderer0.getLegendShape((int) (short) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        barRenderer21.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        java.awt.Shape shape29 = barRenderer21.getLegendShape((int) (short) 0);
        barRenderer21.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer21.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.Marker marker36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        barRenderer21.drawRangeMarker(graphics2D33, categoryPlot34, valueAxis35, marker36, rectangle2D37);
        java.awt.Shape shape40 = barRenderer21.getLegendShape((int) (short) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = barRenderer21.getLegendItems();
        java.lang.Object obj42 = null;
        boolean boolean43 = legendItemCollection41.equals(obj42);
        legendItemCollection20.addAll(legendItemCollection41);
        java.util.Iterator iterator45 = legendItemCollection41.iterator();
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNull(itemLabelPosition32);
        org.junit.Assert.assertNull(shape40);
        org.junit.Assert.assertNotNull(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(iterator45);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        boolean boolean23 = lineAndShapeRenderer2.getItemShapeFilled(255, (int) (short) 0);
        org.jfree.chart.LegendItem legendItem26 = lineAndShapeRenderer2.getLegendItem((int) (short) 0, 0);
        boolean boolean29 = lineAndShapeRenderer2.getItemShapeFilled(3, (int) (short) 1);
        lineAndShapeRenderer2.clearSeriesPaints(false);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 10.0f);
        keyedObjects0.clear();
        java.lang.Object obj4 = keyedObjects0.clone();
        try {
            keyedObjects0.insertValue((-16777024), (java.lang.Comparable) "{0}", (java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        java.awt.Paint paint4 = legendItem3.getFillPaint();
        java.awt.Shape shape5 = legendItem3.getLine();
        boolean boolean6 = legendItem3.isLineVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        renderAttributes0.setSeriesShape(64, shape21);
        java.awt.Paint paint25 = renderAttributes0.getItemFillPaint(3, (int) '4');
        try {
            java.lang.Boolean boolean27 = renderAttributes0.getSeriesLabelVisible(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        java.lang.String str19 = chartEntity18.getToolTipText();
        chartEntity18.setToolTipText("GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str19.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        java.awt.Shape shape28 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        java.lang.Boolean boolean30 = lineAndShapeRenderer2.getSeriesShapesVisible((int) '#');
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color32 = color31.brighter();
        lineAndShapeRenderer2.setBasePaint((java.awt.Paint) color31, false);
        boolean boolean36 = lineAndShapeRenderer2.isSeriesVisibleInLegend(10);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder40 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot39.setRowRenderingOrder(sortOrder40);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.plot.Marker marker46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        barRenderer42.drawRangeMarker(graphics2D43, categoryPlot44, valueAxis45, marker46, rectangle2D47);
        boolean boolean52 = barRenderer42.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean53 = barRenderer42.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape57 = barRenderer42.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity60 = new org.jfree.chart.entity.ChartEntity(shape57, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset63 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number64 = null;
        defaultCategoryDataset63.setValue(number64, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset63.fireSelectionEvent();
        java.util.List list69 = defaultCategoryDataset63.getRowKeys();
        java.lang.Comparable comparable71 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity72 = new org.jfree.chart.entity.CategoryItemEntity(shape57, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset63, (java.lang.Comparable) 10.0d, comparable71);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState74 = lineAndShapeRenderer2.initialise(graphics2D37, rectangle2D38, categoryPlot39, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset63, plotRenderingInfo73);
        categoryPlot39.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation78 = axisLocation77.getOpposite();
        categoryPlot39.setRangeAxisLocation((int) 'a', axisLocation77);
        java.awt.Graphics2D graphics2D80 = null;
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        java.awt.geom.Point2D point2D82 = null;
        org.jfree.chart.plot.PlotState plotState83 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        try {
            categoryPlot39.draw(graphics2D80, rectangle2D81, point2D82, plotState83, plotRenderingInfo84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(sortOrder40);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertNotNull(categoryItemRendererState74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(axisLocation78);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) ' ', (float) '#', (float) (short) 1);
        barRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color21, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        boolean boolean13 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean14 = barRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape18 = barRenderer3.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "TextAnchor.TOP_CENTER", "");
        renderAttributes0.setDefaultShape(shape18);
        java.awt.Paint paint24 = renderAttributes0.getSeriesFillPaint((int) (short) -1);
        java.awt.Paint paint26 = renderAttributes0.getSeriesPaint((int) (byte) 0);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis4.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis4.setLabelInsets(rectangleInsets12);
        double double15 = rectangleInsets12.trimHeight(10.0d);
        categoryAxis0.setLabelInsets(rectangleInsets12, false);
        categoryAxis0.setMinorTickMarkInsideLength((float) (byte) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer1.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator3);
        barRenderer1.setItemMargin((double) ' ');
        barRenderer1.setBaseSeriesVisibleInLegend(true);
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color12 = color11.darker();
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color12);
        java.awt.Paint paint14 = legendItem13.getFillPaint();
        java.lang.Object obj15 = legendItem13.clone();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem13.setLinePaint((java.awt.Paint) color16);
        barRenderer1.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color16, false);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator23 = new org.jfree.chart.util.DefaultShadowGenerator((int) '4', color16, (float) (short) 1, (int) '4', (double) 2.0f);
        double double24 = defaultShadowGenerator23.getAngle();
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 10.0f);
        keyedObjects0.clear();
        try {
            java.lang.Comparable comparable5 = keyedObjects0.getKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Stroke stroke11 = barRenderer0.getBaseOutlineStroke();
        double double12 = barRenderer0.getShadowXOffset();
        java.lang.Boolean boolean14 = barRenderer0.getSeriesVisibleInLegend((int) (byte) 10);
        double double15 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) 100L, false);
        java.lang.Number number3 = selectableValue2.getValue();
        boolean boolean4 = selectableValue2.isSelected();
        boolean boolean5 = selectableValue2.isSelected();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100L + "'", number3.equals(100L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 10.0f);
        keyedObjects0.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        keyedObjects0.sortByObjects(sortOrder5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        java.awt.Color color17 = java.awt.Color.orange;
        barRenderer0.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color17, false);
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color22 = color21.darker();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color22);
        barRenderer0.setShadowPaint((java.awt.Paint) color22);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator25);
        barRenderer0.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightOutset((double) (-1.0f));
        double double5 = rectangleInsets0.calculateBottomOutset((double) 8);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (-14336));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer8.setBaseStroke(stroke14);
        categoryAxis5.setAxisLineStroke(stroke14);
        categoryAxis5.setUpperMargin((double) 3);
        double double19 = categoryAxis5.getLabelAngle();
        java.lang.Object obj20 = categoryAxis5.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder22 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot21.setRowRenderingOrder(sortOrder22);
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint26 = renderAttributes24.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        barRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis30, marker31, rectangle2D32);
        boolean boolean37 = barRenderer27.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean38 = barRenderer27.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape42 = barRenderer27.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity(shape42, "TextAnchor.TOP_CENTER", "");
        renderAttributes24.setDefaultShape(shape42);
        java.awt.Color color47 = java.awt.Color.blue;
        renderAttributes24.setDefaultLabelPaint((java.awt.Paint) color47);
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_YELLOW;
        renderAttributes24.setSeriesFillPaint(100, (java.awt.Paint) color50);
        categoryPlot21.setRangeCrosshairPaint((java.awt.Paint) color50);
        boolean boolean53 = categoryPlot21.isDomainGridlinesVisible();
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        boolean boolean55 = categoryPlot21.canSelectByRegion();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation57, plotOrientation58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace61 = categoryAxis0.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) categoryPlot21, rectangle2D56, rectangleEdge59, axisSpace60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) (short) 100, (java.lang.Boolean) false);
        booleanList0.setBoolean(35, (java.lang.Boolean) false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false, false);
        java.lang.Boolean boolean17 = barRenderer0.getSeriesCreateEntities(2);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator18, false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer2.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint8 = barRenderer2.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        boolean boolean19 = barRenderer9.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint21 = barRenderer9.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape23 = barRenderer9.getLegendShape(100);
        java.awt.Shape shape24 = barRenderer9.getBaseShape();
        barRenderer2.setBaseShape(shape24, false);
        shapeList0.setShape(1, shape24);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = new org.jfree.chart.event.DatasetChangeInfo();
        boolean boolean29 = shapeList0.equals((java.lang.Object) datasetChangeInfo28);
        java.lang.Object obj30 = shapeList0.clone();
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        java.awt.Paint paint22 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 10);
        boolean boolean23 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        int int25 = defaultCategoryDataset24.getRowCount();
        org.jfree.data.Range range26 = lineAndShapeRenderer2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        boolean boolean27 = lineAndShapeRenderer2.getUseOutlinePaint();
        lineAndShapeRenderer2.setSeriesShapesVisible((int) 'a', false);
        boolean boolean31 = lineAndShapeRenderer2.getUseSeriesOffset();
        double double32 = lineAndShapeRenderer2.getItemMargin();
        java.lang.Boolean boolean34 = lineAndShapeRenderer2.getSeriesShapesFilled((-16777024));
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(boolean34);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.lang.Object obj3 = objectList1.get((int) ' ');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        int int5 = objectList1.indexOf((java.lang.Object) chartChangeEventType4);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        java.awt.Shape shape19 = barRenderer0.getLegendShape((int) (short) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer0.notifyListeners(rendererChangeEvent20);
        org.jfree.chart.renderer.category.BarPainter barPainter22 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer0.setBarPainter(barPainter22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition24);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        barRenderer0.setSeriesURLGenerator(100, categoryURLGenerator27);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(barPainter22);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.setShadowYOffset(0.0d);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color17 = color16.darker();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color17);
        boolean boolean19 = barRenderer0.equals((java.lang.Object) color17);
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color22 = color21.brighter();
        renderAttributes20.setDefaultLabelPaint((java.awt.Paint) color22);
        java.awt.Paint paint24 = renderAttributes20.getDefaultLabelPaint();
        boolean boolean25 = color17.equals((java.lang.Object) renderAttributes20);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Stroke stroke11 = barRenderer0.getBaseOutlineStroke();
        double double12 = barRenderer0.getShadowXOffset();
        java.lang.Boolean boolean14 = barRenderer0.getSeriesVisibleInLegend((int) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        barRenderer16.drawRangeMarker(graphics2D17, categoryPlot18, valueAxis19, marker20, rectangle2D21);
        java.awt.Stroke stroke26 = barRenderer16.getItemStroke((-1), 100, true);
        java.awt.Shape shape30 = barRenderer16.getItemShape((int) (byte) 10, (int) (short) 0, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.Marker marker36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        barRenderer32.drawRangeMarker(graphics2D33, categoryPlot34, valueAxis35, marker36, rectangle2D37);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer32.setSeriesOutlineStroke((int) (short) 100, stroke40);
        java.awt.Paint paint45 = barRenderer32.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis31.setAxisLinePaint(paint45);
        java.lang.String str47 = categoryAxis31.getLabel();
        java.awt.Paint paint49 = categoryAxis31.getTickLabelPaint((java.lang.Comparable) 1.0f);
        java.awt.Paint paint50 = categoryAxis31.getTickLabelPaint();
        barRenderer16.setShadowPaint(paint50);
        java.awt.Stroke stroke52 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer16.setBaseStroke(stroke52);
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke52);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke57 = categoryPlot56.getOutlineStroke();
        java.awt.Stroke stroke58 = categoryPlot56.getRangeGridlineStroke();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        try {
            barRenderer0.drawOutline(graphics2D55, categoryPlot56, rectangle2D59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setUseSeriesOffset(false);
        java.lang.Object obj5 = lineAndShapeRenderer2.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint18 = barRenderer6.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape20 = barRenderer6.getLegendShape(100);
        java.awt.Shape shape21 = barRenderer6.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color23 = java.awt.Color.orange;
        float[] floatArray30 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray31 = color23.getColorComponents(floatArray30);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape21, stroke22, (java.awt.Paint) color23);
        try {
            java.awt.GradientPaint gradientPaint33 = standardGradientPaintTransformer0.transform(gradientPaint1, shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        barRenderer4.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition6, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        barRenderer9.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition11, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer9.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer9.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer4.setBaseNegativeItemLabelPosition(itemLabelPosition18);
        lineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition18);
        int int21 = lineAndShapeRenderer3.getPassCount();
        java.awt.Paint paint23 = lineAndShapeRenderer3.getSeriesPaint((int) (short) 10);
        boolean boolean24 = lineAndShapeRenderer3.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        int int26 = defaultCategoryDataset25.getRowCount();
        org.jfree.data.Range range27 = lineAndShapeRenderer3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25);
        boolean boolean28 = sortOrder0.equals((java.lang.Object) defaultCategoryDataset25);
        java.lang.Comparable comparable31 = null;
        try {
            defaultCategoryDataset25.setValue((java.lang.Number) (-1L), (java.lang.Comparable) (short) 10, comparable31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.lang.String str2 = axisLocation0.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation3);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str2.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis4.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis4.setLabelInsets(rectangleInsets12);
        double double15 = rectangleInsets12.trimHeight(10.0d);
        categoryAxis0.setLabelInsets(rectangleInsets12, false);
        boolean boolean18 = categoryAxis0.isVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(0);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        defaultCategoryDataset0.addValue((java.lang.Number) 1, (java.lang.Comparable) "TextAnchor.BOTTOM_LEFT", (java.lang.Comparable) 1);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 35);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (35) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getRowCount();
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset4);
        java.util.List list7 = defaultCategoryDataset4.getColumnKeys();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = defaultCategoryDataset4.hasListener(eventListener8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer12.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        barRenderer16.drawRangeMarker(graphics2D17, categoryPlot18, valueAxis19, marker20, rectangle2D21);
        boolean boolean26 = barRenderer16.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean27 = barRenderer16.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape31 = barRenderer16.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape31, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer12.setSeriesShape((int) '4', shape31, true);
        java.awt.Shape shape38 = lineAndShapeRenderer12.getSeriesShape((int) (byte) 100);
        java.lang.Boolean boolean40 = lineAndShapeRenderer12.getSeriesShapesVisible((int) '#');
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color42 = color41.brighter();
        lineAndShapeRenderer12.setBasePaint((java.awt.Paint) color41, false);
        boolean boolean46 = lineAndShapeRenderer12.isSeriesVisibleInLegend(10);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder50 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot49.setRowRenderingOrder(sortOrder50);
        org.jfree.chart.renderer.category.BarRenderer barRenderer52 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.plot.Marker marker56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        barRenderer52.drawRangeMarker(graphics2D53, categoryPlot54, valueAxis55, marker56, rectangle2D57);
        boolean boolean62 = barRenderer52.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean63 = barRenderer52.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape67 = barRenderer52.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity70 = new org.jfree.chart.entity.ChartEntity(shape67, "TextAnchor.TOP_CENTER", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset73 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number74 = null;
        defaultCategoryDataset73.setValue(number74, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        defaultCategoryDataset73.fireSelectionEvent();
        java.util.List list79 = defaultCategoryDataset73.getRowKeys();
        java.lang.Comparable comparable81 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity82 = new org.jfree.chart.entity.CategoryItemEntity(shape67, "", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset73, (java.lang.Comparable) 10.0d, comparable81);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState84 = lineAndShapeRenderer12.initialise(graphics2D47, rectangle2D48, categoryPlot49, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset73, plotRenderingInfo83);
        categoryPlot49.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation88 = axisLocation87.getOpposite();
        categoryPlot49.setRangeAxisLocation((int) 'a', axisLocation87);
        boolean boolean90 = defaultCategoryDataset4.hasListener((java.util.EventListener) categoryPlot49);
        org.jfree.chart.LegendItemCollection legendItemCollection91 = categoryPlot49.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNull(boolean40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(sortOrder50);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(list79);
        org.junit.Assert.assertNotNull(categoryItemRendererState84);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertNotNull(axisLocation88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(legendItemCollection91);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer3.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer3.setBaseStroke(stroke9);
        categoryAxis0.setAxisLineStroke(stroke9);
        categoryAxis0.setUpperMargin((double) 3);
        double double14 = categoryAxis0.getLabelAngle();
        java.lang.Object obj15 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot16.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint21 = renderAttributes19.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        barRenderer22.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis25, marker26, rectangle2D27);
        boolean boolean32 = barRenderer22.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean33 = barRenderer22.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape37 = barRenderer22.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity(shape37, "TextAnchor.TOP_CENTER", "");
        renderAttributes19.setDefaultShape(shape37);
        java.awt.Color color42 = java.awt.Color.blue;
        renderAttributes19.setDefaultLabelPaint((java.awt.Paint) color42);
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_YELLOW;
        renderAttributes19.setSeriesFillPaint(100, (java.awt.Paint) color45);
        categoryPlot16.setRangeCrosshairPaint((java.awt.Paint) color45);
        boolean boolean48 = categoryPlot16.isDomainGridlinesVisible();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot16.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 100, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color2 = color1.brighter();
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Paint paint5 = renderAttributes0.getDefaultOutlinePaint();
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer9.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint15 = barRenderer9.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        barRenderer16.drawRangeMarker(graphics2D17, categoryPlot18, valueAxis19, marker20, rectangle2D21);
        boolean boolean26 = barRenderer16.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint28 = barRenderer16.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape30 = barRenderer16.getLegendShape(100);
        java.awt.Shape shape31 = barRenderer16.getBaseShape();
        barRenderer9.setBaseShape(shape31, false);
        shapeList7.setShape(1, shape31);
        org.jfree.chart.util.SortOrder sortOrder37 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = null;
        barRenderer41.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition43, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = null;
        barRenderer46.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition48, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = barRenderer46.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = barRenderer46.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer41.setBaseNegativeItemLabelPosition(itemLabelPosition55);
        lineAndShapeRenderer40.setBasePositiveItemLabelPosition(itemLabelPosition55);
        int int58 = lineAndShapeRenderer40.getPassCount();
        java.awt.Paint paint60 = lineAndShapeRenderer40.getSeriesPaint((int) (short) 10);
        boolean boolean61 = lineAndShapeRenderer40.getUseSeriesOffset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset62 = new org.jfree.data.category.DefaultCategoryDataset();
        int int63 = defaultCategoryDataset62.getRowCount();
        org.jfree.data.Range range64 = lineAndShapeRenderer40.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset62);
        boolean boolean65 = sortOrder37.equals((java.lang.Object) defaultCategoryDataset62);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset66 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup67 = defaultCategoryDataset66.getGroup();
        defaultCategoryDataset62.setGroup(datasetGroup67);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity71 = new org.jfree.chart.entity.CategoryItemEntity(shape31, "GradientPaintTransformType.CENTER_HORIZONTAL", "", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset62, (java.lang.Comparable) (short) 1, (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
        renderAttributes0.setSeriesShape((int) (byte) 10, shape31);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNull(itemLabelPosition51);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(datasetGroup67);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation2, plotOrientation3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str6 = textAnchor5.toString();
        boolean boolean7 = plotOrientation3.equals((java.lang.Object) str6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation3);
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str6.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 2, (double) (byte) 10, (double) 0L);
        categoryAxis0.setLabelInsets(rectangleInsets8);
        double double11 = rectangleInsets8.trimHeight(10.0d);
        double double13 = rectangleInsets8.calculateRightOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightOutset((double) (-1.0f));
        double double5 = rectangleInsets0.calculateBottomOutset((double) 8);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets0.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer2.getItemLabelGenerator(0, (int) '#', false);
        java.awt.Paint paint8 = barRenderer2.getSeriesFillPaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        boolean boolean19 = barRenderer9.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint21 = barRenderer9.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape23 = barRenderer9.getLegendShape(100);
        java.awt.Shape shape24 = barRenderer9.getBaseShape();
        barRenderer2.setBaseShape(shape24, false);
        shapeList0.setShape(1, shape24);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = new org.jfree.chart.event.DatasetChangeInfo();
        boolean boolean29 = shapeList0.equals((java.lang.Object) datasetChangeInfo28);
        int int30 = shapeList0.size();
        java.lang.Object obj31 = shapeList0.clone();
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem(2, (int) (byte) 10);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Paint paint18 = barRenderer0.getSeriesItemLabelPaint(100);
        barRenderer0.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getRowKey((-16777024));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color1.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        int int3 = lineAndShapeRenderer2.getColumnCount();
        java.awt.Font font5 = lineAndShapeRenderer2.getLegendTextFont(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(font5);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint14 = barRenderer0.getItemLabelPaint(10, 100, true);
        java.awt.Font font15 = null;
        barRenderer0.setBaseItemLabelFont(font15, false);
        java.awt.Paint paint18 = barRenderer0.getBasePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis26, marker27, rectangle2D28);
        boolean boolean33 = barRenderer23.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint35 = barRenderer23.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape37 = barRenderer23.getLegendShape(100);
        java.awt.Shape shape38 = barRenderer23.getBaseShape();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color40 = java.awt.Color.orange;
        float[] floatArray47 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray48 = color40.getColorComponents(floatArray47);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape38, stroke39, (java.awt.Paint) color40);
        java.awt.Shape shape50 = legendItem49.getLine();
        legendItem49.setSeriesKey((java.lang.Comparable) (byte) -1);
        java.awt.Shape shape53 = legendItem49.getShape();
        barRenderer0.setBaseLegendShape(shape53);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shape53);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer1.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition3, true);
        barRenderer1.setItemLabelAnchorOffset(0.0d);
        barRenderer1.clearSeriesStrokes(true);
        java.awt.Font font13 = barRenderer1.getItemLabelFont((-1), (int) (byte) 0, false);
        boolean boolean14 = gradientPaintTransformType0.equals((java.lang.Object) barRenderer1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        double double2 = categoryAxis0.getFixedDimension();
        java.awt.Font font3 = categoryAxis0.getLabelFont();
        java.awt.Paint paint4 = categoryAxis0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) (short) 100, (java.lang.Boolean) false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextStroke();
        java.awt.Stroke stroke6 = defaultDrawingSupplier4.getNextStroke();
        boolean boolean7 = booleanList0.equals((java.lang.Object) defaultDrawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number5 = null;
        defaultCategoryDataset4.setValue(number5, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        java.util.List list9 = defaultCategoryDataset4.getRowKeys();
        boolean boolean10 = gradientPaintTransformType3.equals((java.lang.Object) list9);
        boolean boolean11 = datasetGroup1.equals((java.lang.Object) list9);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes4.setDefaultCreateEntity((java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer12.drawRangeMarker(graphics2D13, categoryPlot14, valueAxis15, marker16, rectangle2D17);
        boolean boolean22 = barRenderer12.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint24 = barRenderer12.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape26 = barRenderer12.getLegendShape(100);
        java.awt.Shape shape27 = barRenderer12.getBaseShape();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color29 = java.awt.Color.orange;
        float[] floatArray36 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray37 = color29.getColorComponents(floatArray36);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape27, stroke28, (java.awt.Paint) color29);
        renderAttributes4.setSeriesShape((int) (byte) 10, shape27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        barRenderer43.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition45, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = null;
        barRenderer48.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition50, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = barRenderer48.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = barRenderer48.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer43.setBaseNegativeItemLabelPosition(itemLabelPosition57);
        lineAndShapeRenderer42.setBasePositiveItemLabelPosition(itemLabelPosition57);
        int int60 = lineAndShapeRenderer42.getPassCount();
        boolean boolean61 = lineAndShapeRenderer42.getDrawOutlines();
        java.awt.Stroke stroke62 = lineAndShapeRenderer42.getBaseOutlineStroke();
        java.awt.Paint paint63 = null;
        try {
            org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem(attributedString0, "", "ItemLabelAnchor.OUTSIDE2", "TextAnchor.BOTTOM_LEFT", shape27, stroke62, paint63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(shape26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        java.lang.String str19 = chartEntity18.getShapeType();
        java.lang.Object obj20 = chartEntity18.clone();
        java.lang.String str21 = chartEntity18.getURLText();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) "TextAnchor.BOTTOM_LEFT", (java.lang.Comparable) "TextAnchor.HALF_ASCENT_CENTER");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (TextAnchor.BOTTOM_LEFT) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis14, marker15, rectangle2D16);
        java.awt.Shape shape19 = barRenderer0.getLegendShape((int) (short) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = barRenderer0.getLegendItems();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color23 = color22.darker();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color23);
        java.awt.Paint paint25 = legendItem24.getFillPaint();
        java.lang.Object obj26 = legendItem24.clone();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem24.setLinePaint((java.awt.Paint) color27);
        legendItemCollection20.add(legendItem24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection20);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint5 = renderAttributes3.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        renderAttributes3.setDefaultShape(shape21);
        java.awt.Color color26 = java.awt.Color.blue;
        renderAttributes3.setDefaultLabelPaint((java.awt.Paint) color26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_YELLOW;
        renderAttributes3.setSeriesFillPaint(100, (java.awt.Paint) color29);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color29);
        int int32 = color29.getRGB();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-4145152) + "'", int32 == (-4145152));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        java.awt.Shape shape11 = barRenderer3.getLegendShape((int) (short) 0);
        barRenderer3.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer3.getPositiveItemLabelPositionFallback();
        barRenderer3.setSeriesVisible(0, (java.lang.Boolean) false, true);
        keyedObjects2D0.setObject((java.lang.Object) true, (java.lang.Comparable) 8, (java.lang.Comparable) 10.0d);
        try {
            java.lang.Object obj24 = keyedObjects2D0.getObject((java.lang.Comparable) (byte) 0, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertNull(itemLabelPosition14);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setLabelAngle((double) (short) 1);
        categoryAxis0.setLabel("GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition5, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer8.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer8.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        int int20 = lineAndShapeRenderer2.getPassCount();
        lineAndShapeRenderer2.setUseOutlinePaint(true);
        lineAndShapeRenderer2.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 1, (double) 0L, (double) 2.0f);
        double double7 = rectangleInsets5.extendHeight((double) (short) 1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.Marker marker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        barRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis4, marker5, rectangle2D6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 100, stroke9);
        java.awt.Paint paint14 = barRenderer1.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis0.setAxisLinePaint(paint14);
        java.lang.String str16 = categoryAxis0.getLabel();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0f);
        double double19 = categoryAxis0.getCategoryMargin();
        java.awt.Paint paint20 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        renderAttributes0.setSeriesShape(64, shape21);
        java.awt.Paint paint25 = renderAttributes0.getItemFillPaint(3, (int) '4');
        java.awt.Shape shape28 = renderAttributes0.getItemShape((int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNull(shape28);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getRowCount();
        legendItem3.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset4);
        defaultCategoryDataset4.addValue((double) (-14336), (java.lang.Comparable) 0.0d, (java.lang.Comparable) (-14336.0d));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        barRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis7, marker8, rectangle2D9);
        boolean boolean14 = barRenderer4.isItemLabelVisible((int) (short) 10, (int) '4', true);
        java.awt.Paint paint16 = barRenderer4.getSeriesItemLabelPaint((int) (byte) 100);
        java.awt.Shape shape18 = barRenderer4.getLegendShape(100);
        java.awt.Shape shape19 = barRenderer4.getBaseShape();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color21 = java.awt.Color.orange;
        float[] floatArray28 = new float[] { 100.0f, (short) 1, 10L, 0.0f, (byte) -1, (-1) };
        float[] floatArray29 = color21.getColorComponents(floatArray28);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "DatasetRenderingOrder.FORWARD", shape19, stroke20, (java.awt.Paint) color21);
        java.awt.Shape shape31 = legendItem30.getLine();
        legendItem30.setSeriesKey((java.lang.Comparable) (byte) -1);
        java.awt.Stroke stroke34 = legendItem30.getLineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = null;
        barRenderer38.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition40, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        barRenderer43.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition45, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = barRenderer43.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = barRenderer43.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer38.setBaseNegativeItemLabelPosition(itemLabelPosition52);
        lineAndShapeRenderer37.setBasePositiveItemLabelPosition(itemLabelPosition52);
        int int55 = lineAndShapeRenderer37.getPassCount();
        boolean boolean58 = lineAndShapeRenderer37.getItemShapeFilled(255, (int) (short) 0);
        java.awt.Paint paint60 = lineAndShapeRenderer37.lookupSeriesOutlinePaint((int) (short) 0);
        legendItem30.setLabelPaint(paint60);
        java.awt.Stroke stroke62 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendItem30.setOutlineStroke(stroke62);
        java.lang.Object obj64 = legendItem30.clone();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(itemLabelPosition48);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(obj64);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset4.setValue((double) (byte) 1, (java.lang.Comparable) "hi!", (java.lang.Comparable) 1);
        java.lang.Object obj9 = defaultCategoryDataset4.clone();
        boolean boolean10 = categoryAxis0.equals((java.lang.Object) defaultCategoryDataset4);
        java.util.List list11 = defaultCategoryDataset4.getRowKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.Marker marker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        barRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis4, marker5, rectangle2D6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 100, stroke9);
        java.awt.Paint paint14 = barRenderer1.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis0.setAxisLinePaint(paint14);
        java.lang.String str16 = categoryAxis0.getLabel();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0f);
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.Paint paint20 = categoryAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.Marker marker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        barRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis4, marker5, rectangle2D6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 100, stroke9);
        java.awt.Paint paint14 = barRenderer1.getItemOutlinePaint((int) (short) 10, (int) '4', false);
        categoryAxis0.setAxisLinePaint(paint14);
        java.lang.String str16 = categoryAxis0.getLabel();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0f);
        double double19 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMinorTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "TextAnchor.TOP_CENTER", "");
        java.lang.String str19 = chartEntity18.getShapeType();
        java.lang.String str20 = chartEntity18.getShapeType();
        java.lang.String str21 = chartEntity18.getToolTipText();
        java.lang.Object obj22 = chartEntity18.clone();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str21.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 64);
        categoryAxis0.setUpperMargin((double) (byte) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        barRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis10, marker11, rectangle2D12);
        boolean boolean17 = barRenderer7.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean18 = barRenderer7.getBaseSeriesVisibleInLegend();
        barRenderer7.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Paint paint23 = barRenderer7.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Font font24 = barRenderer7.getBaseItemLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 2.0f, font24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        int int27 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.lang.Boolean boolean29 = lineAndShapeRenderer2.getSeriesShapesVisible((int) (byte) 100);
        lineAndShapeRenderer2.setSeriesShapesVisible(10, (java.lang.Boolean) false);
        lineAndShapeRenderer2.setDrawOutlines(true);
        try {
            lineAndShapeRenderer2.setItemMargin((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNull(boolean29);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str1.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        boolean boolean10 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) ' ', (int) (short) 0, true);
        barRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = barRenderer0.getURLGenerator((int) (short) -1, (int) (short) 10, false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryURLGenerator25);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 10.0f);
        keyedObjects0.clear();
        keyedObjects0.clear();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer6.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator8);
        barRenderer6.setItemMargin((double) ' ');
        barRenderer6.setBaseSeriesVisibleInLegend(true);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color17 = color16.darker();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color17);
        java.awt.Paint paint19 = legendItem18.getFillPaint();
        java.lang.Object obj20 = legendItem18.clone();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        legendItem18.setLinePaint((java.awt.Paint) color21);
        barRenderer6.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color21, false);
        keyedObjects0.setObject((java.lang.Comparable) 0.0d, (java.lang.Object) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder27 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot26.setRowRenderingOrder(sortOrder27);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot26.getColumnRenderingOrder();
        keyedObjects0.sortByObjects(sortOrder29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNotNull(sortOrder29);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        barRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Shape shape8 = barRenderer0.getLegendShape((int) (short) 0);
        barRenderer0.setShadowXOffset((double) 100.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer0.getBaseToolTipGenerator();
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        barRenderer0.setSeriesItemLabelPaint(100, (java.awt.Paint) color14, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        barRenderer18.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition20, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer18.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer18.getNegativeItemLabelPosition((int) ' ', (-14336), false);
        barRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition27, false);
        java.lang.Object obj30 = null;
        boolean boolean31 = itemLabelPosition27.equals(obj30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_BLUE;
        boolean boolean33 = itemLabelPosition27.equals((java.lang.Object) color32);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number2 = null;
        defaultCategoryDataset1.setValue(number2, (java.lang.Comparable) 'a', (java.lang.Comparable) (byte) 10);
        java.util.List list6 = defaultCategoryDataset1.getRowKeys();
        boolean boolean7 = gradientPaintTransformType0.equals((java.lang.Object) list6);
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        boolean boolean9 = gradientPaintTransformType0.equals((java.lang.Object) paintArray8);
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        int int11 = color10.getBlue();
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) int11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 64 + "'", int11 == 64);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        barRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis9, marker10, rectangle2D11);
        boolean boolean16 = barRenderer6.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean17 = barRenderer6.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape21 = barRenderer6.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextAnchor.TOP_CENTER", "");
        lineAndShapeRenderer2.setSeriesShape((int) '4', shape21, true);
        int int27 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.lang.Boolean boolean29 = lineAndShapeRenderer2.getSeriesShapesVisible((int) (byte) 100);
        lineAndShapeRenderer2.setSeriesShapesVisible(10, (java.lang.Boolean) false);
        lineAndShapeRenderer2.setDrawOutlines(true);
        java.util.EventListener eventListener35 = null;
        boolean boolean36 = lineAndShapeRenderer2.hasListener(eventListener35);
        lineAndShapeRenderer2.setBaseShapesFilled(true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        categoryAxis0.setLowerMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        categoryAxis0.setLabelInsets(rectangleInsets4, true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        categoryAxis0.addChangeListener(axisChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesOutlinePaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        barRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis6, marker7, rectangle2D8);
        boolean boolean13 = barRenderer3.isItemLabelVisible((int) (short) 10, (int) '4', true);
        boolean boolean14 = barRenderer3.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape18 = barRenderer3.getItemShape((int) ' ', (int) (short) 0, true);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "TextAnchor.TOP_CENTER", "");
        renderAttributes0.setDefaultShape(shape18);
        java.awt.Color color23 = java.awt.Color.blue;
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color23);
        java.awt.Paint paint25 = renderAttributes0.getDefaultPaint();
        try {
            renderAttributes0.setSeriesCreateEntity((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (-4145152));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }
}

