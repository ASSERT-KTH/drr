import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 'a', 10.0f);
        float[] floatArray7 = new float[] { (short) -1, (byte) 0, (byte) 1 };
        try {
            float[] floatArray8 = color3.getComponents(floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        boolean boolean4 = color2.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = new float[] { (short) 0, 1.0f, 100 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        java.awt.Color color3 = color2.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str1.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color2 = java.awt.Color.yellow;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        boolean boolean10 = chartChangeEventType0.equals((java.lang.Object) rectangle5);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        valueMarker1.setAlpha((float) (short) 1);
        double double7 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray4 = new float[] { 10L, 13, (short) 0 };
        try {
            float[] floatArray5 = color0.getRGBComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot6.handleClick(0, (int) (byte) 10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 1, 0.0f, 2.0f);
        int int4 = color3.getRed();
        float[] floatArray6 = new float[] { 500 };
        try {
            float[] floatArray7 = color3.getComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TextAnchor.BASELINE_CENTER");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double5 = rectangleInsets0.trimHeight((double) 43629L);
        double double7 = rectangleInsets0.calculateLeftOutset((double) 255);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets0.createInsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 43629.0d + "'", double5 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int3 = java.awt.Color.HSBtoRGB((float) 43629L, (float) '#', (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-14417954) + "'", int3 == (-14417954));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            xYPlot0.addDomainMarker((int) (byte) 100, marker4, layer5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            xYPlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), (float) 10L, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-246) + "'", int3 == (-246));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            xYPlot0.handleClick((int) (byte) 1, 9, plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double5 = rectangleInsets0.trimHeight((double) 43629L);
        double double6 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            rectangleInsets0.trim(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 43629.0d + "'", double5 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = numberAxis2.draw(graphics2D7, (double) 0L, rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        float[] floatArray8 = new float[] { (-246), 1, '#', 0, 100 };
        float[] floatArray9 = java.awt.Color.RGBtoHSB((int) (byte) 1, 500, (-246), floatArray8);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener15 = null;
        valueMarker14.addChangeListener(markerChangeListener15);
        java.awt.Paint paint17 = valueMarker14.getOutlinePaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = valueMarker14.equals(obj18);
        org.jfree.chart.util.Layer layer20 = null;
        try {
            xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker14, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            categoryPlot6.handleClick(255, (int) 'a', plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        categoryPlot6.setAnchorValue((double) '4', false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        try {
            int int15 = categoryPlot6.getRangeAxisIndex(valueAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
//        boolean boolean4 = day0.equals((java.lang.Object) unitType3);
//        java.lang.Object obj5 = null;
//        boolean boolean6 = unitType3.equals(obj5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color1 = java.awt.Color.black;
        int int2 = color1.getRed();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke3);
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass9 = color8.getClass();
        try {
            java.util.EventListener[] eventListenerArray10 = categoryMarker4.getListeners((java.lang.Class) wildcardClass9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        java.lang.Object obj4 = null;
        boolean boolean5 = textAnchor2.equals(obj4);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setAnchorValue((double) ' ', false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            categoryPlot6.handleClick(3, (int) (byte) 0, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot6.addRangeMarker((int) '4', marker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(categoryAxis35);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        try {
            valueMarker1.setAlpha(2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = java.awt.Color.getColor("ChartChangeEventType.GENERAL", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean12 = categoryPlot6.removeAnnotation(categoryAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Color color8 = java.awt.Color.yellow;
        java.awt.Color color9 = java.awt.Color.getColor("hi!", color8);
        java.awt.Color color10 = color9.darker();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray19, strokeArray20, shapeArray21);
        try {
            java.awt.Shape shape23 = defaultDrawingSupplier22.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createOutsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        boolean boolean12 = numberAxis2.isTickLabelsVisible();
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        java.awt.Color color12 = java.awt.Color.black;
        int int13 = color12.getRed();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color12, stroke14);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker15.setPaint(paint16);
        org.jfree.chart.util.Layer layer18 = null;
        try {
            categoryPlot6.addDomainMarker((int) '4', categoryMarker15, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        double double7 = valueMarker2.getValue();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        valueMarker2.setStroke(stroke11);
        numberAxis0.setTickMarkStroke(stroke11);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis0.valueToJava2D(43629.0d, rectangle2D16, rectangleEdge17);
        org.jfree.data.RangeType rangeType19 = null;
        try {
            numberAxis0.setRangeType(rangeType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getRed();
        java.awt.Color color2 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis(0, 0);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        valueMarker1.removeChangeListener(markerChangeListener4);
        java.awt.Color color6 = java.awt.Color.black;
        valueMarker1.setOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        try {
            int int21 = categoryPlot6.getDomainAxisIndex(categoryAxis20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray29 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot6.setDomainAxes(categoryAxisArray29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        float[] floatArray42 = new float[] { 255, (short) 100, 'a', 100, 'a' };
        float[] floatArray43 = color35.getColorComponents(floatArray42);
        int int44 = color35.getRGB();
        boolean boolean45 = datasetRenderingOrder31.equals((java.lang.Object) color35);
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color35);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-16777216) + "'", int44 == (-16777216));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        xYPlot0.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo11, point2D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot6.handleClick(9, 100, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setRange((double) (short) 100, (double) 43629L);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = null;
        try {
            numberAxis2.setTickUnit(numberTickUnit13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets1.trimHeight((double) 11);
        boolean boolean4 = color0.equals((java.lang.Object) 11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        try {
            categoryPlot6.setDomainAxis((-246), categoryAxis10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = xYPlot0.equals(obj6);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            xYPlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Shape shape10 = numberAxis2.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getParent();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getDomainAxisEdge();
        try {
            double double22 = numberAxis2.valueToJava2D((double) ' ', rectangle2D12, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis2.setLowerMargin(0.0d);
        java.awt.Paint paint16 = numberAxis2.getAxisLinePaint();
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis5, categoryItemRenderer8);
        java.lang.String str10 = categoryPlot9.getNoDataMessage();
        boolean boolean11 = categoryPlot9.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo14, point2D15);
        boolean boolean17 = xYPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean20 = numberAxis19.isInverted();
        try {
            xYPlot0.setDomainAxis((-246), (org.jfree.chart.axis.ValueAxis) numberAxis19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot6.getFixedLegendItems();
        java.awt.Paint paint12 = categoryPlot6.getBackgroundPaint();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        java.awt.Stroke stroke9 = null;
        try {
            xYPlot0.setRangeZeroBaselineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateLeftInset((double) 1);
        double double5 = rectangleInsets0.calculateBottomOutset(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 0, (float) (short) 1, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        java.awt.Font font13 = null;
        try {
            valueMarker1.setLabelFont(font13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        java.util.List list11 = categoryPlot6.getAnnotations();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = regularTimePeriod3.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot6.setDomainAxis(categoryAxis31);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, (double) 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            xYPlot0.setDomainAxisLocation((-16777216), axisLocation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double17 = numberAxis0.getLowerMargin();
        org.jfree.data.Range range18 = numberAxis0.getDefaultAutoRange();
        org.jfree.data.RangeType rangeType19 = null;
        try {
            numberAxis0.setRangeType(rangeType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker18);
        java.lang.Object obj20 = markerChangeEvent19.getSource();
        categoryMarker13.notifyListeners(markerChangeEvent19);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = markerChangeEvent19.getType();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        java.awt.Color color11 = java.awt.Color.red;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace13);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace6);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.awt.Font font7 = numberAxis2.getTickLabelFont();
        java.lang.Object obj8 = null;
        boolean boolean9 = numberAxis2.equals(obj8);
        try {
            numberAxis2.setRange((double) 10L, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot0.getDomainMarkers((int) ' ', layer13);
        org.jfree.chart.plot.Marker marker15 = null;
        try {
            boolean boolean16 = xYPlot0.removeRangeMarker(marker15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker19.getLabelAnchor();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot6.removeRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker19, layer24, false);
        java.awt.Font font27 = valueMarker19.getLabelFont();
        java.awt.Paint paint28 = null;
        try {
            valueMarker19.setLabelPaint(paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker19.getLabelAnchor();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot6.removeRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker19, layer24, false);
        java.awt.Stroke stroke27 = categoryPlot6.getRangeCrosshairStroke();
        boolean boolean28 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.clearDomainMarkers(0);
        java.awt.Color color17 = java.awt.Color.black;
        int int18 = color17.getRed();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color17, stroke19);
        java.lang.Comparable comparable21 = categoryMarker20.getKey();
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot12.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker20, layer22);
        boolean boolean24 = categoryMarker20.getDrawAsLine();
        org.jfree.chart.util.Layer layer25 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100 + "'", comparable21.equals(100));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        boolean boolean5 = numberAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        java.awt.Color color38 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color39 = color38.darker();
        java.awt.Color color40 = color38.brighter();
        java.awt.color.ColorSpace colorSpace41 = color40.getColorSpace();
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot6.zoomDomainAxes((double) (short) -1, plotRenderingInfo44, point2D45, false);
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot6.getDataset();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(colorSpace41);
        org.junit.Assert.assertNull(categoryDataset48);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker19.getLabelAnchor();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot6.removeRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker19, layer24, false);
        org.jfree.chart.util.SortOrder sortOrder27 = null;
        try {
            categoryPlot6.setRowRenderingOrder(sortOrder27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot6.getDomainAxisEdge();
        int int36 = categoryPlot6.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 15 + "'", int36 == 15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        org.jfree.data.Range range18 = null;
        try {
            numberAxis6.setRangeWithMargins(range18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot6.zoomRangeAxes(1.05d, plotRenderingInfo27, point2D28);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            boolean boolean33 = categoryPlot6.removeAnnotation(categoryAnnotation31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.extendHeight((double) (short) 10);
        double double5 = rectangleInsets0.calculateRightOutset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        java.awt.Stroke stroke27 = categoryPlot6.getRangeCrosshairStroke();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color28);
        int int30 = color28.getRed();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 128 + "'", int30 == 128);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        boolean boolean25 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        java.util.List list27 = categoryPlot6.getCategoriesForAxis(categoryAxis26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.clearDomainMarkers(0);
        java.awt.Color color34 = java.awt.Color.black;
        int int35 = color34.getRed();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color34, stroke36);
        java.lang.Comparable comparable38 = categoryMarker37.getKey();
        org.jfree.chart.util.Layer layer39 = null;
        xYPlot29.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker37, layer39);
        boolean boolean41 = categoryMarker37.getDrawAsLine();
        org.jfree.chart.util.Layer layer42 = null;
        try {
            categoryPlot6.addDomainMarker(0, categoryMarker37, layer42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + comparable38 + "' != '" + 100 + "'", comparable38.equals(100));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        categoryPlot6.zoom((double) 10);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopInset((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        try {
            java.awt.Paint paint8 = xYPlot0.getQuadrantPaint(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (11) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.awt.Font font7 = numberAxis2.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot10.getDomainMarkers(layer11);
        java.awt.Color color14 = java.awt.Color.black;
        int int15 = color14.getRed();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color14, stroke16);
        xYPlot10.setRangeZeroBaselineStroke(stroke16);
        java.awt.Paint paint19 = xYPlot10.getDomainCrosshairPaint();
        boolean boolean20 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener23 = null;
        valueMarker22.addChangeListener(markerChangeListener23);
        java.awt.Paint paint25 = valueMarker22.getOutlinePaint();
        java.lang.Object obj26 = null;
        boolean boolean27 = valueMarker22.equals(obj26);
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = xYPlot10.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker22, layer28);
        boolean boolean30 = xYPlot10.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot10.getRangeAxisEdge(100);
        try {
            double double33 = numberAxis2.valueToJava2D((double) (short) 10, rectangle2D9, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        java.awt.Stroke stroke2 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        org.jfree.chart.text.TextAnchor textAnchor4 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = markerChangeEvent5.getType();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            xYPlot0.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        numberAxis8.setLowerBound((double) (short) -1);
        numberAxis8.setLabel("Category Plot");
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        org.jfree.chart.plot.Plot plot22 = categoryPlot21.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        numberAxis25.setVisible(true);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.AxisState axisState33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        java.util.List list36 = numberAxis25.refreshTicks(graphics2D32, axisState33, rectangle2D34, rectangleEdge35);
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis25.setUpArrow(shape37);
        int int39 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot21.getDomainMarkers((int) (short) -1, layer41);
        int int43 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setAnchorValue((double) ' ', false);
        java.awt.Stroke stroke47 = categoryPlot21.getOutlineStroke();
        numberAxis8.setTickMarkStroke(stroke47);
        xYPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getRed();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paintContext7);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
//        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
//        double double5 = rectangleInsets2.calculateTopInset((double) 43629L);
//        int int6 = day0.compareTo((java.lang.Object) 43629L);
//        long long7 = day0.getSerialIndex();
//        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
//        int int9 = day0.compareTo((java.lang.Object) color8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(color8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) ' ');
        double double4 = rectangleInsets0.trimHeight(2.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        org.jfree.chart.plot.Plot plot15 = categoryPlot14.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer21);
        numberAxis18.setVisible(true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = numberAxis18.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge28);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis18.setUpArrow(shape30);
        int int32 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Paint paint33 = categoryPlot14.getBackgroundPaint();
        categoryPlot14.clearDomainAxes();
        java.awt.Stroke stroke35 = categoryPlot14.getRangeCrosshairStroke();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color36);
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        chartChangeEvent9.setChart(jFreeChart10);
        java.lang.Object obj12 = chartChangeEvent9.getSource();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace12);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot4.getDomainMarkers(layer5);
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        xYPlot4.setRangeZeroBaselineStroke(stroke10);
        java.awt.Paint paint13 = xYPlot4.getDomainCrosshairPaint();
        boolean boolean14 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener17 = null;
        valueMarker16.addChangeListener(markerChangeListener17);
        java.awt.Paint paint19 = valueMarker16.getOutlinePaint();
        java.lang.Object obj20 = null;
        boolean boolean21 = valueMarker16.equals(obj20);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer22);
        boolean boolean24 = xYPlot4.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot4.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot4.getRangeAxisEdge();
        try {
            double double28 = categoryAxis0.getCategoryEnd(12, (int) ' ', rectangle2D3, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        double double9 = numberAxis2.getUpperBound();
        java.awt.Paint paint10 = null;
        try {
            numberAxis2.setAxisLinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.05d + "'", double9 == 1.05d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1.0f));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = null;
        try {
            categoryMarker1.setLabelAnchor(rectangleAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateTopInset((double) 43629L);
        double double4 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis5, categoryItemRenderer8);
        java.lang.String str10 = categoryPlot9.getNoDataMessage();
        boolean boolean11 = categoryPlot9.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo14, point2D15);
        boolean boolean17 = xYPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation18 = null;
        try {
            boolean boolean20 = xYPlot0.removeAnnotation(xYAnnotation18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        xYPlot0.axisChanged(axisChangeEvent21);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Color color8 = java.awt.Color.yellow;
        java.awt.Color color9 = java.awt.Color.getColor("hi!", color8);
        java.awt.Color color10 = color9.darker();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextFillPaint();
        try {
            java.awt.Shape shape24 = defaultDrawingSupplier22.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot13.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        numberAxis17.setVisible(true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = numberAxis17.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis17.setUpArrow(shape29);
        int int31 = categoryPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot13.getDomainMarkers((int) (short) -1, layer33);
        int int35 = categoryPlot13.getDomainAxisCount();
        categoryPlot13.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot13.setFixedRangeAxisSpace(axisSpace38, false);
        categoryPlot13.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener46 = null;
        valueMarker45.addChangeListener(markerChangeListener46);
        java.awt.Paint paint48 = valueMarker45.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = valueMarker45.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor52 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker51.setLabelTextAnchor(textAnchor52);
        valueMarker45.setLabelTextAnchor(textAnchor52);
        org.jfree.chart.util.Layer layer55 = null;
        categoryPlot13.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker45, layer55, true);
        org.jfree.chart.util.Layer layer58 = null;
        boolean boolean59 = xYPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker45, layer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        try {
            xYPlot0.handleClick((-1), 8, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint10 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot0.setRenderer(xYItemRenderer11);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int3 = java.awt.Color.HSBtoRGB((float) 43629L, (float) 255, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        valueMarker1.removeChangeListener(markerChangeListener4);
        java.awt.Stroke stroke6 = null;
        try {
            valueMarker1.setStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        java.awt.Stroke stroke6 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setRange((double) (short) 100, (double) 43629L);
        numberAxis2.setTickMarksVisible(false);
        java.awt.Paint paint15 = numberAxis2.getTickMarkPaint();
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        valueMarker24.addChangeListener(markerChangeListener25);
        java.awt.Paint paint27 = valueMarker24.getOutlinePaint();
        java.lang.Object obj28 = null;
        boolean boolean29 = valueMarker24.equals(obj28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker24, layer30);
        java.awt.Stroke stroke32 = categoryPlot6.getOutlineStroke();
        int int33 = categoryPlot6.getBackgroundImageAlignment();
        boolean boolean34 = categoryPlot6.isDomainZoomable();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        java.awt.Font font2 = null;
        try {
            xYPlot0.setNoDataMessageFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, 255, (-246));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        java.awt.Color color4 = java.awt.Color.red;
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis2.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot16 = numberAxis2.getPlot();
        numberAxis2.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(true);
        try {
            numberAxis0.zoomRange((double) '4', (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3.0) <= upper (-103.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray29 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot6.setDomainAxes(categoryAxisArray29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot6.zoomRangeAxes((double) 15, (double) 255, plotRenderingInfo33, point2D34);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray29);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 11);
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 12, (float) (byte) 0, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker12.getLabelTextAnchor();
        boolean boolean16 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        xYPlot0.clearRangeMarkers((-16777216));
        org.jfree.chart.annotations.XYAnnotation xYAnnotation19 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        valueMarker24.addChangeListener(markerChangeListener25);
        java.awt.Paint paint27 = valueMarker24.getOutlinePaint();
        java.lang.Object obj28 = null;
        boolean boolean29 = valueMarker24.equals(obj28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker24, layer30);
        java.awt.Stroke stroke32 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot6.getDomainMarkers(13, layer34);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        numberAxis9.setVisible(true);
        boolean boolean16 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Shape shape17 = numberAxis9.getDownArrow();
        boolean boolean18 = xYPlot0.equals((java.lang.Object) numberAxis9);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean23 = xYPlot0.removeRangeMarker((-246), marker20, layer21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(0, layer9);
        float float11 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        try {
            categoryPlot6.zoomRangeAxes(Double.POSITIVE_INFINITY, plotRenderingInfo15, point2D16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        numberAxis7.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = numberAxis7.getMarkerBand();
        org.jfree.data.Range range15 = numberAxis7.getRange();
        java.awt.Stroke stroke16 = numberAxis7.getAxisLineStroke();
        int int17 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(markerAxisBand14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        int int19 = xYPlot0.getRangeAxisCount();
        xYPlot0.clearDomainMarkers(500);
        org.jfree.chart.plot.Plot plot22 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(plot22);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        int int19 = xYPlot0.getRangeAxisCount();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot0.getRangeAxisForDataset(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 15 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
//        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
//        double double5 = rectangleInsets2.calculateTopInset((double) 43629L);
//        int int6 = day0.compareTo((java.lang.Object) 43629L);
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day0.equals(obj7);
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot26.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer33);
        numberAxis30.setVisible(true);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        java.util.List list41 = numberAxis30.refreshTicks(graphics2D37, axisState38, rectangle2D39, rectangleEdge40);
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis30.setUpArrow(shape42);
        int int44 = categoryPlot26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot26.getDomainMarkers((int) (short) -1, layer46);
        int int48 = categoryPlot26.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setLabelURL("");
        numberAxis49.setLowerBound((double) (short) -1);
        boolean boolean54 = categoryPlot26.equals((java.lang.Object) numberAxis49);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot26.getDomainAxisEdge();
        try {
            double double56 = numberAxis6.java2DToValue((double) (-1L), rectangle2D19, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRenderer((-16777216));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        try {
            valueMarker1.setAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color3 = java.awt.Color.black;
        int int4 = color3.getRed();
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        xYPlot0.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        numberAxis19.setVisible(true);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = numberAxis19.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis19.setUpArrow(shape31);
        int int33 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot15.getDomainMarkers((int) (short) -1, layer35);
        int int37 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setLabelURL("");
        numberAxis38.setLowerBound((double) (short) -1);
        boolean boolean43 = categoryPlot15.equals((java.lang.Object) numberAxis38);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot15.getDomainAxisEdge();
        try {
            double double45 = categoryAxis1.getCategoryStart((-16777216), 13, rectangle2D8, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = xYPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets6.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot0.getOrientation();
        double double24 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener28 = null;
        valueMarker27.addChangeListener(markerChangeListener28);
        java.awt.Paint paint30 = valueMarker27.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker27.getLabelAnchor();
        double double32 = valueMarker27.getValue();
        java.awt.Color color34 = java.awt.Color.black;
        int int35 = color34.getRed();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color34, stroke36);
        valueMarker27.setStroke(stroke36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = valueMarker27.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double41 = rectangleInsets40.getRight();
        double double43 = rectangleInsets40.calculateRightOutset((double) 10.0f);
        double double45 = rectangleInsets40.calculateBottomOutset((double) 9);
        valueMarker27.setLabelOffset(rectangleInsets40);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = valueMarker27.getLabelOffsetType();
        org.jfree.chart.util.Layer layer48 = null;
        try {
            xYPlot0.addDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker27, layer48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        int int34 = categoryPlot6.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace35, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot6.getDomainAxisForDataset((-16777216));
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(categoryAxis39);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        org.jfree.chart.plot.Plot plot22 = categoryPlot21.getParent();
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot21, jFreeChart23);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot21.getRowRenderingOrder();
        categoryPlot6.setColumnRenderingOrder(sortOrder25);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(sortOrder25);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
//        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
//        double double5 = rectangleInsets2.calculateTopInset((double) 43629L);
//        int int6 = day0.compareTo((java.lang.Object) 43629L);
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis10.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
//        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
//        java.awt.Color color18 = java.awt.Color.black;
//        int int19 = color18.getRed();
//        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color18, stroke20);
//        java.lang.Comparable comparable22 = categoryMarker21.getKey();
//        org.jfree.chart.util.Layer layer23 = null;
//        boolean boolean24 = categoryPlot14.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker21, layer23);
//        boolean boolean25 = day0.equals((java.lang.Object) (byte) 1);
//        java.lang.String str26 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(axisLocation15);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100 + "'", comparable22.equals(100));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Color color8 = java.awt.Color.yellow;
        java.awt.Color color9 = java.awt.Color.getColor("hi!", color8);
        java.awt.Color color10 = color9.darker();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray19, strokeArray20, shapeArray21);
        try {
            java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setAnchorValue((double) ' ', false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        try {
            boolean boolean37 = categoryPlot6.removeRangeMarker(0, marker34, layer35, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer32);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        int int34 = categoryPlot6.getDatasetCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation35 = null;
        try {
            boolean boolean37 = categoryPlot6.removeAnnotation(categoryAnnotation35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        org.jfree.data.general.DatasetGroup datasetGroup20 = xYPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(datasetGroup20);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        numberAxis9.setVisible(true);
        boolean boolean16 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Shape shape17 = numberAxis9.getDownArrow();
        boolean boolean18 = xYPlot0.equals((java.lang.Object) numberAxis9);
        int int19 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        int int21 = xYPlot0.getIndexOf(xYItemRenderer20);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint10 = xYPlot0.getDomainGridlinePaint();
        java.awt.Color color17 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot18.getDomainMarkers(layer19);
        java.awt.Color color22 = java.awt.Color.black;
        int int23 = color22.getRed();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color22, stroke24);
        xYPlot18.setRangeZeroBaselineStroke(stroke24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot18.setRangeZeroBaselineStroke(stroke27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener31 = null;
        valueMarker30.addChangeListener(markerChangeListener31);
        java.awt.Paint paint33 = valueMarker30.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot34.getDomainMarkers(layer35);
        xYPlot34.setWeight((int) (short) 100);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot34.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color17, stroke27, paint33, stroke39, (float) (short) 1);
        double double43 = intervalMarker42.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot44.getDomainMarkers(layer45);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        xYPlot44.datasetChanged(datasetChangeEvent47);
        boolean boolean49 = intervalMarker42.equals((java.lang.Object) xYPlot44);
        org.jfree.chart.util.Layer layer50 = null;
        try {
            xYPlot0.addDomainMarker(8, (org.jfree.chart.plot.Marker) intervalMarker42, layer50, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent31);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        double double31 = categoryPlot6.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker34.setAlpha((float) 1L);
        java.awt.Font font37 = valueMarker34.getLabelFont();
        org.jfree.chart.util.Layer layer38 = null;
        categoryPlot6.addRangeMarker((-246), (org.jfree.chart.plot.Marker) valueMarker34, layer38, false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        numberAxis12.setVisible(true);
        org.jfree.data.Range range19 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot6.getRendererForDataset(categoryDataset20);
        java.awt.Image image22 = null;
        categoryPlot6.setBackgroundImage(image22);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot3.getDomainMarkers(layer4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot3.getRenderer(255);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot3.getRangeMarkers((int) '4', layer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot3.getRangeMarkers(0, layer12);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot15.getDomainMarkers(layer16);
        java.awt.Color color19 = java.awt.Color.black;
        int int20 = color19.getRed();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color19, stroke21);
        xYPlot15.setRangeZeroBaselineStroke(stroke21);
        java.awt.Paint paint24 = xYPlot15.getDomainCrosshairPaint();
        boolean boolean25 = xYPlot15.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener28 = null;
        valueMarker27.addChangeListener(markerChangeListener28);
        java.awt.Paint paint30 = valueMarker27.getOutlinePaint();
        java.lang.Object obj31 = null;
        boolean boolean32 = valueMarker27.equals(obj31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27, layer33);
        boolean boolean35 = xYPlot15.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot15.getRangeAxisEdge(100);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace39 = categoryAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) xYPlot3, rectangle2D14, rectangleEdge37, axisSpace38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) 1, 255);
        int int4 = chartColor3.getRGB();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16776705) + "'", int4 == (-16776705));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.extendHeight((double) (short) 10);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
        org.junit.Assert.assertNotNull(unitType4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker19.getLabelAnchor();
        double double24 = valueMarker19.getValue();
        java.awt.Color color26 = java.awt.Color.black;
        int int27 = color26.getRed();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color26, stroke28);
        valueMarker19.setStroke(stroke28);
        org.jfree.chart.util.Layer layer31 = null;
        try {
            xYPlot0.addDomainMarker(128, (org.jfree.chart.plot.Marker) valueMarker19, layer31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 0);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot11.getDomainMarkers(layer12);
        java.awt.Color color15 = java.awt.Color.black;
        int int16 = color15.getRed();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color15, stroke17);
        xYPlot11.setRangeZeroBaselineStroke(stroke17);
        java.awt.Paint paint20 = xYPlot11.getDomainCrosshairPaint();
        boolean boolean21 = xYPlot11.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener24 = null;
        valueMarker23.addChangeListener(markerChangeListener24);
        java.awt.Paint paint26 = valueMarker23.getOutlinePaint();
        java.lang.Object obj27 = null;
        boolean boolean28 = valueMarker23.equals(obj27);
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = xYPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker23, layer29);
        boolean boolean31 = xYPlot11.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot11.getRangeAxisEdge(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = categoryAxis1.draw(graphics2D7, (double) (byte) 100, rectangle2D9, rectangle2D10, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot6.getRangeMarkers(10, layer10);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        java.awt.Color color17 = java.awt.Color.black;
        int int18 = color17.getRed();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color17, stroke19);
        xYPlot13.setRangeZeroBaselineStroke(stroke19);
        java.awt.Paint paint22 = xYPlot13.getDomainCrosshairPaint();
        boolean boolean23 = xYPlot13.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener26 = null;
        valueMarker25.addChangeListener(markerChangeListener26);
        java.awt.Paint paint28 = valueMarker25.getOutlinePaint();
        java.lang.Object obj29 = null;
        boolean boolean30 = valueMarker25.equals(obj29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot33.getDomainMarkers(layer34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        xYPlot33.datasetChanged(datasetChangeEvent36);
        java.awt.Stroke stroke38 = xYPlot33.getRangeZeroBaselineStroke();
        valueMarker25.setStroke(stroke38);
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = categoryPlot6.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker25, layer40, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot6.zoomDomainAxes((double) 6, (double) (short) 0, plotRenderingInfo45, point2D46);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(true);
        numberAxis0.setInverted(true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        int int4 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        xYPlot9.setRangeZeroBaselineStroke(stroke15);
        java.awt.Paint paint18 = xYPlot9.getDomainCrosshairPaint();
        boolean boolean19 = xYPlot9.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener22 = null;
        valueMarker21.addChangeListener(markerChangeListener22);
        java.awt.Paint paint24 = valueMarker21.getOutlinePaint();
        java.lang.Object obj25 = null;
        boolean boolean26 = valueMarker21.equals(obj25);
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = xYPlot9.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker21, layer27);
        boolean boolean29 = xYPlot9.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot9.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot9.getRangeAxisEdge();
        try {
            double double33 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor5, (-14417954), 128, rectangle2D8, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot17.getDomainAxisLocation();
        categoryPlot17.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot17.getDomainAxisLocation((int) (byte) -1);
        categoryPlot6.setDomainAxisLocation((int) (byte) 100, axisLocation21);
        categoryPlot6.setAnchorValue((double) 10);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            categoryPlot6.addRangeMarker(marker25, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(xYItemRenderer7);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double5 = rectangleInsets0.trimHeight((double) 43629L);
        double double6 = rectangleInsets0.getBottom();
        double double7 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 43629.0d + "'", double5 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = numberAxis2.draw(graphics2D9, (double) 100, rectangle2D11, rectangle2D12, rectangleEdge13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        boolean boolean4 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean8 = xYPlot0.removeAnnotation(xYAnnotation6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis2.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot16 = numberAxis2.getPlot();
        java.awt.Font font17 = numberAxis2.getLabelFont();
        boolean boolean18 = numberAxis2.isAxisLineVisible();
        try {
            numberAxis2.setAutoRangeMinimumSize((double) 0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot6.getDomainAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets37.getRight();
        double double40 = rectangleInsets37.calculateRightOutset((double) 10.0f);
        double double42 = rectangleInsets37.trimHeight((double) 43629L);
        double double44 = rectangleInsets37.calculateLeftOutset((double) 255);
        categoryPlot6.setInsets(rectangleInsets37);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 43629.0d + "'", double42 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        categoryPlot6.zoom((double) 0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot6.getIndexOf(categoryItemRenderer37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot6.zoomRangeAxes((double) (short) -1, plotRenderingInfo40, point2D41, false);
        java.awt.Image image44 = null;
        categoryPlot6.setBackgroundImage(image44);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 13, 1.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font23);
        xYPlot0.zoom((double) 100L);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        xYPlot0.clearRangeMarkers(255);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        long long2 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        xYPlot0.clearDomainMarkers((-246));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo11, point2D12);
        java.awt.Stroke stroke14 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot6.handleClick(255, 2, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setVisible(false);
        float float12 = numberAxis2.getTickMarkOutsideLength();
        numberAxis2.resizeRange((-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearRangeMarkers((int) (byte) 10);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        double double8 = categoryPlot6.getRangeCrosshairValue();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets12.getRight();
        numberAxis2.setLabelInsets(rectangleInsets12);
        java.lang.String str15 = numberAxis2.getLabelToolTip();
        try {
            numberAxis2.setRange((double) 500, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (500.0) <= upper (32.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot0.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot0.getRangeAxisEdge();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            xYPlot0.drawBackground(graphics2D24, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        boolean boolean25 = categoryPlot6.isDomainGridlinesVisible();
        categoryPlot6.zoom((double) 1.0f);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        java.lang.String str16 = axisLocation13.toString();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str16.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot0.getDomainMarkers(layer12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot14.getDomainMarkers(layer15);
        xYPlot14.setWeight((int) (short) 100);
        boolean boolean19 = xYPlot14.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str21 = datasetRenderingOrder20.toString();
        xYPlot14.setDatasetRenderingOrder(datasetRenderingOrder20);
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder20);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.Point2D point2D26 = null;
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            xYPlot0.draw(graphics2D24, rectangle2D25, point2D26, plotState27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str21.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        xYPlot9.setRangeZeroBaselineStroke(stroke15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot9.setDomainAxisLocation(axisLocation26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
        categoryPlot6.setInsets(rectangleInsets28);
        int int30 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        double double9 = numberAxis2.getUpperBound();
        numberAxis2.setUpperMargin((double) 0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot13.datasetChanged(datasetChangeEvent16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation26, true);
        java.awt.Stroke stroke29 = xYPlot13.getRangeGridlineStroke();
        double double30 = xYPlot13.getDomainCrosshairValue();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot32.getDomainMarkers(layer33);
        java.awt.Color color36 = java.awt.Color.black;
        int int37 = color36.getRed();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color36, stroke38);
        xYPlot32.setRangeZeroBaselineStroke(stroke38);
        java.awt.Paint paint41 = xYPlot32.getDomainCrosshairPaint();
        boolean boolean42 = xYPlot32.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener45 = null;
        valueMarker44.addChangeListener(markerChangeListener45);
        java.awt.Paint paint47 = valueMarker44.getOutlinePaint();
        java.lang.Object obj48 = null;
        boolean boolean49 = valueMarker44.equals(obj48);
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean51 = xYPlot32.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker44, layer50);
        boolean boolean52 = xYPlot32.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot32.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = xYPlot32.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace57 = numberAxis2.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) xYPlot13, rectangle2D31, rectangleEdge55, axisSpace56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.05d + "'", double9 == 1.05d);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setLowerMargin(1.0E-8d);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot16.getParent();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge();
        try {
            double double19 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 8, (java.lang.Comparable) '#', categoryDataset7, (double) 12, rectangle2D9, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYPlot0.getDrawingSupplier();
        boolean boolean13 = xYPlot0.isRangeCrosshairLockedOnData();
        boolean boolean14 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) 1);
        java.awt.Paint paint18 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        boolean boolean19 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(legendItemCollection20);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color14);
        java.awt.Shape shape16 = numberAxis2.getLeftArrow();
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot13.getParent();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot13, jFreeChart15);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot13.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot13.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot13.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection19);
        xYPlot0.clearDomainMarkers((-16776705));
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        numberAxis7.setAutoTickUnitSelection(false);
        float float14 = numberAxis7.getTickMarkInsideLength();
        numberAxis7.setVisible(false);
        xYPlot1.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis7, true);
        java.awt.Paint paint19 = xYPlot1.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot20.getDomainMarkers(layer21);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        xYPlot20.datasetChanged(datasetChangeEvent23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        org.jfree.chart.plot.Plot plot32 = categoryPlot31.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getDomainAxisLocation();
        xYPlot20.setDomainAxisLocation(axisLocation33, true);
        xYPlot20.clearDomainAxes();
        java.awt.Stroke stroke37 = xYPlot20.getRangeZeroBaselineStroke();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot39.getDomainMarkers(layer40);
        java.awt.Color color43 = java.awt.Color.black;
        int int44 = color43.getRed();
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color43, stroke45);
        xYPlot39.setRangeZeroBaselineStroke(stroke45);
        java.awt.Paint paint48 = xYPlot39.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot39.getRangeAxisForDataset(0);
        java.awt.Stroke stroke51 = xYPlot39.getRangeZeroBaselineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3, paint19, stroke37, (java.awt.Paint) color38, stroke51, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        java.awt.Image image10 = null;
        categoryPlot6.setBackgroundImage(image10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot6.getAxisOffset();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot6.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(0, layer9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.addChangeListener(markerChangeListener14);
        java.awt.Paint paint16 = valueMarker13.getOutlinePaint();
        valueMarker13.setLabel("hi!");
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = xYPlot0.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker13, layer19, true);
        java.awt.Paint paint22 = null;
        try {
            xYPlot0.setRangeCrosshairPaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
//        boolean boolean4 = day0.equals((java.lang.Object) unitType3);
//        java.lang.String str5 = unitType3.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UnitType.RELATIVE" + "'", str5.equals("UnitType.RELATIVE"));
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getRowRenderingOrder();
        java.lang.String str13 = sortOrder12.toString();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SortOrder.ASCENDING" + "'", str13.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        boolean boolean14 = numberAxis2.isVerticalTickLabels();
        numberAxis2.setRangeWithMargins(1.05d, (double) (short) 10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        boolean boolean12 = numberAxis2.isInverted();
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        numberAxis11.setAutoTickUnitSelection(false);
        float float18 = numberAxis11.getTickMarkInsideLength();
        numberAxis11.setVisible(false);
        xYPlot5.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis11.getStandardTickUnits();
        int int24 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Paint paint25 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean26 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        java.awt.Paint paint5 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot10.getDomainMarkers(layer11);
        xYPlot10.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        xYPlot10.datasetChanged(datasetChangeEvent15);
        java.awt.Paint paint17 = xYPlot10.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot10.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker22.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean27 = xYPlot10.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker22, layer25, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot10.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo30, point2D31);
        numberAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker36.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer39 = null;
        try {
            xYPlot10.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker36, layer39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis2.getTickLabelInsets();
        numberAxis2.resizeRange(0.0d, 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        boolean boolean31 = categoryPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        double double7 = valueMarker2.getValue();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        valueMarker2.setStroke(stroke11);
        numberAxis0.setTickMarkStroke(stroke11);
        numberAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(13);
        java.lang.Object obj3 = objectList1.get(12);
        java.lang.Object obj4 = objectList1.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        numberAxis11.setAutoTickUnitSelection(false);
        float float18 = numberAxis11.getTickMarkInsideLength();
        numberAxis11.setVisible(false);
        xYPlot5.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis11.getStandardTickUnits();
        int int24 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Paint paint25 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener28 = null;
        valueMarker27.addChangeListener(markerChangeListener28);
        java.awt.Paint paint30 = valueMarker27.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker27.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker33.setLabelTextAnchor(textAnchor34);
        valueMarker27.setLabelTextAnchor(textAnchor34);
        org.jfree.chart.util.Layer layer37 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker27, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(textAnchor34);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100, 0.0d);
        double double3 = intervalMarker2.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot4.getDomainMarkers(layer5);
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        xYPlot4.setRangeZeroBaselineStroke(stroke10);
        java.awt.Paint paint13 = xYPlot4.getDomainCrosshairPaint();
        boolean boolean14 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener17 = null;
        valueMarker16.addChangeListener(markerChangeListener17);
        java.awt.Paint paint19 = valueMarker16.getOutlinePaint();
        java.lang.Object obj20 = null;
        boolean boolean21 = valueMarker16.equals(obj20);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer22);
        boolean boolean24 = intervalMarker2.equals((java.lang.Object) valueMarker16);
        intervalMarker2.setStartValue((double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer27);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot0.zoomDomainAxes(1.0E-8d, (double) (-16776705), plotRenderingInfo9, point2D10);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
//        double double2 = numberAxis1.getUpperMargin();
//        java.awt.Color color3 = java.awt.Color.BLUE;
//        numberAxis1.setLabelPaint((java.awt.Paint) color3);
//        java.awt.Color color6 = java.awt.Color.black;
//        int int7 = color6.getRed();
//        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color6, stroke8);
//        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
//        categoryMarker9.setPaint(paint10);
//        java.awt.Stroke stroke12 = categoryMarker9.getStroke();
//        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color3, stroke12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        java.util.Date date16 = day14.getStart();
//        java.lang.Class<?> wildcardClass17 = day14.getClass();
//        try {
//            java.util.EventListener[] eventListenerArray18 = categoryMarker13.getListeners((java.lang.Class) wildcardClass17);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Day; cannot be cast to [Ljava.util.EventListener;");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(stroke8);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        java.awt.Paint paint18 = xYPlot0.getDomainGridlinePaint();
        try {
            xYPlot0.setBackgroundImageAlpha((float) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        int int19 = xYPlot0.getRangeAxisCount();
        boolean boolean20 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        java.awt.Stroke stroke29 = categoryPlot6.getOutlineStroke();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker7.setLabelTextAnchor(textAnchor8);
        valueMarker1.setLabelTextAnchor(textAnchor8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        valueMarker1.setValue((double) 15);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot0.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot0.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        int int25 = xYPlot0.indexOf(xYDataset24);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace27, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis31.setMaximumCategoryLabelLines((-16777216));
        int int34 = categoryAxis31.getMaximumCategoryLabelLines();
        categoryPlot6.setDomainAxis(categoryAxis31);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot6.getRowRenderingOrder();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-16777216) + "'", int34 == (-16777216));
        org.junit.Assert.assertNotNull(sortOrder36);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = lengthAdjustmentType0.equals(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        int int27 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        numberAxis6.resizeRange(1.05d, (double) 8);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit6, "Category Plot");
        categoryAxis1.clearCategoryLabelToolTips();
        double double10 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        double double14 = numberAxis2.getAutoRangeMinimumSize();
        double double15 = numberAxis2.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        double double17 = numberAxis16.getUpperMargin();
        org.jfree.data.Range range18 = numberAxis16.getDefaultAutoRange();
        numberAxis2.setRangeWithMargins(range18, false, false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.05d + "'", double15 == 1.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = null;
        intervalMarker30.setGradientPaintTransformer(gradientPaintTransformer32);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot6.getFixedLegendItems();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        categoryPlot6.setAnchorValue((double) (byte) 1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot6.getRenderer();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.extendWidth(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYPlot0.getDrawingSupplier();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot20.getParent();
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot20, jFreeChart22);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        chartChangeEvent23.setChart(jFreeChart24);
        boolean boolean26 = color13.equals((java.lang.Object) chartChangeEvent23);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SortOrder.ASCENDING\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker1.getLabelAnchor();
        java.awt.Stroke stroke14 = valueMarker1.getStroke();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        numberAxis15.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot26.getParent();
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot26, jFreeChart28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot26.getRowRenderingOrder();
        numberAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        java.awt.Font font32 = numberAxis15.getTickLabelFont();
        valueMarker1.setLabelFont(font32);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot17.getDomainAxisLocation();
        categoryPlot17.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot17.getDomainAxisLocation((int) (byte) -1);
        categoryPlot6.setDomainAxisLocation((int) (byte) 100, axisLocation21);
        categoryPlot6.setAnchorValue((double) 10);
        java.awt.Paint paint25 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot0.render(graphics2D6, rectangle2D7, (-246), plotRenderingInfo9, crosshairState10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace12, false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener9 = null;
        valueMarker8.addChangeListener(markerChangeListener9);
        java.awt.Paint paint11 = valueMarker8.getOutlinePaint();
        valueMarker8.setAlpha((float) (short) 1);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot6.getDataset();
        categoryPlot6.configureRangeAxes();
        categoryPlot6.setRangeCrosshairValue(100.0d, false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryDataset16);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
//        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
//        double double5 = rectangleInsets2.calculateTopInset((double) 43629L);
//        int int6 = day0.compareTo((java.lang.Object) 43629L);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(true);
        double double7 = numberAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        categoryAxis1.removeChangeListener(axisChangeListener2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategoryMiddle(0, 2, rectangle2D7, rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot7.getFixedLegendItems();
        boolean boolean11 = textAnchor0.equals((java.lang.Object) legendItemCollection10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot0.getRangeAxisEdge(100);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean25 = numberAxis24.isInverted();
        xYPlot0.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace27, true);
        java.awt.Paint paint30 = categoryPlot6.getDomainGridlinePaint();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot6.getRangeMarkers(10, layer10);
        boolean boolean12 = categoryPlot6.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        double double7 = valueMarker2.getValue();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        valueMarker2.setStroke(stroke11);
        numberAxis0.setTickMarkStroke(stroke11);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis0.valueToJava2D(43629.0d, rectangle2D16, rectangleEdge17);
        boolean boolean19 = numberAxis0.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis0.getTickLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperMargin();
        java.awt.Color color23 = java.awt.Color.BLUE;
        numberAxis21.setLabelPaint((java.awt.Paint) color23);
        java.awt.Shape shape25 = numberAxis21.getLeftArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis21.setTickUnit(numberTickUnit26, false, false);
        numberAxis0.setTickUnit(numberTickUnit26);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(numberTickUnit26);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        xYPlot9.setRangeZeroBaselineStroke(stroke15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot9.setDomainAxisLocation(axisLocation26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
        categoryPlot6.setInsets(rectangleInsets28);
        categoryPlot6.clearDomainAxes();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot6.setDomainGridlineStroke(stroke31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot6.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        double double35 = categoryAxis34.getLabelAngle();
        categoryPlot6.setDomainAxis(categoryAxis34);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker12.getLabelTextAnchor();
        boolean boolean16 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYPlot0.getDrawingSupplier();
        boolean boolean13 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot14.getDomainMarkers(layer15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        xYPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer24);
        org.jfree.chart.plot.Plot plot26 = categoryPlot25.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getDomainAxisLocation();
        xYPlot14.setDomainAxisLocation(axisLocation27, true);
        xYPlot0.setRangeAxisLocation(axisLocation27);
        java.lang.String str31 = xYPlot0.getPlotType();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "XY Plot" + "'", str31.equals("XY Plot"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setVisible(false);
        float float12 = numberAxis2.getTickMarkOutsideLength();
        org.jfree.chart.plot.Plot plot13 = numberAxis2.getPlot();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(plot13);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis7.setMaximumCategoryLabelLines((-16777216));
//        int int10 = categoryAxis7.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getStart();
//        java.awt.Font font14 = categoryAxis7.getTickLabelFont((java.lang.Comparable) day11);
//        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1.05d, font14);
//        double double16 = categoryAxis1.getUpperMargin();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.chart.util.UnitType unitType20 = org.jfree.chart.util.UnitType.RELATIVE;
//        boolean boolean21 = day17.equals((java.lang.Object) unitType20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
//        java.awt.geom.Rectangle2D rectangle2D26 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis29.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer32);
//        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot33.getDomainAxisLocation();
//        categoryPlot33.clearAnnotations();
//        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.util.Layer layer37 = null;
//        java.util.Collection collection38 = xYPlot36.getDomainMarkers(layer37);
//        java.awt.Color color40 = java.awt.Color.black;
//        int int41 = color40.getRed();
//        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color40, stroke42);
//        xYPlot36.setRangeZeroBaselineStroke(stroke42);
//        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis47.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis47, categoryItemRenderer50);
//        org.jfree.chart.plot.Plot plot52 = categoryPlot51.getParent();
//        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot51.getDomainAxisLocation();
//        xYPlot36.setDomainAxisLocation(axisLocation53);
//        org.jfree.chart.util.RectangleInsets rectangleInsets55 = xYPlot36.getAxisOffset();
//        categoryPlot33.setInsets(rectangleInsets55);
//        categoryPlot33.clearDomainAxes();
//        java.awt.Stroke stroke58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        categoryPlot33.setDomainGridlineStroke(stroke58);
//        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot33.getDomainAxisEdge();
//        try {
//            double double61 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) day17, (java.lang.Comparable) day22, categoryDataset24, 0.0d, rectangle2D26, rectangleEdge60);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(unitType20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertNull(collection38);
//        org.junit.Assert.assertNotNull(color40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(stroke42);
//        org.junit.Assert.assertNull(plot52);
//        org.junit.Assert.assertNotNull(axisLocation53);
//        org.junit.Assert.assertNotNull(rectangleInsets55);
//        org.junit.Assert.assertNotNull(stroke58);
//        org.junit.Assert.assertNotNull(rectangleEdge60);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
//        boolean boolean4 = day0.equals((java.lang.Object) unitType3);
//        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis7.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
//        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot11.getDomainAxisLocation();
//        categoryPlot11.clearAnnotations();
//        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.util.Layer layer15 = null;
//        java.util.Collection collection16 = xYPlot14.getDomainMarkers(layer15);
//        java.awt.Color color18 = java.awt.Color.black;
//        int int19 = color18.getRed();
//        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color18, stroke20);
//        xYPlot14.setRangeZeroBaselineStroke(stroke20);
//        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis25.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
//        org.jfree.chart.plot.Plot plot30 = categoryPlot29.getParent();
//        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot29.getDomainAxisLocation();
//        xYPlot14.setDomainAxisLocation(axisLocation31);
//        org.jfree.chart.util.RectangleInsets rectangleInsets33 = xYPlot14.getAxisOffset();
//        categoryPlot11.setInsets(rectangleInsets33);
//        categoryPlot11.clearDomainAxes();
//        java.awt.Stroke stroke36 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        categoryPlot11.setDomainGridlineStroke(stroke36);
//        boolean boolean38 = unitType3.equals((java.lang.Object) stroke36);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(axisLocation12);
//        org.junit.Assert.assertNull(collection16);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNull(plot30);
//        org.junit.Assert.assertNotNull(axisLocation31);
//        org.junit.Assert.assertNotNull(rectangleInsets33);
//        org.junit.Assert.assertNotNull(stroke36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        xYPlot9.setRangeZeroBaselineStroke(stroke15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot9.setDomainAxisLocation(axisLocation26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
        categoryPlot6.setInsets(rectangleInsets28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot30.getDomainMarkers(layer31);
        java.awt.Paint paint33 = xYPlot30.getDomainCrosshairPaint();
        categoryPlot6.setRangeCrosshairPaint(paint33);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        xYPlot0.setDomainZeroBaselineVisible(true);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        double double8 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        try {
            java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.clearRangeMarkers((int) (short) 100);
        java.awt.Image image17 = categoryPlot6.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot6.getIndexOf(categoryItemRenderer18);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color1.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        int int9 = color1.getGreen();
        int int10 = color1.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.setRangeCrosshairVisible(true);
        boolean boolean13 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        categoryPlot6.setOutlineVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.util.List list8 = categoryPlot6.getCategories();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        double double31 = categoryPlot6.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = valueMarker33.getLabelOffset();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        categoryPlot6.clearRangeMarkers(9);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker5.addChangeListener(markerChangeListener6);
        java.awt.Paint paint8 = valueMarker5.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 100, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot19.getDomainAxisLocation();
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        java.awt.Color color26 = java.awt.Color.black;
        int int27 = color26.getRed();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color26, stroke28);
        xYPlot22.setRangeZeroBaselineStroke(stroke28);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        org.jfree.chart.plot.Plot plot38 = categoryPlot37.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getDomainAxisLocation();
        xYPlot22.setDomainAxisLocation(axisLocation39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot22.getAxisOffset();
        categoryPlot19.setInsets(rectangleInsets41);
        categoryPlot19.clearDomainAxes();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot19.setDomainGridlineStroke(stroke44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot19.getDomainAxisEdge();
        try {
            java.util.List list47 = categoryAxis1.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot0.render(graphics2D6, rectangle2D7, (-246), plotRenderingInfo9, crosshairState10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        numberAxis12.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getParent();
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot23, jFreeChart25);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot23.getRowRenderingOrder();
        numberAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        double double29 = numberAxis12.getLowerMargin();
        numberAxis12.setUpperMargin(1.0d);
        org.jfree.data.Range range32 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Color color35 = java.awt.Color.black;
        int int36 = color35.getRed();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color35, stroke37);
        org.jfree.chart.util.Layer layer39 = null;
        xYPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker38, layer39);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100, 0.0d);
        double double3 = intervalMarker2.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot4.getDomainMarkers(layer5);
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        xYPlot4.setRangeZeroBaselineStroke(stroke10);
        java.awt.Paint paint13 = xYPlot4.getDomainCrosshairPaint();
        boolean boolean14 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener17 = null;
        valueMarker16.addChangeListener(markerChangeListener17);
        java.awt.Paint paint19 = valueMarker16.getOutlinePaint();
        java.lang.Object obj20 = null;
        boolean boolean21 = valueMarker16.equals(obj20);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer22);
        boolean boolean24 = intervalMarker2.equals((java.lang.Object) valueMarker16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker2.getGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertNull(gradientPaintTransformer26);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        boolean boolean17 = numberAxis10.getAutoRangeStickyZero();
        java.awt.Shape shape18 = numberAxis10.getDownArrow();
        org.jfree.data.Range range19 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis10.getLabelInsets();
        categoryPlot6.setInsets(rectangleInsets20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets20.createOutsetRectangle(rectangle2D22, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getParent();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot7, jFreeChart9);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot7.getRowRenderingOrder();
        categoryPlot7.setAnchorValue((double) '4', false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        categoryPlot7.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot7.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        numberAxis22.setVisible(true);
        double double29 = numberAxis22.getUpperBound();
        java.awt.Shape shape30 = numberAxis22.getUpArrow();
        boolean boolean31 = plotOrientation18.equals((java.lang.Object) shape30);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.05d + "'", double29 == 1.05d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(0);
        xYPlot0.configureDomainAxes();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        double double8 = categoryPlot6.getRangeCrosshairValue();
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(0, layer9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.addChangeListener(markerChangeListener14);
        java.awt.Paint paint16 = valueMarker13.getOutlinePaint();
        valueMarker13.setLabel("hi!");
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = xYPlot0.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker13, layer19, true);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        numberAxis24.setVisible(true);
        boolean boolean31 = numberAxis24.getAutoRangeStickyZero();
        java.awt.Shape shape32 = numberAxis24.getDownArrow();
        org.jfree.data.Range range33 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis24.getTickUnit();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(numberTickUnit34);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        java.awt.Stroke stroke16 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.clearDomainMarkers(0);
        java.awt.Color color23 = java.awt.Color.black;
        int int24 = color23.getRed();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color23, stroke25);
        java.lang.Comparable comparable27 = categoryMarker26.getKey();
        org.jfree.chart.util.Layer layer28 = null;
        xYPlot18.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot18.getDomainMarkers((int) ' ', layer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot18.getDomainAxisLocation();
        try {
            xYPlot0.setDomainAxisLocation((-16777216), axisLocation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker14);
        java.lang.Object obj16 = markerChangeEvent15.getSource();
        java.lang.Object obj17 = markerChangeEvent15.getSource();
        org.jfree.chart.plot.Marker marker18 = markerChangeEvent15.getMarker();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        marker18.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot6.removeRangeMarker(marker18, layer21);
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(marker18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.setRangeCrosshairVisible(true);
        int int13 = categoryPlot6.getWeight();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double5 = rectangleInsets0.calculateBottomOutset((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis2.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
//        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
//        categoryPlot6.clearAnnotations();
//        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.util.Layer layer10 = null;
//        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
//        java.awt.Color color13 = java.awt.Color.black;
//        int int14 = color13.getRed();
//        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
//        xYPlot9.setRangeZeroBaselineStroke(stroke15);
//        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis20.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
//        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
//        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
//        xYPlot9.setDomainAxisLocation(axisLocation26);
//        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
//        categoryPlot6.setInsets(rectangleInsets28);
//        categoryPlot6.clearDomainAxes();
//        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        categoryPlot6.setDomainGridlineStroke(stroke31);
//        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis34.setMaximumCategoryLabelLines((-16777216));
//        int int37 = categoryAxis34.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getSerialIndex();
//        java.util.Date date40 = day38.getStart();
//        java.awt.Font font41 = categoryAxis34.getTickLabelFont((java.lang.Comparable) day38);
//        java.util.List list42 = categoryPlot6.getCategoriesForAxis(categoryAxis34);
//        java.awt.Stroke stroke43 = categoryPlot6.getDomainGridlineStroke();
//        org.junit.Assert.assertNotNull(axisLocation7);
//        org.junit.Assert.assertNull(collection11);
//        org.junit.Assert.assertNotNull(color13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertNull(plot25);
//        org.junit.Assert.assertNotNull(axisLocation26);
//        org.junit.Assert.assertNotNull(rectangleInsets28);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-16777216) + "'", int37 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43629L + "'", long39 == 43629L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(font41);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertNotNull(stroke43);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        java.lang.Object obj17 = xYPlot0.clone();
        boolean boolean18 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint19 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot0.zoomDomainAxes((double) 10L, plotRenderingInfo21, point2D22, false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        try {
            java.util.Date date2 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str4 = chartChangeEventType3.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartChangeEventType0, jFreeChart2, chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str4.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        categoryPlot6.setNoDataMessage("");
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            boolean boolean29 = categoryPlot6.removeRangeMarker(marker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(layer28);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot0.render(graphics2D6, rectangle2D7, (-246), plotRenderingInfo9, crosshairState10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        numberAxis12.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getParent();
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot23, jFreeChart25);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot23.getRowRenderingOrder();
        numberAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        double double29 = numberAxis12.getLowerMargin();
        numberAxis12.setUpperMargin(1.0d);
        org.jfree.data.Range range32 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.extendHeight((double) ' ');
        double double37 = rectangleInsets33.trimHeight(2.0d);
        numberAxis12.setTickLabelInsets(rectangleInsets33);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 32.0d + "'", double35 == 32.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis5, categoryItemRenderer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot9.getParent();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot9, jFreeChart11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot9.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot9.getFixedLegendItems();
        java.awt.Stroke stroke15 = categoryPlot9.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot9.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot9.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.clearDomainMarkers(0);
        java.awt.Color color23 = java.awt.Color.black;
        int int24 = color23.getRed();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color23, stroke25);
        java.lang.Comparable comparable27 = categoryMarker26.getKey();
        org.jfree.chart.util.Layer layer28 = null;
        xYPlot18.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot18.getDomainMarkers((int) ' ', layer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot18.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot34.getDomainMarkers(layer35);
        xYPlot34.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        xYPlot34.datasetChanged(datasetChangeEvent39);
        java.awt.Paint paint41 = xYPlot34.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        xYPlot34.datasetChanged(datasetChangeEvent42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker46.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer49 = null;
        boolean boolean51 = xYPlot34.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker46, layer49, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot34.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo54, point2D55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = xYPlot34.getOrientation();
        java.lang.String str58 = plotOrientation57.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double61 = rectangleInsets59.extendHeight((double) ' ');
        double double63 = rectangleInsets59.trimWidth((double) 2.0f);
        double double65 = rectangleInsets59.calculateTopOutset(2.0d);
        boolean boolean66 = plotOrientation57.equals((java.lang.Object) double65);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation57);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation57);
        try {
            double double69 = dateAxis0.java2DToValue((double) 8, rectangle2D2, rectangleEdge68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "PlotOrientation.VERTICAL" + "'", str58.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 32.0d + "'", double61 == 32.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.0d + "'", double63 == 2.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        boolean boolean17 = numberAxis10.getAutoRangeStickyZero();
        java.awt.Shape shape18 = numberAxis10.getDownArrow();
        org.jfree.data.Range range19 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis10.getLabelInsets();
        categoryPlot6.setInsets(rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) 15);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(13);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        double double5 = numberAxis0.getFixedAutoRange();
        java.text.NumberFormat numberFormat6 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperMargin();
        java.awt.Color color2 = java.awt.Color.BLUE;
        numberAxis0.setLabelPaint((java.awt.Paint) color2);
        java.awt.Shape shape4 = numberAxis0.getLeftArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit5, false, false);
        boolean boolean9 = numberAxis0.isInverted();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        double double14 = numberAxis2.getAutoRangeMinimumSize();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot15.getDomainMarkers(layer16);
        java.awt.Color color19 = java.awt.Color.black;
        int int20 = color19.getRed();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color19, stroke21);
        xYPlot15.setRangeZeroBaselineStroke(stroke21);
        java.awt.Paint paint24 = xYPlot15.getDomainCrosshairPaint();
        boolean boolean25 = xYPlot15.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener28 = null;
        valueMarker27.addChangeListener(markerChangeListener28);
        java.awt.Paint paint30 = valueMarker27.getOutlinePaint();
        java.lang.Object obj31 = null;
        boolean boolean32 = valueMarker27.equals(obj31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27, layer33);
        boolean boolean35 = numberAxis2.equals((java.lang.Object) xYPlot15);
        java.text.NumberFormat numberFormat36 = null;
        numberAxis2.setNumberFormatOverride(numberFormat36);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        java.awt.Font font10 = numberAxis2.getLabelFont();
        numberAxis2.setVisible(true);
        java.awt.Paint paint13 = numberAxis2.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot0.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = xYPlot0.getOrientation();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder25 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis2.setUpArrow(shape14);
        try {
            numberAxis2.setRangeWithMargins((double) 6, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot0.getDomainGridlinePaint();
        float float5 = xYPlot0.getBackgroundAlpha();
        int int6 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setRange((double) (short) 100, (double) 43629L);
        numberAxis2.setAutoRangeMinimumSize((double) 255);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = null;
        numberAxis2.setStandardTickUnits(tickUnitSource15);
        org.junit.Assert.assertNull(markerAxisBand9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "XY Plot", paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str2.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        double double14 = numberAxis2.getAutoRangeMinimumSize();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot15.getDomainMarkers(layer16);
        java.awt.Color color19 = java.awt.Color.black;
        int int20 = color19.getRed();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color19, stroke21);
        xYPlot15.setRangeZeroBaselineStroke(stroke21);
        java.awt.Paint paint24 = xYPlot15.getDomainCrosshairPaint();
        boolean boolean25 = xYPlot15.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener28 = null;
        valueMarker27.addChangeListener(markerChangeListener28);
        java.awt.Paint paint30 = valueMarker27.getOutlinePaint();
        java.lang.Object obj31 = null;
        boolean boolean32 = valueMarker27.equals(obj31);
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = xYPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27, layer33);
        boolean boolean35 = numberAxis2.equals((java.lang.Object) xYPlot15);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.CrosshairState crosshairState40 = null;
        boolean boolean41 = xYPlot15.render(graphics2D36, rectangle2D37, 9, plotRenderingInfo39, crosshairState40);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        categoryPlot6.setDrawSharedDomainAxis(false);
        categoryPlot6.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean7 = xYPlot0.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer(xYItemRenderer8);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        xYPlot0.clearDomainMarkers(0);
//        java.awt.Color color5 = java.awt.Color.black;
//        int int6 = color5.getRed();
//        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
//        java.lang.Comparable comparable9 = categoryMarker8.getKey();
//        org.jfree.chart.util.Layer layer10 = null;
//        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
//        org.jfree.chart.util.Layer layer13 = null;
//        java.util.Collection collection14 = xYPlot0.getDomainMarkers((int) ' ', layer13);
//        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
//        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.util.Layer layer17 = null;
//        java.util.Collection collection18 = xYPlot16.getDomainMarkers(layer17);
//        xYPlot16.setWeight((int) (short) 100);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
//        xYPlot16.datasetChanged(datasetChangeEvent21);
//        java.awt.Paint paint23 = xYPlot16.getDomainCrosshairPaint();
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
//        xYPlot16.datasetChanged(datasetChangeEvent24);
//        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 0);
//        valueMarker28.setAlpha((float) 1L);
//        org.jfree.chart.util.Layer layer31 = null;
//        boolean boolean33 = xYPlot16.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker28, layer31, false);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
//        java.awt.geom.Point2D point2D37 = null;
//        xYPlot16.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo36, point2D37);
//        org.jfree.chart.plot.PlotOrientation plotOrientation39 = xYPlot16.getOrientation();
//        java.lang.String str40 = plotOrientation39.toString();
//        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        double double43 = rectangleInsets41.extendHeight((double) ' ');
//        double double45 = rectangleInsets41.trimWidth((double) 2.0f);
//        double double47 = rectangleInsets41.calculateTopOutset(2.0d);
//        boolean boolean48 = plotOrientation39.equals((java.lang.Object) double47);
//        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation39);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getSerialIndex();
//        java.util.Date date52 = day50.getStart();
//        boolean boolean53 = plotOrientation39.equals((java.lang.Object) day50);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
//        org.junit.Assert.assertNull(collection14);
//        org.junit.Assert.assertNotNull(axisLocation15);
//        org.junit.Assert.assertNull(collection18);
//        org.junit.Assert.assertNotNull(paint23);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(plotOrientation39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PlotOrientation.VERTICAL" + "'", str40.equals("PlotOrientation.VERTICAL"));
//        org.junit.Assert.assertNotNull(rectangleInsets41);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 32.0d + "'", double43 == 32.0d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43629L + "'", long51 == 43629L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(13);
        java.lang.Object obj3 = objectList1.get((-14417954));
        java.lang.Object obj4 = objectList1.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        java.awt.Color color34 = java.awt.Color.getHSBColor((float) (byte) 1, 0.0f, 2.0f);
        int int35 = color34.getRed();
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color34);
        java.awt.Color color40 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass41 = color40.getClass();
        float[] floatArray47 = new float[] { 255, (short) 100, 'a', 100, 'a' };
        float[] floatArray48 = color40.getColorComponents(floatArray47);
        float[] floatArray49 = color34.getComponents(floatArray48);
        java.awt.Color color53 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color54 = color53.darker();
        java.awt.Color color55 = color53.brighter();
        java.awt.color.ColorSpace colorSpace56 = color55.getColorSpace();
        java.awt.Color color60 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass61 = color60.getClass();
        float[] floatArray67 = new float[] { 255, (short) 100, 'a', 100, 'a' };
        float[] floatArray68 = color60.getColorComponents(floatArray67);
        float[] floatArray69 = color34.getComponents(colorSpace56, floatArray68);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(colorSpace56);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray69);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        numberAxis0.setInverted(false);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis0.setTickMarkStroke(stroke4);
        numberAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        java.lang.String str12 = categoryPlot11.getNoDataMessage();
        boolean boolean13 = categoryPlot11.isRangeCrosshairVisible();
        categoryPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = dateAxis0.draw(graphics2D1, (double) (byte) 1, rectangle2D3, rectangle2D4, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        int int34 = categoryPlot6.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot6.getLegendItems();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection35);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean7 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener10 = null;
        valueMarker9.addChangeListener(markerChangeListener10);
        java.awt.Paint paint12 = valueMarker9.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker9.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker15.setLabelTextAnchor(textAnchor16);
        valueMarker9.setLabelTextAnchor(textAnchor16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        valueMarker9.setLabelAnchor(rectangleAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer22);
        valueMarker9.setLabel("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer22);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer8);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 13 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker1.setAlpha((float) 1L);
        java.awt.Color color4 = java.awt.Color.pink;
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        categoryPlot6.zoom((double) 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener39 = null;
        valueMarker38.addChangeListener(markerChangeListener39);
        org.jfree.chart.text.TextAnchor textAnchor41 = valueMarker38.getLabelTextAnchor();
        valueMarker38.setAlpha(0.0f);
        boolean boolean44 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        numberAxis12.setVisible(true);
        org.jfree.data.Range range19 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot6.getRendererForDataset(categoryDataset20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot6.getRenderer(2);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot0.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation24 = null;
        try {
            boolean boolean25 = xYPlot0.removeAnnotation(xYAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Category Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot5.getDomainMarkers(layer6);
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        xYPlot5.setRangeZeroBaselineStroke(stroke11);
        java.awt.Paint paint14 = xYPlot5.getDomainCrosshairPaint();
        boolean boolean15 = xYPlot5.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener18 = null;
        valueMarker17.addChangeListener(markerChangeListener18);
        java.awt.Paint paint20 = valueMarker17.getOutlinePaint();
        java.lang.Object obj21 = null;
        boolean boolean22 = valueMarker17.equals(obj21);
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = xYPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker17, layer23);
        boolean boolean25 = xYPlot5.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot5.getRangeAxisEdge(100);
        try {
            java.util.List list28 = dateAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        java.util.TimeZone timeZone3 = null;
//        try {
//            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker14);
        java.lang.Object obj16 = markerChangeEvent15.getSource();
        java.lang.Object obj17 = markerChangeEvent15.getSource();
        org.jfree.chart.plot.Marker marker18 = markerChangeEvent15.getMarker();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        marker18.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot6.removeRangeMarker(marker18, layer21);
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        try {
            categoryPlot6.setRangeAxisLocation(axisLocation24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(marker18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot32.getDomainMarkers(layer33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot32.datasetChanged(datasetChangeEvent35);
        boolean boolean37 = intervalMarker30.equals((java.lang.Object) xYPlot32);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis40, categoryItemRenderer43);
        numberAxis40.setVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis40.getTickLabelInsets();
        xYPlot32.setInsets(rectangleInsets47);
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        numberAxis52.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis52, categoryItemRenderer55);
        numberAxis52.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = numberAxis52.getMarkerBand();
        numberAxis52.setAutoRangeStickyZero(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis52);
        numberAxis52.configure();
        java.awt.Stroke stroke64 = numberAxis52.getAxisLineStroke();
        try {
            xYPlot32.setRangeAxis((-16776705), (org.jfree.chart.axis.ValueAxis) numberAxis52, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(markerAxisBand59);
        org.junit.Assert.assertNotNull(stroke64);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis0.java2DToValue((double) 1.0f, rectangle2D3, rectangleEdge4);
        float float6 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(0);
        java.awt.Stroke stroke12 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxis(15);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.clearRangeMarkers((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        float float20 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        categoryPlot6.setDomainAxis(10, categoryAxis19, true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets14.calculateBottomOutset((double) 9);
        valueMarker1.setLabelOffset(rectangleInsets14);
        double double22 = rectangleInsets14.calculateBottomOutset(0.0d);
        double double24 = rectangleInsets14.extendHeight((double) (short) 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getParent();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot7, jFreeChart9);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot7.getRowRenderingOrder();
        categoryPlot7.setAnchorValue((double) '4', false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        categoryPlot7.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot7.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation18);
        java.lang.String str20 = plotOrientation18.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.VERTICAL" + "'", str20.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        java.awt.Color color14 = java.awt.Color.yellow;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        valueMarker1.setPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot17.getDomainMarkers(layer18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot17.getRenderer(255);
        xYPlot17.configureDomainAxes();
        xYPlot17.configureDomainAxes();
        java.awt.Color color27 = java.awt.Color.getHSBColor(0.0f, (float) 'a', 10.0f);
        xYPlot17.setRangeTickBandPaint((java.awt.Paint) color27);
        double double29 = xYPlot17.getRangeCrosshairValue();
        boolean boolean30 = valueMarker1.equals((java.lang.Object) double29);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis7.setMaximumCategoryLabelLines((-16777216));
//        int int10 = categoryAxis7.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getStart();
//        java.awt.Font font14 = categoryAxis7.getTickLabelFont((java.lang.Comparable) day11);
//        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1.05d, font14);
//        double double16 = categoryAxis1.getUpperMargin();
//        java.lang.Comparable comparable17 = null;
//        try {
//            java.awt.Font font18 = categoryAxis1.getTickLabelFont(comparable17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        categoryPlot6.zoom((double) 0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer42);
        org.jfree.chart.plot.Plot plot44 = categoryPlot43.getParent();
        org.jfree.chart.JFreeChart jFreeChart45 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot43, jFreeChart45);
        boolean boolean47 = categoryPlot6.equals((java.lang.Object) categoryPlot43);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperMargin();
        java.awt.Color color2 = java.awt.Color.BLUE;
        numberAxis0.setLabelPaint((java.awt.Paint) color2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot20.getDomainAxisLocation();
        java.awt.Color color24 = java.awt.Color.black;
        int int25 = color24.getRed();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color24, stroke26);
        java.lang.Comparable comparable28 = categoryMarker27.getKey();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = categoryPlot20.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker27, layer29);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener34 = null;
        valueMarker33.addChangeListener(markerChangeListener34);
        java.awt.Paint paint36 = valueMarker33.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = valueMarker33.getLabelAnchor();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = categoryPlot20.removeRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker33, layer38, false);
        java.awt.Stroke stroke41 = categoryPlot20.getRangeCrosshairStroke();
        numberAxis6.setAxisLineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        numberAxis43.setLabelURL("");
        numberAxis43.setLowerBound((double) (short) -1);
        java.awt.Font font48 = numberAxis43.getLabelFont();
        numberAxis6.setLabelFont(font48);
        numberAxis0.setTickLabelFont(font48);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100 + "'", comparable28.equals(100));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(font48);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        numberAxis11.setAutoTickUnitSelection(false);
        float float18 = numberAxis11.getTickMarkInsideLength();
        numberAxis11.setVisible(false);
        xYPlot5.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis11.getStandardTickUnits();
        int int24 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Paint paint25 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot32.getDomainAxisLocation();
        java.awt.Color color36 = java.awt.Color.black;
        int int37 = color36.getRed();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color36, stroke38);
        java.lang.Comparable comparable40 = categoryMarker39.getKey();
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = categoryPlot32.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker39, layer41);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker44);
        java.lang.Object obj46 = markerChangeEvent45.getSource();
        categoryMarker39.notifyListeners(markerChangeEvent45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryMarker39.setOutlinePaint((java.awt.Paint) color48);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color48);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + 100 + "'", comparable40.equals(100));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker14);
        java.lang.Object obj16 = markerChangeEvent15.getSource();
        java.lang.Object obj17 = markerChangeEvent15.getSource();
        org.jfree.chart.plot.Marker marker18 = markerChangeEvent15.getMarker();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        marker18.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot6.removeRangeMarker(marker18, layer21);
        categoryPlot6.clearRangeMarkers();
        java.awt.Color color25 = java.awt.Color.black;
        int int26 = color25.getRed();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color25, stroke27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean30 = categoryMarker28.equals((java.lang.Object) categoryAxis29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        org.jfree.chart.plot.Plot plot38 = categoryPlot37.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot37.getFixedLegendItems();
        java.lang.String str41 = categoryPlot37.getPlotType();
        java.awt.Color color44 = java.awt.Color.black;
        int int45 = color44.getRed();
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color44, stroke46);
        java.lang.Comparable comparable48 = categoryMarker47.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        numberAxis51.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer54);
        java.lang.String str56 = categoryPlot55.getNoDataMessage();
        boolean boolean57 = categoryPlot55.isRangeCrosshairVisible();
        categoryPlot55.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot55.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker63);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType65 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent64.setType(chartChangeEventType65);
        org.jfree.chart.plot.Marker marker67 = markerChangeEvent64.getMarker();
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean69 = categoryPlot55.removeRangeMarker(0, marker67, layer68);
        boolean boolean71 = categoryPlot37.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker47, layer68, true);
        categoryPlot6.addDomainMarker(categoryMarker28, layer68);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(marker18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 100 + "'", comparable48.equals(100));
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(chartChangeEventType65);
        org.junit.Assert.assertNotNull(marker67);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        java.awt.Font font10 = numberAxis2.getLabelFont();
        numberAxis2.setVisible(true);
        numberAxis2.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        categoryMarker13.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = categoryMarker13.getLabelOffsetType();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker5.addChangeListener(markerChangeListener6);
        java.awt.Paint paint8 = valueMarker5.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 100, paint8);
        java.awt.Font font10 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        numberAxis8.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getParent();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot19.getRowRenderingOrder();
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        double double25 = numberAxis8.getLowerMargin();
        org.jfree.data.Range range26 = numberAxis8.getDefaultAutoRange();
        boolean boolean27 = numberAxis8.isAutoTickUnitSelection();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        java.awt.Stroke stroke30 = xYPlot0.getDomainZeroBaselineStroke();
        java.awt.Paint paint31 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker10.setLabelTextAnchor(textAnchor11);
        org.jfree.chart.util.Layer layer13 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker10, layer13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot15.getDomainMarkers(layer16);
        java.awt.Paint paint18 = xYPlot15.getDomainCrosshairPaint();
        xYPlot0.setRangeCrosshairPaint(paint18);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = xYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        org.jfree.chart.plot.Plot plot13 = categoryPlot12.getParent();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot12, jFreeChart14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot12.getRowRenderingOrder();
        categoryPlot12.setAnchorValue((double) '4', false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot12.setRangeAxes(valueAxisArray20);
        xYPlot0.setDomainAxes(valueAxisArray20);
        boolean boolean23 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1.0f));
        categoryMarker1.setKey((java.lang.Comparable) 6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Color color1 = java.awt.Color.black;
        int int2 = color1.getRed();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke3);
        int int5 = color1.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis2);
        numberAxis2.configure();
        java.awt.Stroke stroke14 = numberAxis2.getAxisLineStroke();
        double double15 = numberAxis2.getAutoRangeMinimumSize();
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot0.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = xYPlot0.getOrientation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot17.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot17.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot17.getDataset(13);
        java.lang.Class<?> wildcardClass22 = categoryPlot17.getClass();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot17.getRowRenderingOrder();
        categoryPlot6.setColumnRenderingOrder(sortOrder23);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot6.setDomainGridlinePosition(categoryAnchor25);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(categoryAnchor25);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        java.lang.String str2 = numberAxis0.getLabelURL();
        boolean boolean3 = numberAxis0.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        boolean boolean6 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray7);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(valueAxisArray7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot6.getIndexOf(categoryItemRenderer10);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Color color8 = java.awt.Color.yellow;
        java.awt.Color color9 = java.awt.Color.getColor("hi!", color8);
        java.awt.Color color10 = color9.darker();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextStroke();
        try {
            java.awt.Paint paint24 = defaultDrawingSupplier22.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint4 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot6.axisChanged(axisChangeEvent8);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets14.calculateBottomOutset((double) 9);
        valueMarker1.setLabelOffset(rectangleInsets14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.awt.Font font23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean24 = lengthAdjustmentType22.equals((java.lang.Object) font23);
        java.lang.Object obj25 = null;
        boolean boolean26 = lengthAdjustmentType22.equals(obj25);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Color color2 = java.awt.Color.getColor("ChartChangeEventType.GENERAL", 7);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Shape shape14 = numberAxis2.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        numberAxis17.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = numberAxis17.getMarkerBand();
        org.jfree.data.Range range25 = numberAxis17.getRange();
        numberAxis2.setRange(range25);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getUpperMargin();
        java.awt.Color color29 = java.awt.Color.BLUE;
        numberAxis27.setLabelPaint((java.awt.Paint) color29);
        java.awt.Shape shape31 = numberAxis27.getLeftArrow();
        numberAxis2.setRightArrow(shape31);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        xYPlot35.clearDomainMarkers(0);
        java.awt.Color color40 = java.awt.Color.black;
        int int41 = color40.getRed();
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color40, stroke42);
        java.lang.Comparable comparable44 = categoryMarker43.getKey();
        org.jfree.chart.util.Layer layer45 = null;
        xYPlot35.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker43, layer45);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = xYPlot35.getDomainMarkers((int) ' ', layer48);
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot35.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = xYPlot51.getDomainMarkers(layer52);
        xYPlot51.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        xYPlot51.datasetChanged(datasetChangeEvent56);
        java.awt.Paint paint58 = xYPlot51.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent59 = null;
        xYPlot51.datasetChanged(datasetChangeEvent59);
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker63.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean68 = xYPlot51.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker63, layer66, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Point2D point2D72 = null;
        xYPlot51.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo71, point2D72);
        org.jfree.chart.plot.PlotOrientation plotOrientation74 = xYPlot51.getOrientation();
        java.lang.String str75 = plotOrientation74.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double78 = rectangleInsets76.extendHeight((double) ' ');
        double double80 = rectangleInsets76.trimWidth((double) 2.0f);
        double double82 = rectangleInsets76.calculateTopOutset(2.0d);
        boolean boolean83 = plotOrientation74.equals((java.lang.Object) double82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation50, plotOrientation74);
        try {
            double double85 = numberAxis2.lengthToJava2D(13.0d, rectangle2D34, rectangleEdge84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(markerAxisBand24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 100 + "'", comparable44.equals(100));
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(plotOrientation74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "PlotOrientation.VERTICAL" + "'", str75.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 32.0d + "'", double78 == 32.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 2.0d + "'", double80 == 2.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(rectangleEdge84);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot11.getDomainMarkers(layer12);
        xYPlot11.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot11.datasetChanged(datasetChangeEvent16);
        java.awt.Paint paint18 = xYPlot11.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot11.datasetChanged(datasetChangeEvent19);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker23.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean28 = xYPlot11.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer26, false);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker23);
        java.awt.Paint paint30 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(legendItemCollection20);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setAnchorValue((double) ' ', false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot6.getRenderer();
        try {
            categoryPlot6.setBackgroundImageAlpha((float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer32);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        java.lang.String str10 = categoryPlot6.getPlotType();
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        java.lang.Comparable comparable17 = categoryMarker16.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        java.lang.String str25 = categoryPlot24.getNoDataMessage();
        boolean boolean26 = categoryPlot24.isRangeCrosshairVisible();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent33.setType(chartChangeEventType34);
        org.jfree.chart.plot.Marker marker36 = markerChangeEvent33.getMarker();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = categoryPlot24.removeRangeMarker(0, marker36, layer37);
        boolean boolean40 = categoryPlot6.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker16, layer37, true);
        boolean boolean41 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100 + "'", comparable17.equals(100));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(marker36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font23);
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace27);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke9 = xYPlot0.getOutlineStroke();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        numberAxis8.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getParent();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot19.getRowRenderingOrder();
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        double double25 = numberAxis8.getLowerMargin();
        org.jfree.data.Range range26 = numberAxis8.getDefaultAutoRange();
        boolean boolean27 = numberAxis8.isAutoTickUnitSelection();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        boolean boolean30 = numberAxis8.isAutoTickUnitSelection();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot8.getDomainMarkers(layer9);
        xYPlot8.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        xYPlot8.datasetChanged(datasetChangeEvent13);
        java.awt.Paint paint15 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot8.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker20.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean25 = xYPlot8.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker20, layer23, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot8.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo28, point2D29);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = xYPlot8.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = xYPlot8.getOrientation();
        boolean boolean34 = plotOrientation32.equals((java.lang.Object) 100.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation32);
        java.lang.String str36 = plotOrientation32.toString();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PlotOrientation.VERTICAL" + "'", str36.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        java.awt.Stroke stroke16 = xYPlot0.getRangeGridlineStroke();
        double double17 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint18 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker14);
        java.lang.Object obj16 = markerChangeEvent15.getSource();
        java.lang.Object obj17 = markerChangeEvent15.getSource();
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19, chartChangeEventType20);
        markerChangeEvent15.setType(chartChangeEventType20);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer10, jFreeChart12, chartChangeEventType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent27.setType(chartChangeEventType28);
        xYPlot0.markerChanged(markerChangeEvent27);
        try {
            java.awt.Paint paint32 = xYPlot0.getQuadrantPaint((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (52) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(chartChangeEventType28);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot15.getDomainMarkers(layer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot15.getRenderer(255);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot15.getRangeMarkers((int) '4', layer21);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot15.getRangeMarkers(0, layer24);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener29 = null;
        valueMarker28.addChangeListener(markerChangeListener29);
        java.awt.Paint paint31 = valueMarker28.getOutlinePaint();
        valueMarker28.setLabel("hi!");
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = xYPlot15.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker28, layer34, true);
        xYPlot15.setDomainZeroBaselineVisible(false);
        categoryMarker12.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot15);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        java.awt.Color color34 = java.awt.Color.getHSBColor((float) (byte) 1, 0.0f, 2.0f);
        int int35 = color34.getRed();
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener39 = null;
        valueMarker38.addChangeListener(markerChangeListener39);
        java.awt.Paint paint41 = valueMarker38.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker38.getLabelAnchor();
        double double43 = valueMarker38.getValue();
        java.awt.Color color45 = java.awt.Color.black;
        int int46 = color45.getRed();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color45, stroke47);
        valueMarker38.setStroke(stroke47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = valueMarker38.getLabelAnchor();
        org.jfree.chart.util.Layer layer51 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker38, layer51);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener55 = null;
        valueMarker54.addChangeListener(markerChangeListener55);
        java.awt.Paint paint57 = valueMarker54.getOutlinePaint();
        java.awt.Color color58 = java.awt.Color.black;
        java.awt.Paint[] paintArray59 = new java.awt.Paint[] { paint57, color58 };
        java.awt.Color color61 = java.awt.Color.yellow;
        java.awt.Color color62 = java.awt.Color.getColor("hi!", color61);
        java.awt.Color color63 = color62.darker();
        java.awt.Paint[] paintArray64 = new java.awt.Paint[] { color63 };
        java.awt.Paint[] paintArray65 = new java.awt.Paint[] {};
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray72 = new java.awt.Stroke[] { stroke66, stroke67, stroke68, stroke69, stroke70, stroke71 };
        java.awt.Stroke[] strokeArray73 = null;
        java.awt.Shape[] shapeArray74 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier75 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray59, paintArray64, paintArray65, strokeArray72, strokeArray73, shapeArray74);
        java.awt.Paint paint76 = defaultDrawingSupplier75.getNextFillPaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier75);
        boolean boolean78 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paintArray59);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paintArray64);
        org.junit.Assert.assertNotNull(paintArray65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(strokeArray72);
        org.junit.Assert.assertNotNull(shapeArray74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Shape shape10 = numberAxis2.getDownArrow();
        org.jfree.data.Range range11 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        double double14 = rectangleInsets12.extendWidth((double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.0d + "'", double14 == 6.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis2.setLowerMargin(0.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis17.setMaximumCategoryLabelLines((-16777216));
        categoryAxis17.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis17.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit22, "Category Plot");
        float float25 = categoryAxis17.getTickMarkOutsideLength();
        java.awt.Font font26 = categoryAxis17.getTickLabelFont();
        numberAxis2.setTickLabelFont(font26);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Shape shape10 = numberAxis2.getDownArrow();
        double double11 = numberAxis2.getAutoRangeMinimumSize();
        float float12 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setVisible(false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-8d + "'", double11 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent2.getMarker();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.clearDomainMarkers(0);
        java.awt.Color color11 = java.awt.Color.black;
        int int12 = color11.getRed();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color11, stroke13);
        java.lang.Comparable comparable15 = categoryMarker14.getKey();
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot6.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker14, layer16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker14.setOutlineStroke(stroke18);
        marker5.setStroke(stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        marker5.setLabelPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 100 + "'", comparable15.equals(100));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener39 = null;
        valueMarker38.addChangeListener(markerChangeListener39);
        java.awt.Paint paint41 = valueMarker38.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker38.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker44.setLabelTextAnchor(textAnchor45);
        valueMarker38.setLabelTextAnchor(textAnchor45);
        org.jfree.chart.util.Layer layer48 = null;
        categoryPlot6.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker38, layer48, true);
        org.jfree.chart.text.TextAnchor textAnchor51 = valueMarker38.getLabelTextAnchor();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(textAnchor51);
    }
}

