import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker22.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer25 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer25, true);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Color color1 = java.awt.Color.black;
        int int2 = color1.getRed();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke3);
        java.lang.Comparable comparable5 = categoryMarker4.getKey();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot6.getRenderer(255);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot6.getRangeMarkers((int) '4', layer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot6.getRangeMarkers(0, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        valueMarker19.setLabel("hi!");
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean27 = xYPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker19, layer25, true);
        java.awt.Stroke stroke28 = valueMarker19.getOutlineStroke();
        categoryMarker4.setStroke(stroke28);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 100 + "'", comparable5.equals(100));
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis2.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot16 = numberAxis2.getPlot();
        java.awt.Font font17 = numberAxis2.getLabelFont();
        numberAxis2.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets14.calculateBottomOutset((double) 9);
        valueMarker1.setLabelOffset(rectangleInsets14);
        double double22 = rectangleInsets14.calculateBottomOutset(0.0d);
        double double23 = rectangleInsets14.getRight();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double17 = numberAxis0.getLowerMargin();
        org.jfree.data.Range range18 = numberAxis0.getDefaultAutoRange();
        numberAxis0.setLabelURL("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        numberAxis0.setVisible(false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.setRangeCrosshairValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot6.zoomRangeAxes((double) 100, plotRenderingInfo17, point2D18, false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker19.getLabelAnchor();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot6.removeRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker19, layer24, false);
        java.awt.Stroke stroke27 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer34);
        org.jfree.chart.plot.Plot plot36 = categoryPlot35.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot35.getDataset(13);
        java.lang.Class<?> wildcardClass40 = categoryPlot35.getClass();
        java.lang.String str41 = categoryPlot35.getPlotType();
        categoryPlot35.setRangeCrosshairValue((double) 0L, false);
        float float45 = categoryPlot35.getForegroundAlpha();
        boolean boolean46 = categoryPlot35.isRangeCrosshairLockedOnData();
        boolean boolean47 = categoryPlot35.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot35.getRangeAxis();
        categoryPlot6.setRangeAxis((int) (byte) 0, valueAxis48);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(valueAxis48);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        xYPlot6.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        xYPlot6.datasetChanged(datasetChangeEvent11);
        java.awt.Paint paint13 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        xYPlot6.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker18.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean23 = xYPlot6.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker18, layer21, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis26, categoryItemRenderer29);
        java.lang.String str31 = categoryPlot30.getNoDataMessage();
        boolean boolean32 = categoryPlot30.isRangeCrosshairVisible();
        categoryPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker38);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent39.setType(chartChangeEventType40);
        org.jfree.chart.plot.Marker marker42 = markerChangeEvent39.getMarker();
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean44 = categoryPlot30.removeRangeMarker(0, marker42, layer43);
        xYPlot0.addDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer43, true);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
        org.junit.Assert.assertNotNull(marker42);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(legendItemCollection47);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        double double9 = numberAxis2.getUpperBound();
        numberAxis2.setUpperMargin((double) 0);
        numberAxis2.centerRange((double) 100);
        java.text.NumberFormat numberFormat14 = null;
        numberAxis2.setNumberFormatOverride(numberFormat14);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.05d + "'", double9 == 1.05d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Shape shape14 = numberAxis2.getLeftArrow();
        numberAxis2.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainCrosshairVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = null;
        try {
            xYPlot0.setRenderers(xYItemRendererArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis2);
        numberAxis2.configure();
        java.awt.Stroke stroke14 = numberAxis2.getAxisLineStroke();
        numberAxis2.setAutoRangeMinimumSize(3.0d);
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getDomainAxis(3);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color1 = java.awt.Color.black;
        int int2 = color1.getRed();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean6 = categoryMarker4.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        numberAxis7.setLowerBound((double) (short) -1);
        java.awt.Font font12 = numberAxis7.getLabelFont();
        categoryAxis5.setTickLabelFont(font12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        boolean boolean12 = categoryMarker8.getDrawAsLine();
        java.lang.String str13 = categoryMarker8.getLabel();
        categoryMarker8.setDrawAsLine(true);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener18 = null;
        valueMarker17.addChangeListener(markerChangeListener18);
        java.awt.Paint paint20 = valueMarker17.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker17.getLabelAnchor();
        double double22 = valueMarker17.getValue();
        java.awt.Color color24 = java.awt.Color.black;
        int int25 = color24.getRed();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color24, stroke26);
        valueMarker17.setStroke(stroke26);
        java.awt.Color color30 = java.awt.Color.yellow;
        java.awt.Color color31 = java.awt.Color.getColor("hi!", color30);
        valueMarker17.setPaint((java.awt.Paint) color31);
        java.awt.Font font33 = valueMarker17.getLabelFont();
        categoryMarker8.setLabelFont(font33);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        valueMarker24.addChangeListener(markerChangeListener25);
        java.awt.Paint paint27 = valueMarker24.getOutlinePaint();
        java.lang.Object obj28 = null;
        boolean boolean29 = valueMarker24.equals(obj28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker24, layer30);
        int int32 = categoryPlot6.getDatasetCount();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Color color1 = java.awt.Color.black;
        int int2 = color1.getRed();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke3);
        categoryMarker4.setKey((java.lang.Comparable) 9);
        java.awt.Paint paint7 = categoryMarker4.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = xYPlot0.getAxisOffset();
        double double8 = rectangleInsets6.calculateLeftInset(0.0d);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis10.getTickLabelInsets();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        org.jfree.chart.text.TextAnchor textAnchor4 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        java.util.List list20 = categoryPlot6.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace21);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(list20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        java.lang.String str10 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = null;
        try {
            categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(0);
        java.awt.Stroke stroke12 = xYPlot0.getRangeZeroBaselineStroke();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot23.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot32.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getDomainAxisLocation();
        categoryPlot23.setRangeAxisLocation(axisLocation34, false);
        categoryPlot23.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener42 = null;
        valueMarker41.addChangeListener(markerChangeListener42);
        java.awt.Paint paint44 = valueMarker41.getOutlinePaint();
        java.lang.Object obj45 = null;
        boolean boolean46 = valueMarker41.equals(obj45);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot23.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker41, layer47);
        java.awt.Stroke stroke49 = categoryPlot23.getOutlineStroke();
        xYPlot0.setOutlineStroke(stroke49);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener20 = null;
        valueMarker19.addChangeListener(markerChangeListener20);
        java.awt.Paint paint22 = valueMarker19.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker19.getLabelAnchor();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot6.removeRangeMarker(255, (org.jfree.chart.plot.Marker) valueMarker19, layer24, false);
        categoryPlot6.setForegroundAlpha((float) 12);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis7.setMaximumCategoryLabelLines((-16777216));
//        int int10 = categoryAxis7.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getStart();
//        java.awt.Font font14 = categoryAxis7.getTickLabelFont((java.lang.Comparable) day11);
//        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1.05d, font14);
//        int int16 = categoryAxis1.getCategoryLabelPositionOffset();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font23);
        xYPlot0.mapDatasetToRangeAxis((int) '4', 6);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.setRangeCrosshairValue((double) 0L, false);
        float float16 = categoryPlot6.getForegroundAlpha();
        boolean boolean17 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean18 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryPlot6.getInsets();
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.lengthToJava2D((double) 0L, rectangle2D2, rectangleEdge3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        java.lang.Object obj3 = markerChangeEvent2.getSource();
        java.lang.Object obj4 = markerChangeEvent2.getSource();
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent2.getMarker();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        marker5.setLabelAnchor(rectangleAnchor6);
        marker5.setLabel("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { paint4, color5 };
        java.awt.Color color8 = java.awt.Color.yellow;
        java.awt.Color color9 = java.awt.Color.getColor("hi!", color8);
        java.awt.Color color10 = color9.darker();
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] {};
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke13, stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray19, strokeArray20, shapeArray21);
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextStroke();
        try {
            java.awt.Stroke stroke24 = defaultDrawingSupplier22.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        java.awt.Paint paint32 = intervalMarker30.getOutlinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker7);
        java.lang.Object obj9 = markerChangeEvent8.getSource();
        java.lang.Object obj10 = markerChangeEvent8.getSource();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder11, jFreeChart12, chartChangeEventType13);
        markerChangeEvent8.setType(chartChangeEventType13);
        boolean boolean16 = seriesRenderingOrder5.equals((java.lang.Object) chartChangeEventType13);
        chartChangeEvent1.setType(chartChangeEventType13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setVisible(false);
        float float12 = numberAxis2.getTickMarkOutsideLength();
        numberAxis2.setAutoRange(true);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer20);
        numberAxis17.setVisible(true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = numberAxis17.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        java.awt.Shape shape29 = numberAxis17.getLeftArrow();
        numberAxis2.setRightArrow(shape29);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        float float6 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot7.getDomainMarkers(layer8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot7.getRenderer(255);
        xYPlot7.configureDomainAxes();
        xYPlot7.configureDomainAxes();
        java.awt.Color color17 = java.awt.Color.getHSBColor(0.0f, (float) 'a', 10.0f);
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color17);
        org.jfree.chart.ChartColor chartColor23 = new org.jfree.chart.ChartColor(4, (int) (short) 10, (int) (short) 1);
        xYPlot7.setQuadrantPaint(3, (java.awt.Paint) chartColor23);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint26 = defaultDrawingSupplier25.getNextOutlinePaint();
        xYPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier25);
        java.awt.Stroke stroke28 = defaultDrawingSupplier25.getNextStroke();
        xYPlot0.setDomainCrosshairStroke(stroke28);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        categoryPlot6.clearRangeAxes();
        boolean boolean12 = categoryPlot6.isDomainZoomable();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot32.getDomainMarkers(layer33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot32.datasetChanged(datasetChangeEvent35);
        boolean boolean37 = intervalMarker30.equals((java.lang.Object) xYPlot32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = xYPlot32.getRenderer();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot32.drawBackgroundImage(graphics2D39, rectangle2D40);
        boolean boolean42 = xYPlot32.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        java.lang.Comparable comparable17 = categoryMarker13.getKey();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100 + "'", comparable17.equals(100));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup9 = categoryPlot6.getDatasetGroup();
        java.awt.Paint paint10 = categoryPlot6.getRangeGridlinePaint();
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        java.awt.Color color14 = java.awt.Color.yellow;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        valueMarker1.setPaint((java.awt.Paint) color15);
        java.awt.Font font17 = valueMarker1.getLabelFont();
        valueMarker1.setLabel("CONTRACT");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 10);
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
        java.util.List list17 = categoryPlot6.getAnnotations();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        java.lang.Object obj3 = markerChangeEvent2.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = markerChangeEvent2.getType();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        java.awt.Color color38 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color39 = color38.darker();
        java.awt.Color color40 = color38.brighter();
        java.awt.color.ColorSpace colorSpace41 = color40.getColorSpace();
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace43);
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation48 = null;
        categoryPlot6.setRangeAxisLocation(9, axisLocation48);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(colorSpace41);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener9 = null;
        valueMarker8.addChangeListener(markerChangeListener9);
        java.awt.Paint paint11 = valueMarker8.getOutlinePaint();
        valueMarker8.setAlpha((float) (short) 1);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer14);
        java.awt.Stroke stroke16 = categoryPlot6.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = numberAxis6.getStandardTickUnits();
        try {
            numberAxis6.setAutoRangeMinimumSize((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource18);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Color color1 = java.awt.Color.black;
        int int2 = color1.getRed();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke3);
        categoryMarker4.setDrawAsLine(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot6.getRangeMarkers(10, layer10);
        categoryPlot6.configureDomainAxes();
        java.awt.Stroke stroke13 = categoryPlot6.getRangeGridlineStroke();
        java.awt.Stroke stroke14 = categoryPlot6.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        java.awt.Shape shape10 = numberAxis2.getDownArrow();
        org.jfree.data.Range range11 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getLabelInsets();
        java.lang.String str13 = rectangleInsets12.toString();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str13.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        int int5 = color3.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        int int27 = categoryPlot6.getRangeAxisCount();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        java.awt.Paint paint6 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 10);
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot6.getDomainGridlinePosition();
        java.lang.String str17 = categoryAnchor16.toString();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str17.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainCrosshairVisible(false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot0.drawDomainTickBands(graphics2D8, rectangle2D9, list10);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        valueMarker24.addChangeListener(markerChangeListener25);
        java.awt.Paint paint27 = valueMarker24.getOutlinePaint();
        java.lang.Object obj28 = null;
        boolean boolean29 = valueMarker24.equals(obj28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker24, layer30);
        java.awt.Stroke stroke32 = categoryPlot6.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot6.getRendererForDataset(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        categoryPlot6.setDataset(100, categoryDataset36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot6.zoomRangeAxes((double) 10, plotRenderingInfo39, point2D40);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(categoryItemRenderer34);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) 0.0f, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        float[] floatArray10 = new float[] { 255, (short) 100, 'a', 100, 'a' };
        float[] floatArray11 = color3.getColorComponents(floatArray10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color3.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(paintContext17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        numberAxis9.setVisible(true);
        boolean boolean16 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Shape shape17 = numberAxis9.getDownArrow();
        boolean boolean18 = xYPlot0.equals((java.lang.Object) numberAxis9);
        int int19 = xYPlot0.getSeriesCount();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            xYPlot0.handleClick(0, 4, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot6.getRangeAxisForDataset(255);
        float float36 = valueAxis35.getTickMarkInsideLength();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke5);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getDomainAxisForDataset(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 9 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        categoryPlot6.zoom((double) 0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot6.getIndexOf(categoryItemRenderer37);
        categoryPlot6.mapDatasetToDomainAxis(255, (int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot6.getRangeAxisLocation(13);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot6.setDataset(categoryDataset44);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke4 = xYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        int int6 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit6, "Category Plot");
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis1.getCategoryLabelPositions();
        boolean boolean11 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double17 = numberAxis0.getLowerMargin();
        numberAxis0.setUpperMargin(1.0d);
        numberAxis0.setUpperMargin((double) 10.0f);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        numberAxis3.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis3.getMarkerBand();
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        numberAxis3.setLabelInsets(rectangleInsets13);
        java.lang.String str16 = numberAxis3.getLabelToolTip();
        boolean boolean17 = rectangleAnchor0.equals((java.lang.Object) numberAxis3);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        numberAxis11.setAutoTickUnitSelection(false);
        float float18 = numberAxis11.getTickMarkInsideLength();
        numberAxis11.setVisible(false);
        xYPlot5.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis11.getStandardTickUnits();
        int int24 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Paint paint25 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean26 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        double double31 = categoryPlot6.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = valueMarker33.getLabelOffset();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        java.lang.Object obj36 = categoryPlot6.clone();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        double double31 = categoryPlot6.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = valueMarker33.getLabelOffset();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        categoryPlot6.setRenderer(2019, categoryItemRenderer38);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        java.lang.Class<?> wildcardClass18 = valueMarker12.getClass();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot0.getRendererForDataset(xYDataset25);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(xYItemRenderer26);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        numberAxis11.setAutoTickUnitSelection(false);
        float float18 = numberAxis11.getTickMarkInsideLength();
        numberAxis11.setVisible(false);
        xYPlot5.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis11, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis11.getStandardTickUnits();
        int int24 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Paint paint25 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot0.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot0.setDataset((int) (short) 0, xYDataset28);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setAnchorValue((double) ' ', false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot6.getRenderer();
        java.util.List list33 = categoryPlot6.getCategories();
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertNull(list33);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = xYPlot0.getAxisOffset();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        java.awt.Stroke stroke17 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray19 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer18 };
        xYPlot0.setRenderers(xYItemRendererArray19);
        java.lang.Object obj21 = xYPlot0.clone();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(xYItemRendererArray19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot13.datasetChanged(datasetChangeEvent16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation26, true);
        java.awt.Stroke stroke29 = xYPlot13.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot13.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            org.jfree.chart.axis.AxisState axisState32 = dateAxis6.draw(graphics2D9, (double) ' ', rectangle2D11, rectangle2D12, rectangleEdge30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setVisible(false);
        float float12 = numberAxis2.getTickMarkOutsideLength();
        numberAxis2.setAutoRange(true);
        numberAxis2.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue(1L);
        java.util.TimeZone timeZone3 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12, false);
        categoryPlot6.clearDomainMarkers((-246));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1 + "'", obj2.equals(1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(true);
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        float float8 = numberAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation19 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis2.getTickLabelInsets();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot10.getDomainMarkers(layer11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot10.getRenderer(255);
        xYPlot10.configureDomainAxes();
        xYPlot10.setBackgroundAlpha((float) 0);
        numberAxis2.setPlot((org.jfree.chart.plot.Plot) xYPlot10);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(xYItemRenderer14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str6 = seriesRenderingOrder5.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder5);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str6.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo11, point2D12);
        java.awt.Stroke stroke14 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot6.getRangeMarkers((int) '#', layer21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        numberAxis25.setVisible(true);
        double double32 = numberAxis25.getUpperBound();
        numberAxis25.setUpperMargin((double) 0);
        org.jfree.data.Range range35 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis25);
        boolean boolean36 = numberAxis25.isNegativeArrowVisible();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.05d + "'", double32 == 1.05d);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getDomainAxisEdge(100);
        java.awt.Paint paint12 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        numberAxis9.setVisible(true);
        boolean boolean16 = numberAxis9.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        numberAxis9.setLabel("");
        java.awt.Stroke stroke20 = numberAxis9.getAxisLineStroke();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        org.jfree.chart.plot.Plot plot30 = categoryPlot29.getParent();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getDomainAxisEdge();
        try {
            double double32 = numberAxis9.java2DToValue((double) 3, rectangle2D22, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setVisible(false);
        float float12 = numberAxis2.getTickMarkOutsideLength();
        numberAxis2.setFixedAutoRange((double) 11);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot6.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setAnchorValue((double) ' ', false);
        java.awt.Stroke stroke32 = categoryPlot6.getOutlineStroke();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot6.getRangeMarkers(layer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot6.zoomRangeAxes(1.0d, plotRenderingInfo36, point2D37);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(collection34);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot32.getDomainMarkers(layer33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot32.datasetChanged(datasetChangeEvent35);
        boolean boolean37 = intervalMarker30.equals((java.lang.Object) xYPlot32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = xYPlot32.getRenderer();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot32.drawBackgroundImage(graphics2D39, rectangle2D40);
        double double42 = xYPlot32.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        java.awt.Color color38 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color39 = color38.darker();
        java.awt.Color color40 = color38.brighter();
        java.awt.color.ColorSpace colorSpace41 = color40.getColorSpace();
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace43);
        categoryPlot6.setRangeCrosshairVisible(true);
        java.lang.String str47 = categoryPlot6.getPlotType();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(colorSpace41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Category Plot" + "'", str47.equals("Category Plot"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.setRangeCrosshairValue((double) 0L, false);
        float float16 = categoryPlot6.getForegroundAlpha();
        boolean boolean17 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            boolean boolean20 = categoryPlot6.removeAnnotation(categoryAnnotation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1.0f));
        java.awt.Paint paint9 = categoryMarker8.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        java.lang.String str17 = categoryPlot16.getNoDataMessage();
        boolean boolean18 = categoryPlot16.isRangeCrosshairVisible();
        categoryPlot16.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot16.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.plot.Marker marker28 = markerChangeEvent25.getMarker();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot16.removeRangeMarker(0, marker28, layer29);
        xYPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker8, layer29);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertNotNull(marker28);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        boolean boolean18 = xYPlot0.isOutlineVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot0.getDomainGridlinePaint();
        float float5 = xYPlot0.getBackgroundAlpha();
        java.lang.Object obj6 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        java.awt.Color color34 = java.awt.Color.getHSBColor((float) (byte) 1, 0.0f, 2.0f);
        int int35 = color34.getRed();
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener39 = null;
        valueMarker38.addChangeListener(markerChangeListener39);
        java.awt.Paint paint41 = valueMarker38.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker38.getLabelAnchor();
        double double43 = valueMarker38.getValue();
        java.awt.Color color45 = java.awt.Color.black;
        int int46 = color45.getRed();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color45, stroke47);
        valueMarker38.setStroke(stroke47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = valueMarker38.getLabelAnchor();
        org.jfree.chart.util.Layer layer51 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker38, layer51);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener55 = null;
        valueMarker54.addChangeListener(markerChangeListener55);
        java.awt.Paint paint57 = valueMarker54.getOutlinePaint();
        java.awt.Color color58 = java.awt.Color.black;
        java.awt.Paint[] paintArray59 = new java.awt.Paint[] { paint57, color58 };
        java.awt.Color color61 = java.awt.Color.yellow;
        java.awt.Color color62 = java.awt.Color.getColor("hi!", color61);
        java.awt.Color color63 = color62.darker();
        java.awt.Paint[] paintArray64 = new java.awt.Paint[] { color63 };
        java.awt.Paint[] paintArray65 = new java.awt.Paint[] {};
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray72 = new java.awt.Stroke[] { stroke66, stroke67, stroke68, stroke69, stroke70, stroke71 };
        java.awt.Stroke[] strokeArray73 = null;
        java.awt.Shape[] shapeArray74 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier75 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray59, paintArray64, paintArray65, strokeArray72, strokeArray73, shapeArray74);
        java.awt.Paint paint76 = defaultDrawingSupplier75.getNextFillPaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier75);
        java.awt.Paint paint78 = defaultDrawingSupplier75.getNextPaint();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paintArray59);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paintArray64);
        org.junit.Assert.assertNotNull(paintArray65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(strokeArray72);
        org.junit.Assert.assertNotNull(shapeArray74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(paint78);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYPlot0.getDrawingSupplier();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(drawingSupplier12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer8);
        xYPlot0.setDomainCrosshairValue(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        numberAxis14.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis14.getMarkerBand();
        numberAxis14.setRange((double) (short) 100, (double) 43629L);
        int int25 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(drawingSupplier26);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        java.lang.Object obj4 = categoryAxis1.clone();
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 500);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot14.setRenderer(categoryItemRenderer15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot24.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = xYPlot26.getDomainMarkers(layer27);
        xYPlot26.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        xYPlot26.datasetChanged(datasetChangeEvent31);
        java.awt.Paint paint33 = xYPlot26.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        xYPlot26.datasetChanged(datasetChangeEvent34);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker38.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean43 = xYPlot26.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker38, layer41, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot26.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo46, point2D47);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = xYPlot26.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = xYPlot26.getOrientation();
        boolean boolean52 = plotOrientation50.equals((java.lang.Object) 100.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation50);
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace55 = categoryAxis1.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) categoryPlot14, rectangle2D17, rectangleEdge53, axisSpace54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        categoryPlot6.notifyListeners(plotChangeEvent26);
        boolean boolean28 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis5, categoryItemRenderer8);
        java.lang.String str10 = categoryPlot9.getNoDataMessage();
        boolean boolean11 = categoryPlot9.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo14, point2D15);
        boolean boolean17 = xYPlot0.equals((java.lang.Object) 0.0f);
        java.awt.Color color23 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot24.getDomainMarkers(layer25);
        java.awt.Color color28 = java.awt.Color.black;
        int int29 = color28.getRed();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color28, stroke30);
        xYPlot24.setRangeZeroBaselineStroke(stroke30);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot24.setRangeZeroBaselineStroke(stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener37 = null;
        valueMarker36.addChangeListener(markerChangeListener37);
        java.awt.Paint paint39 = valueMarker36.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot40.getDomainMarkers(layer41);
        xYPlot40.setWeight((int) (short) 100);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot40.setRangeCrosshairStroke(stroke45);
        org.jfree.chart.plot.IntervalMarker intervalMarker48 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color23, stroke33, paint39, stroke45, (float) (short) 1);
        xYPlot0.setRangeCrosshairStroke(stroke45);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener11 = null;
        valueMarker10.addChangeListener(markerChangeListener11);
        java.awt.Paint paint13 = valueMarker10.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker10.getLabelAnchor();
        boolean boolean15 = numberAxis2.equals((java.lang.Object) valueMarker10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainCrosshairVisible(false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxisForDataset((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis7.setMaximumCategoryLabelLines((-16777216));
//        int int10 = categoryAxis7.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getStart();
//        java.awt.Font font14 = categoryAxis7.getTickLabelFont((java.lang.Comparable) day11);
//        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1.05d, font14);
//        double double16 = categoryAxis1.getUpperMargin();
//        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis19.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
//        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getParent();
//        org.jfree.chart.JFreeChart jFreeChart25 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot23, jFreeChart25);
//        org.jfree.chart.LegendItemCollection legendItemCollection27 = null;
//        categoryPlot23.setFixedLegendItems(legendItemCollection27);
//        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis31.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer34);
//        java.lang.String str36 = categoryPlot35.getNoDataMessage();
//        boolean boolean37 = categoryPlot35.isRangeCrosshairVisible();
//        categoryPlot35.setRangeCrosshairLockedOnData(false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot35.getRangeAxisEdge();
//        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 0);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker43);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType45 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
//        markerChangeEvent44.setType(chartChangeEventType45);
//        org.jfree.chart.plot.Marker marker47 = markerChangeEvent44.getMarker();
//        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean49 = categoryPlot35.removeRangeMarker(0, marker47, layer48);
//        java.awt.Paint paint50 = marker47.getPaint();
//        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean52 = categoryPlot23.removeRangeMarker(marker47, layer51);
//        boolean boolean53 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot23);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-16777216) + "'", int10 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
//        org.junit.Assert.assertNull(plot24);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge40);
//        org.junit.Assert.assertNotNull(chartChangeEventType45);
//        org.junit.Assert.assertNotNull(marker47);
//        org.junit.Assert.assertNotNull(layer48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(paint50);
//        org.junit.Assert.assertNotNull(layer51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot17.getDomainAxisLocation();
        categoryPlot17.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot17.getDomainAxisLocation((int) (byte) -1);
        categoryPlot6.setDomainAxisLocation((int) (byte) 100, axisLocation21);
        categoryPlot6.setRangeCrosshairValue((double) '4');
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot6.getRangeAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace27, false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        numberAxis33.setVisible(true);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.axis.AxisState axisState41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        java.util.List list44 = numberAxis33.refreshTicks(graphics2D40, axisState41, rectangle2D42, rectangleEdge43);
        numberAxis33.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot47 = numberAxis33.getPlot();
        java.awt.Font font48 = numberAxis33.getLabelFont();
        categoryPlot6.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis33, true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(plot47);
        org.junit.Assert.assertNotNull(font48);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        double double7 = valueMarker2.getValue();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        valueMarker2.setStroke(stroke11);
        numberAxis0.setTickMarkStroke(stroke11);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis0.valueToJava2D(43629.0d, rectangle2D16, rectangleEdge17);
        boolean boolean19 = numberAxis0.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis0.getTickLabelInsets();
        boolean boolean21 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        numberAxis24.setAutoTickUnitSelection(false);
        float float31 = numberAxis24.getTickMarkInsideLength();
        java.awt.Shape shape32 = numberAxis24.getUpArrow();
        numberAxis0.setLeftArrow(shape32);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot0.setRenderer(xYItemRenderer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot18.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot18.getDomainAxisForDataset((int) ' ');
        java.awt.Color color23 = java.awt.Color.red;
        categoryPlot18.setDomainGridlinePaint((java.awt.Paint) color23);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color23);
        boolean boolean26 = xYPlot0.isSubplot();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot6.getRangeAxisLocation((int) ' ');
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(4, layer3);
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperMargin();
        numberAxis0.setFixedAutoRange((double) (-16777216));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double5 = rectangleInsets0.trimHeight((double) 43629L);
        double double6 = rectangleInsets0.getBottom();
        double double8 = rectangleInsets0.calculateTopInset((double) 8);
        double double10 = rectangleInsets0.calculateRightInset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets0.createInsetRectangle(rectangle2D11, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 43629.0d + "'", double5 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot32.getDomainMarkers(layer33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot32.datasetChanged(datasetChangeEvent35);
        boolean boolean37 = intervalMarker30.equals((java.lang.Object) xYPlot32);
        boolean boolean38 = xYPlot32.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            xYPlot32.handleClick(12, (int) '#', plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot6.getFixedLegendItems();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        categoryPlot6.setAnchorValue((double) (byte) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot6.getRenderer((-14417954));
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot0.setRenderer(xYItemRenderer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot18.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot18.getDomainAxisForDataset((int) ' ');
        java.awt.Color color23 = java.awt.Color.red;
        categoryPlot18.setDomainGridlinePaint((java.awt.Paint) color23);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace26, true);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        try {
            xYPlot0.drawBackground(graphics2D29, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        double double8 = categoryPlot6.getRangeCrosshairValue();
        java.awt.Color color9 = java.awt.Color.green;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint10 = xYPlot0.getDomainGridlinePaint();
        int int11 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        categoryPlot6.zoom((double) 0.0f);
        categoryPlot6.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot6.setRenderer((int) (short) 10, categoryItemRenderer40, true);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot6.getColumnRenderingOrder();
        java.awt.Stroke stroke44 = categoryPlot6.getRangeGridlineStroke();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setRangeZeroBaselineStroke(stroke9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot0.rendererChanged(rendererChangeEvent11);
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot0.render(graphics2D4, rectangle2D5, 3, plotRenderingInfo7, crosshairState8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        numberAxis8.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getParent();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot19.getRowRenderingOrder();
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        double double25 = numberAxis8.getLowerMargin();
        org.jfree.data.Range range26 = numberAxis8.getDefaultAutoRange();
        boolean boolean27 = numberAxis8.isAutoTickUnitSelection();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        org.jfree.data.Range range30 = numberAxis8.getRange();
        boolean boolean31 = numberAxis8.isAxisLineVisible();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot0.getOrientation();
        java.lang.String str24 = plotOrientation23.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.extendHeight((double) ' ');
        double double29 = rectangleInsets25.trimWidth((double) 2.0f);
        double double31 = rectangleInsets25.calculateTopOutset(2.0d);
        boolean boolean32 = plotOrientation23.equals((java.lang.Object) double31);
        java.lang.Object obj33 = null;
        boolean boolean34 = plotOrientation23.equals(obj33);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PlotOrientation.VERTICAL" + "'", str24.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 32.0d + "'", double27 == 32.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot6.getRangeMarkers(10, layer10);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        java.awt.Color color17 = java.awt.Color.black;
        int int18 = color17.getRed();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color17, stroke19);
        xYPlot13.setRangeZeroBaselineStroke(stroke19);
        java.awt.Paint paint22 = xYPlot13.getDomainCrosshairPaint();
        boolean boolean23 = xYPlot13.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener26 = null;
        valueMarker25.addChangeListener(markerChangeListener26);
        java.awt.Paint paint28 = valueMarker25.getOutlinePaint();
        java.lang.Object obj29 = null;
        boolean boolean30 = valueMarker25.equals(obj29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot33.getDomainMarkers(layer34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        xYPlot33.datasetChanged(datasetChangeEvent36);
        java.awt.Stroke stroke38 = xYPlot33.getRangeZeroBaselineStroke();
        valueMarker25.setStroke(stroke38);
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = categoryPlot6.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker25, layer40, true);
        java.awt.Stroke stroke43 = valueMarker25.getStroke();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.setRangeCrosshairValue((double) 0L, false);
        categoryPlot6.configureDomainAxes();
        categoryPlot6.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        int int34 = categoryPlot6.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot6.getRenderer();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer35);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.setRangeCrosshairValue((double) 0L, false);
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        categoryPlot6.setInsets(rectangleInsets17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(unitType18);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot11.setRangeCrosshairValue((double) 'a');
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        java.awt.Font font5 = numberAxis0.getLabelFont();
        boolean boolean6 = numberAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        double double7 = valueMarker2.getValue();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        valueMarker2.setStroke(stroke11);
        numberAxis0.setTickMarkStroke(stroke11);
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Paint paint5 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            xYPlot0.handleClick((int) '#', 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        double double8 = categoryPlot6.getRangeCrosshairValue();
        java.awt.Paint paint9 = categoryPlot6.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) 8);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace31, false);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener39 = null;
        valueMarker38.addChangeListener(markerChangeListener39);
        java.awt.Paint paint41 = valueMarker38.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker38.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker44.setLabelTextAnchor(textAnchor45);
        valueMarker38.setLabelTextAnchor(textAnchor45);
        org.jfree.chart.util.Layer layer48 = null;
        categoryPlot6.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker38, layer48, true);
        java.awt.Stroke stroke51 = valueMarker38.getOutlineStroke();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis2);
        numberAxis2.configure();
        java.awt.Stroke stroke14 = numberAxis2.getAxisLineStroke();
        numberAxis2.setPositiveArrowVisible(true);
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = intervalMarker30.getLabelOffset();
        java.lang.Object obj33 = intervalMarker30.clone();
        double double34 = intervalMarker30.getEndValue();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        org.jfree.chart.plot.Plot plot42 = categoryPlot41.getParent();
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot41, jFreeChart43);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = null;
        categoryPlot41.setFixedLegendItems(legendItemCollection45);
        boolean boolean47 = intervalMarker30.equals((java.lang.Object) categoryPlot41);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 13.0d + "'", double34 == 13.0d);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis2);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        numberAxis15.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = numberAxis15.getMarkerBand();
        org.jfree.data.Range range23 = numberAxis15.getRange();
        org.jfree.data.RangeType rangeType24 = numberAxis15.getRangeType();
        numberAxis2.setRangeType(rangeType24);
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertNull(markerAxisBand22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(rangeType24);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(13);
//        java.lang.Object obj3 = objectList1.get(12);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        long long6 = day4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
//        int int8 = day4.getMonth();
//        boolean boolean9 = objectList1.equals((java.lang.Object) int8);
//        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.util.Layer layer11 = null;
//        java.util.Collection collection12 = xYPlot10.getDomainMarkers(layer11);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot10.getRenderer(255);
//        xYPlot10.configureDomainAxes();
//        xYPlot10.configureDomainAxes();
//        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis18.setLabelURL("");
//        numberAxis18.setLowerBound((double) (short) -1);
//        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis25.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
//        org.jfree.chart.plot.Plot plot30 = categoryPlot29.getParent();
//        org.jfree.chart.JFreeChart jFreeChart31 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot29, jFreeChart31);
//        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot29.getRowRenderingOrder();
//        numberAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
//        double double35 = numberAxis18.getLowerMargin();
//        org.jfree.data.Range range36 = numberAxis18.getDefaultAutoRange();
//        boolean boolean37 = numberAxis18.isAutoTickUnitSelection();
//        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
//        org.jfree.data.Range range40 = numberAxis18.getRange();
//        boolean boolean41 = objectList1.equals((java.lang.Object) range40);
//        org.junit.Assert.assertNull(obj3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNull(collection12);
//        org.junit.Assert.assertNull(xYItemRenderer14);
//        org.junit.Assert.assertNull(plot30);
//        org.junit.Assert.assertNotNull(sortOrder33);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
//        org.junit.Assert.assertNotNull(range36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(range40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Category Plot");
        dateAxis1.setAutoTickUnitSelection(false, false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        boolean boolean19 = xYPlot0.isDomainCrosshairVisible();
        float float20 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
//        java.text.DateFormat dateFormat2 = null;
//        dateAxis1.setDateFormatOverride(dateFormat2);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis1.setTimeZone(timeZone4);
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        long long9 = day7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.next();
//        java.util.Date date11 = regularTimePeriod10.getStart();
//        java.util.Date date12 = regularTimePeriod10.getEnd();
//        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
//        java.text.DateFormat dateFormat14 = null;
//        dateAxis13.setDateFormatOverride(dateFormat14);
//        org.jfree.chart.axis.Timeline timeline16 = dateAxis13.getTimeline();
//        java.util.Date date17 = dateAxis13.getMinimumDate();
//        try {
//            dateAxis6.setRange(date12, date17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeline16);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        valueMarker24.addChangeListener(markerChangeListener25);
        java.awt.Paint paint27 = valueMarker24.getOutlinePaint();
        java.lang.Object obj28 = null;
        boolean boolean29 = valueMarker24.equals(obj28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker24, layer30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot6.setDomainAxis(categoryAxis33);
        org.jfree.chart.plot.Plot plot35 = categoryAxis33.getPlot();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(plot35);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot13.getParent();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot13, jFreeChart15);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot13.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot13.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot13.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot0.getRangeAxisLocation((int) '4');
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener7 = null;
        valueMarker6.addChangeListener(markerChangeListener7);
        java.awt.Paint paint9 = valueMarker6.getOutlinePaint();
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 100, paint9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        numberAxis13.setVisible(true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = numberAxis13.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        numberAxis13.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot27 = numberAxis13.getPlot();
        java.awt.Font font28 = numberAxis13.getLabelFont();
        boolean boolean29 = numberAxis13.isAxisLineVisible();
        numberAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        org.jfree.chart.plot.Plot plot42 = categoryPlot41.getParent();
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot41, jFreeChart43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        numberAxis47.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis47, categoryItemRenderer50);
        numberAxis47.setVisible(true);
        org.jfree.data.Range range54 = categoryPlot41.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis47);
        java.awt.Stroke stroke55 = categoryPlot41.getOutlineStroke();
        numberAxis13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo11, point2D12);
        java.awt.Stroke stroke14 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot6.getRangeMarkers((int) '#', layer21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        numberAxis25.setVisible(true);
        double double32 = numberAxis25.getUpperBound();
        numberAxis25.setUpperMargin((double) 0);
        org.jfree.data.Range range35 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace36, false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.05d + "'", double32 == 1.05d);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color4 = color3.darker();
        java.awt.Color color5 = color3.brighter();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener15 = null;
        valueMarker14.addChangeListener(markerChangeListener15);
        java.awt.Paint paint17 = valueMarker14.getOutlinePaint();
        valueMarker14.setAlpha((float) (short) 1);
        org.jfree.chart.util.Layer layer20 = null;
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14, layer20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot12.getDataset();
        boolean boolean23 = color3.equals((java.lang.Object) categoryPlot12);
        categoryPlot12.mapDatasetToRangeAxis(1, 8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot12.zoomRangeAxes((double) (-16776705), 0.0d, plotRenderingInfo29, point2D30);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 10);
        categoryPlot6.setRangeCrosshairVisible(true);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener22 = null;
        valueMarker21.addChangeListener(markerChangeListener22);
        java.awt.Paint paint24 = valueMarker21.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = valueMarker21.getLabelAnchor();
        double double26 = valueMarker21.getValue();
        java.awt.Color color28 = java.awt.Color.black;
        int int29 = color28.getRed();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color28, stroke30);
        valueMarker21.setStroke(stroke30);
        numberAxis19.setTickMarkStroke(stroke30);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis19.valueToJava2D(43629.0d, rectangle2D35, rectangleEdge36);
        boolean boolean38 = numberAxis19.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis19.getTickLabelInsets();
        boolean boolean40 = numberAxis19.getAutoRangeIncludesZero();
        categoryPlot6.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis19, false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset((int) (byte) -1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        java.lang.String str6 = rectangleAnchor5.toString();
        java.lang.String str7 = rectangleAnchor5.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str6.equals("RectangleAnchor.TOP_LEFT"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str7.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, (float) 'a', 10.0f);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.ChartColor chartColor16 = new org.jfree.chart.ChartColor(4, (int) (short) 10, (int) (short) 1);
        xYPlot0.setQuadrantPaint(3, (java.awt.Paint) chartColor16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextOutlinePaint();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot0.getDomainAxis(2);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(valueAxis22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        double double14 = numberAxis2.getAutoRangeMinimumSize();
        double double15 = numberAxis2.getUpperBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = numberAxis2.getStandardTickUnits();
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.05d + "'", double15 == 1.05d);
        org.junit.Assert.assertNotNull(tickUnitSource16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot6.getDomainAxis();
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double17 = numberAxis0.getLowerMargin();
        org.jfree.data.RangeType rangeType18 = numberAxis0.getRangeType();
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(rangeType18);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        double double31 = intervalMarker30.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot32.getDomainMarkers(layer33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot32.datasetChanged(datasetChangeEvent35);
        boolean boolean37 = intervalMarker30.equals((java.lang.Object) xYPlot32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = xYPlot32.getRenderer();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot32.drawBackgroundImage(graphics2D39, rectangle2D40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = xYPlot32.getOrientation();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(plotOrientation42);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        java.lang.String str10 = categoryPlot6.getPlotType();
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        java.lang.Comparable comparable17 = categoryMarker16.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        java.lang.String str25 = categoryPlot24.getNoDataMessage();
        boolean boolean26 = categoryPlot24.isRangeCrosshairVisible();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent33.setType(chartChangeEventType34);
        org.jfree.chart.plot.Marker marker36 = markerChangeEvent33.getMarker();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = categoryPlot24.removeRangeMarker(0, marker36, layer37);
        boolean boolean40 = categoryPlot6.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker16, layer37, true);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = xYPlot41.getRenderer((-16777216));
        java.awt.Paint paint44 = xYPlot41.getRangeTickBandPaint();
        java.awt.Paint paint45 = xYPlot41.getRangeTickBandPaint();
        categoryMarker16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot41);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100 + "'", comparable17.equals(100));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(marker36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(xYItemRenderer43);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNull(paint45);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.clearRangeMarkers((int) (short) 100);
        java.awt.Image image17 = categoryPlot6.getBackgroundImage();
        categoryPlot6.setAnchorValue(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        org.jfree.chart.plot.Plot plot28 = categoryPlot27.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer34);
        numberAxis31.setVisible(true);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis31.setUpArrow(shape43);
        int int45 = categoryPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = categoryPlot27.getDomainMarkers((int) (short) -1, layer47);
        int int49 = categoryPlot27.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setLabelURL("");
        numberAxis50.setLowerBound((double) (short) -1);
        boolean boolean55 = categoryPlot27.equals((java.lang.Object) numberAxis50);
        categoryPlot27.zoom((double) 0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        int int59 = categoryPlot27.getIndexOf(categoryItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        categoryPlot27.zoomRangeAxes((double) (short) -1, plotRenderingInfo61, point2D62, false);
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot27.getDomainAxisLocation(13);
        try {
            categoryPlot6.setDomainAxisLocation((int) (short) -1, axisLocation66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot0.setRenderer(xYItemRenderer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot18.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot18.getDomainAxisForDataset((int) ' ');
        java.awt.Color color23 = java.awt.Color.red;
        categoryPlot18.setDomainGridlinePaint((java.awt.Paint) color23);
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLabelURL("");
        numberAxis26.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer36);
        org.jfree.chart.plot.Plot plot38 = categoryPlot37.getParent();
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot37, jFreeChart39);
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot37.getRowRenderingOrder();
        numberAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot37);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryPlot37.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 100, 0.0d);
        double double48 = intervalMarker47.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = xYPlot49.getDomainMarkers(layer50);
        java.awt.Color color53 = java.awt.Color.black;
        int int54 = color53.getRed();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color53, stroke55);
        xYPlot49.setRangeZeroBaselineStroke(stroke55);
        java.awt.Paint paint58 = xYPlot49.getDomainCrosshairPaint();
        boolean boolean59 = xYPlot49.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener62 = null;
        valueMarker61.addChangeListener(markerChangeListener62);
        java.awt.Paint paint64 = valueMarker61.getOutlinePaint();
        java.lang.Object obj65 = null;
        boolean boolean66 = valueMarker61.equals(obj65);
        org.jfree.chart.util.Layer layer67 = null;
        boolean boolean68 = xYPlot49.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker61, layer67);
        boolean boolean69 = intervalMarker47.equals((java.lang.Object) valueMarker61);
        intervalMarker47.setStartValue((double) (short) -1);
        boolean boolean72 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        boolean boolean73 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(sortOrder41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0);
        java.awt.Font font22 = valueMarker21.getLabelFont();
        xYPlot0.setNoDataMessageFont(font22);
        java.awt.Paint paint24 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.Timeline timeline3 = dateAxis0.getTimeline();
        java.util.Date date4 = dateAxis0.getMinimumDate();
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(timeline3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot0.getDomainMarkers((int) ' ', layer13);
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        numberAxis20.setVisible(true);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = numberAxis20.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis20.setUpArrow(shape32);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis20, false);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot37.getDomainMarkers(layer38);
        xYPlot37.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        xYPlot37.datasetChanged(datasetChangeEvent42);
        java.awt.Paint paint44 = xYPlot37.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = null;
        xYPlot37.datasetChanged(datasetChangeEvent45);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker49.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer52 = null;
        boolean boolean54 = xYPlot37.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker49, layer52, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        xYPlot37.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo57, point2D58);
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = xYPlot37.getOrientation();
        double double61 = xYPlot37.getDomainCrosshairValue();
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = null;
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        numberAxis66.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset64, categoryAxis65, (org.jfree.chart.axis.ValueAxis) numberAxis66, categoryItemRenderer69);
        java.lang.String str71 = categoryPlot70.getNoDataMessage();
        boolean boolean72 = categoryPlot70.isRangeCrosshairVisible();
        categoryPlot70.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = categoryPlot70.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker78 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent79 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker78);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType80 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent79.setType(chartChangeEventType80);
        org.jfree.chart.plot.Marker marker82 = markerChangeEvent79.getMarker();
        org.jfree.chart.util.Layer layer83 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean84 = categoryPlot70.removeRangeMarker(0, marker82, layer83);
        boolean boolean85 = xYPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer83);
        java.util.Collection collection86 = xYPlot0.getRangeMarkers((int) (byte) 100, layer83);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertNotNull(chartChangeEventType80);
        org.junit.Assert.assertNotNull(marker82);
        org.junit.Assert.assertNotNull(layer83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(collection86);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer9);
        numberAxis6.setAutoTickUnitSelection(false);
        float float13 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVisible(false);
        xYPlot0.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis6, true);
        org.jfree.data.Range range18 = numberAxis6.getRange();
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100, 0.0d);
        double double22 = intervalMarker21.getStartValue();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot23.getDomainMarkers(layer24);
        java.awt.Color color27 = java.awt.Color.black;
        int int28 = color27.getRed();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color27, stroke29);
        xYPlot23.setRangeZeroBaselineStroke(stroke29);
        java.awt.Paint paint32 = xYPlot23.getDomainCrosshairPaint();
        boolean boolean33 = xYPlot23.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener36 = null;
        valueMarker35.addChangeListener(markerChangeListener36);
        java.awt.Paint paint38 = valueMarker35.getOutlinePaint();
        java.lang.Object obj39 = null;
        boolean boolean40 = valueMarker35.equals(obj39);
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = xYPlot23.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker35, layer41);
        boolean boolean43 = intervalMarker21.equals((java.lang.Object) valueMarker35);
        intervalMarker21.setStartValue((double) (short) -1);
        boolean boolean46 = categoryPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        categoryPlot11.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        java.awt.Font font5 = numberAxis0.getLabelFont();
        numberAxis0.setLowerMargin(2.0d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit6, "Category Plot");
        float float9 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        numberAxis23.setVisible(true);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis23.refreshTicks(graphics2D30, axisState31, rectangle2D32, rectangleEdge33);
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis23.setUpArrow(shape35);
        int int37 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot19.getDomainMarkers((int) (short) -1, layer39);
        int int41 = categoryPlot19.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        numberAxis42.setLabelURL("");
        numberAxis42.setLowerBound((double) (short) -1);
        boolean boolean47 = categoryPlot19.equals((java.lang.Object) numberAxis42);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot19.getDomainAxisEdge();
        try {
            double double49 = categoryAxis1.getCategoryEnd(0, 0, rectangle2D12, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        double double5 = numberAxis0.getFixedAutoRange();
        numberAxis0.resizeRange((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Color color3 = java.awt.Color.blue;
        java.awt.Color color10 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass11 = color10.getClass();
        float[] floatArray17 = new float[] { 255, (short) 100, 'a', 100, 'a' };
        float[] floatArray18 = color10.getColorComponents(floatArray17);
        float[] floatArray19 = java.awt.Color.RGBtoHSB((int) (byte) 0, 0, (int) (short) 1, floatArray17);
        float[] floatArray20 = color3.getComponents(floatArray17);
        float[] floatArray21 = java.awt.Color.RGBtoHSB((int) (byte) 1, 2, 9, floatArray17);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        double double9 = numberAxis2.getUpperBound();
        numberAxis2.setUpperMargin((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis2.getTickLabelInsets();
        double double13 = rectangleInsets12.getLeft();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.05d + "'", double9 == 1.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        double double11 = rectangleInsets8.getBottom();
        double double12 = rectangleInsets8.getLeft();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo20, point2D21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font23);
        xYPlot0.setRangeCrosshairVisible(false);
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        numberAxis8.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getParent();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot19.getRowRenderingOrder();
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        double double25 = numberAxis8.getLowerMargin();
        org.jfree.data.Range range26 = numberAxis8.getDefaultAutoRange();
        boolean boolean27 = numberAxis8.isAutoTickUnitSelection();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        boolean boolean30 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        double double32 = numberAxis31.getUpperMargin();
        java.awt.Color color33 = java.awt.Color.BLUE;
        numberAxis31.setLabelPaint((java.awt.Paint) color33);
        int int35 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace36, false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        java.awt.Font font5 = numberAxis0.getLabelFont();
        numberAxis0.resizeRange((double) (byte) 10, 1.0d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        java.lang.String str10 = categoryPlot6.getPlotType();
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        java.lang.Comparable comparable17 = categoryMarker16.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        java.lang.String str25 = categoryPlot24.getNoDataMessage();
        boolean boolean26 = categoryPlot24.isRangeCrosshairVisible();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot24.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent33.setType(chartChangeEventType34);
        org.jfree.chart.plot.Marker marker36 = markerChangeEvent33.getMarker();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = categoryPlot24.removeRangeMarker(0, marker36, layer37);
        boolean boolean40 = categoryPlot6.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker16, layer37, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot6.getRangeAxisEdge(9);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot6.getRangeAxisLocation();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100 + "'", comparable17.equals(100));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(marker36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (byte) 10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot6.getDomainMarkers((int) (short) -1, layer26);
        int int28 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        numberAxis29.setLowerBound((double) (short) -1);
        boolean boolean34 = categoryPlot6.equals((java.lang.Object) numberAxis29);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot6.getDomainAxisEdge();
        java.awt.Color color41 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = xYPlot42.getDomainMarkers(layer43);
        java.awt.Color color46 = java.awt.Color.black;
        int int47 = color46.getRed();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color46, stroke48);
        xYPlot42.setRangeZeroBaselineStroke(stroke48);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot42.setRangeZeroBaselineStroke(stroke51);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener55 = null;
        valueMarker54.addChangeListener(markerChangeListener55);
        java.awt.Paint paint57 = valueMarker54.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer59 = null;
        java.util.Collection collection60 = xYPlot58.getDomainMarkers(layer59);
        xYPlot58.setWeight((int) (short) 100);
        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot58.setRangeCrosshairStroke(stroke63);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color41, stroke51, paint57, stroke63, (float) (short) 1);
        double double67 = intervalMarker66.getStartValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = intervalMarker66.getLabelOffset();
        java.lang.Object obj69 = intervalMarker66.clone();
        org.jfree.chart.util.Layer layer70 = null;
        boolean boolean71 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker66, layer70);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        xYPlot9.setRangeZeroBaselineStroke(stroke15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot9.setDomainAxisLocation(axisLocation26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
        categoryPlot6.setInsets(rectangleInsets28);
        boolean boolean30 = categoryPlot6.isDomainZoomable();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        numberAxis3.setVisible(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis3.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        numberAxis3.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot17 = numberAxis3.getPlot();
        java.awt.Font font18 = numberAxis3.getLabelFont();
        boolean boolean19 = numberAxis3.isAxisLineVisible();
        boolean boolean20 = textAnchor0.equals((java.lang.Object) numberAxis3);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis0.java2DToValue((double) 1.0f, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = xYPlot6.getSeriesRenderingOrder();
        java.awt.Stroke stroke10 = xYPlot6.getRangeCrosshairStroke();
        numberAxis0.setAxisLineStroke(stroke10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        numberAxis12.setLowerBound((double) (short) -1);
        numberAxis12.setInverted(true);
        java.awt.Shape shape19 = numberAxis12.getDownArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis12.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit20, true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        java.lang.Object obj19 = xYPlot0.clone();
        xYPlot0.clearDomainMarkers(2);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getParent();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot7, jFreeChart9);
        boolean boolean11 = seriesRenderingOrder0.equals((java.lang.Object) jFreeChart9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        java.awt.Color color14 = java.awt.Color.yellow;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        valueMarker1.setPaint((java.awt.Paint) color15);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        valueMarker1.setLabelTextAnchor(textAnchor17);
        valueMarker1.setValue((double) 10L);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent3.setChart(jFreeChart5);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot6.getDomainMarkers(layer7);
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        xYPlot6.setRangeZeroBaselineStroke(stroke12);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener19 = null;
        valueMarker18.addChangeListener(markerChangeListener19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot22.getDomainMarkers(layer23);
        xYPlot22.setWeight((int) (short) 100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color5, stroke15, paint21, stroke27, (float) (short) 1);
        int int31 = color5.getBlue();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean7 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot0.handleClick(128, 0, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = valueMarker2.getLabelAnchor();
        double double7 = valueMarker2.getValue();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        valueMarker2.setStroke(stroke11);
        numberAxis0.setTickMarkStroke(stroke11);
        java.text.NumberFormat numberFormat15 = null;
        numberAxis0.setNumberFormatOverride(numberFormat15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.awt.Font font9 = dateAxis6.getTickLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot13.datasetChanged(datasetChangeEvent16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation26, true);
        java.awt.Stroke stroke29 = xYPlot13.getRangeGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot13.getDomainAxisEdge();
        try {
            java.util.List list31 = dateAxis6.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-1.0f));
        org.jfree.chart.util.Layer layer17 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot19.getDomainMarkers(layer20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot19.getRenderer(255);
        xYPlot19.configureDomainAxes();
        xYPlot19.configureDomainAxes();
        xYPlot19.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis29.isHiddenValue((long) 100);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getEnd();
        dateAxis29.setMaximumDate(date33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat37 = null;
        dateAxis36.setDateFormatOverride(dateFormat37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis36.setTimeZone(timeZone39);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!", timeZone39);
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis41.setTickUnit(dateTickUnit42);
        java.util.Date date44 = dateAxis29.calculateHighestVisibleTickValue(dateTickUnit42);
        xYPlot19.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis29, false);
        boolean boolean47 = categoryMarker16.equals((java.lang.Object) 0);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(dateTickUnit42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot0.render(graphics2D6, rectangle2D7, (-246), plotRenderingInfo9, crosshairState10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        numberAxis12.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getParent();
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot23, jFreeChart25);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot23.getRowRenderingOrder();
        numberAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        double double29 = numberAxis12.getLowerMargin();
        numberAxis12.setUpperMargin(1.0d);
        org.jfree.data.Range range32 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer38);
        numberAxis35.setVisible(true);
        boolean boolean42 = numberAxis35.getAutoRangeStickyZero();
        java.awt.Shape shape43 = numberAxis35.getDownArrow();
        double double44 = numberAxis35.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        double double46 = numberAxis45.getUpperMargin();
        org.jfree.data.Range range47 = numberAxis45.getDefaultAutoRange();
        numberAxis35.setRangeWithMargins(range47, false, false);
        numberAxis12.setRangeWithMargins(range47);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0E-8d + "'", double44 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot0.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot17.getParent();
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17, jFreeChart19);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot17.getRowRenderingOrder();
        categoryPlot17.setAnchorValue((double) '4', false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot17.setRangeAxes(valueAxisArray25);
        xYPlot0.setRangeAxes(valueAxisArray25);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(valueAxisArray25);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Color color2 = java.awt.Color.yellow;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearDomainMarkers(0);
        java.awt.Color color9 = java.awt.Color.black;
        int int10 = color9.getRed();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color9, stroke11);
        java.lang.Comparable comparable13 = categoryMarker12.getKey();
        org.jfree.chart.util.Layer layer14 = null;
        xYPlot4.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker12, layer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot4.getDomainMarkers((int) ' ', layer17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot4.setDomainZeroBaselineStroke(stroke19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot21.getDomainMarkers(layer22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        xYPlot21.datasetChanged(datasetChangeEvent24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer31);
        org.jfree.chart.plot.Plot plot33 = categoryPlot32.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getDomainAxisLocation();
        xYPlot21.setDomainAxisLocation(axisLocation34, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot21.zoomDomainAxes(0.0d, plotRenderingInfo38, point2D39);
        java.awt.Paint paint41 = xYPlot21.getNoDataMessagePaint();
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = xYPlot42.getDomainMarkers(layer43);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = null;
        xYPlot42.datasetChanged(datasetChangeEvent45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis49, categoryItemRenderer52);
        org.jfree.chart.plot.Plot plot54 = categoryPlot53.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getDomainAxisLocation();
        xYPlot42.setDomainAxisLocation(axisLocation55, true);
        java.awt.Stroke stroke58 = xYPlot42.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(4.0d, (java.awt.Paint) color2, stroke19, paint41, stroke58, (float) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis11.setMaximumCategoryLabelLines((-16777216));
        categoryAxis11.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit16, "Category Plot");
        float float19 = categoryAxis11.getTickMarkOutsideLength();
        java.awt.Font font20 = categoryAxis11.getTickLabelFont();
        categoryPlot6.setNoDataMessageFont(font20);
        categoryPlot6.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
        try {
            dateAxis6.setRange(13.0d, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        xYPlot0.setDomainZeroBaselineVisible(true);
        int int6 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double17 = numberAxis0.getLowerMargin();
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = unitType1.toString();
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot0.setRenderer(4, xYItemRenderer20);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot1.getDomainMarkers(layer2);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        xYPlot1.setRangeZeroBaselineStroke(stroke7);
        java.awt.Paint paint10 = xYPlot1.getDomainCrosshairPaint();
        boolean boolean11 = xYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.addChangeListener(markerChangeListener14);
        java.awt.Paint paint16 = valueMarker13.getOutlinePaint();
        java.lang.Object obj17 = null;
        boolean boolean18 = valueMarker13.equals(obj17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker13, layer19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot21.getDomainMarkers(layer22);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        xYPlot21.datasetChanged(datasetChangeEvent24);
        java.awt.Stroke stroke26 = xYPlot21.getRangeZeroBaselineStroke();
        valueMarker13.setStroke(stroke26);
        int int28 = day0.compareTo((java.lang.Object) stroke26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day0.next();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener9 = null;
        valueMarker8.addChangeListener(markerChangeListener9);
        java.awt.Paint paint11 = valueMarker8.getOutlinePaint();
        valueMarker8.setAlpha((float) (short) 1);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot6.getDataset();
        double double17 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot6.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("XY Plot", timeZone3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone3);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot11, jFreeChart13);
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot11.getRowRenderingOrder();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot11.getRenderer();
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 10);
        categoryPlot6.setRangeCrosshairVisible(true);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot6.getRangeAxisEdge(128);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = xYPlot17.getSeriesRenderingOrder();
        xYPlot17.mapDatasetToDomainAxis((int) '#', 255);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) xYPlot17);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot0.getDomainGridlinePaint();
        float float5 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            xYPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.Timeline timeline3 = dateAxis0.getTimeline();
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(timeline3);
        org.junit.Assert.assertNotNull(timeline4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation17, false);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener25 = null;
        valueMarker24.addChangeListener(markerChangeListener25);
        java.awt.Paint paint27 = valueMarker24.getOutlinePaint();
        java.lang.Object obj28 = null;
        boolean boolean29 = valueMarker24.equals(obj28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker24, layer30);
        java.awt.Stroke stroke32 = categoryPlot6.getOutlineStroke();
        int int33 = categoryPlot6.getBackgroundImageAlignment();
        boolean boolean34 = categoryPlot6.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace35 = categoryPlot6.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        numberAxis12.setVisible(true);
        org.jfree.data.Range range19 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            categoryPlot6.handleClick(12, 0, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation13, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot0.getRangeMarkers(layer17);
        boolean boolean19 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.util.ObjectList objectList20 = new org.jfree.chart.util.ObjectList();
        java.awt.Color color22 = java.awt.Color.black;
        int int23 = color22.getRed();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color22, stroke24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker25.setPaint(paint26);
        int int28 = objectList20.indexOf((java.lang.Object) paint26);
        xYPlot0.setDomainZeroBaselinePaint(paint26);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent2.getMarker();
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder6, jFreeChart7, chartChangeEventType8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = chartChangeEvent9.getType();
        markerChangeEvent2.setType(chartChangeEventType10);
        org.jfree.chart.plot.Marker marker12 = markerChangeEvent2.getMarker();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNotNull(marker12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.awt.Stroke stroke11 = categoryPlot6.getDomainGridlineStroke();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot0.getDomainGridlineStroke();
        double double9 = xYPlot0.getDomainCrosshairValue();
        java.awt.Shape[] shapeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) shapeArray10, dataset11);
        xYPlot0.datasetChanged(datasetChangeEvent12);
        org.jfree.data.general.Dataset dataset14 = datasetChangeEvent12.getDataset();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNull(dataset14);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.centerRange(0.05d);
        numberAxis0.setAutoTickUnitSelection(true, false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYPlot0.getDrawingSupplier();
        boolean boolean13 = xYPlot0.isRangeCrosshairLockedOnData();
        boolean boolean14 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke15 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
//        java.text.DateFormat dateFormat2 = null;
//        dateAxis1.setDateFormatOverride(dateFormat2);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis1.setTimeZone(timeZone4);
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        dateAxis6.setTickUnit(dateTickUnit7);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
//        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
//        categoryAxis11.removeChangeListener(axisChangeListener12);
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = categoryAxis11.getCategoryLabelPositions();
//        int int15 = categoryAxis11.getMaximumCategoryLabelLines();
//        java.awt.Font font17 = categoryAxis11.getTickLabelFont((java.lang.Comparable) 15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getSerialIndex();
//        java.util.Date date20 = day18.getStart();
//        java.awt.Paint paint21 = categoryAxis11.getTickLabelPaint((java.lang.Comparable) date20);
//        try {
//            dateAxis6.setRange(date9, date20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(dateTickUnit7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(categoryLabelPositions14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(font17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(paint21);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Color color2 = java.awt.Color.getColor("XY Plot", 11);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        numberAxis9.setVisible(true);
        boolean boolean16 = numberAxis9.getAutoRangeStickyZero();
        java.awt.Shape shape17 = numberAxis9.getDownArrow();
        boolean boolean18 = xYPlot0.equals((java.lang.Object) numberAxis9);
        java.awt.Stroke stroke19 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot0.setOrientation(plotOrientation20);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(plotOrientation20);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Paint paint25 = categoryPlot6.getBackgroundPaint();
        categoryPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setDomainAxisLocation(1, axisLocation28, true);
        double double31 = categoryPlot6.getAnchorValue();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = valueMarker33.getLabelOffset();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        categoryPlot6.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot6.setDataset((int) (byte) 1, categoryDataset38);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!", timeZone4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.awt.Font font9 = dateAxis6.getTickLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        dateAxis6.setTickMarkPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        java.lang.Object obj3 = markerChangeEvent2.getSource();
        java.lang.Object obj4 = markerChangeEvent2.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = markerChangeEvent2.getType();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = null;
        dateAxis2.setDateFormatOverride(dateFormat3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("", timeZone5);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.addChangeListener(markerChangeListener2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        double double6 = valueMarker1.getValue();
        java.awt.Color color8 = java.awt.Color.black;
        int int9 = color8.getRed();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color8, stroke10);
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets14.calculateBottomOutset((double) 9);
        valueMarker1.setLabelOffset(rectangleInsets14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = valueMarker1.getLabelOffsetType();
        java.lang.String str22 = lengthAdjustmentType21.toString();
        java.lang.String str23 = lengthAdjustmentType21.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "CONTRACT" + "'", str22.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "CONTRACT" + "'", str23.equals("CONTRACT"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 100);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        dateAxis10.setMaximumDate(date14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat18 = null;
        dateAxis17.setDateFormatOverride(dateFormat18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis17.setTimeZone(timeZone20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!", timeZone20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit23);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        java.util.TimeZone timeZone28 = dateAxis10.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot31.getDomainMarkers(layer32);
        xYPlot31.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        xYPlot31.datasetChanged(datasetChangeEvent36);
        java.awt.Paint paint38 = xYPlot31.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        xYPlot31.datasetChanged(datasetChangeEvent39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot31.getDomainAxisEdge(100);
        try {
            double double43 = dateAxis10.valueToJava2D(0.0d, rectangle2D30, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAutoTickUnitSelection(false);
        float float9 = numberAxis2.getTickMarkInsideLength();
        numberAxis2.setAutoTickUnitSelection(true, false);
        numberAxis2.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRenderer((-16777216));
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, false);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        boolean boolean8 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 0.0f, (double) 13, plotRenderingInfo11, point2D12);
        java.awt.Stroke stroke14 = categoryPlot6.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot6.getRangeMarkers((int) '#', layer21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        numberAxis25.setVisible(true);
        double double32 = numberAxis25.getUpperBound();
        numberAxis25.setUpperMargin((double) 0);
        org.jfree.data.Range range35 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis25);
        java.text.NumberFormat numberFormat36 = numberAxis25.getNumberFormatOverride();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.05d + "'", double32 == 1.05d);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNull(numberFormat36);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker2.addChangeListener(markerChangeListener3);
        java.awt.Paint paint5 = valueMarker2.getOutlinePaint();
        java.awt.Color color6 = java.awt.Color.black;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { paint5, color6 };
        java.awt.Color color9 = java.awt.Color.yellow;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        java.awt.Color color11 = color10.darker();
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color11 };
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] {};
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke14, stroke15, stroke16, stroke17, stroke18, stroke19 };
        java.awt.Stroke[] strokeArray21 = null;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray12, paintArray13, strokeArray20, strokeArray21, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextFillPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer32);
        numberAxis29.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = numberAxis29.getMarkerBand();
        numberAxis29.setAutoRangeStickyZero(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis29);
        numberAxis29.configure();
        java.awt.Stroke stroke41 = numberAxis29.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint26, stroke41);
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d, paint24, stroke41);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(markerAxisBand36);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot1.getDomainMarkers(layer2);
        xYPlot1.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        xYPlot1.datasetChanged(datasetChangeEvent6);
        java.awt.Paint paint8 = xYPlot1.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot1.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker13.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean18 = xYPlot1.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker13, layer16, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot1.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo21, point2D22);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot1.setDataset((int) (short) 100, xYDataset25);
        boolean boolean27 = categoryAnchor0.equals((java.lang.Object) xYPlot1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis10.setMaximumCategoryLabelLines((-16777216));
        categoryAxis10.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit15, "Category Plot");
        numberAxis2.setTickUnit(numberTickUnit15, false, false);
        org.junit.Assert.assertNotNull(numberTickUnit15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        numberAxis0.setInverted(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer18);
        numberAxis15.setVisible(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        java.util.List list26 = numberAxis15.refreshTicks(graphics2D22, axisState23, rectangle2D24, rectangleEdge25);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis15.setUpArrow(shape27);
        int int29 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers((int) (short) -1, layer31);
        int int33 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setLabelURL("");
        numberAxis34.setLowerBound((double) (short) -1);
        boolean boolean39 = categoryPlot11.equals((java.lang.Object) numberAxis34);
        java.awt.Color color43 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color44 = color43.darker();
        java.awt.Color color45 = color43.brighter();
        java.awt.color.ColorSpace colorSpace46 = color45.getColorSpace();
        categoryPlot11.setDomainGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace48);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        numberAxis53.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer56);
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot57.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = xYPlot59.getDomainMarkers(layer60);
        xYPlot59.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent64 = null;
        xYPlot59.datasetChanged(datasetChangeEvent64);
        java.awt.Paint paint66 = xYPlot59.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent67 = null;
        xYPlot59.datasetChanged(datasetChangeEvent67);
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker71.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer74 = null;
        boolean boolean76 = xYPlot59.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker71, layer74, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        java.awt.geom.Point2D point2D80 = null;
        xYPlot59.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo79, point2D80);
        org.jfree.chart.plot.PlotOrientation plotOrientation82 = xYPlot59.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = xYPlot59.getOrientation();
        boolean boolean85 = plotOrientation83.equals((java.lang.Object) 100.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation58, plotOrientation83);
        org.jfree.chart.axis.AxisSpace axisSpace87 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace88 = numberAxis0.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D50, rectangleEdge86, axisSpace87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(colorSpace46);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(plotOrientation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        numberAxis2.setAutoRangeMinimumSize((double) 10L, true);
        numberAxis2.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener9 = null;
        valueMarker8.addChangeListener(markerChangeListener9);
        java.awt.Paint paint11 = valueMarker8.getOutlinePaint();
        valueMarker8.setAlpha((float) (short) 1);
        org.jfree.chart.util.Layer layer14 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer14);
        java.awt.Font font16 = valueMarker8.getLabelFont();
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot0.zoomRangeAxes(3.0d, plotRenderingInfo6, point2D7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener12 = null;
        valueMarker11.addChangeListener(markerChangeListener12);
        java.awt.Paint paint14 = valueMarker11.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = valueMarker11.getLabelAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker17.setLabelTextAnchor(textAnchor18);
        valueMarker11.setLabelTextAnchor(textAnchor18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker11);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot0.addRangeMarker(3, (org.jfree.chart.plot.Marker) valueMarker11, layer22, true);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getDomainAxis();
        java.awt.Shape[] shapeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) shapeArray21, dataset22);
        org.jfree.data.general.Dataset dataset24 = datasetChangeEvent23.getDataset();
        org.jfree.data.general.Dataset dataset25 = datasetChangeEvent23.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent23);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNull(dataset24);
        org.junit.Assert.assertNull(dataset25);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Paint paint1 = null;
        java.awt.Color color3 = java.awt.Color.black;
        int int4 = color3.getRed();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker6.setPaint(paint7);
        java.awt.Stroke stroke9 = categoryMarker6.getStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(43629.0d, paint1, stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        double double11 = rectangleInsets8.getBottom();
        java.lang.String str12 = rectangleInsets8.toString();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str12.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("");
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(true);
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        double double8 = numberAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        java.awt.Color color13 = java.awt.Color.black;
        int int14 = color13.getRed();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
        xYPlot9.setRangeZeroBaselineStroke(stroke15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        xYPlot9.setDomainAxisLocation(axisLocation26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
        categoryPlot6.setInsets(rectangleInsets28);
        double double31 = rectangleInsets28.calculateLeftInset((double) 100);
        double double33 = rectangleInsets28.calculateRightInset((double) 4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot10.getDomainMarkers(layer11);
        xYPlot10.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        xYPlot10.datasetChanged(datasetChangeEvent15);
        java.awt.Paint paint17 = xYPlot10.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot10.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker22.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean27 = xYPlot10.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker22, layer25, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot10.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo30, point2D31);
        numberAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot10.zoomRangeAxes(0.0d, plotRenderingInfo35, point2D36);
        java.awt.Stroke stroke38 = xYPlot10.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke38);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.util.Date date7 = day5.getStart();
//        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) day5);
//        categoryAxis1.configure();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(font8);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        java.awt.Stroke stroke3 = dateAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        boolean boolean12 = categoryMarker8.getDrawAsLine();
        java.lang.String str13 = categoryMarker8.getLabel();
        categoryMarker8.setDrawAsLine(true);
        java.lang.Object obj16 = categoryMarker8.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        java.awt.Color color10 = java.awt.Color.getHSBColor(0.0f, (float) 'a', 10.0f);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color10);
        double double12 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup9 = categoryPlot6.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot16.getParent();
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot16, jFreeChart18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot16.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot16.getFixedLegendItems();
        java.awt.Stroke stroke22 = categoryPlot16.getOutlineStroke();
        categoryPlot16.setAnchorValue((double) (byte) 1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot16.setDatasetRenderingOrder(datasetRenderingOrder25);
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder25);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        categoryAxis1.removeChangeListener(axisChangeListener2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.setFixedDimension(0.0d);
        categoryAxis1.setUpperMargin((double) 2.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis2.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
//        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
//        categoryPlot6.clearAnnotations();
//        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.util.Layer layer10 = null;
//        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
//        java.awt.Color color13 = java.awt.Color.black;
//        int int14 = color13.getRed();
//        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color13, stroke15);
//        xYPlot9.setRangeZeroBaselineStroke(stroke15);
//        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis20.setLabelURL("");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer23);
//        org.jfree.chart.plot.Plot plot25 = categoryPlot24.getParent();
//        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
//        xYPlot9.setDomainAxisLocation(axisLocation26);
//        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot9.getAxisOffset();
//        categoryPlot6.setInsets(rectangleInsets28);
//        categoryPlot6.clearDomainAxes();
//        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        categoryPlot6.setDomainGridlineStroke(stroke31);
//        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis34.setMaximumCategoryLabelLines((-16777216));
//        int int37 = categoryAxis34.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getSerialIndex();
//        java.util.Date date40 = day38.getStart();
//        java.awt.Font font41 = categoryAxis34.getTickLabelFont((java.lang.Comparable) day38);
//        java.util.List list42 = categoryPlot6.getCategoriesForAxis(categoryAxis34);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
//        categoryPlot6.rendererChanged(rendererChangeEvent43);
//        org.junit.Assert.assertNotNull(axisLocation7);
//        org.junit.Assert.assertNull(collection11);
//        org.junit.Assert.assertNotNull(color13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertNull(plot25);
//        org.junit.Assert.assertNotNull(axisLocation26);
//        org.junit.Assert.assertNotNull(rectangleInsets28);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-16777216) + "'", int37 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43629L + "'", long39 == 43629L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(font41);
//        org.junit.Assert.assertNotNull(list42);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.setDomainGridlinesVisible(false);
        java.awt.Image image8 = xYPlot0.getBackgroundImage();
        xYPlot0.mapDatasetToDomainAxis(10, 11);
        boolean boolean12 = xYPlot0.isSubplot();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        java.awt.Color color5 = java.awt.Color.black;
        int int6 = color5.getRed();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color5, stroke7);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        org.jfree.chart.util.Layer layer10 = null;
        xYPlot0.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot0.getDomainMarkers((int) ' ', layer13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 10);
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray16);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRed();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color20, stroke22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryMarker23.setPaint(paint24);
        java.awt.Stroke stroke26 = categoryMarker23.getStroke();
        org.jfree.chart.util.Layer layer27 = null;
        try {
            categoryPlot6.addDomainMarker(2, categoryMarker23, layer27, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis2.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis2.setLowerMargin(0.0d);
        org.jfree.chart.plot.Plot plot16 = numberAxis2.getPlot();
        java.awt.Stroke stroke17 = numberAxis2.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        org.jfree.chart.plot.Plot plot28 = categoryPlot27.getParent();
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot27, jFreeChart29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot27.getRowRenderingOrder();
        categoryPlot27.setAnchorValue((double) '4', false);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        categoryPlot27.drawBackgroundImage(graphics2D35, rectangle2D36);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = categoryPlot27.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation38);
        try {
            double double40 = numberAxis2.lengthToJava2D((double) 1, rectangle2D19, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        xYPlot0.addChangeListener(plotChangeListener3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLabelURL("");
        numberAxis5.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot16.getParent();
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot16, jFreeChart18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot16.getRowRenderingOrder();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis5.getTickLabelInsets();
        boolean boolean23 = xYPlot0.equals((java.lang.Object) rectangleInsets22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace24, false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer8);
        xYPlot0.setDomainCrosshairValue(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        numberAxis14.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis14.getMarkerBand();
        numberAxis14.setRange((double) (short) 100, (double) 43629L);
        int int25 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        xYPlot0.setDomainCrosshairValue((double) 2);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis10.setUpArrow(shape22);
        int int24 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = categoryPlot6.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
        categoryAxis27.removeChangeListener(axisChangeListener28);
        boolean boolean30 = categoryPlot6.equals((java.lang.Object) axisChangeListener28);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetGroup datasetGroup32 = categoryPlot6.getDatasetGroup();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNull(datasetGroup32);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getParent();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot7, jFreeChart9);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        chartChangeEvent10.setChart(jFreeChart11);
        boolean boolean13 = color0.equals((java.lang.Object) chartChangeEvent10);
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color0.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paintContext19);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(0);
        java.awt.Stroke stroke12 = xYPlot0.getRangeZeroBaselineStroke();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        xYPlot0.setDomainGridlinesVisible(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace19);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 0);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot15.getDatasetGroup();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot20.getRenderer((-16777216));
        java.awt.Paint paint23 = xYPlot20.getRangeTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot20.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace26 = categoryAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot15, rectangle2D19, rectangleEdge24, axisSpace25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        double double8 = categoryPlot6.getRangeCrosshairValue();
        java.awt.Color color10 = java.awt.Color.black;
        int int11 = color10.getRed();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color10, stroke12);
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot13.getParent();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot13, jFreeChart15);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot13.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot13.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot13.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot24.getDomainMarkers(layer25);
        java.awt.Color color28 = java.awt.Color.black;
        int int29 = color28.getRed();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color28, stroke30);
        xYPlot24.setRangeZeroBaselineStroke(stroke30);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot24.setRangeZeroBaselineStroke(stroke33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        numberAxis37.setAutoTickUnitSelection(false);
        float float44 = numberAxis37.getTickMarkInsideLength();
        numberAxis37.setVisible(false);
        float float47 = numberAxis37.getTickMarkOutsideLength();
        org.jfree.data.Range range48 = xYPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        xYPlot0.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis37, true);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertNull(range48);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 100);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        dateAxis10.setMaximumDate(date14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat18 = null;
        dateAxis17.setDateFormatOverride(dateFormat18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis17.setTimeZone(timeZone20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!", timeZone20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit23);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone28);
        dateAxis10.setTimeZone(timeZone28);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(tickUnitSource29);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot6.getDomainAxisLocation();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot6.getRangeMarkers(10, layer10);
        java.util.List list12 = categoryPlot6.getAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot20.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot20.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer28);
        org.jfree.chart.plot.Plot plot30 = categoryPlot29.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot29.getDomainAxisLocation();
        categoryPlot20.setRangeAxisLocation(axisLocation31, false);
        categoryPlot6.setDomainAxisLocation(4, axisLocation31, true);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getRowRenderingOrder();
        int int13 = categoryPlot6.getDatasetCount();
        categoryPlot6.setRangeCrosshairValue((double) 6, false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup9 = categoryPlot6.getDatasetGroup();
        java.awt.Paint paint10 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets11.getRight();
        double double14 = rectangleInsets11.calculateRightOutset((double) 10.0f);
        double double16 = rectangleInsets11.trimHeight((double) 43629L);
        double double17 = rectangleInsets11.getBottom();
        double double19 = rectangleInsets11.calculateTopInset((double) 8);
        double double21 = rectangleInsets11.calculateRightInset((double) 0.0f);
        categoryPlot6.setInsets(rectangleInsets11);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 43629.0d + "'", double16 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(0, layer9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.addChangeListener(markerChangeListener14);
        java.awt.Paint paint16 = valueMarker13.getOutlinePaint();
        valueMarker13.setLabel("hi!");
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = xYPlot0.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker13, layer19, true);
        xYPlot0.setDomainZeroBaselineVisible(false);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis0.isHiddenValue(1L);
        java.util.TimeZone timeZone3 = dateAxis0.getTimeZone();
        dateAxis0.setAutoTickUnitSelection(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8, false);
        categoryPlot6.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 10);
        categoryPlot6.setRangeCrosshairVisible(true);
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis20.setMaximumCategoryLabelLines((-16777216));
        categoryAxis20.setUpperMargin((double) 10.0f);
        java.util.List list25 = categoryPlot6.getCategoriesForAxis(categoryAxis20);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint8 = xYPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke9 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot6.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(sortOrder12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        xYPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot0.render(graphics2D6, rectangle2D7, (-246), plotRenderingInfo9, crosshairState10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        numberAxis12.setLowerBound((double) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getParent();
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot23, jFreeChart25);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot23.getRowRenderingOrder();
        numberAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        double double29 = numberAxis12.getLowerMargin();
        numberAxis12.setUpperMargin(1.0d);
        org.jfree.data.Range range32 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.geom.Point2D point2D35 = null;
        org.jfree.chart.plot.PlotState plotState36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            xYPlot0.draw(graphics2D33, rectangle2D34, point2D35, plotState36, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot1.getSeriesRenderingOrder();
        java.awt.Stroke stroke5 = xYPlot1.getRangeCrosshairStroke();
        java.awt.Stroke stroke6 = xYPlot1.getRangeZeroBaselineStroke();
        boolean boolean7 = seriesRenderingOrder0.equals((java.lang.Object) xYPlot1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        xYPlot1.axisChanged(axisChangeEvent8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker22.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer25 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer25, true);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace28, true);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
//        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
//        double double5 = rectangleInsets2.calculateTopInset((double) 43629L);
//        int int6 = day0.compareTo((java.lang.Object) 43629L);
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertNotNull(unitType3);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.awt.Color color4 = color3.darker();
        java.awt.Color color5 = color3.brighter();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener15 = null;
        valueMarker14.addChangeListener(markerChangeListener15);
        java.awt.Paint paint17 = valueMarker14.getOutlinePaint();
        valueMarker14.setAlpha((float) (short) 1);
        org.jfree.chart.util.Layer layer20 = null;
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14, layer20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot12.getDataset();
        boolean boolean23 = color3.equals((java.lang.Object) categoryPlot12);
        float float24 = categoryPlot12.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer30);
        org.jfree.chart.plot.Plot plot32 = categoryPlot31.getParent();
        java.awt.Color color34 = java.awt.Color.black;
        int int35 = color34.getRed();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color34, stroke36);
        java.lang.Comparable comparable38 = categoryMarker37.getKey();
        categoryPlot31.addDomainMarker(categoryMarker37);
        java.awt.Color color43 = java.awt.Color.getHSBColor((float) 100L, (float) 'a', 0.0f);
        java.lang.Class<?> wildcardClass44 = color43.getClass();
        float[] floatArray50 = new float[] { 255, (short) 100, 'a', 100, 'a' };
        float[] floatArray51 = color43.getColorComponents(floatArray50);
        categoryPlot31.setDomainGridlinePaint((java.awt.Paint) color43);
        categoryPlot12.setDomainGridlinePaint((java.awt.Paint) color43);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + comparable38 + "' != '" + 100 + "'", comparable38.equals(100));
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(0, layer9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener14 = null;
        valueMarker13.addChangeListener(markerChangeListener14);
        java.awt.Paint paint16 = valueMarker13.getOutlinePaint();
        valueMarker13.setLabel("hi!");
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = xYPlot0.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker13, layer19, true);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer27);
        numberAxis24.setVisible(true);
        boolean boolean31 = numberAxis24.getAutoRangeStickyZero();
        java.awt.Shape shape32 = numberAxis24.getDownArrow();
        org.jfree.data.Range range33 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis24);
        boolean boolean34 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setLabelToolTip("UnitType.ABSOLUTE");
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer8);
        xYPlot0.setDomainCrosshairValue(0.0d);
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot0.getDataset((int) '#');
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot14.getDomainMarkers(layer15);
        xYPlot14.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot14.datasetChanged(datasetChangeEvent19);
        java.awt.Paint paint21 = xYPlot14.getDomainCrosshairPaint();
        java.awt.Stroke stroke22 = xYPlot14.getDomainGridlineStroke();
        double double23 = xYPlot14.getDomainCrosshairValue();
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) shapeArray24, dataset25);
        xYPlot14.datasetChanged(datasetChangeEvent26);
        xYPlot0.datasetChanged(datasetChangeEvent26);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(shapeArray24);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        xYPlot0.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Paint paint7 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker12.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker12, layer15, false);
        valueMarker12.setValue((double) 1.0f);
        valueMarker12.setLabel("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        double double21 = rectangleInsets19.calculateLeftInset((double) '#');
        double double23 = rectangleInsets19.extendWidth((double) (-1.0f));
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 7.0d + "'", double23 == 7.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = numberAxis2.getMarkerBand();
        numberAxis2.setRange((double) (short) 100, (double) 43629L);
        numberAxis2.setTickMarksVisible(false);
        boolean boolean15 = numberAxis2.isTickMarksVisible();
        org.junit.Assert.assertNull(markerAxisBand9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Color color0 = java.awt.Color.magenta;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.util.Date date7 = day5.getStart();
//        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) day5);
//        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis10.setMaximumCategoryLabelLines((-16777216));
//        categoryAxis10.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
//        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit15, "Category Plot");
//        float float18 = categoryAxis10.getTickMarkOutsideLength();
//        java.awt.Font font19 = categoryAxis10.getTickLabelFont();
//        categoryAxis1.setTickLabelFont(font19);
//        categoryAxis1.setAxisLineVisible(true);
//        double double23 = categoryAxis1.getCategoryMargin();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(font8);
//        org.junit.Assert.assertNotNull(numberTickUnit15);
//        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
//        org.junit.Assert.assertNotNull(font19);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(255);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis10.isHiddenValue((long) 100);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        dateAxis10.setMaximumDate(date14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat18 = null;
        dateAxis17.setDateFormatOverride(dateFormat18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis17.setTimeZone(timeZone20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!", timeZone20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit23);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        boolean boolean29 = dateAxis10.isHiddenValue((long) (-1));
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker12.addChangeListener(markerChangeListener13);
        java.awt.Paint paint15 = valueMarker12.getOutlinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = valueMarker12.equals(obj16);
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker12, layer18);
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot0.getRangeAxisEdge(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot24.getDomainMarkers(layer25);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot24.datasetChanged(datasetChangeEvent27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer34);
        org.jfree.chart.plot.Plot plot36 = categoryPlot35.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        xYPlot24.setDomainAxisLocation(axisLocation37, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot24.zoomDomainAxes(0.0d, plotRenderingInfo41, point2D42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        boolean boolean45 = xYPlot24.equals((java.lang.Object) color44);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color44);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.util.Date date7 = day5.getStart();
//        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) day5);
//        int int9 = day5.getDayOfMonth();
//        boolean boolean11 = day5.equals((java.lang.Object) 43629.0d);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day5.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16777216) + "'", int4 == (-16777216));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(font8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer13);
        numberAxis10.setVisible(true);
        boolean boolean17 = numberAxis10.getAutoRangeStickyZero();
        java.awt.Shape shape18 = numberAxis10.getDownArrow();
        org.jfree.data.Range range19 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis10.getLabelInsets();
        categoryPlot6.setInsets(rectangleInsets20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot6.getRowRenderingOrder();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(sortOrder22);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot16.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot16.getFixedLegendItems();
        java.lang.String str20 = categoryPlot16.getPlotType();
        java.awt.Color color23 = java.awt.Color.black;
        int int24 = color23.getRed();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color23, stroke25);
        java.lang.Comparable comparable27 = categoryMarker26.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer33);
        java.lang.String str35 = categoryPlot34.getNoDataMessage();
        boolean boolean36 = categoryPlot34.isRangeCrosshairVisible();
        categoryPlot34.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        markerChangeEvent43.setType(chartChangeEventType44);
        org.jfree.chart.plot.Marker marker46 = markerChangeEvent43.getMarker();
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = categoryPlot34.removeRangeMarker(0, marker46, layer47);
        boolean boolean50 = categoryPlot16.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker26, layer47, true);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26);
        categoryMarker26.setLabel("hi!");
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Category Plot" + "'", str20.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertNotNull(marker46);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        numberAxis2.setVisible(true);
        boolean boolean9 = numberAxis2.getAutoRangeStickyZero();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot10.getDomainMarkers(layer11);
        xYPlot10.setWeight((int) (short) 100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        xYPlot10.datasetChanged(datasetChangeEvent15);
        java.awt.Paint paint17 = xYPlot10.getDomainCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot10.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker22.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean27 = xYPlot10.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker22, layer25, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot10.zoomDomainAxes(32.0d, (double) 0, plotRenderingInfo30, point2D31);
        numberAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.clearDomainMarkers(0);
        java.awt.Color color39 = java.awt.Color.black;
        int int40 = color39.getRed();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color39, stroke41);
        java.lang.Comparable comparable43 = categoryMarker42.getKey();
        org.jfree.chart.util.Layer layer44 = null;
        xYPlot34.addRangeMarker(1, (org.jfree.chart.plot.Marker) categoryMarker42, layer44);
        boolean boolean46 = categoryMarker42.getDrawAsLine();
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker42);
        boolean boolean48 = categoryMarker42.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100 + "'", comparable43.equals(100));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(0, (int) (byte) 1, 255);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) chartColor6);
        java.awt.color.ColorSpace colorSpace8 = chartColor6.getColorSpace();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(colorSpace8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getAxisOffset();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot9.getDomainMarkers(layer10);
        xYPlot9.setWeight((int) (short) 100);
        boolean boolean14 = xYPlot9.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = xYPlot9.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        xYPlot9.setDomainCrosshairValue(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer26);
        numberAxis23.setVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = numberAxis23.getMarkerBand();
        numberAxis23.setRange((double) (short) 100, (double) 43629L);
        int int34 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis23);
        double double35 = numberAxis23.getFixedAutoRange();
        numberAxis23.setTickMarkInsideLength((float) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets38.getRight();
        double double41 = rectangleInsets38.calculateRightOutset((double) 10.0f);
        double double43 = rectangleInsets38.trimHeight((double) 43629L);
        double double44 = rectangleInsets38.getBottom();
        double double46 = rectangleInsets38.calculateRightInset((double) (short) 10);
        double double47 = rectangleInsets38.getTop();
        numberAxis23.setTickLabelInsets(rectangleInsets38);
        categoryPlot6.setInsets(rectangleInsets38, false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(markerAxisBand30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 43629.0d + "'", double43 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot6.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot6.getDataset(13);
        java.lang.Class<?> wildcardClass11 = categoryPlot6.getClass();
        java.lang.String str12 = categoryPlot6.getPlotType();
        categoryPlot6.setRangeCrosshairValue((double) 0L, false);
        float float16 = categoryPlot6.getForegroundAlpha();
        boolean boolean17 = categoryPlot6.isRangeCrosshairLockedOnData();
        boolean boolean18 = categoryPlot6.isDomainGridlinesVisible();
        double double19 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getDomainAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation17);
        java.lang.Object obj19 = xYPlot0.clone();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str21 = chartChangeEventType20.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets22.getRight();
        double double25 = rectangleInsets22.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets22.trimHeight((double) 43629L);
        double double28 = rectangleInsets22.getBottom();
        boolean boolean29 = chartChangeEventType20.equals((java.lang.Object) rectangleInsets22);
        xYPlot0.setAxisOffset(rectangleInsets22);
        java.awt.Color color31 = java.awt.Color.yellow;
        java.awt.Color color32 = color31.darker();
        xYPlot0.setOutlinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str21.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 43629.0d + "'", double27 == 43629.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder3 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.mapDatasetToDomainAxis((int) '#', 255);
        java.awt.Color color12 = java.awt.Color.getHSBColor(2.0f, (float) (short) 1, (float) 100);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot13.getDomainMarkers(layer14);
        java.awt.Color color17 = java.awt.Color.black;
        int int18 = color17.getRed();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color17, stroke19);
        xYPlot13.setRangeZeroBaselineStroke(stroke19);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setRangeZeroBaselineStroke(stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener26 = null;
        valueMarker25.addChangeListener(markerChangeListener26);
        java.awt.Paint paint28 = valueMarker25.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = xYPlot29.getDomainMarkers(layer30);
        xYPlot29.setWeight((int) (short) 100);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot29.setRangeCrosshairStroke(stroke34);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, (double) 13, (java.awt.Paint) color12, stroke22, paint28, stroke34, (float) (short) 1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(seriesRenderingOrder3);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(axisSpace39);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = xYPlot0.getDomainMarkers(layer1);
        java.awt.Color color4 = java.awt.Color.black;
        int int5 = color4.getRed();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color4, stroke6);
        xYPlot0.setRangeZeroBaselineStroke(stroke6);
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        xYPlot0.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.plot.Plot plot13 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(plot13);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelLines((-16777216));
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 32.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit6, "Category Plot");
        float float9 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Font font10 = categoryAxis1.getTickLabelFont();
        categoryAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setLabelURL("");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot18.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot18.getDataset(13);
        java.lang.Class<?> wildcardClass23 = categoryPlot18.getClass();
        boolean boolean24 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot18);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot25.getDomainMarkers(layer26);
        java.awt.Color color29 = java.awt.Color.black;
        int int30 = color29.getRed();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color29, stroke31);
        xYPlot25.setRangeZeroBaselineStroke(stroke31);
        java.awt.Paint paint34 = xYPlot25.getDomainCrosshairPaint();
        boolean boolean35 = xYPlot25.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener38 = null;
        valueMarker37.addChangeListener(markerChangeListener38);
        java.awt.Paint paint40 = valueMarker37.getOutlinePaint();
        java.lang.Object obj41 = null;
        boolean boolean42 = valueMarker37.equals(obj41);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = xYPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37, layer43);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker47.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer50 = null;
        xYPlot25.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker47, layer50, true);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        xYPlot25.drawAnnotations(graphics2D53, rectangle2D54, plotRenderingInfo55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        xYPlot25.zoomDomainAxes((double) (byte) -1, plotRenderingInfo58, point2D59, false);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.Layer layer63 = null;
        java.util.Collection collection64 = xYPlot62.getDomainMarkers(layer63);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent65 = null;
        xYPlot62.datasetChanged(datasetChangeEvent65);
        xYPlot62.setDomainZeroBaselineVisible(true);
        java.awt.Paint paint69 = xYPlot62.getDomainCrosshairPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection70 = xYPlot62.getLegendItems();
        xYPlot25.setFixedLegendItems(legendItemCollection70);
        categoryPlot18.setFixedLegendItems(legendItemCollection70);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(legendItemCollection70);
    }
}

