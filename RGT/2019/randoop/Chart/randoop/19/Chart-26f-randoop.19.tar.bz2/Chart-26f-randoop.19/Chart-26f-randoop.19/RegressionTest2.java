import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        double double2 = categoryAxis3D1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        int int9 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font13 = categoryAxis11.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28, textAnchor29, (double) 0L);
        stackedBarRenderer3D23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot33.getDomainAxis(0);
        java.awt.Paint paint36 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double39 = dateAxis38.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = stackedBarRenderer3D41.getPositiveItemLabelPositionFallback();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D41.setBaseOutlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = stackedBarRenderer3D41.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double51 = dateAxis50.getUpperMargin();
        java.awt.Paint paint52 = dateAxis50.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        stackedBarRenderer3D41.drawRangeGridline(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D53, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean58 = dateAxis57.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date62 = dateAxis57.calculateLowestVisibleTickValue(dateTickUnit61);
        dateAxis50.setTickUnit(dateTickUnit61);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke65 = polarPlot64.getRadiusGridlineStroke();
        dateAxis50.setTickMarkStroke(stroke65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { dateAxis38, dateAxis50 };
        categoryPlot33.setRangeAxes(valueAxisArray67);
        xYPlot0.setDomainAxes(valueAxisArray67);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot0.getRangeAxisLocation((-457));
        xYPlot0.setBackgroundAlpha((float) (-459));
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(axisLocation71);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        xYPlot0.setDataset(xYDataset1);
        int int3 = xYPlot0.getSeriesCount();
        xYPlot0.clearRangeMarkers((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        java.awt.Paint paint31 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer33 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        minMaxCategoryRenderer33.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition35, true);
        java.awt.Stroke stroke39 = minMaxCategoryRenderer33.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer33.setItemLabelAnchorOffset((double) 0);
        boolean boolean42 = minMaxCategoryRenderer33.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke44 = minMaxCategoryRenderer33.getSeriesOutlineStroke((int) (short) 0);
        categoryPlot28.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) minMaxCategoryRenderer33, false);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer47 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions50 = categoryAxis49.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot51 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis49.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot51);
        boolean boolean53 = stackedBarRenderer47.equals((java.lang.Object) multiplePiePlot51);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = stackedBarRenderer47.getSeriesNegativeItemLabelPosition((int) '#');
        int int56 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer47);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(stroke44);
        org.junit.Assert.assertNotNull(categoryLabelPositions50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) (short) 0);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        ringPlot11.setLabelLinkPaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = ringPlot11.getSectionPaint((java.lang.Comparable) (-1L));
        double double18 = ringPlot11.getShadowYOffset();
        java.awt.Paint paint19 = ringPlot11.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = ringPlot11.getURLGenerator();
        org.jfree.chart.util.Rotation rotation21 = ringPlot11.getDirection();
        ringPlot0.setDirection(rotation21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(pieURLGenerator20);
        org.junit.Assert.assertNotNull(rotation21);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        int int3 = defaultKeyedValues0.getIndex((java.lang.Comparable) 0.05d);
        defaultKeyedValues0.setValue((java.lang.Comparable) ' ', (java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        boolean boolean11 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtTop();
        java.util.List list17 = axisCollection15.getAxesAtTop();
        xYPlot0.drawDomainTickBands(graphics2D13, rectangle2D14, list17);
        org.jfree.chart.plot.Plot plot19 = xYPlot0.getParent();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        minMaxCategoryRenderer5.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition7, true);
        org.jfree.chart.util.BooleanList booleanList10 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) (short) 0);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        ringPlot11.setLabelLinkPaint((java.awt.Paint) color14);
        boolean boolean16 = booleanList10.equals((java.lang.Object) color14);
        minMaxCategoryRenderer5.setBaseItemLabelPaint((java.awt.Paint) color14);
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color14);
        java.awt.Font font19 = polarPlot3.getAngleLabelFont();
        textTitle0.setFont(font19);
        textTitle0.setHeight(0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle0.getTextAlignment();
        textTitle0.setURLText("{0}");
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        categoryPlot28.clearDomainMarkers();
        categoryPlot28.clearRangeAxes();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition2);
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        boolean boolean8 = rectangleInsets6.equals((java.lang.Object) 100.0d);
        dateAxis1.setLabelInsets(rectangleInsets6);
        org.jfree.data.Range range10 = dateAxis1.getDefaultAutoRange();
        org.jfree.data.Range range11 = dateAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = xYPlot0.getRangeMarkers(layer5);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.util.Size2D size2D1 = new org.jfree.chart.util.Size2D();
        double double2 = size2D1.getHeight();
        boolean boolean3 = color0.equals((java.lang.Object) double2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        int int9 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font13 = categoryAxis11.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28, textAnchor29, (double) 0L);
        stackedBarRenderer3D23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot33.getDomainAxis(0);
        java.awt.Paint paint36 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double39 = dateAxis38.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = stackedBarRenderer3D41.getPositiveItemLabelPositionFallback();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D41.setBaseOutlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = stackedBarRenderer3D41.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double51 = dateAxis50.getUpperMargin();
        java.awt.Paint paint52 = dateAxis50.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        stackedBarRenderer3D41.drawRangeGridline(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D53, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean58 = dateAxis57.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date62 = dateAxis57.calculateLowestVisibleTickValue(dateTickUnit61);
        dateAxis50.setTickUnit(dateTickUnit61);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke65 = polarPlot64.getRadiusGridlineStroke();
        dateAxis50.setTickMarkStroke(stroke65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { dateAxis38, dateAxis50 };
        categoryPlot33.setRangeAxes(valueAxisArray67);
        xYPlot0.setDomainAxes(valueAxisArray67);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot0.getRangeAxisLocation((-457));
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean75 = dateAxis74.isTickLabelsVisible();
        dateAxis74.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis74.setLabelFont(font78);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent80 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis74);
        dateAxis74.setLabelAngle((double) 2);
        xYPlot0.setDomainAxis(8, (org.jfree.chart.axis.ValueAxis) dateAxis74);
        java.awt.Color color84 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color84);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(color84);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        ringPlot0.setDrawingSupplier(drawingSupplier3);
        ringPlot0.setIgnoreZeroValues(true);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtTop();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat4 = numberAxis3D3.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L));
        numberAxis3D3.setTickUnit(numberTickUnit6, true, false);
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(list2, (java.lang.Comparable) numberTickUnit6, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (Infinity) <= upper (-Infinity).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        legendItem14.setSeriesKey((java.lang.Comparable) 128);
        java.awt.Paint paint17 = legendItem14.getLinePaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection18 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection18, 4);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection18);
        int int22 = taskSeriesCollection18.getRowCount();
        legendItem14.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection18);
        java.awt.Paint paint24 = legendItem14.getLinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.Plot plot9 = ringPlot0.getRootPlot();
        ringPlot0.setSectionOutlinesVisible(false);
        java.lang.Object obj12 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        ringPlot2.removeChangeListener(plotChangeListener3);
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(paint5);
        ringPlot2.setShadowPaint(paint5);
        java.awt.Color color8 = java.awt.Color.YELLOW;
        ringPlot2.setOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = textBlock1.equals((java.lang.Object) color8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape18 = textBlock1.calculateBounds(graphics2D11, (float) (short) 1, 0.0f, textBlockAnchor14, (float) (short) 100, (float) 3600000L, 1.0E-5d);
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        boolean boolean11 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtTop();
        java.util.List list17 = axisCollection15.getAxesAtTop();
        xYPlot0.drawDomainTickBands(graphics2D13, rectangle2D14, list17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedBarRenderer3D23.getPositiveItemLabelPositionFallback();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D23.setBaseOutlinePaint((java.awt.Paint) color25);
        stackedBarRenderer3D23.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection30 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection30, 4);
        int int33 = taskSeriesCollection30.getSeriesCount();
        int int34 = taskSeriesCollection30.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double37 = categoryAxis36.getUpperMargin();
        java.awt.Font font38 = categoryAxis36.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean41 = dateAxis40.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition42 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis40.setTickMarkPosition(dateTickMarkPosition42);
        dateAxis40.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = dateAxis40.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean50 = stackedBarRenderer3D48.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor52 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor53 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor54 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor52, textAnchor53, textAnchor54, (double) 0L);
        stackedBarRenderer3D48.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition56);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection30, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D48);
        java.awt.Paint paint59 = categoryPlot58.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean62 = dateAxis61.isTickLabelsVisible();
        dateAxis61.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Marker marker65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        stackedBarRenderer3D23.drawRangeMarker(graphics2D29, categoryPlot58, (org.jfree.chart.axis.ValueAxis) dateAxis61, marker65, rectangle2D66);
        org.jfree.chart.plot.RingPlot ringPlot68 = new org.jfree.chart.plot.RingPlot();
        boolean boolean70 = ringPlot68.equals((java.lang.Object) (short) 0);
        java.awt.Color color71 = java.awt.Color.YELLOW;
        ringPlot68.setLabelLinkPaint((java.awt.Paint) color71);
        java.lang.Object obj73 = null;
        boolean boolean74 = ringPlot68.equals(obj73);
        ringPlot68.setBackgroundAlpha((float) (short) 100);
        float float77 = ringPlot68.getBackgroundImageAlpha();
        dateAxis61.setPlot((org.jfree.chart.plot.Plot) ringPlot68);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis61);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(pieDataset32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition42);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor52);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.5f + "'", float77 == 0.5f);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        dateAxis1.setLabelURL("SortOrder.DESCENDING");
        java.lang.Object obj9 = dateAxis1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle4.getSources();
        java.lang.Object obj27 = legendTitle4.clone();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot28.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot28.getAxisOffset();
        legendTitle4.setItemLabelPadding(rectangleInsets30);
        java.lang.Object obj32 = legendTitle4.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition2);
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        boolean boolean8 = rectangleInsets6.equals((java.lang.Object) 100.0d);
        dateAxis1.setLabelInsets(rectangleInsets6);
        double double11 = rectangleInsets6.trimHeight(0.25d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.75d) + "'", double11 == (-1.75d));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.awt.Paint paint2 = piePlot3D0.getNoDataMessagePaint();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        piePlot3D0.setBaseSectionPaint(paint3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        boolean boolean7 = stackedBarRenderer3D1.isDrawBarOutline();
        stackedBarRenderer3D1.setBaseSeriesVisible(false, false);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint12 = polarPlot11.getAngleGridlinePaint();
        java.awt.Paint paint13 = null;
        polarPlot11.setRadiusGridlinePaint(paint13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot11);
        org.jfree.chart.util.BooleanList booleanList16 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        boolean boolean19 = ringPlot17.equals((java.lang.Object) (short) 0);
        java.awt.Color color20 = java.awt.Color.YELLOW;
        ringPlot17.setLabelLinkPaint((java.awt.Paint) color20);
        boolean boolean22 = booleanList16.equals((java.lang.Object) color20);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) (short) 0);
        java.awt.Color color26 = java.awt.Color.YELLOW;
        ringPlot23.setLabelLinkPaint((java.awt.Paint) color26);
        java.awt.Paint paint29 = ringPlot23.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot23.setShadowYOffset((double) 10L);
        ringPlot23.setCircular(false);
        boolean boolean34 = booleanList16.equals((java.lang.Object) ringPlot23);
        java.awt.Paint paint35 = ringPlot23.getBackgroundPaint();
        boolean boolean36 = legendTitle15.equals((java.lang.Object) ringPlot23);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray37 = legendTitle15.getSources();
        java.lang.Object obj38 = legendTitle15.clone();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot39.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot39.getAxisOffset();
        legendTitle15.setItemLabelPadding(rectangleInsets41);
        boolean boolean43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) false, (java.lang.Object) legendTitle15);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            int int12 = defaultIntervalCategoryDataset10.getSeriesIndex((java.lang.Comparable) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot28.getRangeAxis((int) (byte) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot28.getDomainAxisEdge((int) (short) 0);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        textTitle0.setExpandToFitSpace(false);
        boolean boolean5 = textTitle0.getExpandToFitSpace();
        java.lang.Object obj6 = textTitle0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot28.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        ringPlot3.removeChangeListener(plotChangeListener4);
        ringPlot3.setLabelLinksVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup8 = ringPlot3.getDatasetGroup();
        boolean boolean9 = dateAxis1.hasListener((java.util.EventListener) ringPlot3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection10, 4);
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        ringPlot3.setDataset(pieDataset12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month2, shape4, "{0}", "ThreadContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.next();
        boolean boolean10 = sortOrder0.equals((java.lang.Object) month2);
        int int11 = month2.getMonth();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        ringPlot12.removeChangeListener(plotChangeListener13);
        java.awt.Paint paint15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(paint15);
        ringPlot12.setShadowPaint(paint15);
        java.awt.Color color18 = java.awt.Color.YELLOW;
        ringPlot12.setOutlinePaint((java.awt.Paint) color18);
        int int20 = month2.compareTo((java.lang.Object) color18);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        ringPlot6.removeChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot6.setBaseSectionPaint(paint9);
        ringPlot0.setLabelShadowPaint(paint9);
        ringPlot0.setCircular(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        textTitle0.setExpandToFitSpace(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle0.getPosition();
        org.jfree.chart.block.BlockFrame blockFrame6 = textTitle0.getFrame();
        java.lang.String str7 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop(0.0d);
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        double double4 = size2D3.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D3, 0.2d, (double) 500, rectangleAnchor7);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, 4);
        int int12 = taskSeriesCollection9.getSeriesCount();
        int int13 = taskSeriesCollection9.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double16 = categoryAxis15.getUpperMargin();
        java.awt.Font font17 = categoryAxis15.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean20 = dateAxis19.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition21 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis19.setTickMarkPosition(dateTickMarkPosition21);
        dateAxis19.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis19.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean29 = stackedBarRenderer3D27.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32, textAnchor33, (double) 0L);
        stackedBarRenderer3D27.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D27);
        java.lang.Comparable[] comparableArray45 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray46 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray47 = null;
        java.lang.Number[][] numberArray48 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset49 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray45, comparableArray46, numberArray47, numberArray48);
        categoryPlot37.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset49);
        categoryPlot37.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot37.getRangeAxisEdge((int) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D55 = axisSpace0.reserved(rectangle2D8, rectangleEdge54);
        axisSpace0.setRight((double) (-459));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition21);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(comparableArray45);
        org.junit.Assert.assertNotNull(comparableArray46);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha((float) 1);
        java.awt.Color color4 = java.awt.Color.blue;
        categoryMarker1.setOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle7.setPadding(rectangleInsets8);
        textTitle7.setExpandToFitSpace(false);
        java.awt.Font font12 = textTitle7.getFont();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font12, (org.jfree.chart.plot.Plot) xYPlot13, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart17.getPadding();
        categoryMarker1.setLabelOffset(rectangleInsets18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        ringPlot0.setBackgroundAlpha((float) (short) 0);
        double double11 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("Size2D[width=0.0, height=0.0]");
        java.lang.String str2 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("Size2D[width=0.0, height=0.0]");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        java.lang.String str6 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]" + "'", str2.equals("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]" + "'", str6.equals("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) '4');
        java.lang.String str7 = categoryAxis1.getLabelURL();
        categoryAxis1.setMaximumCategoryLabelLines(128);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D2.setBaseOutlinePaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double12 = dateAxis11.getUpperMargin();
        java.awt.Paint paint13 = dateAxis11.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis11, rectangle2D14, (double) 100L);
        java.awt.Font font17 = dateAxis11.getLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot19.equals((java.lang.Object) (short) 0);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        ringPlot19.setLabelLinkPaint((java.awt.Paint) color22);
        java.awt.Paint paint25 = ringPlot19.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot19.setLabelPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.Plot plot28 = ringPlot19.getRootPlot();
        java.awt.Paint paint29 = ringPlot19.getOutlinePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedBarRenderer3D31.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D34.getPositiveItemLabelPositionFallback();
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D34.setBaseOutlinePaint((java.awt.Paint) color36);
        stackedBarRenderer3D31.setWallPaint((java.awt.Paint) color36);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer39 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        minMaxCategoryRenderer39.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition41, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = minMaxCategoryRenderer39.getLegendItemToolTipGenerator();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int46 = color45.getGreen();
        minMaxCategoryRenderer39.setBaseFillPaint((java.awt.Paint) color45);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer48 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color18, paint29, (java.awt.Paint) color36, (java.awt.Paint) color45);
        org.jfree.chart.block.LabelBlock labelBlock49 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.CENTER_RIGHT", font17, (java.awt.Paint) color36);
        java.awt.Font font50 = null;
        try {
            labelBlock49.setFont(font50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(itemLabelPosition32);
        org.junit.Assert.assertNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 128 + "'", int46 == 128);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) (short) 0);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        ringPlot8.setLabelLinkPaint((java.awt.Paint) color11);
        java.awt.Paint paint14 = ringPlot8.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot8.setShadowYOffset((double) 10L);
        ringPlot8.setCircular(false);
        taskSeriesCollection5.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot8);
        org.jfree.data.general.DatasetGroup datasetGroup21 = new org.jfree.data.general.DatasetGroup("");
        taskSeriesCollection5.setGroup(datasetGroup21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean26 = stackedBarRenderer3D24.equals((java.lang.Object) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection27 = stackedBarRenderer3D24.getLegendItems();
        boolean boolean28 = datasetGroup21.equals((java.lang.Object) legendItemCollection27);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean5 = dateAxis4.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date9 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit8);
        java.util.Date date10 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        int int11 = dateTickUnit8.getRollUnit();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean14 = dateAxis13.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis13.setTickMarkPosition(dateTickMarkPosition15);
        dateAxis13.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis13.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date26 = dateAxis21.calculateLowestVisibleTickValue(dateTickUnit25);
        dateAxis13.setMinimumDate(date26);
        java.util.Date date28 = dateTickUnit8.rollDate(date26);
        double double29 = dateTickUnit8.getSize();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.64E7d + "'", double29 == 8.64E7d);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryMarker1.getLabelOffset();
        boolean boolean5 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getDomainMarkers((int) (short) 10, layer3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getRangeAxisLocation();
        xYPlot0.clearDomainMarkers(8);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        java.lang.Object obj12 = jFreeChart11.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        org.jfree.data.KeyToGroupMap keyToGroupMap8 = null;
        try {
            org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, keyToGroupMap8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        java.awt.Paint paint44 = categoryPlot28.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace45 = new org.jfree.chart.axis.AxisSpace();
        double double46 = axisSpace45.getRight();
        categoryPlot28.setFixedRangeAxisSpace(axisSpace45);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat50 = numberAxis3D49.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit52 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        numberAxis3D49.setTickUnit(numberTickUnit52, true, true);
        categoryPlot28.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand58 = null;
        numberAxis3D49.setMarkerBand(markerAxisBand58);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(numberFormat50);
    }
}

