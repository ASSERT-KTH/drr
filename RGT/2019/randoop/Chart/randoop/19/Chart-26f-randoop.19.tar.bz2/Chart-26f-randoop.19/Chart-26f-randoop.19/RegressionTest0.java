import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) 0;
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) (short) 100, (float) 0L, (double) 10.0f, (float) '#', (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 10.0f, (float) '4', (double) (byte) 1, (float) 100L, (float) (byte) 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 10.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        try {
            ringPlot0.setInteriorGap(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            minMaxCategoryRenderer0.drawOutline(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries2 = taskSeriesCollection0.getSeries((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { false, (short) 10, (-1), (-1L) };
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { "", (-1.0d), 1.0d, (short) 0, 0.2d };
        double[] doubleArray12 = new double[] { 0.2d };
        double[] doubleArray14 = new double[] { 0.2d };
        double[] doubleArray16 = new double[] { 0.2d };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray14, doubleArray16 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray10, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "", textAnchor2, textAnchor3, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        minMaxCategoryRenderer11.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition13, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = minMaxCategoryRenderer11.getLegendItemToolTipGenerator();
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        minMaxCategoryRenderer11.setSeriesOutlinePaint(0, (java.awt.Paint) color18);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer20 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon21 = minMaxCategoryRenderer20.getMinIcon();
        java.awt.Stroke stroke24 = minMaxCategoryRenderer20.getItemStroke((int) (byte) 100, (int) (short) 100);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        java.awt.Stroke stroke28 = null;
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem(attributedString0, "Size2D[width=0.0, height=0.0]", "Size2D[width=0.0, height=0.0]", "", false, shape6, false, (java.awt.Paint) color8, true, (java.awt.Paint) color18, stroke24, true, shape27, stroke28, (java.awt.Paint) color29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(icon21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color7 = java.awt.Color.DARK_GRAY;
        minMaxCategoryRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        float[] floatArray13 = new float[] { '#', (byte) 1 };
        try {
            float[] floatArray14 = color7.getColorComponents(colorSpace10, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 0.0f, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        try {
            dateAxis1.setRangeWithMargins((double) 100L, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.2).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        ringPlot0.setDataset(pieDataset7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        try {
            java.lang.Comparable comparable8 = taskSeriesCollection5.getSeriesKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        try {
            java.lang.Number number10 = taskSeriesCollection5.getStartValue((int) ' ', (int) (short) 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0 == 0L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        minMaxCategoryRenderer8.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition10, true);
        java.awt.Stroke stroke14 = minMaxCategoryRenderer8.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesStroke(10, stroke14, false);
        java.awt.Paint paint17 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        minMaxCategoryRenderer0.setBasePaint(paint17, false);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.CENTER_LEFT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double2 = dateAxis1.getUpperMargin();
        org.jfree.data.Range range3 = null;
        try {
            dateAxis1.setRange(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        try {
            lineAndShapeRenderer2.setSeriesLinesVisible((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5, textAnchor6, (double) 0L);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.awt.Shape shape11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) 1, (float) ' ', textAnchor5, (double) (byte) 0, textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String[] strArray6 = new java.lang.String[] { "Size2D[width=0.0, height=0.0]", "hi!", "TextBlockAnchor.CENTER_LEFT", "hi!", "", "TextBlockAnchor.CENTER_LEFT" };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 6, (short) -1, 3600000L, 0.0d, (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 6, (short) -1, 3600000L, 0.0d, (-1.0d) };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 6, (short) -1, 3600000L, 0.0d, (-1.0d) };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray12, numberArray18, numberArray24 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0d };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0d };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0d };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray27, numberArray29, numberArray31, numberArray33, numberArray35 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset37 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray6, numberArray25, numberArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        try {
            double double8 = categoryAxis1.getCategoryMiddle((int) (byte) 100, 10, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean10 = size2D7.equals((java.lang.Object) numberTickUnit9);
        try {
            java.lang.Number number12 = taskSeriesCollection5.getEndValue((java.lang.Comparable) boolean10, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 10, (double) ' ', 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Apr" + "'", str2.equals("Apr"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            stackedBarRenderer3D1.drawOutline(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double2 = dateAxis1.getUpperMargin();
        java.awt.Paint paint3 = dateAxis1.getAxisLinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        double double10 = axisSpace9.getTop();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace11 = dateAxis1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) waferMapPlot6, rectangle2D7, rectangleEdge8, axisSpace9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setMaximumBarWidth((double) (byte) -1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        minMaxCategoryRenderer9.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition11, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range15 = minMaxCategoryRenderer9.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        minMaxCategoryRenderer17.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition19, true);
        java.awt.Stroke stroke23 = minMaxCategoryRenderer17.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer9.setSeriesStroke(10, stroke23, false);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double30 = dateAxis29.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        minMaxCategoryRenderer9.drawRangeGridline(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) dateAxis29, rectangle2D31, (double) (byte) 100);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer34 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        minMaxCategoryRenderer34.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition36, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection39 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range40 = minMaxCategoryRenderer34.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection39);
        try {
            barRenderer3D0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.data.category.CategoryDataset) taskSeriesCollection39, 10, 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertNull(range40);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        java.lang.Comparable comparable3 = null;
        int int4 = taskSeriesCollection0.indexOf(comparable3);
        try {
            java.lang.Number number7 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 1.0f, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries8 = taskSeriesCollection5.getSeries((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.axis.AxisState axisState11 = categoryAxis1.draw(graphics2D5, 4.0d, rectangle2D7, rectangle2D8, rectangleEdge9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean3 = stackedBarRenderer3D1.equals((java.lang.Object) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = stackedBarRenderer3D1.getLegendItems();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedBarRenderer3D1.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        minMaxCategoryRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        minMaxCategoryRenderer11.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition13, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range17 = minMaxCategoryRenderer11.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection16);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer19 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        minMaxCategoryRenderer19.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition21, true);
        java.awt.Stroke stroke25 = minMaxCategoryRenderer19.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer11.setSeriesStroke(10, stroke25, false);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        boolean boolean34 = ringPlot32.equals((java.lang.Object) (short) 0);
        java.awt.Color color35 = java.awt.Color.YELLOW;
        ringPlot32.setLabelLinkPaint((java.awt.Paint) color35);
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "TextBlockAnchor.CENTER_LEFT", "Apr", "Size2D[width=0.0, height=0.0]", false, shape6, true, paint8, false, (java.awt.Paint) color10, stroke25, false, shape30, stroke31, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        boolean boolean4 = rectangleInsets2.equals((java.lang.Object) 100.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets2.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (byte) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset2);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ERROR : Relative To String", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        boolean boolean9 = minMaxCategoryRenderer0.getAutoPopulateSeriesPaint();
        boolean boolean12 = minMaxCategoryRenderer0.getItemVisible(0, (int) 'a');
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        java.lang.Comparable comparable3 = null;
        int int4 = taskSeriesCollection0.indexOf(comparable3);
        org.jfree.data.gantt.TaskSeries taskSeries5 = null;
        try {
            taskSeriesCollection0.add(taskSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Comparable comparable12 = defaultIntervalCategoryDataset10.getRowKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE2" + "'", str1.equals("ItemLabelAnchor.INSIDE2"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            lineAndShapeRenderer2.drawDomainGridline(graphics2D3, categoryPlot4, rectangle2D5, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean7 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            int int11 = defaultIntervalCategoryDataset10.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) '4', (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double2 = dateAxis1.getUpperMargin();
        java.awt.Paint paint3 = dateAxis1.getAxisLinePaint();
        try {
            dateAxis1.setRange((double) 100.0f, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        try {
            java.lang.Number number8 = taskSeriesCollection0.getEndValue((java.lang.Comparable) (short) 100, (java.lang.Comparable) 10L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Color color2 = java.awt.Color.yellow;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color2);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset(10.0d);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = minMaxCategoryRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) "Apr");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        try {
            java.util.List list10 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Color color2 = java.awt.Color.yellow;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color2);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset(10.0d);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon7 = minMaxCategoryRenderer6.getMinIcon();
        minMaxCategoryRenderer0.setMinIcon(icon7);
        java.awt.Stroke stroke9 = null;
        try {
            minMaxCategoryRenderer0.setBaseOutlineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(icon7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getRight();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int3 = java.awt.Color.HSBtoRGB((float) 1L, (float) 6, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16318469) + "'", int3 == (-16318469));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = stackedBarRenderer3D1.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double11 = dateAxis10.getUpperMargin();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) dateAxis10, rectangle2D13, (double) 100L);
        java.awt.Font font16 = dateAxis10.getTickLabelFont();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.data.Range range7 = null;
        try {
            dateAxis1.setDefaultAutoRange(range7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowXOffset((double) 1);
        java.awt.Font font6 = ringPlot3.getLabelFont();
        boolean boolean7 = year1.equals((java.lang.Object) ringPlot3);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        minMaxCategoryRenderer8.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition10, true);
        java.awt.Stroke stroke14 = minMaxCategoryRenderer8.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesStroke(10, stroke14, false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double21 = dateAxis20.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        minMaxCategoryRenderer0.drawRangeGridline(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) dateAxis20, rectangle2D22, (double) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        minMaxCategoryRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26, true);
        minMaxCategoryRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        java.lang.Comparable[] comparableArray17 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray19 = null;
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray17, comparableArray18, numberArray19, numberArray20);
        try {
            defaultIntervalCategoryDataset10.setCategoryKeys(comparableArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray17);
        org.junit.Assert.assertNotNull(comparableArray18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, 0.0d, (float) '4', (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', (int) (byte) 100, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ERROR : Relative To String", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.String[] strArray4 = new java.lang.String[] { "October", "RectangleEdge.TOP", "TextBlockAnchor.CENTER_LEFT", "" };
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.2d };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.2d };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray6, numberArray8 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10.0f };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10.0f };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray4, numberArray9, numberArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        java.lang.Comparable[] comparableArray17 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray19 = null;
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray17, comparableArray18, numberArray19, numberArray20);
        try {
            defaultIntervalCategoryDataset10.setSeriesKeys(comparableArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray17);
        org.junit.Assert.assertNotNull(comparableArray18);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, 0, 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) '4');
        boolean boolean7 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.insertValue(1, (java.lang.Comparable) (-16318469), (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = stackedBarRenderer3D1.initialise(graphics2D2, rectangle2D3, categoryPlot4, 9, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Comparable comparable12 = defaultIntervalCategoryDataset10.getRowKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            blockBorder1.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Number number13 = defaultIntervalCategoryDataset10.getStartValue((java.lang.Comparable) (short) 100, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isTickLabelsVisible();
        dateAxis9.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis9.setLabelFont(font13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        try {
            intervalBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryDataset15, (int) (short) -1, (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon8 = minMaxCategoryRenderer0.getObjectIcon();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker13.setLabelOffsetType(lengthAdjustmentType14);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            minMaxCategoryRenderer0.drawDomainMarker(graphics2D9, categoryPlot10, categoryAxis11, categoryMarker13, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(icon8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int7 = color6.getGreen();
        minMaxCategoryRenderer0.setBaseFillPaint((java.awt.Paint) color6);
        boolean boolean9 = minMaxCategoryRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon3 = minMaxCategoryRenderer2.getMinIcon();
        java.awt.Stroke stroke6 = minMaxCategoryRenderer2.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer0.setBaseOutlineStroke(stroke6, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double13 = categoryAxis12.getUpperMargin();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer15 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        minMaxCategoryRenderer15.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition17, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = minMaxCategoryRenderer15.getLegendItemToolTipGenerator();
        java.awt.Color color22 = java.awt.Color.DARK_GRAY;
        minMaxCategoryRenderer15.setSeriesOutlinePaint(0, (java.awt.Paint) color22);
        categoryAxis12.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            minMaxCategoryRenderer0.drawDomainMarker(graphics2D9, categoryPlot10, categoryAxis12, categoryMarker26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(icon3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        java.awt.Paint paint9 = stackedBarRenderer3D1.getItemLabelPaint((int) (byte) 1, 3);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Color color2 = java.awt.Color.YELLOW;
        stackedBarRenderer3D1.setWallPaint((java.awt.Paint) color2);
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            int int12 = defaultIntervalCategoryDataset10.getColumnIndex((java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        ringPlot9.removeChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(paint12);
        ringPlot9.setShadowPaint(paint12);
        ringPlot0.setLabelPaint(paint12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        ringPlot0.addChangeListener(plotChangeListener16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = categoryMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Paint paint3 = null;
        ringPlot0.setLabelBackgroundPaint(paint3);
        java.awt.Stroke stroke5 = ringPlot0.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        ringPlot0.setDrawingSupplier(drawingSupplier3);
        try {
            java.lang.Object obj5 = ringPlot0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean1 = stackedBarRenderer3D0.isDrawBarOutline();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        try {
            stackedBarRenderer3D0.setPlot(categoryPlot2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color0 = java.awt.Color.pink;
        float[] floatArray2 = new float[] { 0L };
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int7 = color6.getGreen();
        minMaxCategoryRenderer0.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = minMaxCategoryRenderer0.getBaseOutlinePaint();
        boolean boolean10 = minMaxCategoryRenderer0.getAutoPopulateSeriesStroke();
        int int11 = minMaxCategoryRenderer0.getPassCount();
        java.lang.Object obj12 = minMaxCategoryRenderer0.clone();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        java.awt.Font font3 = ringPlot0.getLabelFont();
        ringPlot0.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        minMaxCategoryRenderer4.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition6, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = minMaxCategoryRenderer4.getLegendItemToolTipGenerator();
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        minMaxCategoryRenderer4.setSeriesOutlinePaint(0, (java.awt.Paint) color11);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color11);
        categoryAxis1.setAxisLineVisible(false);
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, (int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        lineAndShapeRenderer2.setSeriesShapesFilled(6, (java.lang.Boolean) false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        ringPlot1.removeChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot1.setBaseSectionPaint(paint4);
        boolean boolean6 = size2D0.equals((java.lang.Object) ringPlot1);
        java.lang.Object obj7 = ringPlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        ringPlot1.notifyListeners(plotChangeEvent8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getBaseItemLabelPaint();
        java.lang.Boolean boolean8 = minMaxCategoryRenderer0.getSeriesItemLabelsVisible(128);
        boolean boolean9 = minMaxCategoryRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean8 = lengthConstraintType4.equals((java.lang.Object) 10);
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 1, range3, lengthConstraintType4, (double) (-1), range10, lengthConstraintType11);
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 100L, range1, lengthConstraintType11, 0.0d, range14, lengthConstraintType15);
        org.jfree.data.Range range17 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toRangeWidth(range17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean3 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        try {
            java.lang.Number number11 = taskSeriesCollection5.getPercentComplete((int) 'a', 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int7 = color6.getGreen();
        minMaxCategoryRenderer0.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = minMaxCategoryRenderer0.getBaseOutlinePaint();
        boolean boolean10 = minMaxCategoryRenderer0.getAutoPopulateSeriesStroke();
        int int11 = minMaxCategoryRenderer0.getPassCount();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis17.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean23 = dateAxis22.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date27 = dateAxis22.calculateLowestVisibleTickValue(dateTickUnit26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D12, categoryItemRendererState13, rectangle2D14, categoryPlot15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryDataset28, (int) (byte) 100, 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        ringPlot0.setBackgroundAlpha((float) (short) 0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        ringPlot0.setSeparatorsVisible(false);
        boolean boolean5 = ringPlot0.isCircular();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        minMaxCategoryRenderer4.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition6, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = minMaxCategoryRenderer4.getLegendItemToolTipGenerator();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int11 = color10.getGreen();
        minMaxCategoryRenderer4.setBaseFillPaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = minMaxCategoryRenderer4.getBaseOutlinePaint();
        categoryAxis1.setAxisLinePaint(paint13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            waferMapPlot1.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7, textAnchor8, (double) 0L);
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(2, itemLabelPosition10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = lineAndShapeRenderer2.initialise(graphics2D12, rectangle2D13, categoryPlot14, 100, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        stackedBarRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setMaximumBarWidth((double) (byte) -1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isTickLabelsVisible();
        dateAxis6.setFixedAutoRange((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            barRenderer3D0.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) dateAxis6, rectangle2D10, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month5, shape7, "{0}", "ThreadContext");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.String str14 = year13.toString();
        try {
            java.lang.Number number16 = taskSeriesCollection0.getEndValue((java.lang.Comparable) "ThreadContext", (java.lang.Comparable) str14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.lang.String str3 = categoryAxis1.getLabel();
        java.awt.Paint paint4 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.gantt.TaskSeries taskSeries1 = null;
        try {
            taskSeriesCollection0.add(taskSeries1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str6 = datasetGroup5.getID();
        taskSeriesCollection0.setGroup(datasetGroup5);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("2019", graphics2D1, (double) (byte) 0, 0.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean4 = standardCategoryToolTipGenerator0.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        defaultKeyedValues0.clear();
        try {
            java.lang.Number number4 = defaultKeyedValues0.getValue((java.lang.Comparable) "Size2D[width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: Size2D[width=0.0, height=0.0]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Other", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        try {
            java.lang.Comparable comparable8 = taskSeriesCollection5.getColumnKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        java.util.Iterator iterator6 = legendItemCollection5.iterator();
        java.util.Iterator iterator7 = legendItemCollection5.iterator();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertNotNull(iterator7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            int int12 = defaultIntervalCategoryDataset10.getColumnIndex((java.lang.Comparable) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        ringPlot0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) 0.5f, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange13);
        double double15 = rectangleConstraint14.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (byte) 10, (double) 10, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(polarItemRenderer2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        boolean boolean9 = minMaxCategoryRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer12 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator14 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer12.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator14, false);
        java.text.NumberFormat numberFormat17 = standardCategoryToolTipGenerator14.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator18 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("2019", numberFormat17);
        try {
            minMaxCategoryRenderer0.setSeriesToolTipGenerator((int) (byte) -1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberFormat17);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = null;
        try {
            taskSeriesCollection0.setGroup(datasetGroup5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon7 = minMaxCategoryRenderer6.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon9 = minMaxCategoryRenderer8.getMinIcon();
        java.awt.Stroke stroke12 = minMaxCategoryRenderer8.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer6.setBaseOutlineStroke(stroke12, false);
        minMaxCategoryRenderer0.setGroupStroke(stroke12);
        java.io.ObjectOutputStream objectOutputStream16 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke12, objectOutputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(icon7);
        org.junit.Assert.assertNotNull(icon9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, true);
        try {
            java.lang.Number number12 = taskSeriesCollection5.getPercentComplete(4, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesPaint(0);
        boolean boolean7 = lineAndShapeRenderer2.getItemShapeVisible(8, (int) (byte) 100);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot3D0.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean8 = lengthConstraintType4.equals((java.lang.Object) 10);
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 1, range3, lengthConstraintType4, (double) (-1), range10, lengthConstraintType11);
        boolean boolean13 = size2D0.equals((java.lang.Object) lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        double double5 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (short) 0);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "August" + "'", str1.equals("August"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            defaultIntervalCategoryDataset10.setEndValue((-457), (java.lang.Comparable) "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]", (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) (short) 0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color4);
        boolean boolean6 = booleanList0.equals((java.lang.Object) color4);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = ringPlot7.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot7.setShadowYOffset((double) 10L);
        ringPlot7.setCircular(false);
        boolean boolean18 = booleanList0.equals((java.lang.Object) ringPlot7);
        java.awt.Paint paint19 = ringPlot7.getBackgroundPaint();
        double double20 = ringPlot7.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Number number13 = defaultIntervalCategoryDataset10.getEndValue((java.lang.Comparable) 1, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setDrawAsLine(false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3, textAnchor4, (double) 0L);
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition6.getTextAnchor();
        categoryMarker1.setLabelTextAnchor(textAnchor7);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getBottom();
        double double6 = rectangleInsets2.calculateTopInset(10.0d);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            multiplePiePlot0.setPieChart(jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Object obj11 = defaultIntervalCategoryDataset10.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean3 = stackedBarRenderer3D1.equals((java.lang.Object) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = stackedBarRenderer3D1.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        stackedBarRenderer3D1.setSeriesItemLabelGenerator(9, categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=0.0]", graphics2D1, (double) (short) 0, (float) 2, (float) 25200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        chartEntity2.setArea(shape5);
        java.lang.String str8 = chartEntity2.getToolTipText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean3 = dateAxis2.isTickLabelsVisible();
        dateAxis2.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font6);
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("SortOrder.DESCENDING", font6, paint8, (float) 8, textMeasurer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10L, (java.lang.Number) 10L);
        defaultKeyedValue2.setValue((java.lang.Number) 0.05d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        boolean boolean4 = polarPlot0.equals((java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int7 = color6.getGreen();
        minMaxCategoryRenderer0.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = minMaxCategoryRenderer0.getBaseOutlinePaint();
        boolean boolean10 = minMaxCategoryRenderer0.getAutoPopulateSeriesStroke();
        minMaxCategoryRenderer0.setDrawLines(false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        org.jfree.data.xy.XYDataset xYDataset3 = polarPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(xYDataset3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean4 = ringPlot0.equals((java.lang.Object) textAnchor3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator5);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer7 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        minMaxCategoryRenderer7.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = minMaxCategoryRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint13 = minMaxCategoryRenderer7.getBaseItemLabelPaint();
        ringPlot0.setNoDataMessagePaint(paint13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.data.gantt.TaskSeries taskSeries5 = null;
        try {
            taskSeriesCollection0.add(taskSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon2 = minMaxCategoryRenderer1.getMinIcon();
        java.awt.Stroke stroke5 = minMaxCategoryRenderer1.getItemStroke((int) (byte) 100, (int) (short) 100);
        stackedBarRenderer3D0.setBaseOutlineStroke(stroke5);
        org.junit.Assert.assertNotNull(icon2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int4 = taskSeriesCollection0.getColumnCount();
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 1, 9, (int) 'a', 6, dateFormat10);
        try {
            java.lang.Number number13 = taskSeriesCollection0.getEndValue((java.lang.Comparable) "RectangleAnchor.TOP_RIGHT", (java.lang.Comparable) dateTickUnit11, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        minMaxCategoryRenderer1.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition3, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = minMaxCategoryRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = minMaxCategoryRenderer1.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon9 = minMaxCategoryRenderer1.getObjectIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        minMaxCategoryRenderer10.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition12, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = minMaxCategoryRenderer10.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = minMaxCategoryRenderer10.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon18 = minMaxCategoryRenderer10.getObjectIcon();
        minMaxCategoryRenderer1.setObjectIcon(icon18);
        boolean boolean20 = shapeList0.equals((java.lang.Object) minMaxCategoryRenderer1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(icon9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(icon18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D4.getPositiveItemLabelPositionFallback();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = stackedBarRenderer3D4.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double14 = dateAxis13.getUpperMargin();
        java.awt.Paint paint15 = dateAxis13.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        stackedBarRenderer3D4.drawRangeGridline(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) dateAxis13, rectangle2D16, (double) 100L);
        java.awt.Shape shape19 = dateAxis13.getDownArrow();
        try {
            java.awt.GradientPaint gradientPaint20 = standardGradientPaintTransformer0.transform(gradientPaint2, shape19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = null;
        try {
            areaRenderer0.setEndType(areaRendererEndType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Color color2 = java.awt.Color.yellow;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color2);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset(10.0d);
        boolean boolean8 = minMaxCategoryRenderer0.getItemCreateEntity(4, 3);
        int int9 = minMaxCategoryRenderer0.getColumnCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        minMaxCategoryRenderer0.setSeriesNegativeItemLabelPosition(6, itemLabelPosition11, true);
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextBlockAnchor.CENTER_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextBlockAnchor.CENTER_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        double double2 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.JFreeChart jFreeChart3 = plotChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(9, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateLeftInset((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        boolean boolean6 = lineAndShapeRenderer2.getUseOutlinePaint();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator11 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer9.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator11, false);
        java.text.NumberFormat numberFormat14 = standardCategoryToolTipGenerator11.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator15 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("2019", numberFormat14);
        try {
            lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (byte) -1, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberFormat14);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = ringPlot0.getToolTipGenerator();
        boolean boolean4 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getLastMillisecond();
        try {
            java.lang.Number number4 = defaultKeyedValues2D0.getValue((java.lang.Comparable) long2, (java.lang.Comparable) 28);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 28");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getBaseItemLabelPaint();
        minMaxCategoryRenderer0.setBaseCreateEntities(true);
        boolean boolean9 = minMaxCategoryRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        waferMapPlot1.setRenderer(waferMapRenderer4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        double double29 = dateAxis10.getFixedAutoRange();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 1, 9, (int) 'a', 6, dateFormat4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        ringPlot6.removeChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(paint9);
        ringPlot6.setShadowPaint(paint9);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        ringPlot6.setOutlinePaint((java.awt.Paint) color12);
        float[] floatArray19 = new float[] { 60000L, 3, 10.0f, 100, 4 };
        float[] floatArray20 = color12.getRGBComponents(floatArray19);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer21 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = null;
        minMaxCategoryRenderer21.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition23, true);
        java.awt.Stroke stroke27 = minMaxCategoryRenderer21.lookupSeriesStroke((int) (short) 0);
        java.awt.Paint paint28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color12, stroke27, paint28, stroke29, (float) 25200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("October", "", "{0}", "October");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getColumnKey(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        try {
            defaultKeyedValues0.insertValue(4, (java.lang.Comparable) "ThreadContext", (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        float[] floatArray13 = new float[] { 60000L, 3, 10.0f, 100, 4 };
        float[] floatArray14 = color6.getRGBComponents(floatArray13);
        int int15 = color6.getAlpha();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = ringPlot6.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot6.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        ringPlot15.removeChangeListener(plotChangeListener16);
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        ringPlot15.setShadowPaint(paint18);
        ringPlot6.setLabelPaint(paint18);
        double double22 = ringPlot6.getOuterSeparatorExtension();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = ringPlot6.getInsets();
        multiplePiePlot3.setInsets(rectangleInsets23, false);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 4 + "'", number3.equals(4));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getAutoPopulateSeriesPaint();
        int int2 = stackedBarRenderer0.getPassCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, 4);
        int int6 = taskSeriesCollection3.getSeriesCount();
        int int7 = taskSeriesCollection3.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double10 = categoryAxis9.getUpperMargin();
        java.awt.Font font11 = categoryAxis9.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean14 = dateAxis13.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis13.setTickMarkPosition(dateTickMarkPosition15);
        dateAxis13.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis13.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean23 = stackedBarRenderer3D21.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor25, textAnchor26, textAnchor27, (double) 0L);
        stackedBarRenderer3D21.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D21);
        java.lang.Comparable[] comparableArray39 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray40 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray41 = null;
        java.lang.Number[][] numberArray42 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset43 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray39, comparableArray40, numberArray41, numberArray42);
        categoryPlot31.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset43);
        try {
            org.jfree.data.Range range45 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(comparableArray39);
        org.junit.Assert.assertNotNull(comparableArray40);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 5, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (5.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        java.awt.Font font3 = null;
        try {
            piePlot3D0.setNoDataMessageFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        try {
            java.lang.Comparable comparable43 = defaultIntervalCategoryDataset40.getSeriesKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        try {
            java.lang.Number number44 = defaultIntervalCategoryDataset40.getValue((int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = lineAndShapeRenderer2.getItemShapeFilled(8, 5);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(10.0d, 0.05d, (double) 100, (double) 9);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.0d + "'", double6 == 9.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getFirstBarPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color3, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = waterfallBarRenderer0.getItemLabelGenerator((int) (short) 0, 31);
        java.awt.Paint paint9 = null;
        try {
            waterfallBarRenderer0.setPositiveBarPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = sortOrder0.equals(obj2);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        categoryPlot28.clearDomainMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        try {
            categoryPlot28.zoomRangeAxes((double) 10, (double) 0.5f, plotRenderingInfo32, point2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        minMaxCategoryRenderer0.setSeriesVisibleInLegend(3, (java.lang.Boolean) true, false);
        minMaxCategoryRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        org.jfree.data.Range range11 = rectangleConstraint10.getHeightRange();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        ringPlot30.removeChangeListener(plotChangeListener31);
        java.awt.Paint paint33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(paint33);
        ringPlot30.setShadowPaint(paint33);
        java.awt.Color color36 = java.awt.Color.YELLOW;
        ringPlot30.setOutlinePaint((java.awt.Paint) color36);
        double double38 = ringPlot30.getShadowYOffset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator39 = ringPlot30.getLegendLabelURLGenerator();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = new org.jfree.chart.axis.AxisSpace();
        double double43 = axisSpace42.getTop();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace44 = categoryAxis6.reserveSpace(graphics2D29, (org.jfree.chart.plot.Plot) ringPlot30, rectangle2D40, rectangleEdge41, axisSpace42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertNull(pieURLGenerator39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = java.awt.Color.orange;
        waterfallBarRenderer0.setFirstBarPaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = waterfallBarRenderer0.getSeriesOutlinePaint((int) (byte) -1);
        java.awt.Paint paint5 = null;
        try {
            waterfallBarRenderer0.setPositiveBarPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.lang.Object obj5 = null;
        boolean boolean6 = ringPlot0.equals(obj5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        ringPlot0.setSeparatorPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 10, (float) 100L, 0.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Number number13 = defaultIntervalCategoryDataset10.getValue((java.lang.Comparable) 100L, (java.lang.Comparable) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        minMaxCategoryRenderer8.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition10, true);
        java.awt.Stroke stroke14 = minMaxCategoryRenderer8.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesStroke(10, stroke14, false);
        boolean boolean17 = minMaxCategoryRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        java.lang.Comparable comparable8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, comparable8);
        try {
            java.lang.Comparable comparable11 = taskSeriesCollection5.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list6 = axisCollection5.getAxesAtBottom();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) list6);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.awt.Paint paint2 = piePlot3D0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        try {
            java.awt.GradientPaint gradientPaint8 = standardGradientPaintTransformer0.transform(gradientPaint2, shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date6 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit5);
        dateAxis1.setRange((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        boolean boolean29 = categoryPlot28.isDomainGridlinesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot28.addAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getGPL();
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int7 = color6.getGreen();
        minMaxCategoryRenderer0.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = minMaxCategoryRenderer0.getBaseOutlinePaint();
        javax.swing.Icon icon10 = minMaxCategoryRenderer0.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer12 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator14 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer12.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator14, false);
        java.text.NumberFormat numberFormat17 = standardCategoryToolTipGenerator14.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator18 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("2019", numberFormat17);
        minMaxCategoryRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator18);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(icon10);
        org.junit.Assert.assertNotNull(numberFormat17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        blockResult0.setEntityCollection(entityCollection3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 28800000L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.lightGray;
        ringPlot0.setBackgroundPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1562097599999L, (double) 100.0f, 4.0d, (double) 6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        ringPlot0.setDrawingSupplier(drawingSupplier3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        ringPlot0.datasetChanged(datasetChangeEvent5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D4.getPositiveItemLabelPositionFallback();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color6);
        stackedBarRenderer3D1.setWallPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint10 = piePlot3D9.getLabelLinkPaint();
        stackedBarRenderer3D1.setBaseOutlinePaint(paint10);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) 0.5f, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange13);
        org.jfree.data.Range range15 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint10.toRangeWidth(range15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Stroke stroke6 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        java.lang.Comparable comparable5 = multiplePiePlot3.getAggregatedItemsKey();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection6, 4);
        java.util.List list9 = taskSeriesCollection6.getRowKeys();
        multiplePiePlot3.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        try {
            multiplePiePlot3.setPieChart(jFreeChart11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        boolean boolean16 = legendItem14.equals((java.lang.Object) 3.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        java.awt.Paint paint5 = dateAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha(0.0f);
        categoryMarker1.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = categoryMarker1.getLabelOffsetType();
        org.jfree.chart.util.BooleanList booleanList7 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) (short) 0);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        ringPlot8.setLabelLinkPaint((java.awt.Paint) color11);
        boolean boolean13 = booleanList7.equals((java.lang.Object) color11);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot14.equals((java.lang.Object) (short) 0);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        ringPlot14.setLabelLinkPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = ringPlot14.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot14.setShadowYOffset((double) 10L);
        ringPlot14.setCircular(false);
        boolean boolean25 = booleanList7.equals((java.lang.Object) ringPlot14);
        java.awt.Paint paint26 = ringPlot14.getBackgroundPaint();
        categoryMarker1.setPaint(paint26);
        try {
            categoryMarker1.setAlpha((float) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = ringPlot0.getURLGenerator();
        double double12 = ringPlot0.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            ringPlot0.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        dateAxis1.setLabelURL("RectangleAnchor.TOP_RIGHT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.lang.Boolean boolean4 = stackedBarRenderer3D1.getSeriesVisible(1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D1.getPositiveItemLabelPosition(8, (int) (short) 100);
        double double8 = stackedBarRenderer3D1.getYOffset();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.lang.Boolean boolean4 = stackedBarRenderer3D1.getSeriesVisible(1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D1.getPositiveItemLabelPosition(8, (int) (short) 100);
        stackedBarRenderer3D1.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color2 = java.awt.Color.getColor("SortOrder.DESCENDING", 31);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        java.lang.Comparable comparable5 = multiplePiePlot3.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder6 = null;
        try {
            multiplePiePlot3.setDataExtractOrder(tableOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis6.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot8.getLegendItems();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot8);
        double double12 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, 4);
        int int7 = taskSeriesCollection4.getSeriesCount();
        int int8 = taskSeriesCollection4.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double11 = categoryAxis10.getUpperMargin();
        java.awt.Font font12 = categoryAxis10.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis14.setTickMarkPosition(dateTickMarkPosition16);
        dateAxis14.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis14.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean24 = stackedBarRenderer3D22.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor26, textAnchor27, textAnchor28, (double) 0L);
        stackedBarRenderer3D22.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D22);
        java.awt.Paint paint33 = categoryPlot32.getDomainGridlinePaint();
        categoryPlot32.setBackgroundAlpha((float) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean40 = dateAxis39.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition41 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis39.setTickMarkPosition(dateTickMarkPosition41);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection43 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection43, 4);
        int int46 = taskSeriesCollection43.getSeriesCount();
        int int47 = taskSeriesCollection43.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double50 = categoryAxis49.getUpperMargin();
        java.awt.Font font51 = categoryAxis49.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean54 = dateAxis53.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition55 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis53.setTickMarkPosition(dateTickMarkPosition55);
        dateAxis53.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource59 = dateAxis53.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D61 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean63 = stackedBarRenderer3D61.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor65 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor66 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor67 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor65, textAnchor66, textAnchor67, (double) 0L);
        stackedBarRenderer3D61.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition69);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection43, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis53, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D61);
        java.lang.Comparable[] comparableArray79 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray80 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray81 = null;
        java.lang.Number[][] numberArray82 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset83 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray79, comparableArray80, numberArray81, numberArray82);
        categoryPlot71.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset83);
        try {
            intervalBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot32, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset83, 3, 10, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition41);
        org.junit.Assert.assertNotNull(pieDataset45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition55);
        org.junit.Assert.assertNotNull(tickUnitSource59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor65);
        org.junit.Assert.assertNotNull(textAnchor66);
        org.junit.Assert.assertNotNull(textAnchor67);
        org.junit.Assert.assertNotNull(comparableArray79);
        org.junit.Assert.assertNotNull(comparableArray80);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        axisState1.setCursor(90.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        ringPlot0.setNoDataMessage("hi!");
        ringPlot0.setInteriorGap((double) (short) 0);
        java.awt.Color color13 = java.awt.Color.blue;
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        int int3 = defaultKeyedValues0.getIndex((java.lang.Comparable) 0.05d);
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues0.getKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        minMaxCategoryRenderer2.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition4, true);
        java.awt.Stroke stroke8 = minMaxCategoryRenderer2.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer2.setItemLabelAnchorOffset((double) 0);
        boolean boolean11 = minMaxCategoryRenderer2.getAutoPopulateSeriesPaint();
        java.lang.Class<?> wildcardClass12 = minMaxCategoryRenderer2.getClass();
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleEdge.TOP", (java.lang.Class) wildcardClass12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isInverted();
        boolean boolean5 = stackedBarRenderer3D1.equals((java.lang.Object) boolean4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean5);
        org.jfree.chart.JFreeChart jFreeChart7 = rendererChangeEvent6.getChart();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = stackedBarRenderer3D1.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double11 = dateAxis10.getUpperMargin();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) dateAxis10, rectangle2D13, (double) 100L);
        java.awt.Font font16 = dateAxis10.getLabelFont();
        dateAxis10.zoomRange((double) (-1.0f), (double) 1577865599999L);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("{0}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        legendItem14.setSeriesKey((java.lang.Comparable) 128);
        java.awt.Paint paint17 = legendItem14.getLinePaint();
        java.lang.String str18 = legendItem14.getToolTipText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]" + "'", str18.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date7 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long9 = segmentedTimeline8.getSegmentsIncludedSize();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean12 = dateAxis11.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date19 = dateAxis14.calculateLowestVisibleTickValue(dateTickUnit18);
        java.util.Date date20 = dateAxis11.calculateHighestVisibleTickValue(dateTickUnit18);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline8.getSegment(date20);
        try {
            org.jfree.data.gantt.Task task22 = new org.jfree.data.gantt.Task("Apr", date7, date20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25200000L + "'", long9 == 25200000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(segment21);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.Plot plot3 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint6 = waterfallBarRenderer5.getFirstBarPaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color8, false);
        textBlock0.addLine("RectangleAnchor.TOP_RIGHT", font4, (java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, true);
        try {
            java.lang.Number number13 = taskSeriesCollection5.getStartValue(8, (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        java.awt.Paint paint31 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double34 = dateAxis33.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = stackedBarRenderer3D36.getPositiveItemLabelPositionFallback();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D36.setBaseOutlinePaint((java.awt.Paint) color38);
        java.awt.Paint paint41 = stackedBarRenderer3D36.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double46 = dateAxis45.getUpperMargin();
        java.awt.Paint paint47 = dateAxis45.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        stackedBarRenderer3D36.drawRangeGridline(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) dateAxis45, rectangle2D48, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean53 = dateAxis52.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date57 = dateAxis52.calculateLowestVisibleTickValue(dateTickUnit56);
        dateAxis45.setTickUnit(dateTickUnit56);
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke60 = polarPlot59.getRadiusGridlineStroke();
        dateAxis45.setTickMarkStroke(stroke60);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { dateAxis33, dateAxis45 };
        categoryPlot28.setRangeAxes(valueAxisArray62);
        categoryPlot28.setRangeCrosshairValue((double) (byte) 1);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        boolean boolean8 = dateAxis1.isNegativeArrowVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str12 = rectangleEdge11.toString();
        try {
            double double13 = dateAxis1.valueToJava2D((double) (-1), rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.TOP" + "'", str12.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue((java.lang.Comparable) 8.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 8.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        boolean boolean4 = rectangleInsets2.equals((java.lang.Object) 100.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("SortOrder.DESCENDING");
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        float float11 = ringPlot0.getBackgroundImageAlpha();
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        ringPlot0.setOutlineStroke(stroke12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 0.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_RIGHT", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean1 = stackedBarRenderer3D0.isDrawBarOutline();
        boolean boolean2 = stackedBarRenderer3D0.getIncludeBaseInRange();
        java.awt.Paint paint5 = stackedBarRenderer3D0.getItemPaint((int) (byte) 0, 3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        minMaxCategoryRenderer2.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition4, true);
        org.jfree.chart.util.BooleanList booleanList7 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) (short) 0);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        ringPlot8.setLabelLinkPaint((java.awt.Paint) color11);
        boolean boolean13 = booleanList7.equals((java.lang.Object) color11);
        minMaxCategoryRenderer2.setBaseItemLabelPaint((java.awt.Paint) color11);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 1561964399999L, (double) 10.0f, plotRenderingInfo18, point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, 4);
        int int7 = taskSeriesCollection4.getSeriesCount();
        int int8 = taskSeriesCollection4.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double11 = categoryAxis10.getUpperMargin();
        java.awt.Font font12 = categoryAxis10.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis14.setTickMarkPosition(dateTickMarkPosition16);
        dateAxis14.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis14.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean24 = stackedBarRenderer3D22.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor26, textAnchor27, textAnchor28, (double) 0L);
        stackedBarRenderer3D22.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D22);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot32.getDomainAxis(0);
        java.awt.Paint paint35 = categoryPlot32.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double38 = dateAxis37.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = stackedBarRenderer3D40.getPositiveItemLabelPositionFallback();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D40.setBaseOutlinePaint((java.awt.Paint) color42);
        java.awt.Paint paint45 = stackedBarRenderer3D40.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double50 = dateAxis49.getUpperMargin();
        java.awt.Paint paint51 = dateAxis49.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        stackedBarRenderer3D40.drawRangeGridline(graphics2D46, categoryPlot47, (org.jfree.chart.axis.ValueAxis) dateAxis49, rectangle2D52, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean57 = dateAxis56.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit60 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date61 = dateAxis56.calculateLowestVisibleTickValue(dateTickUnit60);
        dateAxis49.setTickUnit(dateTickUnit60);
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke64 = polarPlot63.getRadiusGridlineStroke();
        dateAxis49.setTickMarkStroke(stroke64);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { dateAxis37, dateAxis49 };
        categoryPlot32.setRangeAxes(valueAxisArray66);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions70 = categoryAxis69.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot71 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis69.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot71);
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean75 = dateAxis74.isTickLabelsVisible();
        dateAxis74.setFixedAutoRange((double) (byte) 1);
        dateAxis74.setLowerBound(12.0d);
        java.text.DateFormat dateFormat80 = null;
        dateAxis74.setDateFormatOverride(dateFormat80);
        org.jfree.chart.axis.CategoryAxis categoryAxis83 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions84 = categoryAxis83.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot85 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis83.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot85);
        java.lang.Comparable comparable87 = multiplePiePlot85.getAggregatedItemsKey();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection88 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset90 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection88, 4);
        java.util.List list91 = taskSeriesCollection88.getRowKeys();
        multiplePiePlot85.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection88);
        try {
            layeredBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot32, categoryAxis69, (org.jfree.chart.axis.ValueAxis) dateAxis74, (org.jfree.data.category.CategoryDataset) taskSeriesCollection88, 4, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(categoryAxis34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(categoryLabelPositions70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions84);
        org.junit.Assert.assertTrue("'" + comparable87 + "' != '" + "Other" + "'", comparable87.equals("Other"));
        org.junit.Assert.assertNotNull(pieDataset90);
        org.junit.Assert.assertNotNull(list91);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) (short) 0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = ringPlot1.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot1.setLabelPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleEdge.TOP", (java.awt.Paint) color8, stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        ringPlot0.setDrawingSupplier(drawingSupplier3);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color6 = java.awt.Color.orange;
        waterfallBarRenderer5.setFirstBarPaint((java.awt.Paint) color6);
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str7 = rectangleEdge6.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge6);
        try {
            double double9 = categoryAxis1.getCategoryEnd((int) (byte) -1, (int) (byte) 100, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) 100, (double) (short) 0, true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedDimension((double) (-457));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.lang.Boolean boolean4 = stackedBarRenderer3D1.getSeriesVisible(1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D1.getPositiveItemLabelPosition(8, (int) (short) 100);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator11 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer9.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator11, false);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer15 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        minMaxCategoryRenderer15.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition17, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = minMaxCategoryRenderer15.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = minMaxCategoryRenderer15.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon23 = minMaxCategoryRenderer15.getObjectIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer24 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        minMaxCategoryRenderer24.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition26, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = minMaxCategoryRenderer24.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = minMaxCategoryRenderer24.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon32 = minMaxCategoryRenderer24.getObjectIcon();
        minMaxCategoryRenderer15.setObjectIcon(icon32);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        minMaxCategoryRenderer15.setSeriesStroke((int) (byte) 10, stroke35, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = stackedBarRenderer3D39.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = null;
        minMaxCategoryRenderer42.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition44, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection47 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range48 = minMaxCategoryRenderer42.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection47);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer50 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = null;
        minMaxCategoryRenderer50.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition52, true);
        java.awt.Stroke stroke56 = minMaxCategoryRenderer50.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer42.setSeriesStroke(10, stroke56, false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator60 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        minMaxCategoryRenderer42.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator60, true);
        stackedBarRenderer3D39.setSeriesURLGenerator(128, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator60);
        minMaxCategoryRenderer15.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator60);
        minMaxCategoryRenderer9.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator60, false);
        try {
            stackedBarRenderer3D1.setSeriesURLGenerator((int) (byte) -1, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator60, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(icon23);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator31);
        org.junit.Assert.assertNotNull(icon32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        ringPlot0.handleClick((int) (byte) 0, (int) (byte) -1, plotRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int6 = color5.getRed();
        ringPlot0.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        org.jfree.chart.LegendItem legendItem9 = stackedBarRenderer3D1.getLegendItem((int) 'a', 6);
        boolean boolean10 = stackedBarRenderer3D1.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint12 = stackedBarRenderer3D1.getSeriesOutlinePaint((int) '4');
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker30.setAlpha(0.0f);
        categoryMarker30.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = categoryMarker30.getLabelOffsetType();
        org.jfree.chart.util.BooleanList booleanList36 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        boolean boolean39 = ringPlot37.equals((java.lang.Object) (short) 0);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        ringPlot37.setLabelLinkPaint((java.awt.Paint) color40);
        boolean boolean42 = booleanList36.equals((java.lang.Object) color40);
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        boolean boolean45 = ringPlot43.equals((java.lang.Object) (short) 0);
        java.awt.Color color46 = java.awt.Color.YELLOW;
        ringPlot43.setLabelLinkPaint((java.awt.Paint) color46);
        java.awt.Paint paint49 = ringPlot43.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot43.setShadowYOffset((double) 10L);
        ringPlot43.setCircular(false);
        boolean boolean54 = booleanList36.equals((java.lang.Object) ringPlot43);
        java.awt.Paint paint55 = ringPlot43.getBackgroundPaint();
        categoryMarker30.setPaint(paint55);
        categoryPlot28.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        try {
            categoryPlot28.handleClick((int) 'a', (-1), plotRenderingInfo60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        int int3 = dateTickUnit2.getUnit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.TOP_RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextLine textLine3 = null;
        textBlock0.addLine(textLine3);
        java.lang.Object obj5 = null;
        boolean boolean6 = textBlock0.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray7, numberArray11, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "Apr", numberArray16);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 8, (short) 100, (-1.0d), 6 };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray22 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset24 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray16, numberArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis1.setDownArrow(shape8);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, 0.0d, (double) 3);
        org.jfree.data.Range range17 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, (-1.0d), (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        minMaxCategoryRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = minMaxCategoryRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = minMaxCategoryRenderer0.getSeriesToolTipGenerator((int) (short) 10);
        javax.swing.Icon icon16 = minMaxCategoryRenderer0.getObjectIcon();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(icon16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setMaximumBarWidth((double) (byte) -1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon4 = minMaxCategoryRenderer3.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon6 = minMaxCategoryRenderer5.getMinIcon();
        java.awt.Stroke stroke9 = minMaxCategoryRenderer5.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer3.setBaseOutlineStroke(stroke9, false);
        barRenderer3D0.setBaseOutlineStroke(stroke9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14, textAnchor15, (double) 0L);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition17);
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition17.getRotationAnchor();
        org.junit.Assert.assertNotNull(icon4);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        ringPlot9.removeChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(paint12);
        ringPlot9.setShadowPaint(paint12);
        ringPlot0.setLabelPaint(paint12);
        java.awt.Shape shape16 = ringPlot0.getLegendItemShape();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity19 = new org.jfree.chart.entity.TickLabelEntity(shape16, "", "RectangleAnchor.TOP_RIGHT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeCrosshairVisible(false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        try {
            categoryPlot28.drawOutline(graphics2D44, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType2);
        java.lang.String str4 = lengthAdjustmentType2.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CONTRACT" + "'", str4.equals("CONTRACT"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Shape shape5 = dateAxis1.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean8 = dateAxis7.isTickLabelsVisible();
        dateAxis7.setFixedAutoRange((double) (byte) 1);
        dateAxis7.setLowerBound(12.0d);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis7.setDownArrow(shape14);
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            int int12 = defaultIntervalCategoryDataset10.getRowIndex((java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.awt.Paint paint29 = categoryPlot28.getDomainGridlinePaint();
        categoryPlot28.setBackgroundAlpha((float) 1);
        categoryPlot28.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getUpperMargin();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        java.lang.Object obj12 = null;
        boolean boolean13 = ringPlot7.equals(obj12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot14.equals((java.lang.Object) (short) 0);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        ringPlot14.setLabelLinkPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot14.setLabelBackgroundPaint((java.awt.Paint) color19);
        ringPlot7.setBaseSectionOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font6, (java.awt.Paint) color19);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) (short) 0);
        java.awt.Color color26 = java.awt.Color.YELLOW;
        ringPlot23.setLabelLinkPaint((java.awt.Paint) color26);
        java.awt.Paint paint29 = ringPlot23.getSectionPaint((java.lang.Comparable) (-1L));
        double double30 = ringPlot23.getShadowYOffset();
        java.awt.Paint paint31 = ringPlot23.getBaseSectionPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("CONTRACT", font6, paint31, (float) (-1L), textMeasurer33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis3.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis3.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis3.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date16 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit15);
        dateAxis3.setMinimumDate(date16);
        long long18 = segmentedTimeline0.getTime(date16);
        long long19 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25200000L + "'", long19 == 25200000L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        double double3 = ringPlot0.getLabelGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot0.setURLGenerator(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsIncludedSize();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date11 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit10);
        java.util.Date date12 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline0.getSegment(date12);
        java.lang.Object obj14 = segmentedTimeline0.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25200000L + "'", long1 == 25200000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape7);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        ringPlot12.removeChangeListener(plotChangeListener13);
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot12.setBaseSectionPaint(paint15);
        java.awt.Stroke stroke17 = null;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity25 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (short) 1, shape21, "October", "");
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke27 = polarPlot26.getRadiusGridlineStroke();
        java.awt.Paint paint28 = null;
        try {
            org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem(attributedString0, "RectangleAnchor.TOP_RIGHT", "TextBlockAnchor.CENTER_LEFT", "hi!", false, shape7, true, paint10, true, paint15, stroke17, false, shape21, stroke27, paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.lang.Object obj5 = null;
        boolean boolean6 = ringPlot0.equals(obj5);
        double double7 = ringPlot0.getLabelGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        try {
            int int43 = defaultIntervalCategoryDataset40.getCategoryIndex((java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis1.draw(graphics2D6, 0.05d, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        int int6 = stackedBarRenderer3D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        double double11 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getUpperMargin();
        java.awt.Font font4 = categoryAxis2.getLabelFont();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP_RIGHT", font4);
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textLine5.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) 0.5f, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint10.toFixedWidth((double) (-16318469));
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(1);
        org.jfree.chart.LegendItem legendItem10 = minMaxCategoryRenderer0.getLegendItem((int) (byte) 0, (int) (byte) 1);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke12 = polarPlot11.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        minMaxCategoryRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        java.awt.Paint paint17 = minMaxCategoryRenderer0.getItemLabelPaint(255, (int) (byte) 0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(polarItemRenderer13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = lineAndShapeRenderer0.getSeriesToolTipGenerator(500);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.general.Dataset dataset5 = legendItemEntity4.getDataset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(dataset5);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor2, textAnchor3, (double) 31, categoryLabelWidthType5, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 0.05d, (java.lang.Comparable) 0.05d, (java.lang.Comparable) "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]");
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        ringPlot0.setIgnoreNullValues(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = ringPlot0.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener9 = null;
        taskSeriesCollection5.addChangeListener(datasetChangeListener9);
        legendItemEntity4.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection5);
        try {
            java.lang.Number number14 = taskSeriesCollection5.getEndValue(5, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Paint paint5 = legendTitle4.getBackgroundPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean8 = dateAxis7.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis7.setTickMarkPosition(dateTickMarkPosition9);
        dateAxis7.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = dateAxis7.getStandardTickUnits();
        boolean boolean14 = dateAxis7.isNegativeArrowVisible();
        boolean boolean15 = legendTitle4.equals((java.lang.Object) dateAxis7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha(0.0f);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) (short) 0);
        ringPlot4.setSeparatorsVisible(false);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot4);
        java.lang.Object obj10 = categoryMarker1.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot0.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        ringPlot9.removeChangeListener(plotChangeListener10);
        java.awt.Paint paint12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(paint12);
        ringPlot9.setShadowPaint(paint12);
        ringPlot0.setLabelPaint(paint12);
        double double16 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot19.equals((java.lang.Object) (short) 0);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        ringPlot19.setLabelLinkPaint((java.awt.Paint) color22);
        java.awt.Paint paint25 = ringPlot19.getSectionPaint((java.lang.Comparable) (-1L));
        double double26 = ringPlot19.getShadowYOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState29 = ringPlot0.initialise(graphics2D17, rectangle2D18, (org.jfree.chart.plot.PiePlot) ringPlot19, (java.lang.Integer) (-16318469), plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10L, (java.lang.Number) 10L);
        java.lang.Object obj3 = defaultKeyedValue2.clone();
        java.lang.Object obj4 = defaultKeyedValue2.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable2 = null;
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D0.setValue((java.lang.Number) 900000L, comparable2, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis3.setTickMarkPosition(dateTickMarkPosition4);
        java.awt.Paint paint6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) 100.0d);
        dateAxis3.setLabelInsets(rectangleInsets8);
        boolean boolean12 = piePlot3D0.equals((java.lang.Object) rectangleInsets8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.String[] strArray1 = new java.lang.String[] { "CONTRACT" };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray7, numberArray11, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "Apr", numberArray16);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray23, numberArray27, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "Apr", numberArray32);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset34 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray16, numberArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.lang.Boolean boolean6 = minMaxCategoryRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        java.awt.Paint paint8 = minMaxCategoryRenderer0.getSeriesPaint(10);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(6, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jun" + "'", str2.equals("Jun"));
    }
}

