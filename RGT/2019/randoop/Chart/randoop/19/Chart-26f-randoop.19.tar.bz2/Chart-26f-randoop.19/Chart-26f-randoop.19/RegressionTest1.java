import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        double double3 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setBase((double) 1L);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator6 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        stackedBarRenderer3D1.setSeriesURLGenerator((int) (byte) 1, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator6, true);
        double double9 = stackedBarRenderer3D1.getYOffset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin(9.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        int int7 = lineAndShapeRenderer2.getPassCount();
        lineAndShapeRenderer2.setSeriesItemLabelsVisible(255, false);
        boolean boolean11 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        boolean boolean7 = stackedBarRenderer3D1.isDrawBarOutline();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '#', (float) 4);
        stackedBarRenderer3D1.setBaseShape(shape10);
        stackedBarRenderer3D1.setAutoPopulateSeriesOutlinePaint(false);
        stackedBarRenderer3D1.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(1);
        boolean boolean9 = minMaxCategoryRenderer0.isSeriesVisibleInLegend(2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ERROR : Relative To String");
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        try {
            java.lang.Number number44 = defaultIntervalCategoryDataset40.getValue((java.lang.Comparable) "Layer.FOREGROUND", (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        double double8 = ringPlot0.getShadowYOffset();
        java.awt.Paint paint9 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        ringPlot0.setLabelPaint(paint10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D4.getPositiveItemLabelPositionFallback();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color6);
        stackedBarRenderer3D1.setWallPaint((java.awt.Paint) color6);
        double double9 = stackedBarRenderer3D1.getMinimumBarLength();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-16318469), 100.0d, 0.0d, (double) 900000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        try {
            java.lang.Number number13 = defaultIntervalCategoryDataset10.getValue((int) (byte) 100, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        categoryPlot28.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) (short) 0);
        java.awt.Color color5 = java.awt.Color.YELLOW;
        ringPlot2.setLabelLinkPaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = ringPlot2.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot2.setShadowYOffset((double) 10L);
        ringPlot2.setCircular(false);
        boolean boolean14 = ringPlot2.equals((java.lang.Object) (short) 100);
        java.awt.Font font15 = ringPlot2.getNoDataMessageFont();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 0, 0.0f);
        ringPlot2.setLegendItemShape(shape18);
        shapeList0.setShape(100, shape18);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        boolean boolean29 = categoryPlot28.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot28.getRangeAxisEdge(0);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        ringPlot1.removeChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot1.setBaseSectionPaint(paint4);
        boolean boolean6 = size2D0.equals((java.lang.Object) ringPlot1);
        try {
            ringPlot1.setInteriorGap((double) 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (28.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setMaximumBarWidth((double) (byte) -1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon4 = minMaxCategoryRenderer3.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon6 = minMaxCategoryRenderer5.getMinIcon();
        java.awt.Stroke stroke9 = minMaxCategoryRenderer5.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer3.setBaseOutlineStroke(stroke9, false);
        barRenderer3D0.setBaseOutlineStroke(stroke9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14, textAnchor15, (double) 0L);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition17);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        ringPlot19.removeChangeListener(plotChangeListener20);
        java.awt.Paint paint22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(paint22);
        ringPlot19.setShadowPaint(paint22);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        ringPlot19.setOutlinePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean28 = ringPlot19.equals((java.lang.Object) stroke27);
        boolean boolean29 = itemLabelPosition17.equals((java.lang.Object) boolean28);
        org.junit.Assert.assertNotNull(icon4);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        minMaxCategoryRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        piePlot3D0.setShadowYOffset((double) 32400097L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, 4);
        int int7 = taskSeriesCollection4.getSeriesCount();
        int int8 = taskSeriesCollection4.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double11 = categoryAxis10.getUpperMargin();
        java.awt.Font font12 = categoryAxis10.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis14.setTickMarkPosition(dateTickMarkPosition16);
        dateAxis14.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis14.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean24 = stackedBarRenderer3D22.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor26, textAnchor27, textAnchor28, (double) 0L);
        stackedBarRenderer3D22.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D22);
        java.lang.Comparable[] comparableArray40 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray41 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray42 = null;
        java.lang.Number[][] numberArray43 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset44 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray40, comparableArray41, numberArray42, numberArray43);
        categoryPlot32.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset44);
        categoryPlot32.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = stackedBarRenderer3D51.getPositiveItemLabelPositionFallback();
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D51.setBaseOutlinePaint((java.awt.Paint) color53);
        java.awt.Paint paint56 = stackedBarRenderer3D51.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double61 = dateAxis60.getUpperMargin();
        java.awt.Paint paint62 = dateAxis60.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        stackedBarRenderer3D51.drawRangeGridline(graphics2D57, categoryPlot58, (org.jfree.chart.axis.ValueAxis) dateAxis60, rectangle2D63, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean68 = dateAxis67.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit71 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date72 = dateAxis67.calculateLowestVisibleTickValue(dateTickUnit71);
        dateAxis60.setTickUnit(dateTickUnit71);
        org.jfree.chart.plot.PolarPlot polarPlot74 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke75 = polarPlot74.getRadiusGridlineStroke();
        dateAxis60.setTickMarkStroke(stroke75);
        java.lang.Comparable[] comparableArray83 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray84 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray85 = null;
        java.lang.Number[][] numberArray86 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset87 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray83, comparableArray84, numberArray85, numberArray86);
        try {
            layeredBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot32, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, (org.jfree.chart.axis.ValueAxis) dateAxis60, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset87, 100, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(comparableArray40);
        org.junit.Assert.assertNotNull(comparableArray41);
        org.junit.Assert.assertNull(itemLabelPosition52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(comparableArray83);
        org.junit.Assert.assertNotNull(comparableArray84);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean3 = stackedBarRenderer3D1.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = stackedBarRenderer3D1.getWallPaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, 4);
        int int11 = taskSeriesCollection8.getSeriesCount();
        int int12 = taskSeriesCollection8.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double15 = categoryAxis14.getUpperMargin();
        java.awt.Font font16 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis18.setTickMarkPosition(dateTickMarkPosition20);
        dateAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean28 = stackedBarRenderer3D26.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31, textAnchor32, (double) 0L);
        stackedBarRenderer3D26.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D26);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot36.getDomainAxis(0);
        categoryPlot36.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = categoryPlot36.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        int int43 = categoryAxis3D42.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer46 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = null;
        minMaxCategoryRenderer46.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition48, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection51 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range52 = minMaxCategoryRenderer46.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection51);
        taskSeriesCollection51.removeAll();
        java.lang.Comparable comparable54 = null;
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection51, comparable54);
        try {
            stackedBarRenderer3D1.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D42, (org.jfree.chart.axis.ValueAxis) dateAxis45, (org.jfree.data.category.CategoryDataset) taskSeriesCollection51, (int) (short) -1, (int) (byte) 100, (-16318469));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(categoryAxis38);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(pieDataset55);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType3, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str2.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getDomainMarkers((int) (short) 10, layer3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection6, 4);
        int int9 = taskSeriesCollection6.getSeriesCount();
        int int10 = taskSeriesCollection6.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double13 = categoryAxis12.getUpperMargin();
        java.awt.Font font14 = categoryAxis12.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean17 = dateAxis16.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition18 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis16.setTickMarkPosition(dateTickMarkPosition18);
        dateAxis16.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis16.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean26 = stackedBarRenderer3D24.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor28 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor28, textAnchor29, textAnchor30, (double) 0L);
        stackedBarRenderer3D24.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection6, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D24);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker36.setAlpha(0.0f);
        categoryMarker36.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = categoryMarker36.getLabelOffsetType();
        org.jfree.chart.util.BooleanList booleanList42 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        boolean boolean45 = ringPlot43.equals((java.lang.Object) (short) 0);
        java.awt.Color color46 = java.awt.Color.YELLOW;
        ringPlot43.setLabelLinkPaint((java.awt.Paint) color46);
        boolean boolean48 = booleanList42.equals((java.lang.Object) color46);
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot();
        boolean boolean51 = ringPlot49.equals((java.lang.Object) (short) 0);
        java.awt.Color color52 = java.awt.Color.YELLOW;
        ringPlot49.setLabelLinkPaint((java.awt.Paint) color52);
        java.awt.Paint paint55 = ringPlot49.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot49.setShadowYOffset((double) 10L);
        ringPlot49.setCircular(false);
        boolean boolean60 = booleanList42.equals((java.lang.Object) ringPlot49);
        java.awt.Paint paint61 = ringPlot49.getBackgroundPaint();
        categoryMarker36.setPaint(paint61);
        categoryPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36);
        org.jfree.chart.util.Layer layer64 = null;
        try {
            xYPlot0.addDomainMarker(5, (org.jfree.chart.plot.Marker) categoryMarker36, layer64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition18);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis1.setDownArrow(shape8);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange10, 0.0d, (double) 3);
        double double16 = range14.constrain((double) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle0.getVerticalAlignment();
        java.lang.String str4 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean7 = multiplePiePlot3.equals((java.lang.Object) itemLabelAnchor6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean9 = multiplePiePlot3.equals((java.lang.Object) lineAndShapeRenderer8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer8.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        java.awt.Paint paint31 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double34 = dateAxis33.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = stackedBarRenderer3D36.getPositiveItemLabelPositionFallback();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D36.setBaseOutlinePaint((java.awt.Paint) color38);
        java.awt.Paint paint41 = stackedBarRenderer3D36.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double46 = dateAxis45.getUpperMargin();
        java.awt.Paint paint47 = dateAxis45.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        stackedBarRenderer3D36.drawRangeGridline(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) dateAxis45, rectangle2D48, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean53 = dateAxis52.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date57 = dateAxis52.calculateLowestVisibleTickValue(dateTickUnit56);
        dateAxis45.setTickUnit(dateTickUnit56);
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke60 = polarPlot59.getRadiusGridlineStroke();
        dateAxis45.setTickMarkStroke(stroke60);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { dateAxis33, dateAxis45 };
        categoryPlot28.setRangeAxes(valueAxisArray62);
        org.jfree.chart.axis.AxisLocation axisLocation64 = null;
        try {
            categoryPlot28.setRangeAxisLocation(axisLocation64, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot6.getRangeAxisEdge();
        try {
            double double8 = categoryAxis1.getCategoryMiddle((-1), 5, rectangle2D5, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = polarPlot3.getRenderer();
        org.jfree.chart.plot.Plot plot9 = polarPlot3.getRootPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(polarItemRenderer8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) (short) 0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = ringPlot1.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot1.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.Plot plot10 = ringPlot1.getRootPlot();
        java.awt.Paint paint11 = ringPlot1.getOutlinePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D13.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D16.getPositiveItemLabelPositionFallback();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D16.setBaseOutlinePaint((java.awt.Paint) color18);
        stackedBarRenderer3D13.setWallPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer21 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = null;
        minMaxCategoryRenderer21.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition23, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = minMaxCategoryRenderer21.getLegendItemToolTipGenerator();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int28 = color27.getGreen();
        minMaxCategoryRenderer21.setBaseFillPaint((java.awt.Paint) color27);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer30 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint11, (java.awt.Paint) color18, (java.awt.Paint) color27);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection34 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection34, 4);
        int int37 = taskSeriesCollection34.getSeriesCount();
        int int38 = taskSeriesCollection34.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double41 = categoryAxis40.getUpperMargin();
        java.awt.Font font42 = categoryAxis40.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean45 = dateAxis44.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition46 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis44.setTickMarkPosition(dateTickMarkPosition46);
        dateAxis44.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = dateAxis44.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean54 = stackedBarRenderer3D52.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor56 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor58 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor56, textAnchor57, textAnchor58, (double) 0L);
        stackedBarRenderer3D52.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition60);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection34, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D52);
        java.awt.Paint paint63 = categoryPlot62.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions66 = categoryAxis65.getCategoryLabelPositions();
        categoryAxis65.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean71 = dateAxis70.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition72 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis70.setTickMarkPosition(dateTickMarkPosition72);
        dateAxis70.setPositiveArrowVisible(true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection76 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection76, 4);
        java.util.List list79 = taskSeriesCollection76.getRowKeys();
        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year81 = month80.getYear();
        java.util.Date date82 = year81.getEnd();
        int int83 = taskSeriesCollection76.getRowIndex((java.lang.Comparable) year81);
        try {
            waterfallBarRenderer30.drawItem(graphics2D31, categoryItemRendererState32, rectangle2D33, categoryPlot62, categoryAxis65, (org.jfree.chart.axis.ValueAxis) dateAxis70, (org.jfree.data.category.CategoryDataset) taskSeriesCollection76, 0, (int) 'a', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 128 + "'", int28 == 128);
        org.junit.Assert.assertNotNull(pieDataset36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition46);
        org.junit.Assert.assertNotNull(tickUnitSource50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor56);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(textAnchor58);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(categoryLabelPositions66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition72);
        org.junit.Assert.assertNotNull(pieDataset78);
        org.junit.Assert.assertNotNull(list79);
        org.junit.Assert.assertNotNull(year81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        dateAxis1.setLabelAngle((double) 2);
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 1, 9, (int) 'a', 6, dateFormat14);
        java.util.Date date16 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean21 = dateAxis20.isTickLabelsVisible();
        dateAxis20.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis20.setLabelFont(font24);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        dateAxis20.setLabelAngle((double) 2);
        java.text.DateFormat dateFormat33 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 1, 9, (int) 'a', 6, dateFormat33);
        java.util.Date date35 = dateAxis20.calculateHighestVisibleTickValue(dateTickUnit34);
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange();
        dateAxis20.setDefaultAutoRange((org.jfree.data.Range) dateRange36);
        org.jfree.data.Range range38 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange17, (org.jfree.data.Range) dateRange36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getGreen();
        int int2 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        boolean boolean1 = stackedAreaRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        java.lang.String str3 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        ringPlot6.removeChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot6.setBaseSectionPaint(paint9);
        ringPlot0.setLabelShadowPaint(paint9);
        float float12 = ringPlot0.getForegroundAlpha();
        org.jfree.chart.util.Rotation rotation13 = ringPlot0.getDirection();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(rotation13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes(0.0d, (double) 0, plotRenderingInfo4, point2D5);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle4.getSources();
        java.lang.Object obj27 = legendTitle4.clone();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        ringPlot30.removeChangeListener(plotChangeListener31);
        java.awt.Paint paint33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(paint33);
        ringPlot30.setShadowPaint(paint33);
        java.awt.Color color36 = java.awt.Color.YELLOW;
        ringPlot30.setOutlinePaint((java.awt.Paint) color36);
        double double38 = ringPlot30.getShadowYOffset();
        java.awt.Paint paint39 = ringPlot30.getLabelLinkPaint();
        try {
            java.lang.Object obj40 = legendTitle4.draw(graphics2D28, rectangle2D29, (java.lang.Object) ringPlot30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis6.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot8.getLegendItems();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot8);
        java.lang.Comparable comparable12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke14 = polarPlot13.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer15 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        minMaxCategoryRenderer15.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition17, true);
        org.jfree.chart.util.BooleanList booleanList20 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        boolean boolean23 = ringPlot21.equals((java.lang.Object) (short) 0);
        java.awt.Color color24 = java.awt.Color.YELLOW;
        ringPlot21.setLabelLinkPaint((java.awt.Paint) color24);
        boolean boolean26 = booleanList20.equals((java.lang.Object) color24);
        minMaxCategoryRenderer15.setBaseItemLabelPaint((java.awt.Paint) color24);
        polarPlot13.setAngleLabelPaint((java.awt.Paint) color24);
        java.awt.Font font29 = polarPlot13.getAngleLabelFont();
        try {
            categoryAxis1.setTickLabelFont(comparable12, font29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis2.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot4);
        boolean boolean6 = stackedBarRenderer0.equals((java.lang.Object) multiplePiePlot4);
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray15 = null;
        java.lang.Number[][] numberArray16 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset17 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray13, comparableArray14, numberArray15, numberArray16);
        try {
            org.jfree.data.Range range18 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparableArray13);
        org.junit.Assert.assertNotNull(comparableArray14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) "Apr");
        double double5 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "October");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        ringPlot0.handleClick((int) (byte) 0, (int) (byte) -1, plotRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int6 = color5.getRed();
        ringPlot0.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = ringPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setBottom((double) 31);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.shrink(rectangle2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        double double2 = axisState1.getCursor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("TextBlockAnchor.CENTER_LEFT", "SortOrder.DESCENDING", "August", image3, "Pie 3D Plot", "RectangleEdge.TOP", "{0}");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        projectInfo7.addOptionalLibrary("October");
        java.awt.Image image11 = null;
        projectInfo7.setLogo(image11);
        java.util.List list13 = projectInfo7.getContributors();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertNull(list13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        java.lang.Comparable comparable5 = null;
        java.awt.Paint paint6 = null;
        try {
            categoryAxis1.setTickLabelPaint(comparable5, paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        double double8 = ringPlot0.getShadowYOffset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = ringPlot0.getLegendLabelURLGenerator();
        ringPlot0.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNull(pieURLGenerator9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        minMaxCategoryRenderer4.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition6, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range10 = minMaxCategoryRenderer4.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer12 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        minMaxCategoryRenderer12.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition14, true);
        java.awt.Stroke stroke18 = minMaxCategoryRenderer12.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer4.setSeriesStroke(10, stroke18, false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator22 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        minMaxCategoryRenderer4.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator22, true);
        stackedBarRenderer3D1.setSeriesURLGenerator(128, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator22);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = stackedBarRenderer3D1.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = stackedBarRenderer3D30.getPositiveItemLabelPositionFallback();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D30.setBaseOutlinePaint((java.awt.Paint) color32);
        stackedBarRenderer3D30.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection37 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection37, 4);
        int int40 = taskSeriesCollection37.getSeriesCount();
        int int41 = taskSeriesCollection37.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double44 = categoryAxis43.getUpperMargin();
        java.awt.Font font45 = categoryAxis43.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean48 = dateAxis47.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition49 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis47.setTickMarkPosition(dateTickMarkPosition49);
        dateAxis47.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource53 = dateAxis47.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D55 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean57 = stackedBarRenderer3D55.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor59 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor61 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor59, textAnchor60, textAnchor61, (double) 0L);
        stackedBarRenderer3D55.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition63);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection37, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D55);
        java.awt.Paint paint66 = categoryPlot65.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean69 = dateAxis68.isTickLabelsVisible();
        dateAxis68.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        stackedBarRenderer3D30.drawRangeMarker(graphics2D36, categoryPlot65, (org.jfree.chart.axis.ValueAxis) dateAxis68, marker72, rectangle2D73);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState77 = stackedBarRenderer3D1.initialise(graphics2D27, rectangle2D28, categoryPlot65, 0, plotRenderingInfo76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition49);
        org.junit.Assert.assertNotNull(tickUnitSource53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor59);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNotNull(textAnchor61);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha(0.0f);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) (short) 0);
        ringPlot4.setSeparatorsVisible(false);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot4);
        double double10 = ringPlot4.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.25d + "'", double10 == 0.25d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        java.lang.Comparable comparable5 = multiplePiePlot3.getAggregatedItemsKey();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection6, 4);
        java.util.List list9 = taskSeriesCollection6.getRowKeys();
        multiplePiePlot3.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries12 = taskSeriesCollection6.getSeries((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.resizeRange((-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        boolean boolean8 = dateAxis1.isNegativeArrowVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str12 = rectangleEdge11.toString();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon14 = minMaxCategoryRenderer13.getMinIcon();
        java.awt.Color color15 = java.awt.Color.yellow;
        minMaxCategoryRenderer13.setGroupPaint((java.awt.Paint) color15);
        boolean boolean17 = rectangleEdge11.equals((java.lang.Object) minMaxCategoryRenderer13);
        try {
            double double18 = dateAxis1.java2DToValue((double) 1, rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.TOP" + "'", str12.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(icon14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        java.lang.String str8 = axisChangeEvent7.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = categoryAxis1.draw(graphics2D3, (double) (short) -1, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date11 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit10);
        java.util.Date date12 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit10);
        segmentedTimeline1.addException(date12);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segmentedTimeline1.getSegment(1577865599999L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(segment15);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setMaximumBarWidth((double) (byte) -1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon4 = minMaxCategoryRenderer3.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon6 = minMaxCategoryRenderer5.getMinIcon();
        java.awt.Stroke stroke9 = minMaxCategoryRenderer5.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer3.setBaseOutlineStroke(stroke9, false);
        barRenderer3D0.setBaseOutlineStroke(stroke9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14, textAnchor15, (double) 0L);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection20 = chartRenderingInfo19.getEntityCollection();
        boolean boolean21 = barRenderer3D0.equals((java.lang.Object) entityCollection20);
        org.junit.Assert.assertNotNull(icon4);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(entityCollection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean3 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) (short) 0);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        ringPlot4.setLabelLinkPaint((java.awt.Paint) color7);
        java.awt.Paint paint10 = ringPlot4.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot4.setShadowYOffset((double) 10L);
        ringPlot4.setCircular(false);
        boolean boolean16 = ringPlot4.equals((java.lang.Object) (short) 100);
        java.awt.Paint paint17 = ringPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseFillPaint(paint17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month10, shape12, "{0}", "ThreadContext");
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape12, paint17, stroke18, paint19);
        legendItem20.setSeriesKey((java.lang.Comparable) 128);
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection24 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection24, 4);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection24);
        int int28 = taskSeriesCollection24.getRowCount();
        legendItem20.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection24);
        legendItemCollection5.add(legendItem20);
        java.awt.Stroke stroke31 = legendItem20.getLineStroke();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(pieDataset26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setShadowXOffset((double) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        ringPlot3.setLegendItemShape(shape7);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        ringPlot0.setLabelLinksVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = ringPlot0.getDatasetGroup();
        boolean boolean7 = ringPlot0.equals((java.lang.Object) "RectangleAnchor.TOP_RIGHT");
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isTickLabelsVisible();
        dateAxis9.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis9.setLabelFont(font13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis9);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType16 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean18 = areaRendererEndType16.equals((java.lang.Object) itemLabelAnchor17);
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) axisChangeEvent15, (java.lang.Object) areaRendererEndType16);
        org.jfree.chart.axis.Axis axis20 = axisChangeEvent15.getAxis();
        ringPlot0.axisChanged(axisChangeEvent15);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(areaRendererEndType16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axis20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot28.getRangeAxisEdge((int) (byte) 1);
        double double46 = categoryPlot28.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Color color2 = java.awt.Color.yellow;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color2);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset(10.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D8.getPositiveItemLabelPositionFallback();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D8.setBaseOutlinePaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = stackedBarRenderer3D8.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double18 = dateAxis17.getUpperMargin();
        java.awt.Paint paint19 = dateAxis17.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        stackedBarRenderer3D8.drawRangeGridline(graphics2D14, categoryPlot15, (org.jfree.chart.axis.ValueAxis) dateAxis17, rectangle2D20, (double) 100L);
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        minMaxCategoryRenderer0.setSeriesShape((int) '#', shape23);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(6);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer28 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        minMaxCategoryRenderer28.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition30, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator33 = minMaxCategoryRenderer28.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = minMaxCategoryRenderer28.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon36 = minMaxCategoryRenderer28.getObjectIcon();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D38.setBase((double) 1L);
        stackedBarRenderer3D38.setMinimumBarLength((double) (short) 1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor44 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor44, textAnchor45, textAnchor46, (double) 0L);
        stackedBarRenderer3D38.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition48);
        minMaxCategoryRenderer28.setBasePositiveItemLabelPosition(itemLabelPosition48);
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition(5, itemLabelPosition48);
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator35);
        org.junit.Assert.assertNotNull(icon36);
        org.junit.Assert.assertNotNull(itemLabelAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(textAnchor46);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getUpperMargin();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) "Apr");
        boolean boolean6 = blockBorder0.equals((java.lang.Object) categoryAxis2);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        ringPlot1.removeChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot1.setBaseSectionPaint(paint4);
        boolean boolean6 = size2D0.equals((java.lang.Object) ringPlot1);
        java.lang.Object obj7 = ringPlot1.clone();
        ringPlot1.setCircular(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = segmentedTimeline11.getBaseTimeline();
        boolean boolean13 = categoryLabelPositions10.equals((java.lang.Object) segmentedTimeline11);
        java.lang.Object obj14 = segmentedTimeline11.clone();
        boolean boolean15 = ringPlot1.equals((java.lang.Object) segmentedTimeline11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("TextBlockAnchor.CENTER_LEFT", "SortOrder.DESCENDING", "August", image3, "Pie 3D Plot", "RectangleEdge.TOP", "{0}");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        projectInfo7.addOptionalLibrary("October");
        java.awt.Image image11 = null;
        projectInfo7.setLogo(image11);
        projectInfo7.setLicenceText("RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        java.awt.Paint paint3 = ringPlot0.getShadowPaint();
        boolean boolean4 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        double double3 = intervalMarker2.getEndValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        boolean boolean8 = dateAxis1.isNegativeArrowVisible();
        java.awt.Shape shape9 = null;
        try {
            dateAxis1.setRightArrow(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = stackedBarRenderer3D4.getPositiveItemLabelPositionFallback();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color6);
        stackedBarRenderer3D1.setWallPaint((java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection10, 4);
        int int13 = taskSeriesCollection10.getSeriesCount();
        int int14 = taskSeriesCollection10.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double17 = categoryAxis16.getUpperMargin();
        java.awt.Font font18 = categoryAxis16.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean21 = dateAxis20.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis20.setTickMarkPosition(dateTickMarkPosition22);
        dateAxis20.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource26 = dateAxis20.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean30 = stackedBarRenderer3D28.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor32 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor32, textAnchor33, textAnchor34, (double) 0L);
        stackedBarRenderer3D28.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection10, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D28);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot38.getDomainAxis(0);
        java.awt.Paint paint41 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer43 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        minMaxCategoryRenderer43.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition45, true);
        java.awt.Stroke stroke49 = minMaxCategoryRenderer43.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer43.setItemLabelAnchorOffset((double) 0);
        boolean boolean52 = minMaxCategoryRenderer43.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke54 = minMaxCategoryRenderer43.getSeriesOutlineStroke((int) (short) 0);
        categoryPlot38.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) minMaxCategoryRenderer43, false);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        try {
            stackedBarRenderer3D1.drawDomainGridline(graphics2D9, categoryPlot38, rectangle2D57, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(tickUnitSource26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(categoryAxis40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(stroke54);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(128);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D1.isDrawBarOutline();
        boolean boolean3 = stackedBarRenderer3D1.getIncludeBaseInRange();
        boolean boolean4 = textTitle0.equals((java.lang.Object) stackedBarRenderer3D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        ringPlot5.removeChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(paint8);
        ringPlot5.setShadowPaint(paint8);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        ringPlot5.setOutlinePaint((java.awt.Paint) color11);
        boolean boolean13 = textBlock4.equals((java.lang.Object) color11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape21 = textBlock4.calculateBounds(graphics2D14, (float) (short) 1, 0.0f, textBlockAnchor17, (float) (short) 100, (float) 3600000L, 1.0E-5d);
        java.awt.Stroke stroke22 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        stackedBarRenderer3D24.setWallPaint((java.awt.Paint) color25);
        org.jfree.chart.util.BooleanList booleanList27 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        boolean boolean30 = ringPlot28.equals((java.lang.Object) (short) 0);
        java.awt.Color color31 = java.awt.Color.YELLOW;
        ringPlot28.setLabelLinkPaint((java.awt.Paint) color31);
        boolean boolean33 = booleanList27.equals((java.lang.Object) color31);
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        ringPlot34.removeChangeListener(plotChangeListener35);
        java.awt.Paint paint37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder(paint37);
        ringPlot34.setShadowPaint(paint37);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        ringPlot34.setOutlinePaint((java.awt.Paint) color40);
        float[] floatArray47 = new float[] { 60000L, 3, 10.0f, 100, 4 };
        float[] floatArray48 = color40.getRGBComponents(floatArray47);
        float[] floatArray49 = color31.getColorComponents(floatArray47);
        float[] floatArray50 = color25.getRGBComponents(floatArray47);
        try {
            org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "", "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]", shape21, stroke22, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, 4);
        java.util.List list4 = taskSeriesCollection1.getRowKeys();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, (double) 60000L);
        org.jfree.data.Range range8 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        stackedBarRenderer3D5.setWallPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon9 = minMaxCategoryRenderer8.getMinIcon();
        java.awt.Color color10 = java.awt.Color.yellow;
        minMaxCategoryRenderer8.setGroupPaint((java.awt.Paint) color10);
        minMaxCategoryRenderer8.setItemLabelAnchorOffset(10.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D16.getPositiveItemLabelPositionFallback();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D16.setBaseOutlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint21 = stackedBarRenderer3D16.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double26 = dateAxis25.getUpperMargin();
        java.awt.Paint paint27 = dateAxis25.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        stackedBarRenderer3D16.drawRangeGridline(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D28, (double) 100L);
        java.awt.Shape shape31 = dateAxis25.getDownArrow();
        minMaxCategoryRenderer8.setSeriesShape((int) '#', shape31);
        boolean boolean33 = stackedBarRenderer3D5.equals((java.lang.Object) shape31);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer34 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        minMaxCategoryRenderer34.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition36, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = minMaxCategoryRenderer34.getLegendItemToolTipGenerator();
        java.awt.Paint paint40 = minMaxCategoryRenderer34.getBaseItemLabelPaint();
        java.lang.Boolean boolean42 = minMaxCategoryRenderer34.getSeriesItemLabelsVisible(128);
        java.awt.Stroke stroke44 = minMaxCategoryRenderer34.lookupSeriesStroke((int) ' ');
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        ringPlot45.removeChangeListener(plotChangeListener46);
        java.awt.Paint paint48 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder(paint48);
        ringPlot45.setShadowPaint(paint48);
        java.awt.Color color51 = java.awt.Color.YELLOW;
        ringPlot45.setOutlinePaint((java.awt.Paint) color51);
        double double53 = ringPlot45.getShadowYOffset();
        java.awt.Paint paint54 = ringPlot45.getSeparatorPaint();
        org.jfree.chart.JFreeChart jFreeChart55 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType56 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint54, jFreeChart55, chartChangeEventType56);
        try {
            org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem(attributedString0, "RectangleEdge.TOP", "ThreadContext", "", shape31, stroke44, paint54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(icon9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 4.0d + "'", double53 == 4.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(chartChangeEventType56);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Paint paint8 = lineAndShapeRenderer2.getItemLabelPaint((int) (short) 100, 7);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        boolean boolean15 = legendItem14.isShapeFilled();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition2);
        java.text.DateFormat dateFormat4 = null;
        dateAxis1.setDateFormatOverride(dateFormat4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        minMaxCategoryRenderer1.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition3, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = minMaxCategoryRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = minMaxCategoryRenderer1.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon9 = minMaxCategoryRenderer1.getObjectIcon();
        boolean boolean10 = unitType0.equals((java.lang.Object) minMaxCategoryRenderer1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(icon9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        polarPlot0.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((double) 0);
        double double3 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = ringPlot0.getShadowPaint();
        java.awt.Paint paint7 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis2.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot4);
        boolean boolean6 = stackedBarRenderer0.equals((java.lang.Object) multiplePiePlot4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(itemLabelPosition7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Size2D[width=0.0, height=0.0]");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = categoryPlot28.getOrientation();
        boolean boolean33 = categoryPlot28.isRangeZoomable();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setTickMarkOutsideLength((float) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.Year year3 = month0.getYear();
        java.util.Date date4 = month0.getEnd();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getFirstBarPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color3, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = waterfallBarRenderer0.getItemLabelGenerator((int) (short) 0, 31);
        java.awt.Paint paint9 = waterfallBarRenderer0.getFirstBarPaint();
        java.awt.Paint paint10 = waterfallBarRenderer0.getNegativeBarPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        java.lang.Comparable comparable8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, comparable8);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) (byte) -1, 10.0d, (int) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset13, (java.lang.Comparable) (-457), (double) 9, 31);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        int int3 = defaultKeyedValues0.getIndex((java.lang.Comparable) 0.05d);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str5 = sortOrder4.toString();
        defaultKeyedValues0.sortByKeys(sortOrder4);
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder7);
        try {
            java.lang.Comparable comparable10 = defaultKeyedValues0.getKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SortOrder.ASCENDING" + "'", str5.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        java.lang.String str11 = rectangleConstraint10.toString();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean14 = dateAxis13.isTickLabelsVisible();
        dateAxis13.setFixedAutoRange((double) (byte) 1);
        dateAxis13.setLowerBound(12.0d);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis13.setDownArrow(shape20);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        dateAxis13.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range26 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange22, 0.0d, (double) 3);
        double double28 = dateRange22.constrain(12.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange22);
        java.lang.String str30 = rectangleConstraint29.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]" + "'", str11.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]" + "'", str30.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        boolean boolean2 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        minMaxCategoryRenderer0.setSeriesVisibleInLegend(3, (java.lang.Boolean) true, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int12 = color11.getRed();
        minMaxCategoryRenderer0.setBaseOutlinePaint((java.awt.Paint) color11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState15 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle16.setPadding(rectangleInsets17);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle16.getBounds();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection20, 4);
        int int23 = taskSeriesCollection20.getSeriesCount();
        int int24 = taskSeriesCollection20.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double27 = categoryAxis26.getUpperMargin();
        java.awt.Font font28 = categoryAxis26.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean31 = dateAxis30.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis30.setTickMarkPosition(dateTickMarkPosition32);
        dateAxis30.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis30.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean40 = stackedBarRenderer3D38.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor42 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor42, textAnchor43, textAnchor44, (double) 0L);
        stackedBarRenderer3D38.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition46);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection20, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D38);
        categoryPlot48.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double52 = categoryAxis51.getUpperMargin();
        categoryAxis51.setLowerMargin((double) 1.0f);
        java.lang.String str56 = categoryAxis51.getCategoryLabelToolTip((java.lang.Comparable) '4');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions57 = categoryAxis51.getCategoryLabelPositions();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean60 = dateAxis59.isTickLabelsVisible();
        dateAxis59.setFixedAutoRange((double) (byte) 1);
        dateAxis59.setLowerBound(12.0d);
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis59.setDownArrow(shape66);
        org.jfree.data.time.DateRange dateRange68 = new org.jfree.data.time.DateRange();
        dateAxis59.setDefaultAutoRange((org.jfree.data.Range) dateRange68);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection70 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset72 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection70, 4);
        java.lang.Number number73 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection70);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D14, categoryItemRendererState15, rectangle2D19, categoryPlot48, categoryAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis59, (org.jfree.data.category.CategoryDataset) taskSeriesCollection70, 4, 5, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(categoryLabelPositions57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(pieDataset72);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 0.0d + "'", number73.equals(0.0d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        javax.swing.Icon icon5 = minMaxCategoryRenderer0.getMaxIcon();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        minMaxCategoryRenderer0.setSeriesOutlineStroke((int) '4', stroke7, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot10.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot10.getAxisOffset();
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(paint13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        double double17 = rectangleInsets15.trimHeight((double) 100L);
        double double19 = rectangleInsets15.calculateLeftInset((double) 3);
        xYPlot10.setAxisOffset(rectangleInsets15);
        boolean boolean21 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = xYPlot10.getOrientation();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.axis.AxisCollection axisCollection25 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list26 = axisCollection25.getAxesAtTop();
        java.util.List list27 = axisCollection25.getAxesAtTop();
        xYPlot10.drawDomainTickBands(graphics2D23, rectangle2D24, list27);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer29 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon30 = minMaxCategoryRenderer29.getMinIcon();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        minMaxCategoryRenderer29.setSeriesFillPaint(0, (java.awt.Paint) color32, true);
        xYPlot10.setDomainZeroBaselinePaint((java.awt.Paint) color32);
        minMaxCategoryRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot10);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker38.setAlpha(0.0f);
        categoryMarker38.setDrawAsLine(true);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker38, layer43);
        org.junit.Assert.assertNotNull(icon5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 98.0d + "'", double17 == 98.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(icon30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(layer43);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        javax.swing.Icon icon5 = minMaxCategoryRenderer0.getMaxIcon();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        minMaxCategoryRenderer0.setSeriesOutlineStroke((int) '4', stroke7, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot10.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot10.getAxisOffset();
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(paint13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        double double17 = rectangleInsets15.trimHeight((double) 100L);
        double double19 = rectangleInsets15.calculateLeftInset((double) 3);
        xYPlot10.setAxisOffset(rectangleInsets15);
        boolean boolean21 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = xYPlot10.getOrientation();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.axis.AxisCollection axisCollection25 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list26 = axisCollection25.getAxesAtTop();
        java.util.List list27 = axisCollection25.getAxesAtTop();
        xYPlot10.drawDomainTickBands(graphics2D23, rectangle2D24, list27);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer29 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon30 = minMaxCategoryRenderer29.getMinIcon();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        minMaxCategoryRenderer29.setSeriesFillPaint(0, (java.awt.Paint) color32, true);
        xYPlot10.setDomainZeroBaselinePaint((java.awt.Paint) color32);
        minMaxCategoryRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot10);
        java.awt.Paint paint38 = minMaxCategoryRenderer0.getSeriesFillPaint(255);
        org.junit.Assert.assertNotNull(icon5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 98.0d + "'", double17 == 98.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(icon30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        ringPlot3.removeChangeListener(plotChangeListener4);
        ringPlot3.setLabelLinksVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup8 = ringPlot3.getDatasetGroup();
        boolean boolean9 = dateAxis1.hasListener((java.util.EventListener) ringPlot3);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font14 = categoryAxis11.getTickLabelFont((java.lang.Comparable) "Apr");
        ringPlot3.setLabelFont(font14);
        int int16 = ringPlot3.getPieIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setLeft((double) (-16318469));
        axisSpace0.setBottom((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double33 = categoryAxis32.getUpperMargin();
        java.awt.Font font34 = categoryAxis32.getLabelFont();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer35 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        minMaxCategoryRenderer35.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition37, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator40 = minMaxCategoryRenderer35.getLegendItemToolTipGenerator();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int42 = color41.getGreen();
        minMaxCategoryRenderer35.setBaseFillPaint((java.awt.Paint) color41);
        java.awt.Paint paint44 = minMaxCategoryRenderer35.getBaseOutlinePaint();
        categoryAxis32.setAxisLinePaint(paint44);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double48 = categoryAxis47.getUpperMargin();
        java.lang.String str49 = categoryAxis47.getLabel();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double52 = categoryAxis51.getUpperMargin();
        java.awt.Font font53 = categoryAxis51.getLabelFont();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer54 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = null;
        minMaxCategoryRenderer54.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition56, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator59 = minMaxCategoryRenderer54.getLegendItemToolTipGenerator();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int61 = color60.getGreen();
        minMaxCategoryRenderer54.setBaseFillPaint((java.awt.Paint) color60);
        java.awt.Paint paint63 = minMaxCategoryRenderer54.getBaseOutlinePaint();
        categoryAxis51.setAxisLinePaint(paint63);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions67 = categoryAxis66.getCategoryLabelPositions();
        categoryAxis66.setTickMarkOutsideLength((float) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions72 = categoryAxis71.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot73 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis71.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot73);
        org.jfree.chart.LegendItemCollection legendItemCollection75 = multiplePiePlot73.getLegendItems();
        categoryAxis66.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot73);
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions79 = categoryAxis78.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray80 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis32, categoryAxis47, categoryAxis51, categoryAxis66, categoryAxis78 };
        categoryPlot28.setDomainAxes(categoryAxisArray80);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 128 + "'", int61 == 128);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(categoryLabelPositions67);
        org.junit.Assert.assertNotNull(categoryLabelPositions72);
        org.junit.Assert.assertNotNull(legendItemCollection75);
        org.junit.Assert.assertNotNull(categoryLabelPositions79);
        org.junit.Assert.assertNotNull(categoryAxisArray80);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("TextBlockAnchor.CENTER_LEFT", "SortOrder.DESCENDING", "August", image3, "Pie 3D Plot", "RectangleEdge.TOP", "{0}");
        projectInfo7.addOptionalLibrary("August");
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getUpperMargin();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        java.lang.Object obj12 = null;
        boolean boolean13 = ringPlot7.equals(obj12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot14.equals((java.lang.Object) (short) 0);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        ringPlot14.setLabelLinkPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot14.setLabelBackgroundPaint((java.awt.Paint) color19);
        ringPlot7.setBaseSectionOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font6, (java.awt.Paint) color19);
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getAngleGridlinePaint();
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.TOP_RIGHT", font6, paint24);
        java.util.List list26 = textBlock25.getLines();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] { 1561964399999L, 1.0f, 1577865599999L, 8.0d };
        try {
            defaultIntervalCategoryDataset10.setCategoryKeys(comparableArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        blockParams0.setGenerateEntities(true);
        boolean boolean4 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        minMaxCategoryRenderer1.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition3, true);
        org.jfree.chart.util.BooleanList booleanList6 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        boolean boolean12 = booleanList6.equals((java.lang.Object) color10);
        minMaxCategoryRenderer1.setBaseItemLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = minMaxCategoryRenderer1.getLegendItemLabelGenerator();
        waterfallBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection17 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection17, 4);
        int int20 = taskSeriesCollection17.getSeriesCount();
        int int21 = taskSeriesCollection17.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double24 = categoryAxis23.getUpperMargin();
        java.awt.Font font25 = categoryAxis23.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean28 = dateAxis27.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition29 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis27.setTickMarkPosition(dateTickMarkPosition29);
        dateAxis27.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = dateAxis27.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean37 = stackedBarRenderer3D35.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor39 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor39, textAnchor40, textAnchor41, (double) 0L);
        stackedBarRenderer3D35.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection17, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot45.getDomainAxis(0);
        categoryPlot45.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot45.getRangeAxisLocation();
        java.awt.Paint paint50 = categoryPlot45.getRangeCrosshairPaint();
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle51.setPadding(rectangleInsets52);
        java.awt.geom.Rectangle2D rectangle2D54 = textTitle51.getBounds();
        try {
            waterfallBarRenderer0.drawBackground(graphics2D16, categoryPlot45, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition29);
        org.junit.Assert.assertNotNull(tickUnitSource33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor39);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(categoryAxis47);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getColumnCount();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month1, shape3, "{0}", "ThreadContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month1.next();
        int int9 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) month1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double6 = categoryAxis5.getUpperMargin();
        java.awt.Font font7 = categoryAxis5.getLabelFont();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP_RIGHT", font7);
        polarPlot0.setAngleLabelFont(font7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month2, shape4, "{0}", "ThreadContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.next();
        boolean boolean10 = sortOrder0.equals((java.lang.Object) month2);
        java.lang.String str11 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "SortOrder.DESCENDING" + "'", str11.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        int int2 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean9 = size2D6.equals((java.lang.Object) numberTickUnit8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 4.0d, (double) 2, rectangleAnchor12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        try {
            double double15 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor3, 5, 0, rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean7 = multiplePiePlot3.equals((java.lang.Object) itemLabelAnchor6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean9 = multiplePiePlot3.equals((java.lang.Object) lineAndShapeRenderer8);
        boolean boolean12 = lineAndShapeRenderer8.getItemShapeVisible(7, (int) (short) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(1);
        org.jfree.chart.LegendItem legendItem10 = minMaxCategoryRenderer0.getLegendItem((int) (byte) 0, (int) (byte) 1);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke12 = polarPlot11.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = polarPlot11.getRenderer();
        minMaxCategoryRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        polarPlot11.clearCornerTextItems();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(polarItemRenderer13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        double double5 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis2.setTickMarkPosition(dateTickMarkPosition4);
        dateAxis2.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date15 = dateAxis10.calculateLowestVisibleTickValue(dateTickUnit14);
        dateAxis2.setMinimumDate(date15);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        minMaxCategoryRenderer17.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition19, true);
        org.jfree.chart.util.BooleanList booleanList22 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) (short) 0);
        java.awt.Color color26 = java.awt.Color.YELLOW;
        ringPlot23.setLabelLinkPaint((java.awt.Paint) color26);
        boolean boolean28 = booleanList22.equals((java.lang.Object) color26);
        minMaxCategoryRenderer17.setBaseItemLabelPaint((java.awt.Paint) color26);
        dateAxis2.setTickMarkPaint((java.awt.Paint) color26);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        boolean boolean11 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtTop();
        java.util.List list17 = axisCollection15.getAxesAtTop();
        xYPlot0.drawDomainTickBands(graphics2D13, rectangle2D14, list17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke19);
        java.awt.Stroke stroke21 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        xYPlot0.removeChangeListener(plotChangeListener22);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double5 = categoryAxis4.getUpperMargin();
        java.awt.Font font6 = categoryAxis4.getLabelFont();
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP_RIGHT", font6);
        java.awt.Color color8 = java.awt.Color.yellow;
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("October", font6, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker11.setAlpha(0.0f);
        categoryMarker11.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = categoryMarker11.getLabelOffsetType();
        org.jfree.chart.util.BooleanList booleanList17 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        boolean boolean20 = ringPlot18.equals((java.lang.Object) (short) 0);
        java.awt.Color color21 = java.awt.Color.YELLOW;
        ringPlot18.setLabelLinkPaint((java.awt.Paint) color21);
        boolean boolean23 = booleanList17.equals((java.lang.Object) color21);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        boolean boolean26 = ringPlot24.equals((java.lang.Object) (short) 0);
        java.awt.Color color27 = java.awt.Color.YELLOW;
        ringPlot24.setLabelLinkPaint((java.awt.Paint) color27);
        java.awt.Paint paint30 = ringPlot24.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot24.setShadowYOffset((double) 10L);
        ringPlot24.setCircular(false);
        boolean boolean35 = booleanList17.equals((java.lang.Object) ringPlot24);
        java.awt.Paint paint36 = ringPlot24.getBackgroundPaint();
        categoryMarker11.setPaint(paint36);
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("Size2D[width=0.0, height=0.0]", font6, paint36, 0.0f);
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "Size2D[width=0.0, height=0.0]", jFreeChart40, chartChangeEventType41);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "SortOrder.ASCENDING", "Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition2);
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        boolean boolean8 = rectangleInsets6.equals((java.lang.Object) 100.0d);
        dateAxis1.setLabelInsets(rectangleInsets6);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        dateAxis1.setLeftArrow(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
        org.jfree.chart.entity.EntityCollection entityCollection3 = chartRenderingInfo1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker30.setAlpha(0.0f);
        categoryMarker30.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = categoryMarker30.getLabelOffsetType();
        org.jfree.chart.util.BooleanList booleanList36 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        boolean boolean39 = ringPlot37.equals((java.lang.Object) (short) 0);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        ringPlot37.setLabelLinkPaint((java.awt.Paint) color40);
        boolean boolean42 = booleanList36.equals((java.lang.Object) color40);
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        boolean boolean45 = ringPlot43.equals((java.lang.Object) (short) 0);
        java.awt.Color color46 = java.awt.Color.YELLOW;
        ringPlot43.setLabelLinkPaint((java.awt.Paint) color46);
        java.awt.Paint paint49 = ringPlot43.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot43.setShadowYOffset((double) 10L);
        ringPlot43.setCircular(false);
        boolean boolean54 = booleanList36.equals((java.lang.Object) ringPlot43);
        java.awt.Paint paint55 = ringPlot43.getBackgroundPaint();
        categoryMarker30.setPaint(paint55);
        categoryPlot28.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        try {
            categoryMarker30.setLabelOffsetType(lengthAdjustmentType58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        java.lang.Comparable comparable8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, comparable8);
        try {
            java.lang.Number number12 = taskSeriesCollection5.getStartValue((int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, 4);
        int int11 = taskSeriesCollection8.getSeriesCount();
        int int12 = taskSeriesCollection8.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double15 = categoryAxis14.getUpperMargin();
        java.awt.Font font16 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis18.setTickMarkPosition(dateTickMarkPosition20);
        dateAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean28 = stackedBarRenderer3D26.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31, textAnchor32, (double) 0L);
        stackedBarRenderer3D26.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D26);
        java.awt.Paint paint37 = categoryPlot36.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean40 = dateAxis39.isTickLabelsVisible();
        dateAxis39.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D7, categoryPlot36, (org.jfree.chart.axis.ValueAxis) dateAxis39, marker43, rectangle2D44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean48 = dateAxis47.isTickLabelsVisible();
        dateAxis47.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis47.setLabelFont(font51);
        dateAxis39.setTickLabelFont(font51);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0" + "'", str4.equals("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        ringPlot0.setLegendItemShape(shape4);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, 0.4d, (float) 28800000L, (float) 6);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("October");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name October, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isInverted();
        boolean boolean5 = stackedBarRenderer3D1.equals((java.lang.Object) boolean4);
        java.lang.Object obj6 = null;
        boolean boolean7 = stackedBarRenderer3D1.equals(obj6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.lang.Boolean boolean4 = stackedBarRenderer3D1.getSeriesVisible(1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D1.getPositiveItemLabelPosition(8, (int) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis3.setTickMarkPosition(dateTickMarkPosition5);
        dateAxis3.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis3.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date16 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit15);
        dateAxis3.setMinimumDate(date16);
        long long18 = segmentedTimeline0.getTime(date16);
        long long21 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 0, (long) '#');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        int int9 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font13 = categoryAxis11.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28, textAnchor29, (double) 0L);
        stackedBarRenderer3D23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot33.getDomainAxis(0);
        java.awt.Paint paint36 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double39 = dateAxis38.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = stackedBarRenderer3D41.getPositiveItemLabelPositionFallback();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D41.setBaseOutlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = stackedBarRenderer3D41.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double51 = dateAxis50.getUpperMargin();
        java.awt.Paint paint52 = dateAxis50.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        stackedBarRenderer3D41.drawRangeGridline(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D53, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean58 = dateAxis57.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date62 = dateAxis57.calculateLowestVisibleTickValue(dateTickUnit61);
        dateAxis50.setTickUnit(dateTickUnit61);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke65 = polarPlot64.getRadiusGridlineStroke();
        dateAxis50.setTickMarkStroke(stroke65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { dateAxis38, dateAxis50 };
        categoryPlot33.setRangeAxes(valueAxisArray67);
        xYPlot0.setDomainAxes(valueAxisArray67);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot0.getRangeAxisLocation((-457));
        double double72 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("Size2D[width=0.0, height=0.0]");
        java.lang.String str2 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("Size2D[width=0.0, height=0.0]");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        java.lang.String str6 = unknownKeyException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]" + "'", str2.equals("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]" + "'", str6.equals("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) (short) 100);
        java.util.Date date3 = null;
        try {
            boolean boolean4 = segmentedTimeline0.containsDomainValue(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        java.text.AttributedString attributedString15 = legendItem14.getAttributedLabel();
        java.awt.Paint paint16 = legendItem14.getFillPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(attributedString15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        double double3 = ringPlot0.getLabelGap();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean3 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesShapesFilled(28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        intervalMarker2.setEndValue((double) 32400097L);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7, textAnchor8, (double) 0L);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean12 = textAnchor8.equals((java.lang.Object) standardGradientPaintTransformer11);
        intervalMarker2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis1.setDownArrow(shape8);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.util.List list3 = blockContainer2.getBlocks();
        axisState1.setTicks(list3);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        int int11 = defaultIntervalCategoryDataset10.getCategoryCount();
        try {
            java.lang.Comparable comparable13 = defaultIntervalCategoryDataset10.getRowKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle8.setPadding(rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean15 = size2D12.equals((java.lang.Object) numberTickUnit14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, 4.0d, (double) 2, rectangleAnchor18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle20.setPadding(rectangleInsets21);
        textTitle20.setExpandToFitSpace(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = textTitle20.getPosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = categoryAxis1.draw(graphics2D6, 0.0d, rectangle2D11, rectangle2D19, rectangleEdge25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) (short) 0);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        ringPlot4.setLabelLinkPaint((java.awt.Paint) color7);
        java.lang.Object obj9 = null;
        boolean boolean10 = ringPlot4.equals(obj9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) (short) 0);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        ringPlot11.setLabelLinkPaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot11.setLabelBackgroundPaint((java.awt.Paint) color16);
        ringPlot4.setBaseSectionOutlinePaint((java.awt.Paint) color16);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot19.equals((java.lang.Object) (short) 0);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        ringPlot19.setLabelLinkPaint((java.awt.Paint) color22);
        java.awt.Paint paint25 = ringPlot19.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot19.setLabelPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        ringPlot28.removeChangeListener(plotChangeListener29);
        java.awt.Paint paint31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder(paint31);
        ringPlot28.setShadowPaint(paint31);
        ringPlot19.setLabelPaint(paint31);
        java.awt.Shape shape35 = ringPlot19.getLegendItemShape();
        ringPlot4.setLegendItemShape(shape35);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot38.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = xYPlot38.getAxisOffset();
        java.awt.Paint paint41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder(paint41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = blockBorder42.getInsets();
        double double45 = rectangleInsets43.trimHeight((double) 100L);
        double double47 = rectangleInsets43.calculateLeftInset((double) 3);
        xYPlot38.setAxisOffset(rectangleInsets43);
        boolean boolean49 = xYPlot38.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = xYPlot38.getOrientation();
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.axis.AxisCollection axisCollection53 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list54 = axisCollection53.getAxesAtTop();
        java.util.List list55 = axisCollection53.getAxesAtTop();
        xYPlot38.drawDomainTickBands(graphics2D51, rectangle2D52, list55);
        java.awt.Stroke stroke57 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot38.setDomainZeroBaselineStroke(stroke57);
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int60 = color59.getTransparency();
        try {
            org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem(attributedString0, "WMAP_Plot", "ERROR : Relative To String", "Apr", shape35, paint37, stroke57, (java.awt.Paint) color59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 98.0d + "'", double45 == 98.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month0, shape2, "{0}", "ThreadContext");
        categoryLabelEntity6.setToolTipText("Other");
        java.lang.Comparable comparable9 = categoryLabelEntity6.getKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(comparable9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        boolean boolean29 = categoryAxis6.isAxisLineVisible();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, 4);
        int int11 = taskSeriesCollection8.getSeriesCount();
        int int12 = taskSeriesCollection8.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double15 = categoryAxis14.getUpperMargin();
        java.awt.Font font16 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis18.setTickMarkPosition(dateTickMarkPosition20);
        dateAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean28 = stackedBarRenderer3D26.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31, textAnchor32, (double) 0L);
        stackedBarRenderer3D26.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D26);
        java.awt.Paint paint37 = categoryPlot36.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean40 = dateAxis39.isTickLabelsVisible();
        dateAxis39.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D7, categoryPlot36, (org.jfree.chart.axis.ValueAxis) dateAxis39, marker43, rectangle2D44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot36.getLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier47 = categoryPlot36.getDrawingSupplier();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(drawingSupplier47);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        java.lang.String str11 = ringPlot0.getNoDataMessage();
        ringPlot0.setInnerSeparatorExtension((double) 100L);
        ringPlot0.setBackgroundImageAlignment(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsIncludedSize();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date11 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit10);
        java.util.Date date12 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline0.getSegment(date12);
        boolean boolean14 = segment13.inExcludeSegments();
        boolean boolean15 = segment13.inExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long17 = segmentedTimeline16.getSegmentsIncludedSize();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean20 = dateAxis19.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean23 = dateAxis22.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date27 = dateAxis22.calculateLowestVisibleTickValue(dateTickUnit26);
        java.util.Date date28 = dateAxis19.calculateHighestVisibleTickValue(dateTickUnit26);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment29 = segmentedTimeline16.getSegment(date28);
        boolean boolean30 = segment13.contains(segment29);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25200000L + "'", long1 == 25200000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 25200000L + "'", long17 == 25200000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(segment29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        minMaxCategoryRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color3, true);
        java.awt.Stroke stroke7 = minMaxCategoryRenderer0.lookupSeriesOutlineStroke(0);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        double double10 = size2D9.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, 0.2d, (double) 500, rectangleAnchor13);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection15 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection15, 4);
        int int18 = taskSeriesCollection15.getSeriesCount();
        int int19 = taskSeriesCollection15.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double22 = categoryAxis21.getUpperMargin();
        java.awt.Font font23 = categoryAxis21.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean26 = dateAxis25.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition27 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis25.setTickMarkPosition(dateTickMarkPosition27);
        dateAxis25.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = dateAxis25.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean35 = stackedBarRenderer3D33.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor37, textAnchor38, textAnchor39, (double) 0L);
        stackedBarRenderer3D33.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection15, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D33);
        java.lang.Comparable[] comparableArray51 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray52 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray53 = null;
        java.lang.Number[][] numberArray54 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray51, comparableArray52, numberArray53, numberArray54);
        categoryPlot43.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset55);
        boolean boolean57 = categoryPlot43.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace58 = new org.jfree.chart.axis.AxisSpace();
        double double59 = axisSpace58.getRight();
        categoryPlot43.setFixedDomainAxisSpace(axisSpace58);
        categoryPlot43.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState65 = minMaxCategoryRenderer0.initialise(graphics2D8, rectangle2D14, categoryPlot43, 7, plotRenderingInfo64);
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition27);
        org.junit.Assert.assertNotNull(tickUnitSource31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(comparableArray51);
        org.junit.Assert.assertNotNull(comparableArray52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRendererState65);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        boolean boolean7 = multiplePiePlot3.equals((java.lang.Object) itemLabelAnchor6);
        org.jfree.chart.util.TableOrder tableOrder8 = null;
        try {
            multiplePiePlot3.setDataExtractOrder(tableOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("CONTRACT");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) 0, (float) 32400097L, (double) '4', 1.0f, (float) 128);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        ringPlot0.setBackgroundImageAlignment((int) 'a');
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        java.awt.Stroke stroke31 = categoryPlot28.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        boolean boolean8 = polarPlot3.isAngleGridlinesVisible();
        boolean boolean9 = polarPlot3.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(128, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 0, 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, (double) 3600000L, 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(10.0d, 0.05d, (double) 100, (double) 9);
        java.awt.Paint paint15 = blockBorder14.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "August", "ThreadContext", "Jun", shape6, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint15);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long1 = segmentedTimeline0.getSegmentsIncludedSize();
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
//        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
//        boolean boolean7 = dateAxis6.isInverted();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(2, 1);
//        java.util.Date date11 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit10);
//        java.util.Date date12 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit10);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline0.getSegment(date12);
//        segment13.moveIndexToStart();
//        long long15 = segment13.getSegmentStart();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25200000L + "'", long1 == 25200000L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(segment13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-58500000L) + "'", long15 == (-58500000L));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("TextBlockAnchor.CENTER_LEFT", "SortOrder.DESCENDING", "August", image3, "Pie 3D Plot", "RectangleEdge.TOP", "{0}");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        projectInfo7.addOptionalLibrary("October");
        java.awt.Image image11 = projectInfo7.getLogo();
        java.awt.Image image12 = projectInfo7.getLogo();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNull(image12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle4.getSources();
        java.lang.Object obj27 = legendTitle4.clone();
        legendTitle4.setID("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        double double4 = intervalMarker2.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNull(gradientPaintTransformer5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        double double8 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator4 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer2.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator4, false);
        java.text.NumberFormat numberFormat7 = standardCategoryToolTipGenerator4.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator8 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("2019", numberFormat7);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator9 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", numberFormat7);
        java.lang.Object obj10 = null;
        boolean boolean11 = intervalCategoryToolTipGenerator9.equals(obj10);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        minMaxCategoryRenderer0.setSeriesVisibleInLegend(3, (java.lang.Boolean) true, false);
        minMaxCategoryRenderer0.setSeriesItemLabelsVisible((int) 'a', false);
        java.awt.Shape shape16 = minMaxCategoryRenderer0.getItemShape(1, 10);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        size2D0.height = 0.0d;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D11.setMaximumBarWidth((double) (byte) -1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon15 = minMaxCategoryRenderer14.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer16 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon17 = minMaxCategoryRenderer16.getMinIcon();
        java.awt.Stroke stroke20 = minMaxCategoryRenderer16.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer14.setBaseOutlineStroke(stroke20, false);
        barRenderer3D11.setBaseOutlineStroke(stroke20);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer24 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        minMaxCategoryRenderer24.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition26, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection29 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range30 = minMaxCategoryRenderer24.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection29);
        minMaxCategoryRenderer24.setSeriesVisibleInLegend(3, (java.lang.Boolean) true, false);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int36 = color35.getRed();
        minMaxCategoryRenderer24.setBaseOutlinePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        stackedBarRenderer3D39.setWallPaint((java.awt.Paint) color40);
        org.jfree.chart.util.BooleanList booleanList42 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        boolean boolean45 = ringPlot43.equals((java.lang.Object) (short) 0);
        java.awt.Color color46 = java.awt.Color.YELLOW;
        ringPlot43.setLabelLinkPaint((java.awt.Paint) color46);
        boolean boolean48 = booleanList42.equals((java.lang.Object) color46);
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        ringPlot49.removeChangeListener(plotChangeListener50);
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder(paint52);
        ringPlot49.setShadowPaint(paint52);
        java.awt.Color color55 = java.awt.Color.YELLOW;
        ringPlot49.setOutlinePaint((java.awt.Paint) color55);
        float[] floatArray62 = new float[] { 60000L, 3, 10.0f, 100, 4 };
        float[] floatArray63 = color55.getRGBComponents(floatArray62);
        float[] floatArray64 = color46.getColorComponents(floatArray62);
        float[] floatArray65 = color40.getRGBComponents(floatArray62);
        float[] floatArray66 = color35.getRGBComponents(floatArray65);
        try {
            org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem(attributedString0, "Jun", "SortOrder.ASCENDING", "ERROR : Relative To String", shape6, stroke20, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(icon15);
        org.junit.Assert.assertNotNull(icon17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 128 + "'", int36 == 128);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        categoryPlot28.clearDomainMarkers();
        categoryPlot28.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot28.getRenderer();
        java.lang.Comparable[] comparableArray39 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray40 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray41 = null;
        java.lang.Number[][] numberArray42 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset43 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray39, comparableArray40, numberArray41, numberArray42);
        try {
            categoryPlot28.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryItemRenderer32);
        org.junit.Assert.assertNotNull(comparableArray39);
        org.junit.Assert.assertNotNull(comparableArray40);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator9 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator9);
        java.lang.Comparable[] comparableArray17 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray19 = null;
        java.lang.Number[][] numberArray20 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray17, comparableArray18, numberArray19, numberArray20);
        int int22 = defaultIntervalCategoryDataset21.getCategoryCount();
        try {
            java.lang.String str24 = standardCategoryToolTipGenerator9.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset21, (-16318469));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(comparableArray17);
        org.junit.Assert.assertNotNull(comparableArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        minMaxCategoryRenderer5.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition7, true);
        org.jfree.chart.util.BooleanList booleanList10 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) (short) 0);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        ringPlot11.setLabelLinkPaint((java.awt.Paint) color14);
        boolean boolean16 = booleanList10.equals((java.lang.Object) color14);
        minMaxCategoryRenderer5.setBaseItemLabelPaint((java.awt.Paint) color14);
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color14);
        java.awt.Font font19 = polarPlot3.getAngleLabelFont();
        textTitle0.setFont(font19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        ringPlot21.removeChangeListener(plotChangeListener22);
        java.awt.Paint paint24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(paint24);
        ringPlot21.setShadowPaint(paint24);
        textTitle0.setBackgroundPaint(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.RendererState rendererState6 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = rendererState6.getInfo();
        boolean boolean8 = layer3.equals((java.lang.Object) rendererState6);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNull(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        java.lang.String str11 = rectangleConstraint10.toString();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean14 = dateAxis13.isTickLabelsVisible();
        dateAxis13.setFixedAutoRange((double) (byte) 1);
        dateAxis13.setLowerBound(12.0d);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis13.setDownArrow(shape20);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        dateAxis13.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range26 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange22, 0.0d, (double) 3);
        double double28 = dateRange22.constrain(12.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange22);
        double double30 = rectangleConstraint10.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]" + "'", str11.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month0, shape2, "{0}", "ThreadContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.next();
        int int9 = month0.compareTo((java.lang.Object) 128);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str1.equals("AreaRendererEndType.LEVEL"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        minMaxCategoryRenderer8.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition10, true);
        java.awt.Stroke stroke14 = minMaxCategoryRenderer8.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesStroke(10, stroke14, false);
        javax.swing.Icon icon17 = minMaxCategoryRenderer0.getMaxIcon();
        boolean boolean19 = minMaxCategoryRenderer0.isSeriesItemLabelsVisible((int) '#');
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(icon17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        java.lang.Comparable comparable8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, comparable8);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) (byte) -1, 10.0d, (int) (short) -1);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset9);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        java.awt.Paint paint44 = categoryPlot28.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace45 = new org.jfree.chart.axis.AxisSpace();
        double double46 = axisSpace45.getRight();
        categoryPlot28.setFixedRangeAxisSpace(axisSpace45);
        int int48 = categoryPlot28.getDatasetCount();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 11 + "'", int48 == 11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = minMaxCategoryRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon8 = minMaxCategoryRenderer0.getObjectIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        minMaxCategoryRenderer9.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition11, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = minMaxCategoryRenderer9.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = minMaxCategoryRenderer9.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon17 = minMaxCategoryRenderer9.getObjectIcon();
        minMaxCategoryRenderer0.setObjectIcon(icon17);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        minMaxCategoryRenderer0.setSeriesStroke((int) (byte) 10, stroke20, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = stackedBarRenderer3D24.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer27 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        minMaxCategoryRenderer27.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition29, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection32 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range33 = minMaxCategoryRenderer27.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection32);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer35 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        minMaxCategoryRenderer35.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition37, true);
        java.awt.Stroke stroke41 = minMaxCategoryRenderer35.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer27.setSeriesStroke(10, stroke41, false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator45 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        minMaxCategoryRenderer27.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator45, true);
        stackedBarRenderer3D24.setSeriesURLGenerator(128, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator45);
        minMaxCategoryRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator45);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot();
        boolean boolean52 = ringPlot50.equals((java.lang.Object) (short) 0);
        java.awt.Paint paint53 = null;
        ringPlot50.setLabelBackgroundPaint(paint53);
        boolean boolean55 = standardCategoryURLGenerator45.equals((java.lang.Object) paint53);
        boolean boolean57 = standardCategoryURLGenerator45.equals((java.lang.Object) 3600000L);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(icon8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNotNull(icon17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(itemLabelPosition25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue(100L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot28.getRangeAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = categoryPlot28.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(categoryAnchor46);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        dateAxis1.setLabelURL("SortOrder.DESCENDING");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, 4);
        int int14 = taskSeriesCollection11.getSeriesCount();
        int int15 = taskSeriesCollection11.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double18 = categoryAxis17.getUpperMargin();
        java.awt.Font font19 = categoryAxis17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis21.setTickMarkPosition(dateTickMarkPosition23);
        dateAxis21.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = dateAxis21.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean31 = stackedBarRenderer3D29.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor33 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor33, textAnchor34, textAnchor35, (double) 0L);
        stackedBarRenderer3D29.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D29);
        java.lang.Comparable[] comparableArray47 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray48 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray49 = null;
        java.lang.Number[][] numberArray50 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset51 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray47, comparableArray48, numberArray49, numberArray50);
        categoryPlot39.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset51);
        categoryPlot39.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot39.getRangeAxisEdge((int) (byte) 1);
        try {
            double double57 = dateAxis1.valueToJava2D(8.0d, rectangle2D10, rectangleEdge56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor33);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(comparableArray47);
        org.junit.Assert.assertNotNull(comparableArray48);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10L, (java.lang.Number) 10L);
        java.lang.Number number3 = defaultKeyedValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10L + "'", number3.equals(10L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        java.lang.String str11 = ringPlot0.getNoDataMessage();
        ringPlot0.setShadowYOffset(0.4d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator8 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        minMaxCategoryRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator8);
        minMaxCategoryRenderer0.setDrawLines(false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getToolTipText();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        ringPlot3.removeChangeListener(plotChangeListener4);
        ringPlot3.setLabelLinksVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup8 = ringPlot3.getDatasetGroup();
        boolean boolean9 = dateAxis1.hasListener((java.util.EventListener) ringPlot3);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font14 = categoryAxis11.getTickLabelFont((java.lang.Comparable) "Apr");
        ringPlot3.setLabelFont(font14);
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) ringPlot3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date14 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit13);
        dateAxis1.setMinimumDate(date14);
        java.awt.Paint paint16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        boolean boolean20 = rectangleInsets18.equals((java.lang.Object) 100.0d);
        dateAxis1.setTickLabelInsets(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        categoryPlot28.clearDomainMarkers();
        categoryPlot28.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot28.getRenderer();
        categoryPlot28.clearRangeMarkers(28);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryItemRenderer32);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition2);
        try {
            dateAxis1.setRange(3.0d, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.Year year3 = month0.getYear();
        long long4 = month0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        boolean boolean8 = polarPlot3.isRadiusGridlinesVisible();
        java.awt.Paint paint9 = polarPlot3.getAngleGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean12 = dateAxis11.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis11.setTickMarkPosition(dateTickMarkPosition13);
        double double15 = dateAxis11.getUpperBound();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        dateAxis10.setUpperMargin(0.0d);
        double double31 = dateAxis10.getLabelAngle();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean5 = dateAxis4.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date9 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit8);
        java.util.Date date10 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        java.lang.String str12 = dateTickUnit8.valueToString((double) 28);
        java.lang.String str14 = dateTickUnit8.valueToString((double) 31);
        int int15 = dateTickUnit8.getCalendarField();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12/31/69" + "'", str12.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "12/31/69" + "'", str14.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        intervalMarker2.setEndValue((double) 32400097L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType6);
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getUpperMargin();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        java.lang.Object obj11 = null;
        boolean boolean12 = ringPlot6.equals(obj11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot13.equals((java.lang.Object) (short) 0);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        ringPlot13.setLabelLinkPaint((java.awt.Paint) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot13.setLabelBackgroundPaint((java.awt.Paint) color18);
        ringPlot6.setBaseSectionOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font5, (java.awt.Paint) color18);
        java.lang.Object obj22 = null;
        boolean boolean23 = textFragment21.equals(obj22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        javax.swing.Icon icon5 = minMaxCategoryRenderer0.getMaxIcon();
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getBaseOutlinePaint();
        minMaxCategoryRenderer0.setBaseItemLabelsVisible(true, true);
        java.lang.Boolean boolean11 = minMaxCategoryRenderer0.getSeriesItemLabelsVisible((int) '#');
        org.junit.Assert.assertNotNull(icon5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer7 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        minMaxCategoryRenderer7.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition9, true);
        org.jfree.chart.util.BooleanList booleanList12 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot13.equals((java.lang.Object) (short) 0);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        ringPlot13.setLabelLinkPaint((java.awt.Paint) color16);
        boolean boolean18 = booleanList12.equals((java.lang.Object) color16);
        minMaxCategoryRenderer7.setBaseItemLabelPaint((java.awt.Paint) color16);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = minMaxCategoryRenderer7.getLegendItemLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator(categorySeriesLabelGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection23 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection23, 4);
        int int26 = taskSeriesCollection23.getSeriesCount();
        int int27 = taskSeriesCollection23.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double30 = categoryAxis29.getUpperMargin();
        java.awt.Font font31 = categoryAxis29.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean34 = dateAxis33.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition35 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis33.setTickMarkPosition(dateTickMarkPosition35);
        dateAxis33.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = dateAxis33.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean43 = stackedBarRenderer3D41.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor45 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor45, textAnchor46, textAnchor47, (double) 0L);
        stackedBarRenderer3D41.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection23, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D41);
        java.lang.Comparable[] comparableArray59 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray60 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray61 = null;
        java.lang.Number[][] numberArray62 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset63 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray59, comparableArray60, numberArray61, numberArray62);
        categoryPlot51.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset63);
        boolean boolean65 = categoryPlot51.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace66 = new org.jfree.chart.axis.AxisSpace();
        double double67 = axisSpace66.getRight();
        categoryPlot51.setFixedDomainAxisSpace(axisSpace66);
        categoryPlot51.setRangeCrosshairValue(0.0d);
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D22, categoryPlot51, rectangle2D71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(pieDataset25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition35);
        org.junit.Assert.assertNotNull(tickUnitSource39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor45);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNotNull(comparableArray59);
        org.junit.Assert.assertNotNull(comparableArray60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getUpperMargin();
        java.awt.Font font4 = categoryAxis2.getLabelFont();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP_RIGHT", font4);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer7 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon8 = minMaxCategoryRenderer7.getMinIcon();
        java.awt.Color color9 = java.awt.Color.yellow;
        minMaxCategoryRenderer7.setGroupPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D13.getPositiveItemLabelPositionFallback();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D13.setBaseOutlinePaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = stackedBarRenderer3D13.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double23 = dateAxis22.getUpperMargin();
        java.awt.Paint paint24 = dateAxis22.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        stackedBarRenderer3D13.drawRangeGridline(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis22, rectangle2D25, (double) 100L);
        java.awt.Font font28 = dateAxis22.getLabelFont();
        minMaxCategoryRenderer7.setSeriesItemLabelFont(0, font28);
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("August", font28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double34 = categoryAxis33.getUpperMargin();
        java.awt.Font font36 = categoryAxis33.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        boolean boolean39 = ringPlot37.equals((java.lang.Object) (short) 0);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        ringPlot37.setLabelLinkPaint((java.awt.Paint) color40);
        java.lang.Object obj42 = null;
        boolean boolean43 = ringPlot37.equals(obj42);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        boolean boolean46 = ringPlot44.equals((java.lang.Object) (short) 0);
        java.awt.Color color47 = java.awt.Color.YELLOW;
        ringPlot44.setLabelLinkPaint((java.awt.Paint) color47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot44.setLabelBackgroundPaint((java.awt.Paint) color49);
        ringPlot37.setBaseSectionOutlinePaint((java.awt.Paint) color49);
        org.jfree.chart.text.TextFragment textFragment52 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font36, (java.awt.Paint) color49);
        textLine30.removeFragment(textFragment52);
        textLine5.addFragment(textFragment52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(icon8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color49);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date14 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit13);
        dateAxis1.setMinimumDate(date14);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer16 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        minMaxCategoryRenderer16.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition18, true);
        org.jfree.chart.util.BooleanList booleanList21 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        boolean boolean24 = ringPlot22.equals((java.lang.Object) (short) 0);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        ringPlot22.setLabelLinkPaint((java.awt.Paint) color25);
        boolean boolean27 = booleanList21.equals((java.lang.Object) color25);
        minMaxCategoryRenderer16.setBaseItemLabelPaint((java.awt.Paint) color25);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color25);
        dateAxis1.setLabelURL("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        taskSeriesCollection0.addChangeListener(datasetChangeListener4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int9 = taskSeriesCollection0.indexOf((java.lang.Comparable) 0.2d);
        try {
            java.lang.Number number13 = taskSeriesCollection0.getStartValue(31, 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        xYPlot0.setDataset(xYDataset1);
        int int3 = xYPlot0.getSeriesCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, 4);
        int int7 = taskSeriesCollection4.getSeriesCount();
        int int8 = taskSeriesCollection4.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double11 = categoryAxis10.getUpperMargin();
        java.awt.Font font12 = categoryAxis10.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean15 = dateAxis14.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis14.setTickMarkPosition(dateTickMarkPosition16);
        dateAxis14.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis14.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean24 = stackedBarRenderer3D22.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor26, textAnchor27, textAnchor28, (double) 0L);
        stackedBarRenderer3D22.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot32.setDatasetRenderingOrder(datasetRenderingOrder33);
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        xYPlot0.setRenderer(31, xYItemRenderer37, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        categoryPlot28.clearAnnotations();
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = chartRenderingInfo35.getPlotInfo();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot37.getRangeAxisEdge();
        java.awt.geom.Point2D point2D39 = xYPlot37.getQuadrantOrigin();
        try {
            categoryPlot28.zoomRangeAxes((double) 100.0f, (double) (short) 0, plotRenderingInfo36, point2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(point2D39);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("2019");
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        multiplePiePlot3.setAggregatedItemsKey((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) (short) 0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color4);
        boolean boolean6 = booleanList0.equals((java.lang.Object) color4);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = ringPlot7.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot7.setShadowYOffset((double) 10L);
        ringPlot7.setCircular(false);
        boolean boolean18 = booleanList0.equals((java.lang.Object) ringPlot7);
        java.awt.Paint paint19 = ringPlot7.getBackgroundPaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        boolean boolean23 = ringPlot21.equals((java.lang.Object) (short) 0);
        java.awt.Color color24 = java.awt.Color.YELLOW;
        ringPlot21.setLabelLinkPaint((java.awt.Paint) color24);
        java.awt.Paint paint27 = ringPlot21.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot21.setLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.plot.Plot plot30 = ringPlot21.getRootPlot();
        java.awt.Paint paint31 = ringPlot21.getOutlinePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = stackedBarRenderer3D33.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = stackedBarRenderer3D36.getPositiveItemLabelPositionFallback();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D36.setBaseOutlinePaint((java.awt.Paint) color38);
        stackedBarRenderer3D33.setWallPaint((java.awt.Paint) color38);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer41 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = null;
        minMaxCategoryRenderer41.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition43, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator46 = minMaxCategoryRenderer41.getLegendItemToolTipGenerator();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int48 = color47.getGreen();
        minMaxCategoryRenderer41.setBaseFillPaint((java.awt.Paint) color47);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer50 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color20, paint31, (java.awt.Paint) color38, (java.awt.Paint) color47);
        ringPlot7.setBackgroundPaint((java.awt.Paint) color47);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(itemLabelPosition34);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 128 + "'", int48 == 128);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        int int9 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font13 = categoryAxis11.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28, textAnchor29, (double) 0L);
        stackedBarRenderer3D23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot33.getDomainAxis(0);
        java.awt.Paint paint36 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double39 = dateAxis38.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = stackedBarRenderer3D41.getPositiveItemLabelPositionFallback();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D41.setBaseOutlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = stackedBarRenderer3D41.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double51 = dateAxis50.getUpperMargin();
        java.awt.Paint paint52 = dateAxis50.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        stackedBarRenderer3D41.drawRangeGridline(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D53, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean58 = dateAxis57.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date62 = dateAxis57.calculateLowestVisibleTickValue(dateTickUnit61);
        dateAxis50.setTickUnit(dateTickUnit61);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke65 = polarPlot64.getRadiusGridlineStroke();
        dateAxis50.setTickMarkStroke(stroke65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { dateAxis38, dateAxis50 };
        categoryPlot33.setRangeAxes(valueAxisArray67);
        xYPlot0.setDomainAxes(valueAxisArray67);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot0.getRangeAxisLocation((-457));
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = xYPlot72.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = xYPlot72.getAxisOffset();
        java.awt.Paint paint75 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder(paint75);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = blockBorder76.getInsets();
        double double79 = rectangleInsets77.trimHeight((double) 100L);
        double double81 = rectangleInsets77.calculateLeftInset((double) 3);
        xYPlot72.setAxisOffset(rectangleInsets77);
        boolean boolean83 = xYPlot72.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation84 = xYPlot72.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation71, plotOrientation84);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 98.0d + "'", double79 == 98.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(plotOrientation84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        ringPlot1.removeChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        ringPlot1.setShadowPaint(paint4);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        ringPlot1.setOutlinePaint((java.awt.Paint) color7);
        boolean boolean9 = textBlock0.equals((java.lang.Object) color7);
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine11 = null;
        textBlock10.addLine(textLine11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textBlock10.getLineAlignment();
        textBlock0.setLineAlignment(horizontalAlignment13);
        java.lang.String str15 = horizontalAlignment13.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "HorizontalAlignment.CENTER" + "'", str15.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        ringPlot1.removeChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot1.setBaseSectionPaint(paint4);
        boolean boolean6 = size2D0.equals((java.lang.Object) ringPlot1);
        double double7 = size2D0.width;
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        java.awt.Paint paint31 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        categoryPlot28.setRangeAxis((int) (byte) 10, valueAxis33);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        boolean boolean3 = dateAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getFirstBarPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color3, false);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        java.lang.Object obj11 = null;
        boolean boolean12 = ringPlot6.equals(obj11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot13.equals((java.lang.Object) (short) 0);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        ringPlot13.setLabelLinkPaint((java.awt.Paint) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot13.setLabelBackgroundPaint((java.awt.Paint) color18);
        ringPlot6.setBaseSectionOutlinePaint((java.awt.Paint) color18);
        waterfallBarRenderer0.setNegativeBarPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer22 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        minMaxCategoryRenderer22.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition24, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection27 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range28 = minMaxCategoryRenderer22.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        taskSeriesCollection27.removeAll();
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection27, true);
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        org.jfree.data.Range range33 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        try {
            java.lang.Number number36 = taskSeriesCollection27.getPercentComplete(28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 28, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("AxisLocation.TOP_OR_RIGHT");
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot28.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot28.getDomainAxisForDataset((int) (byte) 10);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        ringPlot32.removeChangeListener(plotChangeListener33);
        java.awt.Paint paint35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(paint35);
        ringPlot32.setShadowPaint(paint35);
        java.awt.Color color38 = java.awt.Color.YELLOW;
        ringPlot32.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Color color40 = color38.darker();
        categoryPlot28.setRangeCrosshairPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(categoryAxis31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Color color1 = java.awt.Color.getColor("Category Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener9 = null;
        taskSeriesCollection5.addChangeListener(datasetChangeListener9);
        legendItemEntity4.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection5);
        java.lang.Comparable comparable12 = legendItemEntity4.getSeriesKey();
        org.jfree.data.general.Dataset dataset13 = legendItemEntity4.getDataset();
        legendItemEntity4.setSeriesKey((java.lang.Comparable) "{0}");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertNotNull(dataset13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10L, (java.lang.Number) 10L);
        java.lang.Object obj3 = defaultKeyedValue2.clone();
        java.lang.Comparable comparable4 = defaultKeyedValue2.getKey();
        defaultKeyedValue2.setValue((java.lang.Number) (short) 10);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10L + "'", comparable4.equals(10L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date11 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit10);
        java.util.Date date12 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit10);
        int int13 = dateTickUnit10.getRollUnit();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean24 = dateAxis23.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date28 = dateAxis23.calculateLowestVisibleTickValue(dateTickUnit27);
        dateAxis15.setMinimumDate(date28);
        java.util.Date date30 = dateTickUnit10.rollDate(date28);
        segmentedTimeline0.addBaseTimelineException(date28);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        java.lang.Comparable comparable5 = multiplePiePlot3.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset6 = multiplePiePlot3.getDataset();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNull(categoryDataset6);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-16318469));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 2);
        segmentedTimeline1.addException((long) 28);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot28.getDomainAxis(0);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot28.getRangeAxisLocation();
        java.lang.String str33 = categoryPlot28.getPlotType();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder(paint36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockBorder37.getInsets();
        boolean boolean40 = rectangleInsets38.equals((java.lang.Object) 100.0d);
        categoryMarker35.setLabelOffset(rectangleInsets38);
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        boolean boolean44 = ringPlot42.equals((java.lang.Object) (short) 0);
        java.awt.Color color45 = java.awt.Color.YELLOW;
        ringPlot42.setLabelLinkPaint((java.awt.Paint) color45);
        java.awt.Paint paint48 = ringPlot42.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot42.setLabelPaint((java.awt.Paint) color49);
        org.jfree.chart.plot.Plot plot51 = ringPlot42.getRootPlot();
        java.awt.Paint paint52 = ringPlot42.getOutlinePaint();
        categoryMarker35.setPaint(paint52);
        org.jfree.chart.util.Layer layer54 = null;
        try {
            categoryPlot28.addDomainMarker(categoryMarker35, layer54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(plot51);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getFirstBarPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = waterfallBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, 4);
        int int6 = taskSeriesCollection3.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener7 = null;
        taskSeriesCollection3.addChangeListener(datasetChangeListener7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, true);
        org.jfree.data.Range range11 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        legendTitle4.setItemPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = legendTitle4.getItemPaint();
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        legendTitle4.setWrapper(blockContainer29);
        blockContainer29.setHeight(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean8 = dateAxis7.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date15 = dateAxis10.calculateLowestVisibleTickValue(dateTickUnit14);
        java.util.Date date16 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit14);
        int int17 = dateTickUnit14.getRollUnit();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean20 = dateAxis19.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition21 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis19.setTickMarkPosition(dateTickMarkPosition21);
        dateAxis19.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis19.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean28 = dateAxis27.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date32 = dateAxis27.calculateLowestVisibleTickValue(dateTickUnit31);
        dateAxis19.setMinimumDate(date32);
        java.util.Date date34 = dateTickUnit14.rollDate(date32);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) dateTickUnit14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition21);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        boolean boolean48 = categoryPlot28.render(graphics2D44, rectangle2D45, (-1), plotRenderingInfo47);
        categoryPlot28.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = categoryLabelPosition0.getLabelAnchor();
        double double2 = categoryLabelPosition0.getAngle();
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Stroke stroke4 = minMaxCategoryRenderer0.getItemStroke((int) (byte) 100, (int) (short) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = minMaxCategoryRenderer0.getLegendItems();
        boolean boolean6 = minMaxCategoryRenderer0.isDrawLines();
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Paint paint3 = null;
        ringPlot0.setLabelBackgroundPaint(paint3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float1 = categoryLabelPosition0.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = categoryLabelPosition0.getWidthType();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryLabelWidthType2.equals(obj3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.95f + "'", float1 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        boolean boolean29 = categoryPlot28.isDomainGridlinesVisible();
        int int30 = categoryPlot28.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator4 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        java.lang.Object obj5 = standardCategoryURLGenerator4.clone();
        stackedBarRenderer3D1.setSeriesURLGenerator(4, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator4, false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        boolean boolean8 = polarPlot3.isRadiusGridlinesVisible();
        java.awt.Paint paint9 = polarPlot3.getAngleGridlinePaint();
        java.awt.Stroke stroke10 = polarPlot3.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        double double8 = ringPlot0.getShadowYOffset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = ringPlot0.getLegendLabelURLGenerator();
        java.awt.Paint paint10 = ringPlot0.getLabelLinkPaint();
        boolean boolean11 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNull(pieURLGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues2.clear();
        boolean boolean4 = size2D0.equals((java.lang.Object) defaultKeyedValues2);
        defaultKeyedValues2.clear();
        int int7 = defaultKeyedValues2.getIndex((java.lang.Comparable) "Other");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 12.0d, 1.0d, 100 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "Apr", numberArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15, false);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        int int3 = dateTickUnit2.getRollCount();
        double double4 = dateTickUnit2.getSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.64E7d + "'", double4 == 8.64E7d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation9 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean10 = lengthConstraintType6.equals((java.lang.Object) 10);
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 1, range5, lengthConstraintType6, (double) (-1), range12, lengthConstraintType13);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) 0.5f, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint14.toRangeWidth((org.jfree.data.Range) dateRange17);
        java.lang.String str19 = dateRange17.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint3.toRangeHeight((org.jfree.data.Range) dateRange17);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        int int9 = taskSeriesCollection5.getColumnCount();
        org.jfree.data.Range range10 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        ringPlot0.setMinimumArcAngleToDraw((double) 28800000L);
        ringPlot0.setStartAngle((double) (short) -1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date14 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit13);
        dateAxis1.setMinimumDate(date14);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor18, textAnchor19, textAnchor20, (double) 0L);
        org.jfree.chart.axis.DateTick dateTick24 = new org.jfree.chart.axis.DateTick(date14, "SortOrder.ASCENDING", textAnchor17, textAnchor20, (double) 3600000L);
        org.jfree.chart.text.TextAnchor textAnchor25 = dateTick24.getTextAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        boolean boolean27 = textAnchor25.equals((java.lang.Object) textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.lang.String str2 = gradientPaintTransformType1.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str2.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((int) '4');
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = lineAndShapeRenderer2.getItemLabelGenerator(4, 0);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke13 = polarPlot12.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = polarPlot12.getRenderer();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot12.setRadiusGridlineStroke(stroke15);
        lineAndShapeRenderer2.setSeriesOutlineStroke(1, stroke15, true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(polarItemRenderer14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setMaximumBarWidth((double) (byte) -1);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon4 = minMaxCategoryRenderer3.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon6 = minMaxCategoryRenderer5.getMinIcon();
        java.awt.Stroke stroke9 = minMaxCategoryRenderer5.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer3.setBaseOutlineStroke(stroke9, false);
        barRenderer3D0.setBaseOutlineStroke(stroke9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14, textAnchor15, (double) 0L);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition17);
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition17.getTextAnchor();
        java.lang.String str20 = textAnchor19.toString();
        org.junit.Assert.assertNotNull(icon4);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str20.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        legendItem14.setSeriesKey((java.lang.Comparable) 128);
        java.awt.Stroke stroke17 = legendItem14.getLineStroke();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font5);
        dateAxis1.setAutoTickUnitSelection(true);
        java.lang.String str9 = dateAxis1.getLabelURL();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke18 = dateAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double3 = rectangleInsets2.getTop();
        double double5 = rectangleInsets2.calculateLeftOutset((double) 60000L);
        double double7 = rectangleInsets2.calculateRightOutset((double) (-1L));
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        boolean boolean8 = dateAxis1.isNegativeArrowVisible();
        java.awt.Shape shape9 = dateAxis1.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer8 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        minMaxCategoryRenderer8.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition10, true);
        java.awt.Stroke stroke14 = minMaxCategoryRenderer8.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double20 = dateAxis19.getUpperMargin();
        java.awt.Paint paint21 = dateAxis19.getAxisLinePaint();
        minMaxCategoryRenderer0.setSeriesOutlinePaint(3, paint21, false);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        minMaxCategoryRenderer0.setSeriesStroke((int) (byte) 100, stroke25, true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        boolean boolean7 = stackedBarRenderer3D1.isDrawBarOutline();
        stackedBarRenderer3D1.setBaseSeriesVisible(false, false);
        boolean boolean13 = stackedBarRenderer3D1.getItemCreateEntity((-457), 28);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRadiusGridlinesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        ringPlot6.removeChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot6.setBaseSectionPaint(paint9);
        ringPlot0.setLabelShadowPaint(paint9);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer12 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        minMaxCategoryRenderer12.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition14, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection17 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range18 = minMaxCategoryRenderer12.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection17);
        taskSeriesCollection17.removeAll();
        java.lang.Comparable comparable20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection17, comparable20);
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset21, (java.lang.Comparable) (byte) -1, 10.0d, (int) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot(pieDataset25);
        ringPlot0.setDataset(pieDataset25);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNotNull(pieDataset25);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot7.rendererChanged(rendererChangeEvent12);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        java.awt.Paint paint11 = xYPlot0.getRangeGridlinePaint();
        java.awt.Paint paint12 = xYPlot0.getDomainCrosshairPaint();
        int int13 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Paint paint5 = legendTitle4.getItemPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Paint paint5 = legendTitle4.getBackgroundPaint();
        java.awt.Paint paint6 = legendTitle4.getItemPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.chart.axis.Axis axis8 = axisChangeEvent7.getAxis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axis8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis1.getTickMarkPosition();
        java.util.Date date4 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean4 = ringPlot0.equals((java.lang.Object) textAnchor3);
        double double5 = ringPlot0.getSectionDepth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.event.TitleChangeListener titleChangeListener26 = null;
        legendTitle4.removeChangeListener(titleChangeListener26);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent28 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock0.setLineAlignment(horizontalAlignment4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D8.getPositiveItemLabelPositionFallback();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D8.setBaseOutlinePaint((java.awt.Paint) color10);
        boolean boolean12 = verticalAlignment6.equals((java.lang.Object) stackedBarRenderer3D8);
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment6, 0.4d, (double) 10.0f);
        flowArrangement15.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D2.setBaseOutlinePaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double12 = dateAxis11.getUpperMargin();
        java.awt.Paint paint13 = dateAxis11.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis11, rectangle2D14, (double) 100L);
        java.awt.Font font17 = dateAxis11.getLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot19.equals((java.lang.Object) (short) 0);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        ringPlot19.setLabelLinkPaint((java.awt.Paint) color22);
        java.awt.Paint paint25 = ringPlot19.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot19.setLabelPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.Plot plot28 = ringPlot19.getRootPlot();
        java.awt.Paint paint29 = ringPlot19.getOutlinePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedBarRenderer3D31.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D34.getPositiveItemLabelPositionFallback();
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D34.setBaseOutlinePaint((java.awt.Paint) color36);
        stackedBarRenderer3D31.setWallPaint((java.awt.Paint) color36);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer39 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        minMaxCategoryRenderer39.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition41, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = minMaxCategoryRenderer39.getLegendItemToolTipGenerator();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int46 = color45.getGreen();
        minMaxCategoryRenderer39.setBaseFillPaint((java.awt.Paint) color45);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer48 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color18, paint29, (java.awt.Paint) color36, (java.awt.Paint) color45);
        org.jfree.chart.block.LabelBlock labelBlock49 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.CENTER_RIGHT", font17, (java.awt.Paint) color36);
        java.awt.Font font50 = labelBlock49.getFont();
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(itemLabelPosition32);
        org.junit.Assert.assertNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 128 + "'", int46 == 128);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 0, 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        minMaxCategoryRenderer10.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition12, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = minMaxCategoryRenderer10.getLegendItemToolTipGenerator();
        java.awt.Paint paint16 = minMaxCategoryRenderer10.getBaseItemLabelPaint();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(10.0d, 0.05d, (double) 100, (double) 9);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        java.awt.Paint paint24 = blockBorder22.getPaint();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        boolean boolean29 = ringPlot27.equals((java.lang.Object) (short) 0);
        java.awt.Color color30 = java.awt.Color.YELLOW;
        ringPlot27.setLabelLinkPaint((java.awt.Paint) color30);
        java.awt.Paint paint33 = ringPlot27.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot27.setLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        ringPlot36.removeChangeListener(plotChangeListener37);
        java.awt.Paint paint39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder(paint39);
        ringPlot36.setShadowPaint(paint39);
        ringPlot27.setLabelPaint(paint39);
        java.awt.Shape shape43 = ringPlot27.getLegendItemShape();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer44 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon45 = minMaxCategoryRenderer44.getMinIcon();
        java.awt.Stroke stroke48 = minMaxCategoryRenderer44.getItemStroke((int) (byte) 100, (int) (short) 100);
        java.awt.Paint paint49 = null;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("2019", "Pie 3D Plot", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "poly", true, shape8, false, paint16, false, paint24, stroke25, false, shape43, stroke48, paint49);
        boolean boolean51 = legendItem50.isShapeFilled();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(icon45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, 4);
        int int11 = taskSeriesCollection8.getSeriesCount();
        int int12 = taskSeriesCollection8.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double15 = categoryAxis14.getUpperMargin();
        java.awt.Font font16 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis18.setTickMarkPosition(dateTickMarkPosition20);
        dateAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean28 = stackedBarRenderer3D26.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31, textAnchor32, (double) 0L);
        stackedBarRenderer3D26.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D26);
        java.awt.Paint paint37 = categoryPlot36.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean40 = dateAxis39.isTickLabelsVisible();
        dateAxis39.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D7, categoryPlot36, (org.jfree.chart.axis.ValueAxis) dateAxis39, marker43, rectangle2D44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot36.getLegendItems();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity(shape53);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity57 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month51, shape53, "{0}", "ThreadContext");
        java.awt.Paint paint58 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape53, paint58, stroke59, paint60);
        java.text.AttributedString attributedString62 = legendItem61.getAttributedLabel();
        legendItemCollection46.add(legendItem61);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year65 = month64.getYear();
        java.lang.String str66 = year65.toString();
        java.util.Date date67 = year65.getEnd();
        long long68 = year65.getSerialIndex();
        legendItem61.setSeriesKey((java.lang.Comparable) long68);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(attributedString62);
        org.junit.Assert.assertNotNull(year65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2019" + "'", str66.equals("2019"));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        plotChangeEvent2.setType(chartChangeEventType3);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        dateAxis1.setLabelURL("ERROR : Relative To String");
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int1 = defaultKeyedValues0.getItemCount();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle3.setPadding(rectangleInsets4);
        textTitle3.setExpandToFitSpace(false);
        java.awt.Font font8 = textTitle3.getFont();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot9.setRenderer(xYItemRenderer10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font8, (org.jfree.chart.plot.Plot) xYPlot9, false);
        org.jfree.chart.title.Title title14 = null;
        jFreeChart13.removeSubtitle(title14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) defaultKeyedValues0, jFreeChart13, chartChangeEventType16);
        boolean boolean18 = jFreeChart13.isBorderVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        java.awt.Paint paint44 = categoryPlot28.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace45 = new org.jfree.chart.axis.AxisSpace();
        double double46 = axisSpace45.getRight();
        categoryPlot28.setFixedRangeAxisSpace(axisSpace45);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = categoryPlot28.getLegendItems();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection48);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        java.util.List list3 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Date date6 = year5.getEnd();
        int int7 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) year5);
        long long8 = year5.getLastMillisecond();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean3 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean5 = lineAndShapeRenderer2.getSeriesShapesFilled((int) (byte) 10);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer7 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        minMaxCategoryRenderer7.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = minMaxCategoryRenderer7.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = minMaxCategoryRenderer7.getSeriesItemLabelGenerator(1);
        javax.swing.Icon icon15 = minMaxCategoryRenderer7.getObjectIcon();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D17.setBase((double) 1L);
        stackedBarRenderer3D17.setMinimumBarLength((double) (short) 1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor23, textAnchor24, textAnchor25, (double) 0L);
        stackedBarRenderer3D17.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition27);
        minMaxCategoryRenderer7.setBasePositiveItemLabelPosition(itemLabelPosition27);
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(4, itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNotNull(icon15);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        double double5 = size2D4.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, 0.2d, (double) 500, rectangleAnchor8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        axisSpace10.setTop(0.0d);
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D();
        double double14 = size2D13.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.2d, (double) 500, rectangleAnchor17);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection19, 4);
        int int22 = taskSeriesCollection19.getSeriesCount();
        int int23 = taskSeriesCollection19.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double26 = categoryAxis25.getUpperMargin();
        java.awt.Font font27 = categoryAxis25.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean30 = dateAxis29.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis29.setTickMarkPosition(dateTickMarkPosition31);
        dateAxis29.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = dateAxis29.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D37 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean39 = stackedBarRenderer3D37.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor41 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor41, textAnchor42, textAnchor43, (double) 0L);
        stackedBarRenderer3D37.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition45);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection19, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D37);
        java.lang.Comparable[] comparableArray55 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray56 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray57 = null;
        java.lang.Number[][] numberArray58 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset59 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray55, comparableArray56, numberArray57, numberArray58);
        categoryPlot47.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset59);
        categoryPlot47.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot47.getRangeAxisEdge((int) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D65 = axisSpace10.reserved(rectangle2D18, rectangleEdge64);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = chartRenderingInfo67.getPlotInfo();
        try {
            org.jfree.chart.axis.AxisState axisState69 = numberAxis3D0.draw(graphics2D2, (double) 10, rectangle2D9, rectangle2D65, rectangleEdge66, plotRenderingInfo68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition31);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(comparableArray55);
        org.junit.Assert.assertNotNull(comparableArray56);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(plotRenderingInfo68);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        java.awt.Paint paint44 = categoryPlot28.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer45 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        waterfallBarRenderer45.setNegativeBarPaint((java.awt.Paint) color46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int50 = color49.getGreen();
        java.awt.image.ColorModel colorModel51 = null;
        java.awt.Rectangle rectangle52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.AffineTransform affineTransform54 = null;
        java.awt.RenderingHints renderingHints55 = null;
        java.awt.PaintContext paintContext56 = color49.createContext(colorModel51, rectangle52, rectangle2D53, affineTransform54, renderingHints55);
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace58 = color57.getColorSpace();
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        ringPlot59.removeChangeListener(plotChangeListener60);
        java.awt.Paint paint62 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder63 = new org.jfree.chart.block.BlockBorder(paint62);
        ringPlot59.setShadowPaint(paint62);
        java.awt.Color color65 = java.awt.Color.YELLOW;
        ringPlot59.setOutlinePaint((java.awt.Paint) color65);
        float[] floatArray72 = new float[] { 60000L, 3, 10.0f, 100, 4 };
        float[] floatArray73 = color65.getRGBComponents(floatArray72);
        float[] floatArray74 = color49.getColorComponents(colorSpace58, floatArray72);
        float[] floatArray75 = color48.getRGBColorComponents(floatArray72);
        float[] floatArray76 = color46.getRGBColorComponents(floatArray72);
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer79 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint44, (java.awt.Paint) color46, (java.awt.Paint) color77, (java.awt.Paint) color78);
        java.awt.Color color80 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        waterfallBarRenderer79.setLastBarPaint((java.awt.Paint) color80);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 128 + "'", int50 == 128);
        org.junit.Assert.assertNotNull(paintContext56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(colorSpace58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(color80);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        double double3 = intervalMarker2.getEndValue();
        double double4 = intervalMarker2.getStartValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(gradientPaintTransformer5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 0.95f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        java.lang.String str5 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) "Layer.FOREGROUND");
        categoryAxis1.setMaximumCategoryLabelLines(15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Plot plot5 = null;
        dateAxis1.setPlot(plot5);
        double double7 = dateAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("AreaRendererEndType.LEVEL", "GradientPaintTransformType.VERTICAL", "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0", "TextAnchor.CENTER_RIGHT");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean4 = segmentedTimeline0.containsDomainRange(1L, 2019L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int6 = segmentedTimeline5.getSegmentsIncluded();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean9 = dateAxis8.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis8.setTickMarkPosition(dateTickMarkPosition10);
        dateAxis8.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = dateAxis8.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean17 = dateAxis16.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date21 = dateAxis16.calculateLowestVisibleTickValue(dateTickUnit20);
        dateAxis8.setMinimumDate(date21);
        long long23 = segmentedTimeline5.getTime(date21);
        segmentedTimeline0.addException(date21);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 28 + "'", int6 == 28);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800000L + "'", long23 == 28800000L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        boolean boolean12 = ringPlot0.equals((java.lang.Object) (short) 100);
        java.awt.Font font13 = ringPlot0.getNoDataMessageFont();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 0, 0.0f);
        ringPlot0.setLegendItemShape(shape16);
        ringPlot0.setLabelLinksVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha((float) 1);
        java.awt.Color color4 = java.awt.Color.blue;
        categoryMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryMarker1.getOutlinePaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer7 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color8 = java.awt.Color.orange;
        waterfallBarRenderer7.setFirstBarPaint((java.awt.Paint) color8);
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint6, (java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        stackedBarRenderer3D1.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        stackedBarRenderer3D1.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
        stackedBarRenderer3D1.setSeriesVisibleInLegend(100, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNull(itemLabelPosition2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, 0.0d, (float) 11, (float) 32400097L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        java.util.List list3 = taskSeriesCollection0.getRowKeys();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        try {
            java.lang.Comparable comparable7 = taskSeriesCollection0.getSeriesKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.title.Title title12 = null;
        jFreeChart11.removeSubtitle(title12);
        jFreeChart11.setBackgroundImageAlpha((float) 128);
        java.util.List list16 = jFreeChart11.getSubtitles();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D2.setBaseOutlinePaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double12 = dateAxis11.getUpperMargin();
        java.awt.Paint paint13 = dateAxis11.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis11, rectangle2D14, (double) 100L);
        java.awt.Font font17 = dateAxis11.getLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean21 = ringPlot19.equals((java.lang.Object) (short) 0);
        java.awt.Color color22 = java.awt.Color.YELLOW;
        ringPlot19.setLabelLinkPaint((java.awt.Paint) color22);
        java.awt.Paint paint25 = ringPlot19.getSectionPaint((java.lang.Comparable) (-1L));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        ringPlot19.setLabelPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.Plot plot28 = ringPlot19.getRootPlot();
        java.awt.Paint paint29 = ringPlot19.getOutlinePaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = stackedBarRenderer3D31.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D34.getPositiveItemLabelPositionFallback();
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D34.setBaseOutlinePaint((java.awt.Paint) color36);
        stackedBarRenderer3D31.setWallPaint((java.awt.Paint) color36);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer39 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        minMaxCategoryRenderer39.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition41, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = minMaxCategoryRenderer39.getLegendItemToolTipGenerator();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int46 = color45.getGreen();
        minMaxCategoryRenderer39.setBaseFillPaint((java.awt.Paint) color45);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer48 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color18, paint29, (java.awt.Paint) color36, (java.awt.Paint) color45);
        org.jfree.chart.block.LabelBlock labelBlock49 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.CENTER_RIGHT", font17, (java.awt.Paint) color36);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.data.Range range52 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType53 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation56 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean57 = lengthConstraintType53.equals((java.lang.Object) 10);
        org.jfree.data.Range range59 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType60 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = new org.jfree.chart.block.RectangleConstraint((double) 1, range52, lengthConstraintType53, (double) (-1), range59, lengthConstraintType60);
        try {
            org.jfree.chart.util.Size2D size2D62 = labelBlock49.arrange(graphics2D50, rectangleConstraint61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(itemLabelPosition32);
        org.junit.Assert.assertNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 128 + "'", int46 == 128);
        org.junit.Assert.assertNotNull(lengthConstraintType53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType60);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = color6.darker();
        java.awt.Color color9 = color6.darker();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener9 = null;
        taskSeriesCollection5.addChangeListener(datasetChangeListener9);
        legendItemEntity4.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection5);
        java.lang.Comparable comparable12 = legendItemEntity4.getSeriesKey();
        org.jfree.data.general.Dataset dataset13 = legendItemEntity4.getDataset();
        java.lang.Object obj14 = null;
        boolean boolean15 = legendItemEntity4.equals(obj14);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertNotNull(dataset13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        java.awt.Paint paint11 = xYPlot0.getRangeGridlinePaint();
        java.awt.Paint paint12 = xYPlot0.getDomainCrosshairPaint();
        java.lang.String str13 = xYPlot0.getPlotType();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.awt.Paint paint29 = categoryPlot28.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor30 = categoryPlot28.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(categoryAnchor30);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        legendItem14.setSeriesKey((java.lang.Comparable) 128);
        java.awt.Paint paint17 = legendItem14.getLinePaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection18 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection18, 4);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection18);
        int int22 = taskSeriesCollection18.getRowCount();
        legendItem14.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection18);
        try {
            java.lang.Number number26 = taskSeriesCollection18.getPercentComplete((int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = stackedBarRenderer3D1.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double11 = dateAxis10.getUpperMargin();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) dateAxis10, rectangle2D13, (double) 100L);
        dateAxis10.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        org.jfree.chart.renderer.Outlier outlier2 = null;
        boolean boolean3 = outlierListCollection0.add(outlier2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month6, shape8, "{0}", "ThreadContext");
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape8, paint13, stroke14, paint15);
        boolean boolean17 = segmentedTimeline1.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue(15, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        java.awt.Stroke stroke5 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine2 = null;
        textBlock1.addLine(textLine2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textBlock1.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock1.setLineAlignment(horizontalAlignment5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "SortOrder.ASCENDING", textBlock1, textBlockAnchor7, textAnchor8, (double) (byte) 0);
        java.lang.Object obj11 = categoryTick10.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        minMaxCategoryRenderer2.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition4, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = minMaxCategoryRenderer2.getLegendItemToolTipGenerator();
        java.awt.Paint paint8 = minMaxCategoryRenderer2.getBaseItemLabelPaint();
        minMaxCategoryRenderer2.setBaseCreateEntities(true);
        boolean boolean11 = stackedBarRenderer3D1.equals((java.lang.Object) true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        stackedBarRenderer3D1.setBaseSeriesVisible(true, false);
        java.lang.Object obj6 = stackedBarRenderer3D1.clone();
        double double7 = stackedBarRenderer3D1.getXOffset();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.0d + "'", double7 == 12.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = chartRenderingInfo2.getEntityCollection();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertNotNull(entityCollection4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("August");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getUpperMargin();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        java.lang.Object obj12 = null;
        boolean boolean13 = ringPlot7.equals(obj12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot14.equals((java.lang.Object) (short) 0);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        ringPlot14.setLabelLinkPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot14.setLabelBackgroundPaint((java.awt.Paint) color19);
        ringPlot7.setBaseSectionOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font6, (java.awt.Paint) color19);
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getAngleGridlinePaint();
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.TOP_RIGHT", font6, paint24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean28 = dateAxis27.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition29 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis27.setTickMarkPosition(dateTickMarkPosition29);
        boolean boolean31 = textBlock25.equals((java.lang.Object) dateAxis27);
        dateAxis27.setRange((double) (short) 0, (double) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        intervalMarker2.setEndValue((double) 32400097L);
        java.lang.Object obj6 = intervalMarker2.clone();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint8 = polarPlot7.getAngleGridlinePaint();
        java.awt.Paint paint9 = null;
        polarPlot7.setRadiusGridlinePaint(paint9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        polarPlot7.datasetChanged(datasetChangeEvent12);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot7);
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        ringPlot0.setCircular(false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month10, shape12, "{0}", "ThreadContext");
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape12, paint17, stroke18, paint19);
        legendItem20.setSeriesKey((java.lang.Comparable) 128);
        java.awt.Paint paint23 = legendItem20.getLinePaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection24 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection24, 4);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection24);
        int int28 = taskSeriesCollection24.getRowCount();
        legendItem20.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection24);
        legendItemCollection5.add(legendItem20);
        int int31 = legendItem20.getSeriesIndex();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(pieDataset26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (byte) 10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        intervalMarker2.setEndValue((double) 32400097L);
        java.lang.Object obj6 = intervalMarker2.clone();
        float float7 = intervalMarker2.getAlpha();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Layer.FOREGROUND", "Layer.FOREGROUND", "", "RectangleEdge.TOP");
        java.lang.String str5 = library4.getInfo();
        java.lang.String str6 = library4.getName();
        java.lang.String str7 = library4.getName();
        java.lang.String str8 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.TOP" + "'", str5.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Layer.FOREGROUND" + "'", str6.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.FOREGROUND" + "'", str7.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.TOP" + "'", str8.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getUpperMargin();
        categoryAxis1.setLowerMargin((double) 1.0f);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int6 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis2.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot4);
        boolean boolean6 = stackedBarRenderer0.equals((java.lang.Object) multiplePiePlot4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        try {
            org.jfree.data.Range range8 = stackedBarRenderer0.findRangeBounds(categoryDataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        outlierListCollection0.setHighFarOut(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date14 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit13);
        dateAxis1.setMinimumDate(date14);
        dateAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection15 = new org.jfree.data.gantt.TaskSeriesCollection();
        legendItem14.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection15);
        java.lang.Comparable comparable17 = legendItem14.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(comparable17);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        legendTitle4.setItemPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = legendTitle4.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Color color2 = java.awt.Color.yellow;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color2);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset(10.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D8.getPositiveItemLabelPositionFallback();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D8.setBaseOutlinePaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = stackedBarRenderer3D8.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double18 = dateAxis17.getUpperMargin();
        java.awt.Paint paint19 = dateAxis17.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        stackedBarRenderer3D8.drawRangeGridline(graphics2D14, categoryPlot15, (org.jfree.chart.axis.ValueAxis) dateAxis17, rectangle2D20, (double) 100L);
        java.awt.Shape shape23 = dateAxis17.getDownArrow();
        minMaxCategoryRenderer0.setSeriesShape((int) '#', shape23);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = minMaxCategoryRenderer0.getSeriesItemLabelGenerator(6);
        boolean boolean28 = minMaxCategoryRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection29 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset31 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection29, 4);
        int int32 = taskSeriesCollection29.getSeriesCount();
        int int33 = taskSeriesCollection29.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double36 = categoryAxis35.getUpperMargin();
        java.awt.Font font37 = categoryAxis35.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean40 = dateAxis39.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition41 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis39.setTickMarkPosition(dateTickMarkPosition41);
        dateAxis39.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = dateAxis39.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean49 = stackedBarRenderer3D47.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor51 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor52 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor53 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor51, textAnchor52, textAnchor53, (double) 0L);
        stackedBarRenderer3D47.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition55);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection29, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D47);
        java.lang.Comparable[] comparableArray65 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray66 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray67 = null;
        java.lang.Number[][] numberArray68 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset69 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray65, comparableArray66, numberArray67, numberArray68);
        categoryPlot57.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset69);
        boolean boolean71 = categoryPlot57.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace72 = new org.jfree.chart.axis.AxisSpace();
        double double73 = axisSpace72.getRight();
        categoryPlot57.setFixedDomainAxisSpace(axisSpace72);
        categoryPlot57.setRangeCrosshairValue(0.0d);
        minMaxCategoryRenderer0.setPlot(categoryPlot57);
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(pieDataset31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition41);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor51);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertNotNull(comparableArray65);
        org.junit.Assert.assertNotNull(comparableArray66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D1.setBaseOutlinePaint((java.awt.Paint) color3);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, 4);
        int int11 = taskSeriesCollection8.getSeriesCount();
        int int12 = taskSeriesCollection8.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double15 = categoryAxis14.getUpperMargin();
        java.awt.Font font16 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis18.setTickMarkPosition(dateTickMarkPosition20);
        dateAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean28 = stackedBarRenderer3D26.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31, textAnchor32, (double) 0L);
        stackedBarRenderer3D26.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D26);
        java.awt.Paint paint37 = categoryPlot36.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean40 = dateAxis39.isTickLabelsVisible();
        dateAxis39.setFixedAutoRange((double) (byte) 1);
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D7, categoryPlot36, (org.jfree.chart.axis.ValueAxis) dateAxis39, marker43, rectangle2D44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot36.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = categoryPlot36.getRenderer(15);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNull(categoryItemRenderer48);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha(0.0f);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month8, shape10, "{0}", "ThreadContext");
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape10, paint15, stroke16, paint17);
        categoryMarker1.setLabelPaint(paint17);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(paint17);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue3 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 10L, (java.lang.Number) 10L);
        java.lang.Object obj4 = defaultKeyedValue3.clone();
        java.lang.Comparable comparable5 = defaultKeyedValue3.getKey();
        boolean boolean6 = dateTickMarkPosition0.equals((java.lang.Object) comparable5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10L + "'", comparable5.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean8 = lengthConstraintType4.equals((java.lang.Object) 10);
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 1, range3, lengthConstraintType4, (double) (-1), range10, lengthConstraintType11);
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 100L, range1, lengthConstraintType11, 0.0d, range14, lengthConstraintType15);
        java.lang.Object obj17 = null;
        boolean boolean18 = lengthConstraintType15.equals(obj17);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) 1);
        java.awt.Font font3 = ringPlot0.getLabelFont();
        float float4 = ringPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray5 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(strEnumeration3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        boolean boolean11 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtTop();
        java.util.List list17 = axisCollection15.getAxesAtTop();
        xYPlot0.drawDomainTickBands(graphics2D13, rectangle2D14, list17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke19);
        java.awt.Stroke stroke21 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke22 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setShadowXOffset((double) 60000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        dateAxis1.setPositiveArrowVisible(false);
        boolean boolean10 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        boolean boolean8 = polarPlot3.isAngleGridlinesVisible();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        chartRenderingInfo12.setEntityCollection(entityCollection13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot16.getRangeAxisEdge();
        java.awt.geom.Point2D point2D18 = xYPlot16.getQuadrantOrigin();
        polarPlot3.zoomDomainAxes((double) (-1L), (double) 2.0f, plotRenderingInfo15, point2D18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, true);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        try {
            java.lang.Comparable comparable12 = taskSeriesCollection5.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        boolean boolean9 = minMaxCategoryRenderer0.getAutoPopulateSeriesPaint();
        java.lang.Class<?> wildcardClass10 = minMaxCategoryRenderer0.getClass();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, 4);
        int int14 = taskSeriesCollection11.getSeriesCount();
        int int15 = taskSeriesCollection11.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double18 = categoryAxis17.getUpperMargin();
        java.awt.Font font19 = categoryAxis17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean22 = dateAxis21.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis21.setTickMarkPosition(dateTickMarkPosition23);
        dateAxis21.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = dateAxis21.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean31 = stackedBarRenderer3D29.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor33 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor33, textAnchor34, textAnchor35, (double) 0L);
        stackedBarRenderer3D29.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D29);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot39.getDomainAxis(0);
        categoryPlot39.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot39.getRangeAxisLocation();
        java.awt.Paint paint44 = categoryPlot39.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation46 = axisLocation45.getOpposite();
        categoryPlot39.setDomainAxisLocation(axisLocation46, false);
        boolean boolean49 = minMaxCategoryRenderer0.equals((java.lang.Object) axisLocation46);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor33);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(categoryAxis41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        ringPlot7.removeChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(paint10);
        ringPlot7.setShadowPaint(paint10);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        ringPlot13.removeChangeListener(plotChangeListener14);
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot13.setBaseSectionPaint(paint16);
        ringPlot7.setLabelShadowPaint(paint16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ringPlot7);
        polarPlot0.rendererChanged(rendererChangeEvent19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle0.getVerticalAlignment();
        textTitle0.setExpandToFitSpace(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double9 = categoryAxis8.getUpperMargin();
        java.awt.Font font10 = categoryAxis8.getLabelFont();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP_RIGHT", font10);
        textTitle0.setFont(font10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        int int2 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle5.setPadding(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle5.getBounds();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, 4);
        int int12 = taskSeriesCollection9.getSeriesCount();
        int int13 = taskSeriesCollection9.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double16 = categoryAxis15.getUpperMargin();
        java.awt.Font font17 = categoryAxis15.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean20 = dateAxis19.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition21 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis19.setTickMarkPosition(dateTickMarkPosition21);
        dateAxis19.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis19.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean29 = stackedBarRenderer3D27.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32, textAnchor33, (double) 0L);
        stackedBarRenderer3D27.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D27);
        java.lang.Comparable[] comparableArray45 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray46 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray47 = null;
        java.lang.Number[][] numberArray48 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset49 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray45, comparableArray46, numberArray47, numberArray48);
        categoryPlot37.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset49);
        categoryPlot37.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot37.getRangeAxisEdge((int) (byte) 1);
        double double55 = categoryAxis3D1.getCategoryMiddle(255, 0, rectangle2D8, rectangleEdge54);
        double double56 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition21);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(comparableArray45);
        org.junit.Assert.assertNotNull(comparableArray46);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        lineAndShapeRenderer2.setSeriesShapesFilled(100, true);
        lineAndShapeRenderer2.setUseFillPaint(true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getAutoPopulateSeriesPaint();
        int int2 = stackedBarRenderer0.getPassCount();
        stackedBarRenderer0.setBaseCreateEntities(false);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        int int9 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font13 = categoryAxis11.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28, textAnchor29, (double) 0L);
        stackedBarRenderer3D23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot33.getDomainAxis(0);
        boolean boolean36 = stackedBarRenderer0.equals((java.lang.Object) categoryPlot33);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double40 = categoryAxis39.getUpperMargin();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = null;
        minMaxCategoryRenderer42.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition44, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator47 = minMaxCategoryRenderer42.getLegendItemToolTipGenerator();
        java.awt.Color color49 = java.awt.Color.DARK_GRAY;
        minMaxCategoryRenderer42.setSeriesOutlinePaint(0, (java.awt.Paint) color49);
        categoryAxis39.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color49);
        categoryAxis39.setAxisLineVisible(false);
        categoryPlot33.setDomainAxis((int) (byte) 10, categoryAxis39);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator47);
        org.junit.Assert.assertNotNull(color49);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke4 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot3.setRenderer(polarItemRenderer5);
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) polarPlot3);
        boolean boolean8 = polarPlot3.isRadiusGridlinesVisible();
        int int9 = polarPlot3.getSeriesCount();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        polarPlot3.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot3.getOrientation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font5);
        dateAxis1.setLabel("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isTickLabelsVisible();
        dateAxis10.setFixedAutoRange((double) (byte) 1);
        dateAxis10.setLowerBound(12.0d);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis10.setDownArrow(shape17);
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange();
        dateAxis10.setDefaultAutoRange((org.jfree.data.Range) dateRange19);
        org.jfree.data.Range range23 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange19, 0.0d, (double) 3);
        dateAxis1.setRange((org.jfree.data.Range) dateRange19, false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        double double7 = ringPlot0.getShadowYOffset();
        double double8 = ringPlot0.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.awt.Color color1 = java.awt.Color.getColor("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getRangeAxisEdge();
        java.awt.geom.Point2D point2D9 = xYPlot7.getQuadrantOrigin();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        ringPlot10.setShadowXOffset((double) 1);
        java.awt.Paint paint13 = ringPlot10.getShadowPaint();
        xYPlot7.setRangeCrosshairPaint(paint13);
        ringPlot0.setBaseSectionPaint(paint13);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.title.Title title12 = null;
        jFreeChart11.removeSubtitle(title12);
        jFreeChart11.setBackgroundImageAlpha((float) 128);
        jFreeChart11.setAntiAlias(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator3 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer1.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator3, false);
        java.text.NumberFormat numberFormat6 = standardCategoryToolTipGenerator3.getNumberFormat();
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator7 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        try {
            java.lang.Comparable comparable43 = defaultIntervalCategoryDataset40.getSeriesKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : 128");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        int int11 = defaultIntervalCategoryDataset10.getCategoryCount();
        try {
            defaultIntervalCategoryDataset10.setStartValue(500, (java.lang.Comparable) 2019L, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot0.setShadowYOffset((double) 10L);
        ringPlot0.setCircular(false);
        float float11 = ringPlot0.getBackgroundImageAlpha();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, 4);
        int int15 = taskSeriesCollection12.getSeriesCount();
        int int16 = taskSeriesCollection12.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double19 = categoryAxis18.getUpperMargin();
        java.awt.Font font20 = categoryAxis18.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean23 = dateAxis22.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition24 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis22.setTickMarkPosition(dateTickMarkPosition24);
        dateAxis22.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis22.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean32 = stackedBarRenderer3D30.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor34, textAnchor35, textAnchor36, (double) 0L);
        stackedBarRenderer3D30.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition38);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D30);
        java.lang.Comparable[] comparableArray48 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray49 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray50 = null;
        java.lang.Number[][] numberArray51 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset52 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray48, comparableArray49, numberArray50, numberArray51);
        categoryPlot40.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset52);
        categoryPlot40.setRangeGridlinesVisible(true);
        java.awt.Paint paint56 = categoryPlot40.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer57 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        waterfallBarRenderer57.setNegativeBarPaint((java.awt.Paint) color58);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int62 = color61.getGreen();
        java.awt.image.ColorModel colorModel63 = null;
        java.awt.Rectangle rectangle64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        java.awt.geom.AffineTransform affineTransform66 = null;
        java.awt.RenderingHints renderingHints67 = null;
        java.awt.PaintContext paintContext68 = color61.createContext(colorModel63, rectangle64, rectangle2D65, affineTransform66, renderingHints67);
        java.awt.Color color69 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace70 = color69.getColorSpace();
        org.jfree.chart.plot.RingPlot ringPlot71 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener72 = null;
        ringPlot71.removeChangeListener(plotChangeListener72);
        java.awt.Paint paint74 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder75 = new org.jfree.chart.block.BlockBorder(paint74);
        ringPlot71.setShadowPaint(paint74);
        java.awt.Color color77 = java.awt.Color.YELLOW;
        ringPlot71.setOutlinePaint((java.awt.Paint) color77);
        float[] floatArray84 = new float[] { 60000L, 3, 10.0f, 100, 4 };
        float[] floatArray85 = color77.getRGBComponents(floatArray84);
        float[] floatArray86 = color61.getColorComponents(colorSpace70, floatArray84);
        float[] floatArray87 = color60.getRGBColorComponents(floatArray84);
        float[] floatArray88 = color58.getRGBColorComponents(floatArray84);
        java.awt.Color color89 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color90 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer91 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint56, (java.awt.Paint) color58, (java.awt.Paint) color89, (java.awt.Paint) color90);
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color89);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition24);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(comparableArray48);
        org.junit.Assert.assertNotNull(comparableArray49);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 128 + "'", int62 == 128);
        org.junit.Assert.assertNotNull(paintContext68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(colorSpace70);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(floatArray84);
        org.junit.Assert.assertNotNull(floatArray85);
        org.junit.Assert.assertNotNull(floatArray86);
        org.junit.Assert.assertNotNull(floatArray87);
        org.junit.Assert.assertNotNull(floatArray88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(color90);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean3 = size2D0.equals((java.lang.Object) numberTickUnit2);
        java.lang.Object obj4 = size2D0.clone();
        size2D0.setWidth(9.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d);
        categoryMarker1.setAlpha(0.0f);
        categoryMarker1.setDrawAsLine(true);
        java.awt.Stroke stroke6 = categoryMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color1 = java.awt.Color.yellow;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline1.getBaseTimeline();
        boolean boolean3 = categoryLabelPositions0.equals((java.lang.Object) segmentedTimeline1);
        java.lang.Object obj4 = segmentedTimeline1.clone();
        java.util.Date date6 = segmentedTimeline1.getDate((long) 5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double9 = dateAxis8.getUpperMargin();
        java.awt.Paint paint10 = dateAxis8.getAxisLinePaint();
        java.util.Date date11 = dateAxis8.getMaximumDate();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = segmentedTimeline13.getBaseTimeline();
        boolean boolean15 = categoryLabelPositions12.equals((java.lang.Object) segmentedTimeline13);
        java.lang.Object obj16 = segmentedTimeline13.clone();
        java.util.Date date18 = segmentedTimeline13.getDate((long) 5);
        boolean boolean19 = segmentedTimeline1.containsDomainRange(date11, date18);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        java.lang.Boolean boolean4 = stackedBarRenderer3D1.getSeriesVisible(1);
        boolean boolean7 = stackedBarRenderer3D1.getItemCreateEntity(100, 0);
        double double8 = stackedBarRenderer3D1.getMaximumBarWidth();
        double double9 = stackedBarRenderer3D1.getXOffset();
        boolean boolean10 = stackedBarRenderer3D1.getIncludeBaseInRange();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 12.0d + "'", double9 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape2 = null;
        boolean boolean3 = org.jfree.chart.util.ShapeUtilities.equal(shape1, shape2);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        double double8 = ringPlot0.getShadowYOffset();
        java.awt.Paint paint9 = ringPlot0.getLabelLinkPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        ringPlot0.setBackgroundPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) (short) 0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color4);
        boolean boolean6 = booleanList0.equals((java.lang.Object) color4);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) (short) 0);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        ringPlot7.setLabelLinkPaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = ringPlot7.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot7.setShadowYOffset((double) 10L);
        ringPlot7.setCircular(false);
        float float18 = ringPlot7.getBackgroundImageAlpha();
        boolean boolean19 = booleanList0.equals((java.lang.Object) ringPlot7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        minMaxCategoryRenderer0.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator2, false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean7 = standardCategoryToolTipGenerator2.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        double double7 = ringPlot0.getShadowYOffset();
        java.awt.Paint paint8 = ringPlot0.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = ringPlot0.getURLGenerator();
        double double10 = ringPlot0.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(pieURLGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        int int11 = defaultIntervalCategoryDataset10.getCategoryCount();
        java.util.List list12 = defaultIntervalCategoryDataset10.getColumnKeys();
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) (short) 0);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = ringPlot0.getSectionPaint((java.lang.Comparable) (-1L));
        double double8 = ringPlot0.getExplodePercent((java.lang.Comparable) (short) 1);
        java.lang.Object obj9 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues2.clear();
        boolean boolean4 = size2D0.equals((java.lang.Object) defaultKeyedValues2);
        java.lang.Object obj5 = defaultKeyedValues2.clone();
        defaultKeyedValues2.addValue((java.lang.Comparable) 3.0d, (java.lang.Number) 1560668399999L);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double6 = categoryAxis5.getUpperMargin();
        java.awt.Font font8 = categoryAxis5.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot9.equals((java.lang.Object) (short) 0);
        java.awt.Color color12 = java.awt.Color.YELLOW;
        ringPlot9.setLabelLinkPaint((java.awt.Paint) color12);
        java.lang.Object obj14 = null;
        boolean boolean15 = ringPlot9.equals(obj14);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        boolean boolean18 = ringPlot16.equals((java.lang.Object) (short) 0);
        java.awt.Color color19 = java.awt.Color.YELLOW;
        ringPlot16.setLabelLinkPaint((java.awt.Paint) color19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot16.setLabelBackgroundPaint((java.awt.Paint) color21);
        ringPlot9.setBaseSectionOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font8, (java.awt.Paint) color21);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint26 = polarPlot25.getAngleGridlinePaint();
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.TOP_RIGHT", font8, paint26);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("SortOrder.DESCENDING", font8);
        boolean boolean29 = itemLabelAnchor0.equals((java.lang.Object) font8);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        boolean boolean7 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        ringPlot1.removeChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot1.setBaseSectionPaint(paint4);
        boolean boolean6 = size2D0.equals((java.lang.Object) ringPlot1);
        java.lang.Object obj7 = ringPlot1.clone();
        ringPlot1.setCircular(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        ringPlot1.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int3 = segmentedTimeline2.getSegmentsIncluded();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean6 = dateAxis5.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis5.setTickMarkPosition(dateTickMarkPosition7);
        dateAxis5.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis5.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean14 = dateAxis13.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date18 = dateAxis13.calculateLowestVisibleTickValue(dateTickUnit17);
        dateAxis5.setMinimumDate(date18);
        long long20 = segmentedTimeline2.getTime(date18);
        segmentedTimeline0.addBaseTimelineException(date18);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10, (java.lang.Number) 4);
        boolean boolean6 = lengthConstraintType2.equals((java.lang.Object) 10);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType2, (double) (-1), range8, lengthConstraintType9);
        java.lang.String str11 = rectangleConstraint10.toString();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean14 = dateAxis13.isTickLabelsVisible();
        dateAxis13.setFixedAutoRange((double) (byte) 1);
        dateAxis13.setLowerBound(12.0d);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        dateAxis13.setDownArrow(shape20);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        dateAxis13.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range26 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange22, 0.0d, (double) 3);
        double double28 = dateRange22.constrain(12.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint10.toRangeWidth((org.jfree.data.Range) dateRange22);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        boolean boolean32 = ringPlot30.equals((java.lang.Object) (short) 0);
        java.awt.Color color33 = java.awt.Color.YELLOW;
        ringPlot30.setLabelLinkPaint((java.awt.Paint) color33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot30.setLabelBackgroundPaint((java.awt.Paint) color35);
        boolean boolean37 = dateRange22.equals((java.lang.Object) ringPlot30);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]" + "'", str11.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.awt.Paint paint29 = categoryPlot28.getDomainGridlinePaint();
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke31 = polarPlot30.getRadiusGridlineStroke();
        categoryPlot28.setRangeCrosshairStroke(stroke31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot28.getRenderer(10);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(categoryItemRenderer34);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.title.Title title12 = null;
        jFreeChart11.removeSubtitle(title12);
        boolean boolean14 = jFreeChart11.getAntiAlias();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = jFreeChart11.getPadding();
        jFreeChart11.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        xYPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("TextBlockAnchor.CENTER_LEFT", "SortOrder.DESCENDING", "August", image3, "Pie 3D Plot", "RectangleEdge.TOP", "{0}");
        java.lang.String str8 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.CENTER_LEFT version SortOrder.DESCENDING.\nPie 3D Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:August\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY TextBlockAnchor.CENTER_LEFT:None\nTextBlockAnchor.CENTER_LEFT LICENCE TERMS:\n{0}" + "'", str8.equals("TextBlockAnchor.CENTER_LEFT version SortOrder.DESCENDING.\nPie 3D Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:August\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY TextBlockAnchor.CENTER_LEFT:None\nTextBlockAnchor.CENTER_LEFT LICENCE TERMS:\n{0}"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        categoryPlot28.setRangeGridlinesVisible(true);
        java.awt.Paint paint44 = categoryPlot28.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot28.setDomainAxisLocation(axisLocation45, true);
        double double48 = categoryPlot28.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop(0.0d);
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        double double4 = axisSpace3.getTop();
        axisSpace3.setBottom((double) 31);
        axisSpace0.ensureAtLeast(axisSpace3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedBarRenderer3D1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        stackedBarRenderer3D1.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition4);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        minMaxCategoryRenderer6.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition8, true);
        org.jfree.chart.util.BooleanList booleanList11 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        boolean boolean17 = booleanList11.equals((java.lang.Object) color15);
        minMaxCategoryRenderer6.setBaseItemLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = minMaxCategoryRenderer6.getLegendItemLabelGenerator();
        stackedBarRenderer3D1.setLegendItemLabelGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedBarRenderer3D1.getBaseURLGenerator();
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(categoryURLGenerator21);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        java.lang.Object obj2 = axisSpace0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle3.setPadding(rectangleInsets4);
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = axisSpace0.reserved(rectangle2D6, rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNull(rectangle2D8);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot3.getLegendItems();
        double double6 = multiplePiePlot3.getLimit();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsIncludedSize();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean4 = dateAxis3.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date11 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit10);
        java.util.Date date12 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline0.getSegment(date12);
        boolean boolean16 = segment13.contains((-1L), 100L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25200000L + "'", long1 == 25200000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        categoryPlot28.clearDomainMarkers();
        categoryPlot28.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot28.getRenderer();
        categoryPlot28.configureRangeAxes();
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryItemRenderer32);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getMiddleMillisecond();
        long long4 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = xYPlot0.getOrientation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        int int9 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double12 = categoryAxis11.getUpperMargin();
        java.awt.Font font13 = categoryAxis11.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis15.setTickMarkPosition(dateTickMarkPosition17);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis15.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor28, textAnchor29, (double) 0L);
        stackedBarRenderer3D23.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot33.getDomainAxis(0);
        java.awt.Paint paint36 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double39 = dateAxis38.getUpperMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = stackedBarRenderer3D41.getPositiveItemLabelPositionFallback();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D41.setBaseOutlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = stackedBarRenderer3D41.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double51 = dateAxis50.getUpperMargin();
        java.awt.Paint paint52 = dateAxis50.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        stackedBarRenderer3D41.drawRangeGridline(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D53, (double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean58 = dateAxis57.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date62 = dateAxis57.calculateLowestVisibleTickValue(dateTickUnit61);
        dateAxis50.setTickUnit(dateTickUnit61);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke65 = polarPlot64.getRadiusGridlineStroke();
        dateAxis50.setTickMarkStroke(stroke65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { dateAxis38, dateAxis50 };
        categoryPlot33.setRangeAxes(valueAxisArray67);
        xYPlot0.setDomainAxes(valueAxisArray67);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot0.getRangeAxisLocation((-457));
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = xYPlot72.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = xYPlot72.getAxisOffset();
        java.awt.Paint paint75 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder(paint75);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = blockBorder76.getInsets();
        double double79 = rectangleInsets77.trimHeight((double) 100L);
        double double81 = rectangleInsets77.calculateLeftInset((double) 3);
        xYPlot72.setAxisOffset(rectangleInsets77);
        boolean boolean83 = xYPlot72.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation84 = xYPlot72.getOrientation();
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.axis.AxisCollection axisCollection87 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list88 = axisCollection87.getAxesAtTop();
        java.util.List list89 = axisCollection87.getAxesAtTop();
        xYPlot72.drawDomainTickBands(graphics2D85, rectangle2D86, list89);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer91 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon92 = minMaxCategoryRenderer91.getMinIcon();
        java.awt.Color color94 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        minMaxCategoryRenderer91.setSeriesFillPaint(0, (java.awt.Paint) color94, true);
        xYPlot72.setDomainZeroBaselinePaint((java.awt.Paint) color94);
        java.awt.Stroke stroke98 = xYPlot72.getRangeZeroBaselineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke98);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 98.0d + "'", double79 == 98.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.0d + "'", double81 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(plotOrientation84);
        org.junit.Assert.assertNotNull(list88);
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNotNull(icon92);
        org.junit.Assert.assertNotNull(color94);
        org.junit.Assert.assertNotNull(stroke98);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.title.Title title12 = null;
        jFreeChart11.removeSubtitle(title12);
        org.jfree.chart.plot.Plot plot14 = jFreeChart11.getPlot();
        jFreeChart11.setBackgroundImageAlpha((float) 255);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle0.setPadding(rectangleInsets1);
        textTitle0.setExpandToFitSpace(false);
        textTitle0.setToolTipText("RectangleAnchor.CENTER");
        textTitle0.setText("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 0L);
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        java.lang.Object obj6 = null;
        boolean boolean7 = textAnchor5.equals(obj6);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint9 = polarPlot8.getAngleGridlinePaint();
        java.awt.Paint paint10 = null;
        polarPlot8.setRadiusGridlinePaint(paint10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot8);
        org.jfree.chart.util.BooleanList booleanList13 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot14.equals((java.lang.Object) (short) 0);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        ringPlot14.setLabelLinkPaint((java.awt.Paint) color17);
        boolean boolean19 = booleanList13.equals((java.lang.Object) color17);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        boolean boolean22 = ringPlot20.equals((java.lang.Object) (short) 0);
        java.awt.Color color23 = java.awt.Color.YELLOW;
        ringPlot20.setLabelLinkPaint((java.awt.Paint) color23);
        java.awt.Paint paint26 = ringPlot20.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot20.setShadowYOffset((double) 10L);
        ringPlot20.setCircular(false);
        boolean boolean31 = booleanList13.equals((java.lang.Object) ringPlot20);
        java.awt.Paint paint32 = ringPlot20.getBackgroundPaint();
        boolean boolean33 = legendTitle12.equals((java.lang.Object) ringPlot20);
        ringPlot20.setOuterSeparatorExtension(8.64E7d);
        boolean boolean36 = textAnchor5.equals((java.lang.Object) 8.64E7d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("October", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "ItemLabelAnchor.INSIDE2", image3, "org.jfree.data.UnknownKeyException: Size2D[width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]");
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        ringPlot0.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean9 = ringPlot0.equals((java.lang.Object) stroke8);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        minMaxCategoryRenderer11.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition13, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = minMaxCategoryRenderer11.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon18 = minMaxCategoryRenderer17.getMinIcon();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer19 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon20 = minMaxCategoryRenderer19.getMinIcon();
        java.awt.Stroke stroke23 = minMaxCategoryRenderer19.getItemStroke((int) (byte) 100, (int) (short) 100);
        minMaxCategoryRenderer17.setBaseOutlineStroke(stroke23, false);
        minMaxCategoryRenderer11.setGroupStroke(stroke23);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 11, stroke23);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double32 = categoryAxis31.getUpperMargin();
        java.awt.Font font33 = categoryAxis31.getLabelFont();
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP_RIGHT", font33);
        java.awt.Color color35 = java.awt.Color.yellow;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("October", font33, (java.awt.Paint) color35);
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(icon18);
        org.junit.Assert.assertNotNull(icon20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(textBlock36);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        minMaxCategoryRenderer1.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition3, true);
        java.awt.Stroke stroke7 = minMaxCategoryRenderer1.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer1.setItemLabelAnchorOffset((double) 0);
        boolean boolean10 = minMaxCategoryRenderer1.getAutoPopulateSeriesPaint();
        java.lang.Class<?> wildcardClass11 = minMaxCategoryRenderer1.getClass();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        minMaxCategoryRenderer13.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition15, true);
        java.awt.Stroke stroke19 = minMaxCategoryRenderer13.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer13.setItemLabelAnchorOffset((double) 0);
        boolean boolean22 = minMaxCategoryRenderer13.getAutoPopulateSeriesPaint();
        java.lang.Class<?> wildcardClass23 = minMaxCategoryRenderer13.getClass();
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleEdge.TOP", (java.lang.Class) wildcardClass23);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AreaRendererEndType.LEVEL", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass23);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(6, 98.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (byte) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues2.clear();
        boolean boolean4 = size2D0.equals((java.lang.Object) defaultKeyedValues2);
        try {
            java.lang.Number number6 = defaultKeyedValues2.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener9 = null;
        taskSeriesCollection5.addChangeListener(datasetChangeListener9);
        legendItemEntity4.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection5);
        java.lang.Comparable comparable12 = legendItemEntity4.getSeriesKey();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon14 = minMaxCategoryRenderer13.getMinIcon();
        java.awt.Color color15 = java.awt.Color.yellow;
        minMaxCategoryRenderer13.setGroupPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedBarRenderer3D19.getPositiveItemLabelPositionFallback();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D19.setBaseOutlinePaint((java.awt.Paint) color21);
        java.awt.Paint paint24 = stackedBarRenderer3D19.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double29 = dateAxis28.getUpperMargin();
        java.awt.Paint paint30 = dateAxis28.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        stackedBarRenderer3D19.drawRangeGridline(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) dateAxis28, rectangle2D31, (double) 100L);
        java.awt.Font font34 = dateAxis28.getLabelFont();
        minMaxCategoryRenderer13.setSeriesItemLabelFont(0, font34);
        boolean boolean36 = legendItemEntity4.equals((java.lang.Object) minMaxCategoryRenderer13);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertNotNull(icon14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long13 = segmentedTimeline12.getSegmentsIncludedSize();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean16 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean19 = dateAxis18.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date23 = dateAxis18.calculateLowestVisibleTickValue(dateTickUnit22);
        java.util.Date date24 = dateAxis15.calculateHighestVisibleTickValue(dateTickUnit22);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment25 = segmentedTimeline12.getSegment(date24);
        segment25.moveIndexToStart();
        try {
            defaultIntervalCategoryDataset10.setStartValue(0, (java.lang.Comparable) segment25, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25200000L + "'", long13 == 25200000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(segment25);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 4);
        int int3 = taskSeriesCollection0.getSeriesCount();
        int int4 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getUpperMargin();
        java.awt.Font font8 = categoryAxis6.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        dateAxis10.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean20 = stackedBarRenderer3D18.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23, textAnchor24, (double) 0L);
        stackedBarRenderer3D18.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D18);
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray37 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray38 = null;
        java.lang.Number[][] numberArray39 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray36, comparableArray37, numberArray38, numberArray39);
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryPlot28.getAxisOffset();
        categoryPlot28.mapDatasetToDomainAxis(5, 0);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(comparableArray37);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer1 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon2 = minMaxCategoryRenderer1.getMinIcon();
        java.awt.Color color3 = java.awt.Color.yellow;
        minMaxCategoryRenderer1.setGroupPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D7.getPositiveItemLabelPositionFallback();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        stackedBarRenderer3D7.setBaseOutlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = stackedBarRenderer3D7.getSeriesPaint((int) (short) -1);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        double double17 = dateAxis16.getUpperMargin();
        java.awt.Paint paint18 = dateAxis16.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        stackedBarRenderer3D7.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) dateAxis16, rectangle2D19, (double) 100L);
        java.awt.Font font22 = dateAxis16.getLabelFont();
        minMaxCategoryRenderer1.setSeriesItemLabelFont(0, font22);
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("August", font22);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double28 = categoryAxis27.getUpperMargin();
        java.awt.Font font30 = categoryAxis27.getTickLabelFont((java.lang.Comparable) "Apr");
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        boolean boolean33 = ringPlot31.equals((java.lang.Object) (short) 0);
        java.awt.Color color34 = java.awt.Color.YELLOW;
        ringPlot31.setLabelLinkPaint((java.awt.Paint) color34);
        java.lang.Object obj36 = null;
        boolean boolean37 = ringPlot31.equals(obj36);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        boolean boolean40 = ringPlot38.equals((java.lang.Object) (short) 0);
        java.awt.Color color41 = java.awt.Color.YELLOW;
        ringPlot38.setLabelLinkPaint((java.awt.Paint) color41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot38.setLabelBackgroundPaint((java.awt.Paint) color43);
        ringPlot31.setBaseSectionOutlinePaint((java.awt.Paint) color43);
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE2", font30, (java.awt.Paint) color43);
        textLine24.removeFragment(textFragment46);
        org.jfree.chart.text.TextFragment textFragment48 = textLine24.getFirstTextFragment();
        org.junit.Assert.assertNotNull(icon2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(textFragment48);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(255);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Stroke stroke4 = minMaxCategoryRenderer0.getItemStroke((int) (byte) 100, (int) (short) 100);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        minMaxCategoryRenderer6.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition8, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range12 = minMaxCategoryRenderer6.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection11);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer14 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        minMaxCategoryRenderer14.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition16, true);
        java.awt.Stroke stroke20 = minMaxCategoryRenderer14.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer6.setSeriesStroke(10, stroke20, false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator24 = new org.jfree.chart.urls.StandardCategoryURLGenerator("Size2D[width=0.0, height=0.0]");
        minMaxCategoryRenderer6.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator24, true);
        minMaxCategoryRenderer0.setSeriesURLGenerator((int) (short) 100, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator24);
        int int28 = minMaxCategoryRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(icon1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        dateAxis1.setPositiveArrowVisible(true);
        double double7 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis9.setTickMarkPosition(dateTickMarkPosition10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = dateAxis9.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(tickUnitSource12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray8 = null;
        java.lang.Number[][] numberArray9 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray6, comparableArray7, numberArray8, numberArray9);
        int int11 = defaultIntervalCategoryDataset10.getCategoryCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean18 = dateAxis17.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date22 = dateAxis17.calculateLowestVisibleTickValue(dateTickUnit21);
        java.util.Date date23 = dateAxis14.calculateHighestVisibleTickValue(dateTickUnit21);
        int int24 = dateTickUnit21.getRollUnit();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean27 = dateAxis26.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis26.setTickMarkPosition(dateTickMarkPosition28);
        dateAxis26.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis26.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean35 = dateAxis34.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date39 = dateAxis34.calculateLowestVisibleTickValue(dateTickUnit38);
        dateAxis26.setMinimumDate(date39);
        java.util.Date date41 = dateTickUnit21.rollDate(date39);
        java.lang.String str43 = dateTickUnit21.valueToString((double) (short) 0);
        try {
            defaultIntervalCategoryDataset10.setStartValue(11, (java.lang.Comparable) dateTickUnit21, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "12/31/69" + "'", str43.equals("12/31/69"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        boolean boolean9 = minMaxCategoryRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke10 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint11 = minMaxCategoryRenderer0.getGroupPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        boolean boolean11 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtTop();
        java.util.List list17 = axisCollection15.getAxesAtTop();
        xYPlot0.drawDomainTickBands(graphics2D13, rectangle2D14, list17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        ringPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        ringPlot0.setShadowPaint(paint3);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        ringPlot6.removeChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot6.setBaseSectionPaint(paint9);
        ringPlot0.setLabelShadowPaint(paint9);
        java.awt.Paint paint12 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(paint12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range6 = minMaxCategoryRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        taskSeriesCollection5.removeAll();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) (short) 0);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        ringPlot8.setLabelLinkPaint((java.awt.Paint) color11);
        java.awt.Paint paint14 = ringPlot8.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot8.setShadowYOffset((double) 10L);
        ringPlot8.setCircular(false);
        taskSeriesCollection5.addChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = ringPlot8.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(pieURLGenerator20);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        polarPlot0.setRenderer(polarItemRenderer2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = polarPlot0.getOrientation();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        dateAxis1.setLabelAngle((double) 2);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
        int int14 = categoryAxis3D13.getMaximumCategoryLabelLines();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle17.setPadding(rectangleInsets18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle17.getBounds();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection21 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection21, 4);
        int int24 = taskSeriesCollection21.getSeriesCount();
        int int25 = taskSeriesCollection21.getRowCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double28 = categoryAxis27.getUpperMargin();
        java.awt.Font font29 = categoryAxis27.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean32 = dateAxis31.isInverted();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis31.setTickMarkPosition(dateTickMarkPosition33);
        dateAxis31.setPositiveArrowVisible(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = dateAxis31.getStandardTickUnits();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean41 = stackedBarRenderer3D39.equals((java.lang.Object) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor43 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor43, textAnchor44, textAnchor45, (double) 0L);
        stackedBarRenderer3D39.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition47);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection21, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D39);
        java.lang.Comparable[] comparableArray57 = new java.lang.Comparable[] { 10.0f, 1, 0.2d, true, 100, (byte) 100 };
        java.lang.Comparable[] comparableArray58 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray59 = null;
        java.lang.Number[][] numberArray60 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset61 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray57, comparableArray58, numberArray59, numberArray60);
        categoryPlot49.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset61);
        categoryPlot49.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = categoryPlot49.getRangeAxisEdge((int) (byte) 1);
        double double67 = categoryAxis3D13.getCategoryMiddle(255, 0, rectangle2D20, rectangleEdge66);
        org.jfree.chart.util.Size2D size2D68 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit70 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean71 = size2D68.equals((java.lang.Object) numberTickUnit70);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D75 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, 4.0d, (double) 2, rectangleAnchor74);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str77 = rectangleEdge76.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        try {
            org.jfree.chart.axis.AxisState axisState80 = dateAxis1.draw(graphics2D10, (double) (byte) -1, rectangle2D20, rectangle2D75, rectangleEdge76, plotRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertNotNull(tickUnitSource37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(comparableArray57);
        org.junit.Assert.assertNotNull(comparableArray58);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "RectangleEdge.TOP" + "'", str77.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean2 = dateAxis1.isTickLabelsVisible();
        dateAxis1.setFixedAutoRange((double) (byte) 1);
        dateAxis1.setLowerBound(12.0d);
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        dateAxis1.setLabelURL("ERROR : Relative To String");
        java.awt.Stroke stroke11 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(paint26);
        legendTitle4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle4.getItemLabelPadding();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimHeight((double) 100L);
        double double9 = rectangleInsets5.calculateLeftInset((double) 3);
        xYPlot0.setAxisOffset(rectangleInsets5);
        boolean boolean11 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtTop();
        java.util.List list17 = axisCollection15.getAxesAtTop();
        xYPlot0.drawDomainTickBands(graphics2D13, rectangle2D14, list17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke19);
        java.awt.Stroke stroke21 = xYPlot0.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke22 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 98.0d + "'", double7 == 98.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean7 = dateAxis6.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER_LEFT");
        boolean boolean10 = dateAxis9.isInverted();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(2, 1);
        java.util.Date date14 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit13);
        java.util.Date date15 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit13);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        textTitle1.setPadding(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font6 = textTitle1.getFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot7.setRenderer(xYItemRenderer8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font6, (org.jfree.chart.plot.Plot) xYPlot7, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.addProgressListener(chartProgressListener12);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, (float) (byte) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, 4);
        int int8 = taskSeriesCollection5.getSeriesCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener9 = null;
        taskSeriesCollection5.addChangeListener(datasetChangeListener9);
        legendItemEntity4.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection5);
        java.lang.Comparable comparable12 = legendItemEntity4.getSeriesKey();
        org.jfree.data.general.Dataset dataset13 = legendItemEntity4.getDataset();
        java.lang.Object obj14 = legendItemEntity4.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertNotNull(dataset13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setExpandToFitSpace(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D5.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        stackedBarRenderer3D5.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition8);
        java.awt.Paint paint12 = stackedBarRenderer3D5.getItemFillPaint(128, (-16318469));
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) stackedBarRenderer3D5);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer1.setRenderAsPercentages(false);
        org.jfree.data.KeyedObject keyedObject4 = new org.jfree.data.KeyedObject((java.lang.Comparable) 'a', (java.lang.Object) false);
        java.lang.Comparable comparable5 = keyedObject4.getKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 'a' + "'", comparable5.equals('a'));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        int int2 = defaultKeyedValues2D0.getColumnCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        java.lang.String str5 = year4.toString();
        java.util.Date date6 = year4.getEnd();
        long long7 = year4.getSerialIndex();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        int int11 = year4.compareTo((java.lang.Object) rectangleInsets10);
        long long12 = year4.getMiddleMillisecond();
        int int13 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) long12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month4, shape6, "{0}", "ThreadContext");
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "TextBlockAnchor.CENTER_LEFT", "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=-1.0]", "Apr", shape6, paint11, stroke12, paint13);
        legendItem14.setSeriesKey((java.lang.Comparable) 128);
        java.text.AttributedString attributedString17 = legendItem14.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(attributedString17);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.event.TitleChangeListener titleChangeListener26 = null;
        legendTitle4.removeChangeListener(titleChangeListener26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor28);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getRowKey(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        int int4 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint2 = null;
        polarPlot0.setRadiusGridlinePaint(paint2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot0);
        org.jfree.chart.util.BooleanList booleanList5 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) (short) 0);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        ringPlot6.setLabelLinkPaint((java.awt.Paint) color9);
        boolean boolean11 = booleanList5.equals((java.lang.Object) color9);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) (short) 0);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        ringPlot12.setLabelLinkPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = ringPlot12.getSectionPaint((java.lang.Comparable) (-1L));
        ringPlot12.setShadowYOffset((double) 10L);
        ringPlot12.setCircular(false);
        boolean boolean23 = booleanList5.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint24 = ringPlot12.getBackgroundPaint();
        boolean boolean25 = legendTitle4.equals((java.lang.Object) ringPlot12);
        java.awt.Paint paint26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(paint26);
        legendTitle4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder27);
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle4.getBounds();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        minMaxCategoryRenderer0.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition2, true);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.lookupSeriesStroke((int) (short) 0);
        minMaxCategoryRenderer0.setItemLabelAnchorOffset((double) 0);
        boolean boolean9 = minMaxCategoryRenderer0.getAutoPopulateSeriesPaint();
        minMaxCategoryRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) false);
        minMaxCategoryRenderer0.setSeriesCreateEntities((int) (short) 1, (java.lang.Boolean) true, true);
        javax.swing.Icon icon17 = minMaxCategoryRenderer0.getMinIcon();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(icon17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) month0, shape2, "{0}", "ThreadContext");
        java.lang.String str7 = categoryLabelEntity6.getShapeType();
        java.lang.Comparable comparable8 = categoryLabelEntity6.getKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
        org.junit.Assert.assertNotNull(comparable8);
    }
}

