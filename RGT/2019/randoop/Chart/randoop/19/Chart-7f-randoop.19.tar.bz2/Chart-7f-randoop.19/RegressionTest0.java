import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Object obj2 = null;
        int int3 = day0.compareTo(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean3 = year1.equals((java.lang.Object) timeZone2);
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560452399999L, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
//        long long4 = day0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Object obj2 = null;
        int int3 = day0.compareTo(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues3.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1560452399999L + "'", comparable5.equals(1560452399999L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        try {
            java.lang.Number number10 = timePeriodValues3.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        try {
            java.lang.Number number7 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (short) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        boolean boolean6 = day0.equals((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int4 = day0.compareTo((java.lang.Object) 10.0f);
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues3.getDataItem(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year9.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        timePeriodValue3.setValue((java.lang.Number) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue2.getPeriod();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        long long15 = year6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        try {
            java.lang.Number number8 = timePeriodValues3.getValue(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        try {
            timePeriodValues3.update(2, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
//        java.lang.String str5 = timePeriodValue4.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[13-June-2019,2019]" + "'", str5.equals("TimePeriodValue[13-June-2019,2019]"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 100.0d);
        boolean boolean21 = timePeriodValue19.equals((java.lang.Object) 'a');
        java.lang.Object obj22 = timePeriodValue19.clone();
        try {
            int int23 = simpleTimePeriod14.compareTo(obj22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        java.lang.Number number14 = null;
//        try {
//            timePeriodValues3.update(6, number14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        try {
            timePeriodValues3.delete((int) (short) 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues3.getDataItem(4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        int int21 = timePeriodValues19.getMinStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean24 = year22.equals((java.lang.Object) timeZone23);
        long long25 = year22.getLastMillisecond();
        int int26 = year22.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (byte) 0);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (-1.0d));
        try {
            int int31 = simpleTimePeriod14.compareTo((java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValue2.equals(obj4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue2);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        int int4 = day0.compareTo((java.lang.Object) 10.0f);
        java.util.Calendar calendar5 = null;
        try {
            day0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 100.0d);
        java.util.Date date9 = day5.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date4, timeZone12);
        try {
            org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date0, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int4 = day0.compareTo((java.lang.Object) 10.0f);
//        long long5 = day0.getSerialIndex();
//        int int6 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        int int9 = timePeriodValues7.getMinStartIndex();
        java.lang.String str10 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues7.createCopy(13, (int) (byte) 10);
        try {
            int int14 = simpleTimePeriod2.compareTo((java.lang.Object) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        long long3 = day0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener13);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getMiddleMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.update((int) (byte) 1, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean16 = year14.equals((java.lang.Object) timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date8, timeZone15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date3, timeZone15);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year18.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, number12);
        java.lang.Class<?> wildcardClass14 = timePeriodValue13.getClass();
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValue13.equals(obj15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        boolean boolean19 = timePeriodValue13.equals((java.lang.Object) regularTimePeriod18);
        java.lang.Number number20 = timePeriodValue13.getValue();
        timePeriodValues3.add(timePeriodValue13);
        int int22 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day9.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timePeriodValue2.equals(obj4);
//        java.lang.String str6 = timePeriodValue2.toString();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str6.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (byte) 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        java.util.Date date11 = day7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date4, timeZone31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date39 = simpleTimePeriod38.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date4, date39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        int int8 = timePeriodValues6.getMinEndIndex();
        boolean boolean9 = timePeriodValues6.isEmpty();
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = null;
        try {
            timePeriodValues6.add(timePeriodValue11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            year4.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        java.lang.String str13 = timePeriodValues3.getDescription();
//        java.lang.Object obj14 = timePeriodValues3.clone();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(obj14);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.String str5 = day0.toString();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
//        int int8 = day0.compareTo((java.lang.Object) 100.0d);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
//        int int5 = day0.getDayOfMonth();
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 100.0d);
        java.util.Date date14 = day10.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date14, date23);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        int int26 = year9.compareTo((java.lang.Object) date25);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year9.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        java.lang.Number number16 = null;
        try {
            timePeriodValues3.update((int) '#', number16);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        int int17 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValues3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        try {
//            timePeriodValues3.update((int) (short) 1, (java.lang.Number) 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
//        long long4 = day0.getFirstMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        java.util.Date date6 = day0.getEnd();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        int int4 = day0.compareTo((java.lang.Object) 10.0f);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues3.createCopy((int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, number8);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue9.getClass();
//        java.lang.String str11 = timePeriodValue9.toString();
//        timePeriodValues6.add(timePeriodValue9);
//        java.lang.Class<?> wildcardClass13 = timePeriodValue9.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        try {
//            int int15 = simpleTimePeriod2.compareTo((java.lang.Object) class14);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str11.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,2019]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        java.lang.Object obj6 = timePeriodValue5.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 'a');
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) (short) 0);
        java.lang.Number number8 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0d + "'", number8.equals(100.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        try {
            timePeriodValues3.update(2, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.lang.Comparable comparable7 = timePeriodValues5.getKey();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(comparable7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str7 = year0.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        try {
            timePeriodValues3.delete(10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560409200000L);
        java.lang.String str7 = timePeriodValue6.toString();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,1.5604092E12]" + "'", str7.equals("TimePeriodValue[2019,1.5604092E12]"));
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        boolean boolean12 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(date3, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560452399999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        long long5 = year0.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 100.0d);
        java.util.Date date14 = day10.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date14, date23);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        int int26 = year9.compareTo((java.lang.Object) date25);
        java.lang.String str27 = year9.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        long long16 = day10.getFirstMillisecond();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day10.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        timePeriodValues16.fireSeriesChanged();
//        boolean boolean30 = timePeriodValues16.isEmpty();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.Number number2 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day1, number2);
//        int int4 = day1.getDayOfMonth();
//        long long5 = day1.getMiddleMillisecond();
//        long long6 = day1.getLastMillisecond();
//        int int7 = day1.getYear();
//        java.util.Date date8 = day1.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 100.0d);
//        java.util.Date date13 = day9.getStart();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date13, timeZone16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date13, date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date8, timeZone25);
//        try {
//            org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date0, timeZone25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone25);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.util.Date date0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.lang.Number number2 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day1, number2);
        java.lang.Class<?> wildcardClass4 = timePeriodValue3.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = timePeriodValue3.equals(obj5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        java.util.Date date11 = day7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str24 = seriesChangeEvent23.toString();
        boolean boolean25 = simpleTimePeriod21.equals((java.lang.Object) seriesChangeEvent23);
        boolean boolean26 = timePeriodValue3.equals((java.lang.Object) simpleTimePeriod21);
        java.util.Date date27 = simpleTimePeriod21.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date0, date27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str24.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        int int5 = timePeriodValues3.getMinStartIndex();
//        java.lang.String str6 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
//        java.lang.String str10 = timePeriodValues3.getDomainDescription();
//        int int11 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str16 = timePeriodValues15.getDomainDescription();
//        java.lang.Object obj17 = timePeriodValues15.clone();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.Number number19 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number19);
//        timePeriodValues15.add(timePeriodValue20);
//        timePeriodValues3.add(timePeriodValue20);
//        java.lang.String str23 = timePeriodValue20.toString();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str23.equals("TimePeriodValue[13-June-2019,null]"));
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        long long16 = simpleTimePeriod14.getStartMillis();
//        java.util.Date date17 = simpleTimePeriod14.getStart();
//        long long18 = simpleTimePeriod14.getEndMillis();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timePeriodValue2.equals(obj4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 100.0d);
//        java.util.Date date10 = day6.getStart();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
//        java.util.Date date19 = year16.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date10, date19);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
//        java.lang.String str23 = seriesChangeEvent22.toString();
//        boolean boolean24 = simpleTimePeriod20.equals((java.lang.Object) seriesChangeEvent22);
//        boolean boolean25 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod20);
//        java.util.Date date26 = simpleTimePeriod20.getEnd();
//        long long27 = simpleTimePeriod20.getStartMillis();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValue2.equals(obj4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        boolean boolean8 = timePeriodValue2.equals((java.lang.Object) regularTimePeriod7);
        java.lang.Number number9 = timePeriodValue2.getValue();
        java.lang.Number number10 = timePeriodValue2.getValue();
        timePeriodValue2.setValue((java.lang.Number) 2019L);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(number10);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
//        java.lang.String str17 = seriesChangeEvent16.toString();
//        boolean boolean18 = simpleTimePeriod14.equals((java.lang.Object) seriesChangeEvent16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean18, "org.jfree.data.time.TimePeriodFormatException: ", "");
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) 100.0d);
//        java.util.Date date26 = day22.getStart();
//        java.lang.Class class27 = null;
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date26, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.next();
//        java.util.Date date35 = year32.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date26, date35);
//        java.util.Date date37 = simpleTimePeriod36.getEnd();
//        long long38 = simpleTimePeriod36.getStartMillis();
//        java.util.Date date39 = simpleTimePeriod36.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day40, (java.lang.Number) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str47 = timePeriodValues46.getDomainDescription();
//        int int48 = timePeriodValues46.getMinStartIndex();
//        java.lang.String str49 = timePeriodValues46.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues46.createCopy(13, (int) (byte) 10);
//        java.lang.String str53 = timePeriodValues46.getDescription();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.Number number55 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, number55);
//        java.lang.Class<?> wildcardClass57 = timePeriodValue56.getClass();
//        java.lang.Object obj58 = null;
//        boolean boolean59 = timePeriodValue56.equals(obj58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day60.next();
//        boolean boolean62 = timePeriodValue56.equals((java.lang.Object) regularTimePeriod61);
//        java.lang.Number number63 = timePeriodValue56.getValue();
//        timePeriodValues46.add(timePeriodValue56);
//        boolean boolean65 = timePeriodValues21.equals((java.lang.Object) timePeriodValue56);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str17.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560409200000L + "'", long38 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str47.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str49.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(timePeriodValues52);
//        org.junit.Assert.assertNull(str53);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNull(number63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        timePeriodValues16.delete(2, 0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.setDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) ' ');
        long long19 = simpleTimePeriod16.getEndMillis();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 4L + "'", long19 == 4L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        try {
            java.lang.Number number11 = timePeriodValues3.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,1.5604092E12]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.lang.Comparable comparable7 = timePeriodValues5.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues5.getDataItem(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(comparable7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str25 = timePeriodValues24.getDomainDescription();
        int int26 = timePeriodValues24.getMinStartIndex();
        java.lang.String str27 = timePeriodValues24.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues24.createCopy(13, (int) (byte) 10);
        java.lang.String str31 = timePeriodValues24.getDescription();
        java.lang.Object obj32 = timePeriodValues24.clone();
        try {
            int int33 = simpleTimePeriod20.compareTo((java.lang.Object) timePeriodValues24);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str25.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str27.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        java.util.Date date11 = day7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date4, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, (double) 'a');
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, (double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date27, date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
//        java.util.Date date37 = day33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date37, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone40);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day44, (java.lang.Number) 100.0d);
//        java.util.Date date48 = day44.getStart();
//        java.lang.Class class49 = null;
//        java.util.Date date50 = null;
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date48, timeZone51);
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.Number number59 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day58, number59);
//        java.lang.Class<?> wildcardClass61 = timePeriodValue60.getClass();
//        java.lang.String str62 = timePeriodValue60.toString();
//        timePeriodValues57.add(timePeriodValue60);
//        java.lang.Class<?> wildcardClass64 = timePeriodValue60.getClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        int int67 = day66.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day66, (java.lang.Number) 100.0d);
//        java.util.Date date70 = day66.getStart();
//        java.lang.Class class71 = null;
//        java.util.Date date72 = null;
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date72, timeZone73);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date70, timeZone73);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        int int77 = day76.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue79 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day76, (java.lang.Number) 100.0d);
//        java.util.Date date80 = day76.getStart();
//        java.lang.Class class81 = null;
//        java.util.Date date82 = null;
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone83);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date80, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date70, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date48, timeZone83);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str62.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date3, timeZone11);
        long long15 = day14.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43830L + "'", long15 == 43830L);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        int int3 = day2.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 100.0d);
        java.util.Date date6 = day2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date6, timeZone9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date6, date15);
        long long17 = simpleTimePeriod16.getEndMillis();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100.0d);
        java.util.Date date23 = day19.getStart();
        java.lang.Class class24 = null;
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date23, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date18, timeZone26);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(class30);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        try {
//            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,2019]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        long long3 = day0.getSerialIndex();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        java.lang.String str3 = year0.toString();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        long long6 = year0.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        int int10 = timePeriodValues9.getMinMiddleIndex();
        try {
            java.lang.Number number12 = timePeriodValues9.getValue(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,2019]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean12 = year10.equals((java.lang.Object) timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getEnd();
        java.lang.String str7 = year0.toString();
        java.util.Calendar calendar8 = null;
        try {
            year0.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("2019");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) throwableArray6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 100.0d);
//        java.util.Date date12 = day8.getStart();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        java.util.Date date21 = year18.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date12, date21);
//        java.util.Date date23 = simpleTimePeriod22.getEnd();
//        long long24 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date25 = simpleTimePeriod22.getStart();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        try {
//            int int27 = simpleTimePeriod2.compareTo((java.lang.Object) date25);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str17 = seriesChangeEvent16.toString();
        boolean boolean18 = simpleTimePeriod14.equals((java.lang.Object) seriesChangeEvent16);
        java.lang.Object obj19 = null;
        try {
            int int20 = simpleTimePeriod14.compareTo(obj19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str17.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4L + "'", long4 == 4L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValue2.equals(obj4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        boolean boolean8 = timePeriodValue2.equals((java.lang.Object) regularTimePeriod7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 100.0d);
        boolean boolean14 = timePeriodValue12.equals((java.lang.Object) 'a');
        boolean boolean16 = timePeriodValue12.equals((java.lang.Object) (short) 0);
        java.lang.Object obj17 = timePeriodValue12.clone();
        boolean boolean18 = timePeriodValue2.equals((java.lang.Object) timePeriodValue12);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        timePeriodValue6.setValue((java.lang.Number) (-1L));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        int int8 = timePeriodValues6.getMinEndIndex();
        boolean boolean9 = timePeriodValues6.isEmpty();
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean13 = year11.equals((java.lang.Object) timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
        try {
            int int20 = simpleTimePeriod2.compareTo((java.lang.Object) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
        java.util.Date date21 = day17.getStart();
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date21, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date21, date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day32, (double) 1560452399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
        java.util.Date date19 = day15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 100.0d);
        java.util.Date date29 = day25.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date29, timeZone32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date29, date38);
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        int int41 = year24.compareTo((java.lang.Object) date40);
        boolean boolean42 = timePeriodValues3.equals((java.lang.Object) year24);
        java.util.Calendar calendar43 = null;
        try {
            long long44 = year24.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        int int12 = timePeriodValues3.getMinEndIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        try {
            java.lang.Number number7 = timePeriodValues3.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 'a');
        java.lang.Object obj6 = timePeriodValue3.clone();
        java.lang.Number number7 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getLastMillisecond();
//        java.util.Date date6 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "TimePeriodValue[13-June-2019,null]", "TimePeriodValue[2019,1.5604092E12]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        long long15 = simpleTimePeriod14.getEndMillis();
//        java.util.Date date16 = simpleTimePeriod14.getStart();
//        long long17 = simpleTimePeriod14.getStartMillis();
//        long long18 = simpleTimePeriod14.getEndMillis();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean16 = year14.equals((java.lang.Object) timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date8, timeZone15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date3, timeZone15);
        long long19 = year18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31507200000L) + "'", long19 == (-31507200000L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year9.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValue2.equals(obj4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 100.0d);
        java.util.Date date10 = day6.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date10, date19);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str23 = seriesChangeEvent22.toString();
        boolean boolean24 = simpleTimePeriod20.equals((java.lang.Object) seriesChangeEvent22);
        boolean boolean25 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod20);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean28 = year26.equals((java.lang.Object) timeZone27);
        long long29 = year26.getLastMillisecond();
        long long30 = year26.getSerialIndex();
        long long31 = year26.getFirstMillisecond();
        int int33 = year26.compareTo((java.lang.Object) (short) 1);
        boolean boolean34 = timePeriodValue2.equals((java.lang.Object) year26);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.lang.String str7 = timePeriodValues5.getDescription();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getMonth();
        java.lang.Object obj7 = null;
        int int8 = day5.compareTo(obj7);
        boolean boolean9 = timePeriodValues3.equals((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValue2.equals(obj4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        boolean boolean8 = timePeriodValue2.equals((java.lang.Object) regularTimePeriod7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = regularTimePeriod7.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener17);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=9]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 100L);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100.0d + "'", obj2.equals(100.0d));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100.0d + "'", obj3.equals(100.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        long long11 = year4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,1.5604092E12]");
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str17 = seriesChangeEvent16.toString();
        boolean boolean18 = simpleTimePeriod14.equals((java.lang.Object) seriesChangeEvent16);
        java.lang.String str19 = seriesChangeEvent16.toString();
        java.lang.Object obj20 = seriesChangeEvent16.getSource();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str17.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str19.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + 9 + "'", obj20.equals(9));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) date17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,1.5604092E12]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str7 = timePeriodValue6.toString();
        timePeriodValue6.setValue((java.lang.Number) 6);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,0]" + "'", str7.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        try {
            timePeriodValues3.delete(9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.lang.Comparable comparable7 = timePeriodValues5.getKey();
        try {
            timePeriodValues5.update((int) '#', (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(comparable7);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getMiddleMillisecond();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        int int5 = timePeriodValues3.getMinStartIndex();
//        java.lang.String str6 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
//        java.lang.String str10 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, number12);
//        java.lang.Class<?> wildcardClass14 = timePeriodValue13.getClass();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = timePeriodValue13.equals(obj15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        boolean boolean19 = timePeriodValue13.equals((java.lang.Object) regularTimePeriod18);
//        java.lang.Number number20 = timePeriodValue13.getValue();
//        timePeriodValues3.add(timePeriodValue13);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        boolean boolean25 = day22.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate26 = day22.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) 4);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        long long7 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560452399999L + "'", long7 == 1560452399999L);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
//        java.lang.String str5 = seriesChangeEvent4.toString();
//        boolean boolean6 = day0.equals((java.lang.Object) seriesChangeEvent4);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesChangeEvent[source=9]", "TimePeriodValue[2019,1.5604092E12]");
//        timePeriodValues8.delete((int) (byte) 100, 8);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        boolean boolean8 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560409200000L);
        java.lang.Class<?> wildcardClass7 = year0.getClass();
        int int8 = year0.getYear();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        int int6 = timePeriodValues3.getMinEndIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        java.lang.Object obj12 = null;
//        int int13 = day10.compareTo(obj12);
//        boolean boolean14 = timePeriodValue6.equals((java.lang.Object) int13);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
//        java.util.Date date8 = day4.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date17);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        boolean boolean21 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod18);
//        long long22 = simpleTimePeriod18.getStartMillis();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, number24);
//        java.lang.Class<?> wildcardClass26 = timePeriodValue25.getClass();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 100.0d);
//        java.util.Date date31 = day27.getStart();
//        java.lang.Class class32 = null;
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date31, timeZone34);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        long long38 = year37.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.next();
//        java.util.Date date40 = year37.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date31, date40);
//        long long42 = simpleTimePeriod41.getEndMillis();
//        java.util.Date date43 = simpleTimePeriod41.getEnd();
//        boolean boolean44 = timePeriodValue25.equals((java.lang.Object) simpleTimePeriod41);
//        boolean boolean45 = simpleTimePeriod18.equals((java.lang.Object) simpleTimePeriod41);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getYear();
//        java.lang.Class<?> wildcardClass48 = day46.getClass();
//        int int49 = day46.getYear();
//        int int51 = day46.compareTo((java.lang.Object) (-1.0d));
//        long long52 = day46.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate53 = day46.getSerialDate();
//        boolean boolean54 = simpleTimePeriod41.equals((java.lang.Object) serialDate53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate53);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560409200000L + "'", long52 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
//        java.util.Date date8 = day4.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date17);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        boolean boolean21 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod18);
//        long long22 = simpleTimePeriod18.getStartMillis();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, number24);
//        java.lang.Class<?> wildcardClass26 = timePeriodValue25.getClass();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 100.0d);
//        java.util.Date date31 = day27.getStart();
//        java.lang.Class class32 = null;
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date31, timeZone34);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        long long38 = year37.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.next();
//        java.util.Date date40 = year37.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date31, date40);
//        long long42 = simpleTimePeriod41.getEndMillis();
//        java.util.Date date43 = simpleTimePeriod41.getEnd();
//        boolean boolean44 = timePeriodValue25.equals((java.lang.Object) simpleTimePeriod41);
//        boolean boolean45 = simpleTimePeriod18.equals((java.lang.Object) simpleTimePeriod41);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getYear();
//        java.lang.Class<?> wildcardClass48 = day46.getClass();
//        int int49 = day46.getYear();
//        int int51 = day46.compareTo((java.lang.Object) (-1.0d));
//        long long52 = day46.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate53 = day46.getSerialDate();
//        boolean boolean54 = simpleTimePeriod41.equals((java.lang.Object) serialDate53);
//        java.util.Date date55 = simpleTimePeriod41.getStart();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560409200000L + "'", long52 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date55);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        java.util.Date date7 = day0.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 100.0d);
//        java.util.Date date12 = day8.getStart();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        java.util.Date date21 = year18.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date12, date21);
//        long long23 = simpleTimePeriod22.getEndMillis();
//        java.util.Date date24 = simpleTimePeriod22.getStart();
//        long long25 = simpleTimePeriod22.getEndMillis();
//        int int26 = day0.compareTo((java.lang.Object) simpleTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        boolean boolean6 = timePeriodValues3.isEmpty();
        try {
            java.lang.Number number8 = timePeriodValues3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues3.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timePeriodValue2.equals(obj4);
//        java.lang.Number number6 = timePeriodValue2.getValue();
//        java.lang.String str7 = timePeriodValue2.toString();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str7);
//        java.lang.Object obj9 = seriesChangeEvent8.getSource();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(number6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str7.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", obj9.equals("TimePeriodValue[13-June-2019,null]"));
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        int int8 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.setDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) ' ');
        long long19 = simpleTimePeriod16.getStartMillis();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        java.util.Date date10 = year9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        long long13 = day11.getMiddleMillisecond();
//        java.util.Date date14 = day11.getEnd();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = year16.getEnd();
        long long20 = year16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year16.previous();
        java.util.Date date22 = regularTimePeriod21.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date15, date22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        timePeriodValues16.setNotify(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        int int10 = day0.compareTo((java.lang.Object) year6);
//        long long11 = day0.getMiddleMillisecond();
//        java.util.Date date12 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesChangeEvent[source=9]", "TimePeriodValue[2019,1.5604092E12]");
//        int int9 = timePeriodValues8.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        int int11 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day1, (java.lang.Number) 100.0d);
        java.util.Date date5 = day1.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date5, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 100.0d);
        java.util.Date date15 = day11.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date15, timeZone18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date15, date24);
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        int int27 = year10.compareTo((java.lang.Object) date26);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date26, timeZone28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean16 = year14.equals((java.lang.Object) timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date8, timeZone15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date3, timeZone15);
        long long19 = year18.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1969L + "'", long19 == 1969L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        timePeriodValues5.setNotify(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        int int10 = day0.compareTo((java.lang.Object) year6);
        long long11 = year6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 'a');
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) (short) 0);
        java.lang.Object obj8 = timePeriodValue3.clone();
        java.lang.Number number9 = null;
        timePeriodValue3.setValue(number9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 10);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriod7);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod7);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        java.util.Calendar calendar16 = null;
//        try {
//            day10.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        boolean boolean9 = timePeriodValue7.equals((java.lang.Object) 'a');
        java.lang.Object obj10 = timePeriodValue7.clone();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue7.getPeriod();
        try {
            int int12 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValue7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(timePeriod11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        long long5 = year0.getSerialIndex();
        int int6 = year0.getYear();
        long long7 = year0.getFirstMillisecond();
        long long8 = year0.getFirstMillisecond();
        java.lang.String str9 = year0.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        org.jfree.data.time.SerialDate serialDate10 = day4.getSerialDate();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day4.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValues3.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timePeriod18);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560409200000L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), 1L);
        boolean boolean10 = timePeriodValue6.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        int int13 = timePeriodValues3.getItemCount();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 9 + "'", obj3.equals(9));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        int int12 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone16);
        long long18 = day17.getMiddleMillisecond();
        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day17.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577822399999L + "'", long18 == 1577822399999L);
        org.junit.Assert.assertNotNull(serialDate19);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
//        java.util.Date date16 = year13.getEnd();
//        long long17 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) ' ');
//        timePeriodValues3.setRangeDescription("");
//        java.lang.String str23 = timePeriodValues3.getDescription();
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue25 = timePeriodValues3.getDataItem((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(str23);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        int int13 = timePeriodValues3.getMinStartIndex();
//        int int14 = timePeriodValues3.getMinEndIndex();
//        java.lang.Object obj15 = timePeriodValues3.clone();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(obj15);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560409200000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        int int10 = day0.compareTo((java.lang.Object) year6);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        long long8 = day4.getMiddleMillisecond();
//        long long9 = day4.getLastMillisecond();
//        int int10 = day4.getYear();
//        java.util.Date date11 = day4.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date25, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date11, timeZone28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date3, timeZone28);
//        int int32 = day31.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        timePeriodValue4.setValue((java.lang.Number) 1560409200000L);
//        java.lang.String str8 = timePeriodValue4.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[14-June-2019,1560409200000]" + "'", str8.equals("TimePeriodValue[14-June-2019,1560409200000]"));
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        timePeriodValues3.setDescription("TimePeriodValue[13-June-2019,null]");
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        long long11 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        java.lang.String str3 = year0.toString();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        boolean boolean12 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        java.util.Date date9 = year6.getEnd();
        long long10 = year6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year6.previous();
        java.util.Date date12 = regularTimePeriod11.getStart();
        boolean boolean13 = timePeriodValue5.equals((java.lang.Object) date12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
//        java.util.Date date16 = year13.getEnd();
//        long long17 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) ' ');
//        timePeriodValues3.setRangeDescription("2019");
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue24 = timePeriodValues3.getDataItem(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 2");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560409200000L);
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.5604092E12d + "'", number7.equals(1.5604092E12d));
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod5, (java.lang.Number) 8);
//        timePeriodValue7.setValue((java.lang.Number) 10.0d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 100.0d);
        java.util.Date date14 = day10.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date14, date23);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        int int26 = year9.compareTo((java.lang.Object) date25);
        java.util.Calendar calendar27 = null;
        try {
            year9.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timePeriod5);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date27, date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
//        java.util.Date date37 = day33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date37, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone40);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
//        java.util.Date date47 = simpleTimePeriod46.getStart();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean60 = year58.equals((java.lang.Object) timeZone59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date52, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date47, timeZone59);
//        java.lang.Class class63 = null;
//        java.util.Date date64 = null;
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date64, timeZone65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date47, timeZone65);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        int int69 = day68.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day68, (java.lang.Number) 100.0d);
//        java.util.Date date72 = day68.getStart();
//        java.lang.Class class73 = null;
//        java.util.Date date74 = null;
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class73, date74, timeZone75);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date72, timeZone75);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
//        long long79 = year78.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = year78.next();
//        java.util.Date date81 = year78.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod82 = new org.jfree.data.time.SimpleTimePeriod(date72, date81);
//        java.util.Date date83 = simpleTimePeriod82.getEnd();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date83, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date47, timeZone84);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 6 + "'", int69 == 6);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1577865599999L + "'", long79 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        int int4 = year0.compareTo((java.lang.Object) timePeriodFormatException3);
        java.lang.Number number5 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,null]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date27, date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
//        java.util.Date date37 = day33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date37, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone40);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
//        java.util.Date date47 = simpleTimePeriod46.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Number number53 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day52, number53);
//        java.lang.Class<?> wildcardClass55 = timePeriodValue54.getClass();
//        java.lang.String str56 = timePeriodValue54.toString();
//        timePeriodValues51.add(timePeriodValue54);
//        java.lang.Class<?> wildcardClass58 = timePeriodValue54.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        int int61 = day60.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day60, (java.lang.Number) 100.0d);
//        java.util.Date date64 = day60.getStart();
//        java.lang.Class class65 = null;
//        java.util.Date date66 = null;
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date64, timeZone67);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        int int71 = day70.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day70, (java.lang.Number) 100.0d);
//        java.util.Date date74 = day70.getStart();
//        java.lang.Class class75 = null;
//        java.util.Date date76 = null;
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date76, timeZone77);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date74, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date64, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date47, timeZone77);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str56.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 6 + "'", int71 == 6);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.lang.Object obj11 = timePeriodValues3.clone();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
        boolean boolean17 = timePeriodValue15.equals((java.lang.Object) 'a');
        timePeriodValues3.add(timePeriodValue15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean21 = year19.equals((java.lang.Object) timeZone20);
        long long22 = year19.getLastMillisecond();
        int int23 = year19.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (double) 8);
        long long28 = year19.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        int int16 = day15.getDayOfMonth();
        java.util.Date date17 = day15.getStart();
        java.util.Date date18 = day15.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100.0d + "'", obj2.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=100.0]"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 1);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 'a');
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) (short) 0);
        java.lang.Object obj8 = timePeriodValue3.clone();
        java.lang.Number number9 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0d + "'", number9.equals(100.0d));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (byte) 0);
//        java.lang.String str31 = timePeriodValues3.getRangeDescription();
//        int int32 = timePeriodValues3.getMaxMiddleIndex();
//        int int33 = timePeriodValues3.getMaxStartIndex();
//        try {
//            java.lang.Number number35 = timePeriodValues3.getValue((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        int int12 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues3.getMinEndIndex();
        int int18 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        long long8 = day4.getMiddleMillisecond();
//        long long9 = day4.getLastMillisecond();
//        int int10 = day4.getYear();
//        java.util.Date date11 = day4.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date25, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date11, timeZone28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date3, timeZone28);
//        long long32 = day31.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        long long5 = year0.getSerialIndex();
        int int6 = year0.getYear();
        long long7 = year0.getFirstMillisecond();
        long long8 = year0.getFirstMillisecond();
        java.lang.String str9 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (byte) 0);
//        boolean boolean31 = timePeriodValues3.getNotify();
//        int int32 = timePeriodValues3.getItemCount();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
        int int4 = day0.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            day0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date27, date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
//        java.util.Date date37 = day33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date37, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone40);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date31);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str17 = seriesChangeEvent16.toString();
        boolean boolean18 = simpleTimePeriod14.equals((java.lang.Object) seriesChangeEvent16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean18, "org.jfree.data.time.TimePeriodFormatException: ", "");
        org.jfree.data.time.TimePeriod timePeriod22 = null;
        try {
            timePeriodValues21.add(timePeriod22, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str17.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        boolean boolean7 = timePeriodValues3.getNotify();
        try {
            timePeriodValues3.update(6, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Number number3 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent(obj5);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, 1577865599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        int int8 = timePeriodValues6.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean11 = year9.equals((java.lang.Object) timeZone10);
        long long12 = year9.getLastMillisecond();
        int int13 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (byte) 0);
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (-1.0d));
        timePeriodValues6.setNotify(true);
        int int20 = timePeriodValues6.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener21);
        try {
            int int23 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        try {
            timePeriodValues3.update(0, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date6 = simpleTimePeriod5.getStart();
        try {
            int int7 = simpleTimePeriod2.compareTo((java.lang.Object) date6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (byte) 0);
//        int int31 = timePeriodValues3.getMinMiddleIndex();
//        try {
//            org.jfree.data.time.TimePeriodValues timePeriodValues34 = timePeriodValues3.createCopy(4, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 2");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        long long16 = day10.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long16);
//        java.lang.String str18 = seriesChangeEvent17.toString();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560409200000]" + "'", str18.equals("org.jfree.data.general.SeriesChangeEvent[source=1560409200000]"));
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "TimePeriodValue[13-June-2019,null]");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        java.lang.String str5 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, number11);
//        java.lang.Class<?> wildcardClass13 = timePeriodValue12.getClass();
//        java.lang.String str14 = timePeriodValue12.toString();
//        timePeriodValues9.add(timePeriodValue12);
//        int int16 = timePeriodValues9.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Comparable comparable19 = timePeriodValues9.getKey();
//        boolean boolean20 = timePeriodValues3.equals((java.lang.Object) comparable19);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str14.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1560452399999L + "'", comparable19.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        int int29 = timePeriodValues16.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, number15);
//        int int17 = day14.getDayOfMonth();
//        long long18 = day14.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day14, (double) 2);
//        int int22 = day14.getDayOfMonth();
//        long long23 = day14.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', (long) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        long long27 = simpleTimePeriod26.getEndMillis();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 100.0d);
//        java.util.Date date35 = day31.getStart();
//        java.lang.Class class36 = null;
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        java.util.Date date44 = year41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
//        long long46 = simpleTimePeriod45.getEndMillis();
//        java.util.Date date47 = simpleTimePeriod45.getStart();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date28, timeZone55);
//        java.lang.Class class60 = null;
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date28, timeZone62);
//        int int65 = year64.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.delete((int) (short) 10, 5);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) (byte) 10);
//        int int9 = timePeriodValues3.getMaxEndIndex();
//        timePeriodValues3.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getEnd();
        java.lang.String str7 = year0.toString();
        long long8 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
//        int int13 = timePeriodValues3.getMinEndIndex();
//        java.lang.String str14 = timePeriodValues3.getDescription();
//        java.lang.Comparable comparable15 = null;
//        try {
//            timePeriodValues3.setKey(comparable15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNull(str14);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Date date5 = day0.getEnd();
        int int6 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.previous();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        int int4 = day0.compareTo((java.lang.Object) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
        int int6 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        java.lang.String str5 = year0.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, 1560452399999L);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, number9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue10.getClass();
//        java.lang.String str12 = timePeriodValue10.toString();
//        timePeriodValues7.add(timePeriodValue10);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getMonth();
//        int int17 = day14.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day14, (double) 2019L);
//        long long20 = day14.getFirstMillisecond();
//        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) day14);
//        java.util.Date date22 = simpleTimePeriod2.getEnd();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str12.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date22);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        java.util.Date date11 = day7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date4, timeZone31);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date4);
        int int37 = year36.getYear();
        long long38 = year36.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1562097599999L + "'", long38 == 1562097599999L);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        long long27 = simpleTimePeriod26.getEndMillis();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 100.0d);
//        java.util.Date date35 = day31.getStart();
//        java.lang.Class class36 = null;
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        java.util.Date date44 = year41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
//        long long46 = simpleTimePeriod45.getEndMillis();
//        java.util.Date date47 = simpleTimePeriod45.getStart();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date28, timeZone55);
//        java.lang.Class class60 = null;
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date28, timeZone62);
//        java.util.Calendar calendar65 = null;
//        try {
//            long long66 = year64.getLastMillisecond(calendar65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Object obj5 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
//        timePeriodValues3.add(timePeriodValue8);
//        timePeriodValues3.setRangeDescription("hi!");
//        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
//        java.util.Date date19 = day15.getStart();
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 100.0d);
//        java.util.Date date29 = day25.getStart();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date29, timeZone32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
//        java.util.Date date38 = year35.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date29, date38);
//        java.util.Date date40 = simpleTimePeriod39.getEnd();
//        int int41 = year24.compareTo((java.lang.Object) date40);
//        boolean boolean42 = timePeriodValues3.equals((java.lang.Object) year24);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.Number number44 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, number44);
//        long long46 = day43.getSerialIndex();
//        long long47 = day43.getLastMillisecond();
//        timePeriodValues3.setKey((java.lang.Comparable) long47);
//        int int49 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43629L + "'", long46 == 43629L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        java.util.Date date15 = year6.getEnd();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date27, date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
//        java.util.Date date37 = day33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date37, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone40);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, number3);
        java.lang.Class<?> wildcardClass5 = timePeriodValue4.getClass();
        java.lang.Object obj6 = null;
        boolean boolean7 = timePeriodValue4.equals(obj6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValue4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        java.util.Date date16 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Number number18 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, number18);
        java.lang.Class<?> wildcardClass20 = timePeriodValue19.getClass();
        java.lang.Object obj21 = null;
        boolean boolean22 = timePeriodValue19.equals(obj21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        boolean boolean25 = timePeriodValue19.equals((java.lang.Object) regularTimePeriod24);
        timePeriodValue19.setValue((java.lang.Number) 11);
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue19.getPeriod();
        int int29 = simpleTimePeriod14.compareTo((java.lang.Object) timePeriod28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
        java.util.Date date21 = day17.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100.0d);
        java.util.Date date45 = day41.getStart();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date21, timeZone48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date21);
        int int54 = year53.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year53);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener56);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener58);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Number number3 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        java.lang.Object obj12 = timePeriodValues10.clone();
        int int13 = timePeriodValues10.getMaxStartIndex();
        java.lang.Object obj14 = timePeriodValues10.clone();
        boolean boolean15 = timePeriodValue4.equals((java.lang.Object) timePeriodValues10);
        timePeriodValues10.setDescription("Time");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Number number18 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, number18);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, number20);
        java.lang.Object obj22 = timePeriodValue21.clone();
        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue21.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str28 = timePeriodValues27.getDomainDescription();
        java.lang.Object obj29 = timePeriodValues27.clone();
        int int30 = timePeriodValues27.getMaxStartIndex();
        java.lang.Object obj31 = timePeriodValues27.clone();
        boolean boolean32 = timePeriodValue21.equals((java.lang.Object) timePeriodValues27);
        timePeriodValues3.add(timePeriodValue21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(timePeriod23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str28.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Number number3 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        java.util.Date date17 = year14.getEnd();
//        long long18 = year14.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year14, 0.0d);
//        int int22 = timePeriodValues3.getMaxStartIndex();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (byte) 0);
//        boolean boolean31 = timePeriodValues3.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener32);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        int int6 = timePeriodValues3.getMinEndIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        java.util.Date date16 = simpleTimePeriod14.getStart();
        long long17 = simpleTimePeriod14.getEndMillis();
        java.util.Date date18 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        long long27 = simpleTimePeriod26.getEndMillis();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 100.0d);
//        java.util.Date date35 = day31.getStart();
//        java.lang.Class class36 = null;
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        java.util.Date date44 = year41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
//        long long46 = simpleTimePeriod45.getEndMillis();
//        java.util.Date date47 = simpleTimePeriod45.getStart();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date28, timeZone55);
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
//        java.util.Date date64 = simpleTimePeriod63.getStart();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day65, (java.lang.Number) 100.0d);
//        java.util.Date date69 = day65.getStart();
//        java.lang.Class class70 = null;
//        java.util.Date date71 = null;
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date71, timeZone72);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date69, timeZone72);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean77 = year75.equals((java.lang.Object) timeZone76);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date69, timeZone76);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date64, timeZone76);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass81 = timeZone80.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date64, timeZone80);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNotNull(wildcardClass81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        java.lang.String str6 = timePeriodValues5.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int4 = day0.compareTo((java.lang.Object) 10.0f);
//        int int5 = day0.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str5 = seriesException4.toString();
        java.lang.String str6 = seriesException4.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException4);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        timePeriodValues3.delete((int) (short) 1, 0);
        java.lang.Object obj20 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577822399999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        int int13 = timePeriodValues3.getMaxStartIndex();
//        int int14 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriod timePeriod15 = null;
//        try {
//            timePeriodValues3.add(timePeriod15, (java.lang.Number) 1560495599999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "TimePeriodValue[13-June-2019,null]");
        timePeriodValues3.setRangeDescription("");
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        java.lang.String str10 = timePeriodValues3.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
//        timePeriodValues3.setDescription("");
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setDescription("31-December-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        long long5 = year0.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
//        java.lang.String str10 = year7.toString();
//        long long11 = year7.getSerialIndex();
//        java.util.Date date12 = year7.getEnd();
//        int int13 = day0.compareTo((java.lang.Object) year7);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = year7.equals(obj14);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        java.util.Date date6 = day0.getEnd();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
//        java.util.Date date16 = year13.getEnd();
//        long long17 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) ' ');
//        timePeriodValues3.setRangeDescription("");
//        java.lang.String str23 = timePeriodValues3.getDescription();
//        java.lang.String str24 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray27 = timePeriodFormatException26.getSuppressed();
//        java.lang.String str28 = timePeriodFormatException26.toString();
//        java.lang.Throwable[] throwableArray29 = timePeriodFormatException26.getSuppressed();
//        boolean boolean30 = timePeriodValues3.equals((java.lang.Object) throwableArray29);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str24.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(throwableArray27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
//        java.util.Date date16 = year13.getEnd();
//        long long17 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) ' ');
//        timePeriodValues3.setRangeDescription("");
//        java.lang.String str23 = timePeriodValues3.getDescription();
//        int int24 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 100L);
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,2019]");
        java.lang.String str11 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 'a');
        java.lang.Object obj6 = timePeriodValue3.clone();
        java.lang.Number number7 = null;
        timePeriodValue3.setValue(number7);
        timePeriodValue3.setValue((java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean13 = year11.equals((java.lang.Object) timeZone12);
        boolean boolean14 = timePeriodValue3.equals((java.lang.Object) boolean13);
        java.lang.Object obj15 = timePeriodValue3.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, number10);
//        java.lang.Class<?> wildcardClass12 = timePeriodValue11.getClass();
//        java.lang.String str13 = timePeriodValue11.toString();
//        timePeriodValues8.add(timePeriodValue11);
//        java.lang.Class<?> wildcardClass15 = timePeriodValue11.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, number24);
//        int int26 = day23.getDayOfMonth();
//        long long27 = day23.getMiddleMillisecond();
//        long long28 = day23.getLastMillisecond();
//        int int29 = day23.getYear();
//        java.util.Date date30 = day23.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 100.0d);
//        java.util.Date date35 = day31.getStart();
//        java.lang.Class class36 = null;
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        java.util.Date date44 = year41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date30, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date21, timeZone47);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        boolean boolean52 = timePeriodValue4.equals((java.lang.Object) class16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str13.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560452399999L + "'", long27 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        int int17 = timePeriodValues3.getMinEndIndex();
        int int18 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        java.lang.Object obj17 = timePeriodValues15.clone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number19);
        timePeriodValues15.add(timePeriodValue20);
        timePeriodValues3.add(timePeriodValue20);
        java.lang.Object obj23 = timePeriodValue20.clone();
        java.lang.Number number24 = timePeriodValue20.getValue();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(number24);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        java.lang.Object obj8 = seriesChangeEvent6.getSource();
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent6.getClass();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent6);
        java.lang.Object obj11 = seriesChangeEvent6.getSource();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + 9 + "'", obj7.equals(9));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 9 + "'", obj8.equals(9));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 9 + "'", obj11.equals(9));
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        int int29 = timePeriodValues16.getMinStartIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560409200000L);
        java.lang.Class<?> wildcardClass7 = year0.getClass();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        java.util.Date date16 = simpleTimePeriod14.getStart();
        long long17 = simpleTimePeriod14.getEndMillis();
        java.util.Date date18 = simpleTimePeriod14.getStart();
        java.util.Date date19 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        long long10 = day4.getFirstMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            day4.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        boolean boolean11 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean14 = year12.equals((java.lang.Object) timeZone13);
        long long15 = year12.getLastMillisecond();
        long long16 = year12.getSerialIndex();
        long long17 = year12.getFirstMillisecond();
        java.util.Date date18 = year12.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, (double) 12);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year12.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        int int8 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-1969" + "'", str6.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
        java.util.Date date19 = day15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 100.0d);
        java.util.Date date29 = day25.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date29, timeZone32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date29, date38);
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        int int41 = year24.compareTo((java.lang.Object) date40);
        boolean boolean42 = timePeriodValues3.equals((java.lang.Object) year24);
        int int43 = year24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year24.next();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,1.5604092E12]");
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-1969" + "'", str6.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        java.util.Date date16 = simpleTimePeriod14.getStart();
        java.util.Date date17 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean12 = year10.equals((java.lang.Object) timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        java.util.Date date11 = day7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date4, timeZone31);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass38 = timeZone37.getClass();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        int int40 = day39.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day39, (java.lang.Number) 100.0d);
        java.util.Date date43 = day39.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date43, timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.next();
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date43, date52);
        long long54 = simpleTimePeriod53.getEndMillis();
        java.util.Date date55 = simpleTimePeriod53.getStart();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day56, (java.lang.Number) 100.0d);
        java.util.Date date60 = day56.getStart();
        java.lang.Class class61 = null;
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date60, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date55, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date4, date55);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        boolean boolean7 = timePeriodValues3.getNotify();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass6 = timeZone5.getClass();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        java.util.Date date11 = day7.getStart();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date4, timeZone31);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date4);
        int int37 = year36.getYear();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = year36.getLastMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem(0);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(timePeriodValue12);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        java.lang.Number number16 = timePeriodValues3.getValue(0);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.String str12 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        java.lang.String str14 = timePeriodFormatException10.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException7.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getMonth();
        java.lang.Object obj7 = null;
        int int8 = day5.compareTo(obj7);
        boolean boolean9 = timePeriodValues3.equals((java.lang.Object) day5);
        try {
            timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        int int10 = day0.compareTo((java.lang.Object) year6);
        int int11 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getEnd();
        java.lang.String str7 = year0.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 100.0d);
//        java.util.Date date10 = day6.getStart();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
//        java.util.Date date19 = year16.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date10, date19);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        long long22 = simpleTimePeriod20.getStartMillis();
//        java.util.Date date23 = simpleTimePeriod20.getStart();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        int int25 = day0.compareTo((java.lang.Object) day24);
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day24.getLastMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 100L);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + false + "'", comparable11.equals(false));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.setDescription("");
        java.lang.String str14 = timePeriodValues3.getDescription();
        try {
            timePeriodValues3.update(4, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date3, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        java.util.Calendar calendar16 = null;
        try {
            day14.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,2019]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        int int16 = day15.getDayOfMonth();
        java.util.Date date17 = day15.getStart();
        long long18 = day15.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate19 = day15.getSerialDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577779200000L + "'", long18 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate19);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        java.util.Date date0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Number number6 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, number6);
//        java.lang.Class<?> wildcardClass8 = timePeriodValue7.getClass();
//        java.lang.String str9 = timePeriodValue7.toString();
//        timePeriodValues4.add(timePeriodValue7);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue7.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) 100.0d);
//        java.util.Date date27 = day23.getStart();
//        java.lang.Class class28 = null;
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date27, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone30);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date0, date17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str9.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 1560409200000L);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        long long15 = simpleTimePeriod14.getEndMillis();
//        java.util.Date date16 = simpleTimePeriod14.getStart();
//        long long17 = simpleTimePeriod14.getEndMillis();
//        long long18 = simpleTimePeriod14.getStartMillis();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1560409200000]");
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        try {
            timePeriodValues3.delete((int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        java.util.Date date6 = year0.getEnd();
        java.lang.String str7 = year0.toString();
        long long8 = year0.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        long long6 = day5.getFirstMillisecond();
        int int7 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.lang.Object obj11 = timePeriodValues3.clone();
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        boolean boolean13 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 100, 1);
        timePeriodValues9.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        java.util.Date date7 = day0.getStart();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        timePeriodValue4.setValue((java.lang.Number) 1560409200000L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 100.0d);
//        java.util.Date date12 = day8.getStart();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        java.util.Date date21 = year18.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date12, date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, number30);
//        java.lang.Class<?> wildcardClass32 = timePeriodValue31.getClass();
//        java.lang.String str33 = timePeriodValue31.toString();
//        timePeriodValues28.add(timePeriodValue31);
//        java.lang.Class<?> wildcardClass35 = timePeriodValue31.getClass();
//        timePeriodValues24.add(timePeriodValue31);
//        boolean boolean37 = timePeriodValue4.equals((java.lang.Object) timePeriodValues24);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean40 = year38.equals((java.lang.Object) timeZone39);
//        long long41 = year38.getLastMillisecond();
//        long long42 = year38.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (double) (short) 10);
//        org.jfree.data.time.TimePeriod timePeriod45 = timePeriodValue44.getPeriod();
//        boolean boolean46 = timePeriodValue4.equals((java.lang.Object) timePeriod45);
//        timePeriodValue4.setValue((java.lang.Number) 1.0f);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str33.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
//        org.junit.Assert.assertNotNull(timePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        timePeriodValues16.fireSeriesChanged();
//        try {
//            org.jfree.data.time.TimePeriodValues timePeriodValues32 = timePeriodValues16.createCopy(1, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        int int6 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
        java.util.Date date21 = day17.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100.0d);
        java.util.Date date45 = day41.getStart();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date21, timeZone48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date21);
        int int54 = year53.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year53);
        java.lang.Comparable comparable56 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(comparable56);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        java.lang.Object obj17 = timePeriodValues15.clone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number19);
        timePeriodValues15.add(timePeriodValue20);
        timePeriodValues3.add(timePeriodValue20);
        java.lang.Number number23 = timePeriodValue20.getValue();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(number23);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
//        long long3 = year0.getLastMillisecond();
//        long long4 = year0.getSerialIndex();
//        long long5 = year0.getFirstMillisecond();
//        java.util.Date date6 = year0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, number13);
//        java.lang.Class<?> wildcardClass15 = timePeriodValue14.getClass();
//        java.lang.String str16 = timePeriodValue14.toString();
//        timePeriodValues11.add(timePeriodValue14);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues11.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues11.getRangeDescription();
//        int int21 = year0.compareTo((java.lang.Object) str20);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str16.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Date date2 = year0.getEnd();
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        long long6 = day5.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        java.lang.String str13 = day12.toString();
        int int14 = day5.compareTo((java.lang.Object) str13);
        java.util.Date date15 = day5.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, number10);
//        java.lang.Class<?> wildcardClass12 = timePeriodValue11.getClass();
//        java.lang.String str13 = timePeriodValue11.toString();
//        timePeriodValues8.add(timePeriodValue11);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        int int18 = day15.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day15, (double) 2019L);
//        long long21 = day15.getFirstMillisecond();
//        boolean boolean22 = day0.equals((java.lang.Object) long21);
//        long long23 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 10.0f);
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day0.getFirstMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str13.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        int int9 = timePeriodValues7.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean12 = year10.equals((java.lang.Object) timeZone11);
        long long13 = year10.getLastMillisecond();
        int int14 = year10.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 0);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (-1.0d));
        timePeriodValues7.setNotify(true);
        int int21 = timePeriodValues7.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues7.setRangeDescription("TimePeriodValue[2019,0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener26);
        timePeriodValues7.fireSeriesChanged();
        int int29 = year0.compareTo((java.lang.Object) timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0d);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("TimePeriodValue[2019,1.5604092E12]");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        boolean boolean11 = timePeriodValues3.getNotify();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        int int9 = day8.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 100.0d);
        java.util.Date date12 = day8.getStart();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
        java.util.Date date18 = year17.getEnd();
        boolean boolean19 = year6.equals((java.lang.Object) year17);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year6.next();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        java.lang.Object obj19 = timePeriodValue10.clone();
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue10.getPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(timePeriod20);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        long long27 = simpleTimePeriod26.getEndMillis();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 100.0d);
//        java.util.Date date35 = day31.getStart();
//        java.lang.Class class36 = null;
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        java.util.Date date44 = year41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
//        long long46 = simpleTimePeriod45.getEndMillis();
//        java.util.Date date47 = simpleTimePeriod45.getStart();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date28, timeZone55);
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize(class60);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertNotNull(class61);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        java.lang.String str6 = timePeriodValues5.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues5.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getMiddleMillisecond();
//        java.lang.String str5 = day0.toString();
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=9]");
//        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
//        boolean boolean9 = day0.equals((java.lang.Object) throwableArray8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        int int5 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
//        long long9 = year6.getLastMillisecond();
//        int int10 = year6.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
//        timePeriodValues3.setNotify(true);
//        int int17 = timePeriodValues3.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getMonth();
//        java.lang.Object obj22 = null;
//        int int23 = day20.compareTo(obj22);
//        long long24 = day20.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass25 = day20.getClass();
//        int int26 = day20.getDayOfMonth();
//        timePeriodValues3.setKey((java.lang.Comparable) day20);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560452399999L + "'", long24 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,null]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        long long27 = simpleTimePeriod26.getEndMillis();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 100.0d);
//        java.util.Date date35 = day31.getStart();
//        java.lang.Class class36 = null;
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
//        java.util.Date date44 = year41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
//        long long46 = simpleTimePeriod45.getEndMillis();
//        java.util.Date date47 = simpleTimePeriod45.getStart();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date28, timeZone55);
//        java.lang.Class class60 = null;
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date28, timeZone62);
//        long long65 = year64.getSerialIndex();
//        java.util.Date date66 = year64.getStart();
//        java.util.Calendar calendar67 = null;
//        try {
//            long long68 = year64.getLastMillisecond(calendar67);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(date66);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(28799999L, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        java.lang.Object obj8 = null;
        int int9 = year0.compareTo(obj8);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        boolean boolean5 = timePeriodValues3.isEmpty();
        java.lang.Object obj6 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        long long17 = day16.getMiddleMillisecond();
        int int18 = day16.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577822399999L + "'", long17 == 1577822399999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.lang.String str6 = day5.toString();
        long long7 = day5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-1969" + "'", str6.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
//        java.util.Date date16 = year13.getEnd();
//        long long17 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (double) ' ');
//        timePeriodValues3.setRangeDescription("");
//        int int23 = timePeriodValues3.getMinMiddleIndex();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.String str12 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException19.getSuppressed();
        java.lang.String str23 = timePeriodFormatException19.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod7, (java.lang.Number) 10.0d);
//        int int10 = day0.compareTo((java.lang.Object) 10.0d);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0d);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDescription("TimePeriodValue[2019,1.5604092E12]");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getMiddleMillisecond();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        timePeriodValue2.setValue((java.lang.Number) (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, number10);
//        java.lang.Class<?> wildcardClass12 = timePeriodValue11.getClass();
//        java.lang.String str13 = timePeriodValue11.toString();
//        timePeriodValues8.add(timePeriodValue11);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        int int18 = day15.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day15, (double) 2019L);
//        long long21 = day15.getFirstMillisecond();
//        boolean boolean22 = day0.equals((java.lang.Object) long21);
//        long long23 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 10.0f);
//        java.util.Calendar calendar26 = null;
//        try {
//            day0.peg(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str13.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
//        java.util.Date date8 = day4.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date17);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        boolean boolean21 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod18);
//        long long22 = simpleTimePeriod18.getStartMillis();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean25 = year23.equals((java.lang.Object) timeZone24);
//        long long26 = year23.getLastMillisecond();
//        int int27 = year23.getYear();
//        java.lang.Object obj28 = new java.lang.Object();
//        boolean boolean29 = year23.equals(obj28);
//        boolean boolean30 = simpleTimePeriod18.equals(obj28);
//        long long31 = simpleTimePeriod18.getStartMillis();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        int int16 = day15.getDayOfMonth();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day15.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        int int6 = timePeriodValues3.getMaxEndIndex();
        int int7 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.delete(2, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, 1560452399999L);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, number9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue10.getClass();
//        java.lang.String str12 = timePeriodValue10.toString();
//        timePeriodValues7.add(timePeriodValue10);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getMonth();
//        int int17 = day14.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day14, (double) 2019L);
//        long long20 = day14.getFirstMillisecond();
//        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) day14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
//        try {
//            int int24 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodFormatException23);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str12.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        int int17 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener22);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDomainDescription("TimePeriodValue[14-June-2019,1560409200000]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        int int10 = day0.compareTo((java.lang.Object) year6);
        long long11 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "TimePeriodValue[13-June-2019,null]");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (byte) -1, (int) (byte) 0);
        timePeriodValues8.setNotify(true);
        timePeriodValues8.setNotify(false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }
}

