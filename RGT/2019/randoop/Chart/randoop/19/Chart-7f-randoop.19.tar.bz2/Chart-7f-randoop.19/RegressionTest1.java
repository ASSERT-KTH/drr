import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass8);
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent9);
        java.lang.String str11 = seriesChangeEvent9.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=class sun.util.calendar.ZoneInfo]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=class sun.util.calendar.ZoneInfo]"));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, number17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValue18.getClass();
//        java.lang.String str20 = timePeriodValue18.toString();
//        timePeriodValues15.add(timePeriodValue18);
//        int int22 = timePeriodValues15.getItemCount();
//        java.lang.Number number24 = timePeriodValues15.getValue(0);
//        java.lang.String str25 = timePeriodValues15.getDescription();
//        int int26 = timePeriodValues15.getMinMiddleIndex();
//        boolean boolean27 = timePeriodValues3.equals((java.lang.Object) int26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        java.lang.Class<?> wildcardClass30 = day28.getClass();
//        int int31 = day28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod32);
//        java.lang.Comparable comparable34 = timePeriodValues3.getKey();
//        java.lang.Object obj35 = timePeriodValues3.clone();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str20.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(comparable34);
//        org.junit.Assert.assertNotNull(obj35);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12);
        java.lang.String str14 = timePeriodValues13.getRangeDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean17 = year15.equals((java.lang.Object) timeZone16);
        long long18 = year15.getLastMillisecond();
        long long19 = year15.getSerialIndex();
        long long20 = year15.getFirstMillisecond();
        java.util.Date date21 = year15.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day22, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 100L);
        timePeriodValues3.setRangeDescription("13-June-2019");
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        timePeriodValues3.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(str17);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100L, "13-June-2019", "");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
        java.util.Date date19 = day15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 100.0d);
        java.util.Date date29 = day25.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date29, timeZone32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date29, date38);
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        int int41 = year24.compareTo((java.lang.Object) date40);
        boolean boolean42 = timePeriodValues3.equals((java.lang.Object) year24);
        int int43 = year24.getYear();
        long long44 = year24.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener12);
//        int int14 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str15 = timePeriodValues3.getRangeDescription();
//        java.lang.Object obj16 = timePeriodValues3.clone();
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1560452399999L + "'", comparable11.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(obj16);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timePeriodValue2.equals(obj4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 100.0d);
        java.util.Date date10 = day6.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date10, date19);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str23 = seriesChangeEvent22.toString();
        boolean boolean24 = simpleTimePeriod20.equals((java.lang.Object) seriesChangeEvent22);
        boolean boolean25 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod20);
        java.lang.Number number26 = timePeriodValue2.getValue();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(number26);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
        java.util.Date date21 = day17.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100.0d);
        java.util.Date date45 = day41.getStart();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date21, timeZone48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date21);
        int int54 = year53.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year53);
        java.lang.String str56 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
//        int int10 = day6.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        boolean boolean12 = timePeriodValue4.equals((java.lang.Object) day6);
//        long long13 = day6.getMiddleMillisecond();
//        int int14 = day6.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 100.0d);
//        java.util.Date date7 = day3.getStart();
//        java.lang.Class class8 = null;
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date7, timeZone10);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
//        java.util.Date date16 = year13.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date7, date16);
//        java.util.Date date18 = simpleTimePeriod17.getEnd();
//        long long19 = simpleTimePeriod17.getStartMillis();
//        java.util.Date date20 = simpleTimePeriod17.getStart();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date20, timeZone21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(class23);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        java.lang.Number number16 = timePeriodValues3.getValue(0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener17);
        boolean boolean19 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        long long17 = day16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577822399999L + "'", long17 == 1577822399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Number number3 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        org.jfree.data.time.SerialDate serialDate10 = day4.getSerialDate();
//        java.util.Date date11 = day4.getEnd();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        java.lang.String str7 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str7.equals("TimePeriodValue[13-June-2019,null]"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues3.createCopy(6, (int) (short) 1);
        java.lang.Comparable comparable18 = null;
        try {
            timePeriodValues3.setKey(comparable18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertNotNull(timePeriodValues17);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        long long4 = day0.getMiddleMillisecond();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.String str12 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        java.lang.String str14 = timePeriodFormatException10.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str16 = timePeriodFormatException10.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) throwableArray6);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=class sun.util.calendar.ZoneInfo]");
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1560409200000]");
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
//        int int10 = day6.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        boolean boolean12 = timePeriodValue4.equals((java.lang.Object) day6);
//        long long13 = day6.getMiddleMillisecond();
//        int int14 = day6.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        timePeriodValues3.setKey((java.lang.Comparable) date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues3.createCopy(3, 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        long long17 = day16.getMiddleMillisecond();
        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
        java.lang.String str19 = day16.toString();
        org.jfree.data.time.SerialDate serialDate20 = day16.getSerialDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577822399999L + "'", long17 == 1577822399999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12);
        long long14 = day12.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day12.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25568L + "'", long14 == 25568L);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        timePeriodValues3.delete(100, 0);
//        int int19 = timePeriodValues3.getMinStartIndex();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        int int22 = timePeriodValues3.getItemCount();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.general.SeriesChangeEvent[source=9]", "TimePeriodValue[2019,1.5604092E12]");
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues8.createCopy(10, (int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number3);
//        long long5 = day0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = timePeriodValues3.getNotify();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getYear();
        java.lang.Class<?> wildcardClass13 = day11.getClass();
        int int14 = day11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day11);
        timePeriodValues3.setKey((java.lang.Comparable) day11);
        int int18 = day11.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        java.lang.String str7 = timePeriodValues3.getDescription();
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        java.lang.String str11 = timePeriodValues3.getDescription();
        int int12 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, 1560452399999L);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, number9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue10.getClass();
//        java.lang.String str12 = timePeriodValue10.toString();
//        timePeriodValues7.add(timePeriodValue10);
//        java.lang.Class<?> wildcardClass14 = timePeriodValue10.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        boolean boolean16 = simpleTimePeriod2.equals((java.lang.Object) wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str12.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str7 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,2019]");
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, 1560452399999L);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, number9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue10.getClass();
//        java.lang.String str12 = timePeriodValue10.toString();
//        timePeriodValues7.add(timePeriodValue10);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getMonth();
//        int int17 = day14.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day14, (double) 2019L);
//        long long20 = day14.getFirstMillisecond();
//        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) day14);
//        long long22 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        boolean boolean25 = simpleTimePeriod2.equals((java.lang.Object) timePeriodFormatException24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str12.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        int int4 = year0.compareTo((java.lang.Object) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 3);
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0d);
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        try {
//            java.lang.Number number14 = timePeriodValues3.getValue(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        boolean boolean15 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        int int5 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
//        long long9 = year6.getLastMillisecond();
//        int int10 = year6.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
//        timePeriodValues3.setNotify(true);
//        int int17 = timePeriodValues3.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
//        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,0]");
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) 100.0d);
//        java.util.Date date26 = day22.getStart();
//        java.lang.Class class27 = null;
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date26, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.next();
//        java.util.Date date35 = year32.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date26, date35);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
//        java.lang.String str39 = seriesChangeEvent38.toString();
//        boolean boolean40 = simpleTimePeriod36.equals((java.lang.Object) seriesChangeEvent38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean40, "org.jfree.data.time.TimePeriodFormatException: ", "");
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day44, (java.lang.Number) 100.0d);
//        java.util.Date date48 = day44.getStart();
//        java.lang.Class class49 = null;
//        java.util.Date date50 = null;
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date48, timeZone51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        long long55 = year54.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.next();
//        java.util.Date date57 = year54.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date48, date57);
//        java.util.Date date59 = simpleTimePeriod58.getEnd();
//        long long60 = simpleTimePeriod58.getStartMillis();
//        java.util.Date date61 = simpleTimePeriod58.getStart();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
//        timePeriodValues43.add((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 10);
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timePeriodValues43.removePropertyChangeListener(propertyChangeListener65);
//        boolean boolean67 = timePeriodValues3.equals((java.lang.Object) timePeriodValues43);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str39.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560409200000L + "'", long60 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Object obj5 = timePeriodValues3.clone();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
//        timePeriodValues3.add(timePeriodValue8);
//        timePeriodValues3.setRangeDescription("hi!");
//        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
//        timePeriodValues3.setDescription("13-June-2019");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
//        java.util.Date date21 = day17.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
//        java.util.Date date28 = day24.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
//        java.util.Date date37 = year34.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
//        long long39 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date40 = simpleTimePeriod38.getStart();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100.0d);
//        java.util.Date date45 = day41.getStart();
//        java.lang.Class class46 = null;
//        java.util.Date date47 = null;
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone48);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date21, timeZone48);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date21);
//        int int54 = year53.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year53);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.lang.Number number61 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day60, number61);
//        java.lang.Class<?> wildcardClass63 = timePeriodValue62.getClass();
//        java.lang.String str64 = timePeriodValue62.toString();
//        timePeriodValues59.add(timePeriodValue62);
//        int int66 = timePeriodValues59.getMinStartIndex();
//        java.lang.Comparable comparable67 = timePeriodValues59.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
//        timePeriodValues59.removeChangeListener(seriesChangeListener68);
//        int int70 = timePeriodValues59.getMinMiddleIndex();
//        java.lang.String str71 = timePeriodValues59.getRangeDescription();
//        java.lang.Object obj72 = timePeriodValues59.clone();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        int int74 = day73.getYear();
//        java.lang.Class<?> wildcardClass75 = day73.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day73.next();
//        timePeriodValues59.setKey((java.lang.Comparable) day73);
//        boolean boolean78 = year53.equals((java.lang.Object) day73);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str64.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 1560452399999L + "'", comparable67.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str71.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(obj72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
//        java.util.Date date8 = day4.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date17);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        boolean boolean21 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod18);
//        long long22 = simpleTimePeriod18.getStartMillis();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, number24);
//        java.lang.Class<?> wildcardClass26 = timePeriodValue25.getClass();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 100.0d);
//        java.util.Date date31 = day27.getStart();
//        java.lang.Class class32 = null;
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date31, timeZone34);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        long long38 = year37.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.next();
//        java.util.Date date40 = year37.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date31, date40);
//        long long42 = simpleTimePeriod41.getEndMillis();
//        java.util.Date date43 = simpleTimePeriod41.getEnd();
//        boolean boolean44 = timePeriodValue25.equals((java.lang.Object) simpleTimePeriod41);
//        boolean boolean45 = simpleTimePeriod18.equals((java.lang.Object) simpleTimePeriod41);
//        long long46 = simpleTimePeriod18.getStartMillis();
//        long long47 = simpleTimePeriod18.getEndMillis();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timePeriodValue2.equals(obj4);
//        java.lang.Number number6 = timePeriodValue2.getValue();
//        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue2.getPeriod();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.next();
//        long long11 = day8.getLastMillisecond();
//        boolean boolean12 = timePeriodValue2.equals((java.lang.Object) long11);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(number6);
//        org.junit.Assert.assertNotNull(timePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.String str6 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "TimePeriodValue[13-June-2019,null]");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable5 = null;
        try {
            timePeriodValues3.setKey(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2019, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean6 = timePeriodValue4.equals((java.lang.Object) day5);
        java.lang.Number number7 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 2019 + "'", number7.equals(2019));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.setDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (double) ' ');
        int int19 = timePeriodValues3.getMinEndIndex();
        try {
            java.lang.Object obj20 = timePeriodValues3.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, number9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue10.getClass();
//        java.lang.String str12 = timePeriodValue10.toString();
//        timePeriodValues7.add(timePeriodValue10);
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.String str16 = timePeriodValues7.getRangeDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        long long18 = year17.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
//        java.util.Date date20 = year17.getEnd();
//        long long21 = year17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, (double) ' ');
//        timePeriodValues7.setRangeDescription("");
//        java.lang.String str27 = timePeriodValues7.getDescription();
//        java.lang.String str28 = timePeriodValues7.getDomainDescription();
//        boolean boolean29 = day0.equals((java.lang.Object) timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str12.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str28.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int4 = day0.compareTo((java.lang.Object) 10.0f);
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str10 = timePeriodValues9.getDomainDescription();
//        int int11 = timePeriodValues9.getMinStartIndex();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean14 = year12.equals((java.lang.Object) timeZone13);
//        long long15 = year12.getLastMillisecond();
//        int int16 = year12.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) (byte) 0);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) (-1));
//        int int23 = day0.compareTo((java.lang.Object) year12);
//        java.util.Calendar calendar24 = null;
//        try {
//            day0.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timePeriodValue2.equals(obj4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 100.0d);
//        java.util.Date date10 = day6.getStart();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
//        java.util.Date date19 = year16.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date10, date19);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
//        java.lang.String str23 = seriesChangeEvent22.toString();
//        boolean boolean24 = simpleTimePeriod20.equals((java.lang.Object) seriesChangeEvent22);
//        boolean boolean25 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod20);
//        java.lang.String str26 = timePeriodValue2.toString();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str26.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=9]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
        java.util.Date date21 = day17.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100.0d);
        java.util.Date date45 = day41.getStart();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date21, timeZone48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date21);
        int int54 = year53.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year53);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "13-June-2019" + "'", str58.equals("13-June-2019"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
        int int5 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        java.lang.String str11 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        long long16 = year12.getSerialIndex();
        java.util.Date date17 = year12.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (double) 8);
        timePeriodValues3.setNotify(true);
        timePeriodValues3.setDescription("");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        int int12 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        java.lang.Class<?> wildcardClass15 = day13.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getMonth();
//        int int29 = day26.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day26, (double) 2019L);
//        long long32 = day26.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate33 = day26.getSerialDate();
//        int int34 = day13.compareTo((java.lang.Object) day26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0d);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener37);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        int int7 = day4.getDayOfMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        long long10 = day4.getFirstMillisecond();
//        int int11 = day4.getDayOfMonth();
//        int int12 = day4.getMonth();
//        long long13 = day4.getLastMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day4.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) 100L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate7, "org.jfree.data.general.SeriesChangeEvent[source=100.0]", "");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, number17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValue18.getClass();
//        java.lang.String str20 = timePeriodValue18.toString();
//        timePeriodValues15.add(timePeriodValue18);
//        int int22 = timePeriodValues15.getItemCount();
//        java.lang.Number number24 = timePeriodValues15.getValue(0);
//        java.lang.String str25 = timePeriodValues15.getDescription();
//        int int26 = timePeriodValues15.getMinMiddleIndex();
//        boolean boolean27 = timePeriodValues3.equals((java.lang.Object) int26);
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = null;
//        try {
//            timePeriodValues3.add(timePeriodValue28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str20.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        timePeriodValue6.setValue((java.lang.Number) 12);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        long long17 = day16.getMiddleMillisecond();
        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
        int int19 = day16.getDayOfMonth();
        int int20 = day16.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577822399999L + "'", long17 == 1577822399999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        int int17 = timePeriodValues3.getMinEndIndex();
        java.lang.Comparable comparable18 = timePeriodValues3.getKey();
        timePeriodValues3.delete(13, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 1560452399999L + "'", comparable18.equals(1560452399999L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
//        int int13 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("Value");
//        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) "Value");
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        int int7 = year0.getYear();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        java.lang.Object obj17 = timePeriodValues15.clone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number19);
        timePeriodValues15.add(timePeriodValue20);
        timePeriodValues3.add(timePeriodValue20);
        timePeriodValues3.delete(10, 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.String str11 = year9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        long long16 = day10.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day10.getSerialDate();
//        java.util.Calendar calendar18 = null;
//        try {
//            day10.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.String str10 = timePeriodFormatException8.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str12 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getSerialIndex();
        long long8 = year6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        java.util.Date date2 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        int int6 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        try {
            org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues3.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        java.lang.String str7 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setNotify(true);
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str7.equals("TimePeriodValue[13-June-2019,null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str10.equals("TimePeriodValue[13-June-2019,null]"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date4, date18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date18);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        long long8 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 100, 1);
        int int10 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, number12);
        java.lang.Class<?> wildcardClass14 = timePeriodValue13.getClass();
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValue13.equals(obj15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        boolean boolean19 = timePeriodValue13.equals((java.lang.Object) regularTimePeriod18);
        java.lang.Number number20 = timePeriodValue13.getValue();
        timePeriodValues3.add(timePeriodValue13);
        java.lang.Object obj22 = timePeriodValues3.clone();
        boolean boolean23 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean26 = year24.equals((java.lang.Object) timeZone25);
        java.lang.String str27 = year24.toString();
        java.lang.Object obj28 = null;
        int int29 = year24.compareTo(obj28);
        long long30 = year24.getFirstMillisecond();
        long long31 = year24.getLastMillisecond();
        long long32 = year24.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        java.lang.String str11 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        long long16 = year12.getSerialIndex();
        java.util.Date date17 = year12.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        timePeriodValue5.setValue((java.lang.Number) 1562097599999L);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue5.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, number12);
        java.lang.Class<?> wildcardClass14 = timePeriodValue13.getClass();
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValue13.equals(obj15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        boolean boolean19 = timePeriodValue13.equals((java.lang.Object) regularTimePeriod18);
        java.lang.Number number20 = timePeriodValue13.getValue();
        timePeriodValues3.add(timePeriodValue13);
        java.lang.Object obj22 = timePeriodValue13.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener23);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        java.lang.String str13 = year11.toString();
        java.lang.String str14 = year11.toString();
        int int15 = day5.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = day20.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 100.0d);
        java.util.Date date24 = day20.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date19, timeZone27);
        int int31 = year11.compareTo((java.lang.Object) timeZone27);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date4, timeZone27);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        int int34 = day33.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
        java.util.Date date37 = day33.getStart();
        java.lang.Class class38 = null;
        java.util.Date date39 = null;
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date37, timeZone40);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date4, date37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, 1577865599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year7, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod12);
        java.util.Date date14 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 2019);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        boolean boolean10 = timePeriodValue8.equals((java.lang.Object) day9);
        timePeriodValues3.add(timePeriodValue8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        long long16 = simpleTimePeriod14.getStartMillis();
//        java.util.Date date17 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day18);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener12);
//        int int14 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.String str15 = timePeriodValues3.getRangeDescription();
//        java.lang.Object obj16 = timePeriodValues3.clone();
//        timePeriodValues3.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1560452399999L + "'", comparable11.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(obj16);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        int int17 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("31-December-2019");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        java.lang.Object obj17 = timePeriodValues15.clone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number19);
        timePeriodValues15.add(timePeriodValue20);
        timePeriodValues3.add(timePeriodValue20);
        java.lang.String str23 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (byte) 0);
//        java.lang.String str31 = timePeriodValues3.getRangeDescription();
//        int int32 = timePeriodValues3.getMaxMiddleIndex();
//        java.lang.String str33 = timePeriodValues3.getDescription();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNull(str33);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        int int12 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        java.lang.Class<?> wildcardClass15 = day13.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getMonth();
//        int int29 = day26.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day26, (double) 2019L);
//        long long32 = day26.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate33 = day26.getSerialDate();
//        int int34 = day13.compareTo((java.lang.Object) day26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0d);
//        int int37 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        int int16 = day15.getDayOfMonth();
        java.util.Date date17 = day15.getStart();
        long long18 = day15.getFirstMillisecond();
        long long19 = day15.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate20 = day15.getSerialDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577779200000L + "'", long18 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate20);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, number17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValue18.getClass();
//        java.lang.String str20 = timePeriodValue18.toString();
//        timePeriodValues15.add(timePeriodValue18);
//        int int22 = timePeriodValues15.getItemCount();
//        java.lang.Number number24 = timePeriodValues15.getValue(0);
//        java.lang.String str25 = timePeriodValues15.getDescription();
//        int int26 = timePeriodValues15.getMinMiddleIndex();
//        boolean boolean27 = timePeriodValues3.equals((java.lang.Object) int26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        java.lang.Class<?> wildcardClass30 = day28.getClass();
//        int int31 = day28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod32, "Value", "13-June-2019");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue40 = timePeriodValues36.getDataItem(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str20.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        long long16 = day10.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long16);
//        java.lang.Object obj18 = seriesChangeEvent17.getSource();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + 1560409200000L + "'", obj18.equals(1560409200000L));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) 'a');
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) (short) 0);
        boolean boolean9 = timePeriodValue3.equals((java.lang.Object) (short) 10);
        timePeriodValue3.setValue((java.lang.Number) 7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date15 = simpleTimePeriod14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 100.0d);
        java.util.Date date20 = day16.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date20, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean28 = year26.equals((java.lang.Object) timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date20, timeZone27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date15, timeZone27);
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date15, timeZone33);
        boolean boolean36 = timePeriodValue3.equals((java.lang.Object) timeZone33);
        java.lang.Object obj37 = timePeriodValue3.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj37);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, number17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValue18.getClass();
//        java.lang.String str20 = timePeriodValue18.toString();
//        timePeriodValues15.add(timePeriodValue18);
//        int int22 = timePeriodValues15.getItemCount();
//        java.lang.Number number24 = timePeriodValues15.getValue(0);
//        java.lang.String str25 = timePeriodValues15.getDescription();
//        int int26 = timePeriodValues15.getMinMiddleIndex();
//        boolean boolean27 = timePeriodValues3.equals((java.lang.Object) int26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        java.lang.Class<?> wildcardClass30 = day28.getClass();
//        int int31 = day28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod32);
//        timePeriodValues3.delete((int) (byte) 100, 4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str20.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues5.createCopy(4, 0);
        int int10 = timePeriodValues9.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        int int12 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, number16);
        int int19 = day15.compareTo((java.lang.Object) 10.0f);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues19.removePropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timePeriodValues19.getRangeDescription();
//        java.lang.String str29 = timePeriodValues19.getDescription();
//        int int30 = day15.compareTo((java.lang.Object) str29);
//        int int31 = day15.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.lang.Object obj11 = timePeriodValues3.clone();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
        boolean boolean17 = timePeriodValue15.equals((java.lang.Object) 'a');
        timePeriodValues3.add(timePeriodValue15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean21 = year19.equals((java.lang.Object) timeZone20);
        long long22 = year19.getLastMillisecond();
        int int23 = year19.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (double) 8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 1560452399999L + "'", comparable13.equals(1560452399999L));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.lang.String str7 = timePeriodValues5.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        int int14 = year13.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDescription("13-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 100.0d);
        java.util.Date date21 = day17.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 100.0d);
        java.util.Date date28 = day24.getStart();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100.0d);
        java.util.Date date45 = day41.getStart();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date21, timeZone48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date21);
        int int54 = year53.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year53);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener56);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = timePeriodValues3.createCopy(2, (-1));
        boolean boolean61 = timePeriodValues60.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(timePeriodValues60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
//        int int10 = day6.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        boolean boolean12 = timePeriodValue4.equals((java.lang.Object) day6);
//        java.lang.String str13 = timePeriodValue4.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[14-June-2019,10.0]" + "'", str13.equals("TimePeriodValue[14-June-2019,10.0]"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        java.util.Date date10 = year9.getEnd();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        int int4 = year0.compareTo((java.lang.Object) timePeriodFormatException3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.lang.Object obj11 = timePeriodValues3.clone();
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 6);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, number11);
//        java.lang.Class<?> wildcardClass13 = timePeriodValue12.getClass();
//        java.lang.String str14 = timePeriodValue12.toString();
//        timePeriodValues9.add(timePeriodValue12);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getMonth();
//        int int19 = day16.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day16, (double) 2019L);
//        timePeriodValues5.setKey((java.lang.Comparable) day16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str14.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.lang.String str16 = year13.toString();
        java.util.Date date17 = year13.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        java.lang.String str20 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue22 = timePeriodValues3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        java.lang.Class<?> wildcardClass9 = timePeriodValues7.getClass();
        java.lang.Comparable comparable10 = timePeriodValues7.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        boolean boolean15 = timePeriodValues7.equals((java.lang.Object) date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 1560452399999L + "'", comparable10.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
//        java.util.Date date16 = day12.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date16, timeZone19);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date16, date25);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date27, date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 100.0d);
//        java.util.Date date37 = day33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date37, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone40);
//        java.util.Date date44 = null;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, (java.lang.Number) 100.0d);
//        java.util.Date date49 = day45.getStart();
//        java.lang.Class class50 = null;
//        java.util.Date date51 = null;
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone52);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date49, timeZone52);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        long long56 = year55.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year55.next();
//        java.util.Date date58 = year55.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date49, date58);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date58, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date44, timeZone60);
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(class63);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getLastMillisecond();
//        java.util.Date date6 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str7 = year0.toString();
        java.util.Date date8 = year0.getStart();
        java.lang.Class<?> wildcardClass9 = date8.getClass();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), 1L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, number8);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue9.getClass();
//        java.lang.String str11 = timePeriodValue9.toString();
//        timePeriodValues6.add(timePeriodValue9);
//        java.lang.Class<?> wildcardClass13 = timePeriodValue9.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
//        java.util.Date date19 = day15.getStart();
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        long long26 = year25.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.next();
//        java.util.Date date28 = year25.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date19, date28);
//        java.util.Date date30 = simpleTimePeriod29.getEnd();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
//        java.util.Date date34 = year31.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date30, date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day36, (java.lang.Number) 100.0d);
//        java.util.Date date40 = day36.getStart();
//        java.lang.Class class41 = null;
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date40, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date34, timeZone43);
//        java.util.Date date47 = null;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 100.0d);
//        java.util.Date date52 = day48.getStart();
//        java.lang.Class class53 = null;
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date52, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        long long59 = year58.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year58.next();
//        java.util.Date date61 = year58.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date52, date61);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date61, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date47, timeZone63);
//        boolean boolean66 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        long long68 = year67.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int71 = year67.compareTo((java.lang.Object) timePeriodFormatException70);
//        boolean boolean72 = simpleTimePeriod2.equals((java.lang.Object) int71);
//        java.util.Date date73 = simpleTimePeriod2.getStart();
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str11.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1577865599999L + "'", long68 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date73);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.setDescription("");
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1560452399999L + "'", comparable14.equals(1560452399999L));
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        timePeriodValues16.fireSeriesChanged();
//        timePeriodValues16.fireSeriesChanged();
//        timePeriodValues16.setDescription("org.jfree.data.time.TimePeriodFormatException: 13-June-2019");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
//        java.util.Date date16 = simpleTimePeriod15.getEnd();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.Number number19 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, number19);
//        int int21 = day18.getDayOfMonth();
//        long long22 = day18.getMiddleMillisecond();
//        long long23 = day18.getLastMillisecond();
//        int int24 = day18.getYear();
//        java.util.Date date25 = day18.getEnd();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 100.0d);
//        java.util.Date date30 = day26.getStart();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date30, timeZone33);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        long long37 = year36.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
//        java.util.Date date39 = year36.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date30, date39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date39, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date25, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone42);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.Number number52 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, number52);
//        java.lang.Class<?> wildcardClass54 = timePeriodValue53.getClass();
//        java.lang.String str55 = timePeriodValue53.toString();
//        timePeriodValues50.add(timePeriodValue53);
//        java.lang.Class<?> wildcardClass57 = timePeriodValue53.getClass();
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize(class58);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
//        java.util.Date date63 = simpleTimePeriod62.getEnd();
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        java.lang.Number number66 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day65, number66);
//        int int68 = day65.getDayOfMonth();
//        long long69 = day65.getMiddleMillisecond();
//        long long70 = day65.getLastMillisecond();
//        int int71 = day65.getYear();
//        java.util.Date date72 = day65.getEnd();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        int int74 = day73.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue76 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day73, (java.lang.Number) 100.0d);
//        java.util.Date date77 = day73.getStart();
//        java.lang.Class class78 = null;
//        java.util.Date date79 = null;
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date79, timeZone80);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date77, timeZone80);
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
//        long long84 = year83.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year83.next();
//        java.util.Date date86 = year83.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod87 = new org.jfree.data.time.SimpleTimePeriod(date77, date86);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date86);
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date86, timeZone89);
//        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date72, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date63, timeZone89);
//        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date16, timeZone89);
//        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date16);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560452399999L + "'", long22 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str55.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 13 + "'", int68 == 13);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560452399999L + "'", long69 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560495599999L + "'", long70 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1577865599999L + "'", long84 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 2019, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        try {
            timePeriodValues3.update(10, (java.lang.Number) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        int int9 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        try {
            java.lang.Number number13 = timePeriodValues3.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100.0d);
//        java.util.Date date17 = day13.getStart();
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date17, timeZone20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (byte) 0);
//        java.lang.String str31 = timePeriodValues3.getRangeDescription();
//        int int32 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean35 = year33.equals((java.lang.Object) timeZone34);
//        long long36 = year33.getLastMillisecond();
//        int int37 = year33.getYear();
//        long long38 = year33.getSerialIndex();
//        int int39 = year33.getYear();
//        long long40 = year33.getFirstMillisecond();
//        long long41 = year33.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year33.next();
//        timePeriodValues3.setKey((java.lang.Comparable) year33);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getMonth();
//        java.lang.Object obj46 = null;
//        int int47 = day44.compareTo(obj46);
//        long long48 = day44.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass49 = day44.getClass();
//        int int50 = day44.getDayOfMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day44, (java.lang.Number) 2019L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560452399999L + "'", long48 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 13 + "'", int50 == 13);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=9]");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean14 = year12.equals((java.lang.Object) timeZone13);
        long long15 = year12.getLastMillisecond();
        long long16 = year12.getSerialIndex();
        long long17 = year12.getFirstMillisecond();
        java.util.Date date18 = year12.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, (double) 12);
        java.lang.Object obj21 = null;
        boolean boolean22 = year12.equals(obj21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        java.lang.Number number7 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0d + "'", number7.equals(10.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy((int) (short) 10, 3);
        try {
            org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues25.getTimePeriod(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
//        java.util.Date date8 = day4.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date3, timeZone11);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.Number number16 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, number16);
//        java.lang.Class<?> wildcardClass18 = timePeriodValue17.getClass();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100.0d);
//        java.util.Date date23 = day19.getStart();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date23, timeZone26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        long long30 = year29.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.next();
//        java.util.Date date32 = year29.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date23, date32);
//        long long34 = simpleTimePeriod33.getEndMillis();
//        java.util.Date date35 = simpleTimePeriod33.getEnd();
//        boolean boolean36 = timePeriodValue17.equals((java.lang.Object) simpleTimePeriod33);
//        long long37 = simpleTimePeriod33.getStartMillis();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.Number number39 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, number39);
//        java.lang.Class<?> wildcardClass41 = timePeriodValue40.getClass();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        int int43 = day42.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day42, (java.lang.Number) 100.0d);
//        java.util.Date date46 = day42.getStart();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date46, timeZone49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.next();
//        java.util.Date date55 = year52.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date46, date55);
//        long long57 = simpleTimePeriod56.getEndMillis();
//        java.util.Date date58 = simpleTimePeriod56.getEnd();
//        boolean boolean59 = timePeriodValue40.equals((java.lang.Object) simpleTimePeriod56);
//        boolean boolean60 = simpleTimePeriod33.equals((java.lang.Object) simpleTimePeriod56);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        int int62 = day61.getYear();
//        java.lang.Class<?> wildcardClass63 = day61.getClass();
//        int int64 = day61.getYear();
//        int int66 = day61.compareTo((java.lang.Object) (-1.0d));
//        long long67 = day61.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate68 = day61.getSerialDate();
//        boolean boolean69 = simpleTimePeriod56.equals((java.lang.Object) serialDate68);
//        java.util.Date date70 = simpleTimePeriod56.getEnd();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        int int72 = day71.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue74 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day71, (java.lang.Number) 100.0d);
//        java.util.Date date75 = day71.getStart();
//        java.lang.Class class76 = null;
//        java.util.Date date77 = null;
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date75, timeZone78);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
//        long long82 = year81.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = year81.next();
//        java.util.Date date84 = year81.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(date75, date84);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date84);
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date84, timeZone87);
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date70, timeZone87);
//        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date3, timeZone87);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560409200000L + "'", long37 == 1560409200000L);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560409200000L + "'", long67 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1577865599999L + "'", long82 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone87);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent1.getClass();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 9 + "'", obj2.equals(9));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 9 + "'", obj3.equals(9));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 9 + "'", obj5.equals(9));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.lang.String str16 = year13.toString();
        java.util.Date date17 = year13.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        java.lang.String str20 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setDomainDescription("");
        java.lang.String str17 = timePeriodValues3.getDescription();
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        java.lang.String str11 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        long long16 = year12.getSerialIndex();
        java.util.Date date17 = year12.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (double) 8);
        timePeriodValues3.setNotify(true);
        java.lang.Object obj24 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17, "13-June-2019", "2019");
        int int21 = timePeriodValues20.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = seriesException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str6 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean18 = year16.equals((java.lang.Object) timeZone17);
        long long19 = year16.getLastMillisecond();
        int int20 = year16.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 0);
        java.lang.Number number23 = timePeriodValue22.getValue();
        boolean boolean24 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue22);
        java.util.Date date25 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) 0 + "'", number23.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[14-June-2019,1560409200000]");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        timePeriodValue6.setValue((java.lang.Number) 13);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMinStartIndex();
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        java.util.Date date16 = simpleTimePeriod14.getStart();
        long long17 = simpleTimePeriod14.getEndMillis();
        java.util.Date date18 = simpleTimePeriod14.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date23 = simpleTimePeriod22.getStart();
        java.util.Date date24 = simpleTimePeriod22.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date18, date24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.String str5 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        java.util.Date date7 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, number15);
//        int int17 = day14.getDayOfMonth();
//        long long18 = day14.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day14, (double) 2);
//        timePeriodValues3.setNotify(true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        java.lang.String str4 = timePeriodValue2.toString();
//        timePeriodValue2.setValue((java.lang.Number) 100.0d);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str4.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setRangeDescription("31-December-1969");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
//        java.util.Date date8 = day4.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date17);
//        long long19 = simpleTimePeriod18.getEndMillis();
//        java.util.Date date20 = simpleTimePeriod18.getEnd();
//        boolean boolean21 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod18);
//        long long22 = simpleTimePeriod18.getStartMillis();
//        long long23 = simpleTimePeriod18.getStartMillis();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) (byte) 10);
//        try {
//            timePeriodValues3.update(1, (java.lang.Number) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean14 = year12.equals((java.lang.Object) timeZone13);
        long long15 = year12.getLastMillisecond();
        long long16 = year12.getSerialIndex();
        long long17 = year12.getFirstMillisecond();
        java.util.Date date18 = year12.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, (double) 12);
        long long21 = year12.getSerialIndex();
        java.lang.String str22 = year12.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 100.0d);
        java.util.Date date20 = day16.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date20, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.next();
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date20, date29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date29, timeZone32);
        int int34 = simpleTimePeriod14.compareTo((java.lang.Object) day33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        int int9 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues19.removePropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timePeriodValues19.getRangeDescription();
//        java.lang.String str29 = timePeriodValues19.getDescription();
//        int int30 = day15.compareTo((java.lang.Object) str29);
//        long long31 = day15.getFirstMillisecond();
//        java.util.Calendar calendar32 = null;
//        try {
//            long long33 = day15.getLastMillisecond(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        int int10 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy((int) (short) 10, 3);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue27 = timePeriodValues25.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        int int12 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        java.lang.Class<?> wildcardClass15 = day13.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getMonth();
//        int int29 = day26.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day26, (double) 2019L);
//        long long32 = day26.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate33 = day26.getSerialDate();
//        int int34 = day13.compareTo((java.lang.Object) day26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0d);
//        java.util.Date date37 = day26.getEnd();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(date37);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, number10);
//        java.lang.Class<?> wildcardClass12 = timePeriodValue11.getClass();
//        java.lang.String str13 = timePeriodValue11.toString();
//        timePeriodValues8.add(timePeriodValue11);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        int int18 = day15.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day15, (double) 2019L);
//        long long21 = day15.getFirstMillisecond();
//        boolean boolean22 = day0.equals((java.lang.Object) long21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) 100.0d);
//        java.util.Date date27 = day23.getStart();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass29 = timeZone28.getClass();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) 100.0d);
//        java.util.Date date34 = day30.getStart();
//        java.lang.Class class35 = null;
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date34, timeZone37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.next();
//        java.util.Date date43 = year40.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date34, date43);
//        long long45 = simpleTimePeriod44.getEndMillis();
//        java.util.Date date46 = simpleTimePeriod44.getStart();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        int int48 = day47.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day47, (java.lang.Number) 100.0d);
//        java.util.Date date51 = day47.getStart();
//        java.lang.Class class52 = null;
//        java.util.Date date53 = null;
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date51, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date46, timeZone54);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date27, timeZone54);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.TimePeriodValue timePeriodValue61 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, (double) 1560409200000L);
//        java.lang.Number number62 = timePeriodValue61.getValue();
//        int int63 = day0.compareTo((java.lang.Object) timePeriodValue61);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str13.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 1.5604092E12d + "'", number62.equals(1.5604092E12d));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getMiddleMillisecond();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        java.lang.String str9 = timePeriodValues8.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        int int10 = day0.compareTo((java.lang.Object) year6);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
//        java.util.Date date14 = year11.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
//        java.util.Date date19 = day15.getStart();
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date14, timeZone22);
//        int int26 = year6.compareTo((java.lang.Object) timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day32, number33);
//        java.lang.Class<?> wildcardClass35 = timePeriodValue34.getClass();
//        java.lang.String str36 = timePeriodValue34.toString();
//        timePeriodValues31.add(timePeriodValue34);
//        java.lang.Class<?> wildcardClass38 = timePeriodValue34.getClass();
//        java.lang.String str39 = timePeriodValue34.toString();
//        java.lang.String str40 = timePeriodValue34.toString();
//        java.lang.Object obj41 = timePeriodValue34.clone();
//        boolean boolean42 = year6.equals(obj41);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str36.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str39.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str40.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        int int12 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMinStartIndex();
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.setRangeDescription("");
        int int11 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, number9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValue10.getClass();
//        java.lang.String str12 = timePeriodValue10.toString();
//        timePeriodValues7.add(timePeriodValue10);
//        java.lang.Class<?> wildcardClass14 = timePeriodValue10.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        java.lang.Class<?> wildcardClass17 = day15.getClass();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 100.0d);
//        java.util.Date date22 = day18.getStart();
//        java.lang.Class class23 = null;
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date22, date31);
//        java.util.Date date33 = simpleTimePeriod32.getEnd();
//        long long34 = simpleTimePeriod32.getStartMillis();
//        java.util.Date date35 = simpleTimePeriod32.getStart();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date35, timeZone36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        int int39 = day38.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) 100.0d);
//        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getLastMillisecond();
//        java.lang.String str46 = year44.toString();
//        java.lang.String str47 = year44.toString();
//        int int48 = day38.compareTo((java.lang.Object) year44);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        long long50 = year49.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.next();
//        java.util.Date date52 = year49.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 100.0d);
//        java.util.Date date57 = day53.getStart();
//        java.lang.Class class58 = null;
//        java.util.Date date59 = null;
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone60);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date57, timeZone60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date52, timeZone60);
//        int int64 = year44.compareTo((java.lang.Object) timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date35, timeZone60);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date3, timeZone60);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str12.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560409200000L + "'", long34 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019" + "'", str46.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean8 = year6.equals((java.lang.Object) timeZone7);
        long long9 = year6.getLastMillisecond();
        int int10 = year6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (-1.0d));
        timePeriodValues3.setNotify(true);
        int int17 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener22);
        int int24 = timePeriodValues3.getMaxMiddleIndex();
        int int25 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Number number5 = timePeriodValue3.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
        org.junit.Assert.assertNotNull(timePeriod6);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getYear();
//        int int5 = day0.compareTo((java.lang.Object) (-1.0d));
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, number17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValue18.getClass();
//        java.lang.String str20 = timePeriodValue18.toString();
//        timePeriodValues15.add(timePeriodValue18);
//        int int22 = timePeriodValues15.getItemCount();
//        java.lang.Number number24 = timePeriodValues15.getValue(0);
//        java.lang.String str25 = timePeriodValues15.getDescription();
//        int int26 = timePeriodValues15.getMinMiddleIndex();
//        boolean boolean27 = timePeriodValues3.equals((java.lang.Object) int26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        java.lang.Class<?> wildcardClass30 = day28.getClass();
//        int int31 = day28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
//        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod32, "Value", "13-June-2019");
//        java.lang.String str37 = timePeriodValues36.getDomainDescription();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str20.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str17 = seriesChangeEvent16.toString();
        boolean boolean18 = simpleTimePeriod14.equals((java.lang.Object) seriesChangeEvent16);
        java.lang.Object obj19 = seriesChangeEvent16.getSource();
        java.lang.Object obj20 = seriesChangeEvent16.getSource();
        java.lang.Object obj21 = seriesChangeEvent16.getSource();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str17.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + obj19 + "' != '" + 9 + "'", obj19.equals(9));
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + 9 + "'", obj20.equals(9));
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + 9 + "'", obj21.equals(9));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 9 + "'", obj2.equals(9));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 9 + "'", obj3.equals(9));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        int int19 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
        java.lang.Class<?> wildcardClass3 = timePeriodValue2.getClass();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 100.0d);
        java.util.Date date8 = day4.getStart();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date8, date17);
        long long19 = simpleTimePeriod18.getEndMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        boolean boolean21 = timePeriodValue2.equals((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        java.util.Date date23 = simpleTimePeriod18.getStart();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 100L);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = timePeriodValues5.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        java.lang.Class<?> wildcardClass10 = timePeriodValue6.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        java.lang.Class<?> wildcardClass13 = day11.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 100.0d);
//        java.util.Date date18 = day14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date18, timeZone21);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
//        java.util.Date date27 = year24.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date18, date27);
//        java.util.Date date29 = simpleTimePeriod28.getEnd();
//        long long30 = simpleTimePeriod28.getStartMillis();
//        java.util.Date date31 = simpleTimePeriod28.getStart();
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 100.0d);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getLastMillisecond();
//        java.lang.String str42 = year40.toString();
//        java.lang.String str43 = year40.toString();
//        int int44 = day34.compareTo((java.lang.Object) year40);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.next();
//        java.util.Date date48 = year45.getEnd();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day49, (java.lang.Number) 100.0d);
//        java.util.Date date53 = day49.getStart();
//        java.lang.Class class54 = null;
//        java.util.Date date55 = null;
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date53, timeZone56);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date48, timeZone56);
//        int int60 = year40.compareTo((java.lang.Object) timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone56);
//        java.util.Date date62 = null;
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(date31, date62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019" + "'", str43.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        int int12 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        java.lang.Class<?> wildcardClass15 = day13.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getMonth();
//        int int29 = day26.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day26, (double) 2019L);
//        long long32 = day26.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate33 = day26.getSerialDate();
//        int int34 = day13.compareTo((java.lang.Object) day26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0d);
//        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: 13-June-2019");
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        long long16 = simpleTimePeriod14.getStartMillis();
//        java.util.Date date17 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) ' ');
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = day18.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean7 = year5.equals((java.lang.Object) timeZone6);
//        long long8 = year5.getLastMillisecond();
//        long long9 = year5.getSerialIndex();
//        long long10 = year5.getFirstMillisecond();
//        java.util.Date date11 = year5.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        int int14 = day0.compareTo((java.lang.Object) serialDate13);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str4 = timePeriodValues3.getDomainDescription();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        java.lang.String str8 = year6.toString();
//        java.lang.String str9 = year6.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, number15);
//        int int17 = day14.getDayOfMonth();
//        long long18 = day14.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day14, (double) 2);
//        try {
//            java.lang.Number number23 = timePeriodValues3.getValue(2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 2");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        java.lang.Number number29 = timePeriodValue23.getValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNull(number29);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        int int13 = timePeriodValues3.getMinStartIndex();
//        int int14 = timePeriodValues3.getMinEndIndex();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener17);
//        timePeriodValues3.setDomainDescription("2019");
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        long long16 = simpleTimePeriod14.getStartMillis();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean19 = year17.equals((java.lang.Object) timeZone18);
//        long long20 = year17.getLastMillisecond();
//        long long21 = year17.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 1560409200000L);
//        java.lang.String str24 = timePeriodValue23.toString();
//        java.lang.Number number25 = timePeriodValue23.getValue();
//        try {
//            int int26 = simpleTimePeriod14.compareTo((java.lang.Object) timePeriodValue23);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[2019,1.5604092E12]" + "'", str24.equals("TimePeriodValue[2019,1.5604092E12]"));
//        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.5604092E12d + "'", number25.equals(1.5604092E12d));
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 10.0d);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
//        int int10 = day6.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        boolean boolean12 = timePeriodValue4.equals((java.lang.Object) day6);
//        long long13 = day6.getMiddleMillisecond();
//        java.lang.String str14 = day6.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day6.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate13);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.lang.Number number6 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues3.getDataItem(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.lang.Object obj11 = timePeriodValues3.clone();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 100.0d);
        boolean boolean17 = timePeriodValue15.equals((java.lang.Object) 'a');
        timePeriodValues3.add(timePeriodValue15);
        timePeriodValue15.setValue((java.lang.Number) 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
//        int int13 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, 1560452399999L);
//        long long17 = simpleTimePeriod16.getStartMillis();
//        java.util.Date date18 = simpleTimePeriod16.getEnd();
//        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 10);
//        java.lang.String str6 = timePeriodValue5.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,10]" + "'", str6.equals("TimePeriodValue[13-June-2019,10]"));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 100.0d);
        java.util.Date date19 = day15.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 100.0d);
        java.util.Date date29 = day25.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date29, timeZone32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date29, date38);
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        int int41 = year24.compareTo((java.lang.Object) date40);
        boolean boolean42 = timePeriodValues3.equals((java.lang.Object) year24);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener43);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean12 = year10.equals((java.lang.Object) timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11);
        long long14 = year13.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 100.0d);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 'a');
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) (short) 0);
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) (short) 10);
        java.lang.Number number17 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.setDomainDescription("2019");
        try {
            java.lang.Number number22 = timePeriodValues3.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValue23.getClass();
//        java.lang.String str25 = timePeriodValue23.toString();
//        timePeriodValues20.add(timePeriodValue23);
//        java.lang.Class<?> wildcardClass27 = timePeriodValue23.getClass();
//        timePeriodValues16.add(timePeriodValue23);
//        boolean boolean29 = timePeriodValues16.getNotify();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str25.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(13, (int) (byte) 10);
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.lang.Object obj11 = timePeriodValues3.clone();
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        java.lang.String str13 = timePeriodValues3.getDescription();
        java.lang.Object obj14 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getMiddleMillisecond();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean2 = year0.equals((java.lang.Object) timeZone1);
        java.lang.String str3 = year0.toString();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        java.util.Date date6 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        java.lang.Object obj12 = timePeriodValues10.clone();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, number14);
        timePeriodValues10.add(timePeriodValue15);
        timePeriodValues10.setRangeDescription("hi!");
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        timePeriodValues10.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
        timePeriodValues10.setDescription("13-June-2019");
        timePeriodValues10.setDescription("TimePeriodValue[13-June-2019,2019]");
        boolean boolean26 = year0.equals((java.lang.Object) timePeriodValues10);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1560452399999L + "'", comparable19.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        timePeriodValues3.setKey((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod14, (double) 'a');
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (double) (-31507200000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMinEndIndex();
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean10 = year8.equals((java.lang.Object) timeZone9);
        long long11 = year8.getLastMillisecond();
        long long12 = year8.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (short) 10);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        timePeriodValues3.add(timePeriod15, (double) 28799999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod15);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone16);
        long long18 = day17.getMiddleMillisecond();
        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate19, "org.jfree.data.time.TimePeriodFormatException: ", "Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577822399999L + "'", long18 == 1577822399999L);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "TimePeriodValue[13-June-2019,null]");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (byte) -1, (int) (byte) 0);
        boolean boolean9 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("");
        int int12 = timePeriodValues8.getMinMiddleIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        int int3 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int6 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        int int12 = timePeriodValues10.getMinEndIndex();
        boolean boolean13 = timePeriodValues10.isEmpty();
        int int14 = timePeriodValues10.getMinStartIndex();
        boolean boolean15 = timePeriodValues10.getNotify();
        boolean boolean16 = day0.equals((java.lang.Object) boolean15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        long long16 = simpleTimePeriod14.getStartMillis();
//        java.util.Date date17 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        int int22 = timePeriodValues21.getMinStartIndex();
//        timePeriodValues21.setRangeDescription("TimePeriodValue[13-June-2019,null]");
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 100.0d);
//        boolean boolean30 = timePeriodValue28.equals((java.lang.Object) 'a');
//        boolean boolean32 = timePeriodValue28.equals((java.lang.Object) (short) 0);
//        boolean boolean34 = timePeriodValue28.equals((java.lang.Object) (short) 10);
//        java.lang.Number number35 = timePeriodValue28.getValue();
//        timePeriodValues21.add(timePeriodValue28);
//        timePeriodValue28.setValue((java.lang.Number) 1560409200000L);
//        boolean boolean39 = simpleTimePeriod14.equals((java.lang.Object) 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 100.0d + "'", number35.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        int int11 = year4.getYear();
        java.lang.String str12 = year4.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number1);
//        int int4 = day0.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener10);
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=class sun.util.calendar.ZoneInfo]");
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
        java.util.Date date4 = day0.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone16);
        long long18 = day17.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 4);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.util.Date date4 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, number10);
//        java.lang.Class<?> wildcardClass12 = timePeriodValue11.getClass();
//        java.lang.String str13 = timePeriodValue11.toString();
//        timePeriodValues8.add(timePeriodValue11);
//        java.lang.Class<?> wildcardClass15 = timePeriodValue11.getClass();
//        java.lang.Number number16 = timePeriodValue11.getValue();
//        try {
//            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) number16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str13.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNull(number16);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValue8.setValue((java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Object obj6 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) -1, 2);
        int int10 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        java.lang.String str11 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.lang.String str15 = year12.toString();
        long long16 = year12.getSerialIndex();
        java.util.Date date17 = year12.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year19, (double) 8);
        timePeriodValues3.setNotify(true);
        java.lang.Class<?> wildcardClass24 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 100.0d);
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, number21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValue22.getClass();
//        java.lang.String str24 = timePeriodValue22.toString();
//        timePeriodValues19.add(timePeriodValue22);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues19.removePropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timePeriodValues19.getRangeDescription();
//        java.lang.String str29 = timePeriodValues19.getDescription();
//        int int30 = day15.compareTo((java.lang.Object) str29);
//        long long31 = day15.getFirstMillisecond();
//        int int32 = day15.getMonth();
//        long long33 = day15.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str24.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int13 = day10.compareTo((java.lang.Object) (-1.0f));
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) 2019L);
//        boolean boolean16 = timePeriodValues3.isEmpty();
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number5);
//        java.lang.Class<?> wildcardClass7 = timePeriodValue6.getClass();
//        java.lang.String str8 = timePeriodValue6.toString();
//        timePeriodValues3.add(timePeriodValue6);
//        int int10 = timePeriodValues3.getItemCount();
//        java.lang.Number number12 = timePeriodValues3.getValue(0);
//        int int13 = timePeriodValues3.getMinStartIndex();
//        int int14 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str19 = timePeriodValues18.getDomainDescription();
//        java.lang.Object obj20 = timePeriodValues18.clone();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, number22);
//        timePeriodValues18.add(timePeriodValue23);
//        timePeriodValues18.setRangeDescription("hi!");
//        java.lang.Comparable comparable27 = timePeriodValues18.getKey();
//        timePeriodValues18.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9]");
//        timePeriodValues18.setDescription("13-June-2019");
//        timePeriodValues18.setDescription("TimePeriodValue[13-June-2019,2019]");
//        boolean boolean34 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str8.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str19.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 1560452399999L + "'", comparable27.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj5 = timePeriodValues3.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, number7);
        timePeriodValues3.add(timePeriodValue8);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.lang.String str16 = year13.toString();
        java.util.Date date17 = year13.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=100.0]");
        try {
            java.lang.Number number23 = timePeriodValues3.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560452399999L + "'", comparable12.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1560452399999L + "'", comparable6.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class<?> wildcardClass2 = day0.getClass();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 2019);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean6 = timePeriodValue4.equals((java.lang.Object) day5);
        int int7 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int3 = day0.compareTo((java.lang.Object) (-1.0f));
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, (double) 'a');
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 97.0d + "'", number5.equals(97.0d));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        boolean boolean3 = day0.equals((java.lang.Object) false);
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        java.lang.String str6 = day5.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560452399999L, "org.jfree.data.general.SeriesChangeEvent[source=9]", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        int int12 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) 'a');
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (java.lang.Number) 11);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(date23);
    }
}

