import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            week0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date9, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            week4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        boolean boolean11 = week0.equals((java.lang.Object) week10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week10.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) '4');
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        java.util.TimeZone timeZone27 = null;
        try {
            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        org.jfree.data.time.Year year3 = week0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week12.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week5.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(6, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 1, year4);
        java.lang.String str7 = week6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2019" + "'", str7.equals("Week 1, 2019"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        java.util.Date date5 = week4.getEnd();
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        java.util.Calendar calendar17 = null;
//        try {
//            week10.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        java.lang.Class<?> wildcardClass2 = week0.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        boolean boolean11 = week0.equals((java.lang.Object) week10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week0.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.String str6 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable throwable8 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str20 = timePeriodFormatException12.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date5 = week0.getEnd();
//        long long6 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        java.lang.Class<?> wildcardClass5 = week4.getClass();
        java.util.Calendar calendar6 = null;
        try {
            week4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        int int6 = week4.getWeek();
        long long7 = week4.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549785599999L + "'", long7 == 1549785599999L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getEnd();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        java.lang.Class<?> wildcardClass7 = date6.getClass();
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date6, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        java.util.Date date6 = year4.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        long long8 = regularTimePeriod7.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559761199999L + "'", long8 == 1559761199999L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        org.jfree.data.time.Year year3 = week0.getYear();
        java.lang.Class<?> wildcardClass4 = year3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date21 = week16.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
//        int int29 = week27.compareTo((java.lang.Object) 10);
//        long long30 = week27.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        long long13 = week12.getSerialIndex();
//        long long14 = week12.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        long long7 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        java.lang.Class<?> wildcardClass8 = week0.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.lang.Class<?> wildcardClass4 = week1.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        int int9 = week5.compareTo((java.lang.Object) (short) 1);
        java.util.Date date10 = week5.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        java.util.Date date16 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        org.jfree.data.time.Year year20 = week18.getYear();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(6, year20);
        java.util.Date date22 = week21.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        org.jfree.data.time.Year year26 = week24.getYear();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(0, year26);
        java.lang.Class<?> wildcardClass28 = week27.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        java.lang.Class<?> wildcardClass32 = week29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        org.jfree.data.time.Year year35 = week33.getYear();
        int int37 = week33.compareTo((java.lang.Object) (short) 1);
        java.util.Date date38 = week33.getEnd();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date38, timeZone39);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.previous();
        org.jfree.data.time.Year year45 = week43.getYear();
        java.lang.Class<?> wildcardClass46 = week43.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        org.jfree.data.time.Year year49 = week47.getYear();
        int int51 = week47.compareTo((java.lang.Object) (short) 1);
        java.util.Date date52 = week47.getEnd();
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date52, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.previous();
        org.jfree.data.time.Year year57 = week55.getYear();
        java.lang.Class<?> wildcardClass58 = week55.getClass();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        org.jfree.data.time.Year year61 = week59.getYear();
        int int63 = week59.compareTo((java.lang.Object) (short) 1);
        java.util.Date date64 = week59.getEnd();
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date64, timeZone65);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date64);
        java.util.TimeZone timeZone68 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date64, timeZone68);
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date64, timeZone70);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date64, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date22, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone72);
        try {
            org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date0, timeZone72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(year45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(year57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod75);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(6, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 1, year4);
        int int7 = week6.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(6, year31);
        java.util.Date date33 = week32.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        org.jfree.data.time.Year year37 = week35.getYear();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(0, year37);
        java.lang.Class<?> wildcardClass39 = week38.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        org.jfree.data.time.Year year42 = week40.getYear();
        java.lang.Class<?> wildcardClass43 = week40.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        org.jfree.data.time.Year year46 = week44.getYear();
        int int48 = week44.compareTo((java.lang.Object) (short) 1);
        java.util.Date date49 = week44.getEnd();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone50);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        org.jfree.data.time.Year year56 = week54.getYear();
        java.lang.Class<?> wildcardClass57 = week54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.previous();
        org.jfree.data.time.Year year60 = week58.getYear();
        int int62 = week58.compareTo((java.lang.Object) (short) 1);
        java.util.Date date63 = week58.getEnd();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
        org.jfree.data.time.Year year68 = week66.getYear();
        java.lang.Class<?> wildcardClass69 = week66.getClass();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = week70.previous();
        org.jfree.data.time.Year year72 = week70.getYear();
        int int74 = week70.compareTo((java.lang.Object) (short) 1);
        java.util.Date date75 = week70.getEnd();
        java.util.TimeZone timeZone76 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date75, timeZone76);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date75);
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date75, timeZone79);
        java.util.TimeZone timeZone81 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date75, timeZone81);
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date75, timeZone83);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date33, timeZone83);
        java.util.Locale locale86 = null;
        try {
            org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date21, timeZone83, locale86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(year60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(year72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        int int9 = week5.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Year year12 = week10.getYear();
        java.lang.Class<?> wildcardClass13 = week10.getClass();
        int int14 = week5.compareTo((java.lang.Object) week10);
        java.util.Date date15 = week5.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(6, year19);
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        org.jfree.data.time.Year year25 = week23.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(0, year25);
        java.lang.Class<?> wildcardClass27 = week26.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        org.jfree.data.time.Year year30 = week28.getYear();
        java.lang.Class<?> wildcardClass31 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.Year year34 = week32.getYear();
        int int36 = week32.compareTo((java.lang.Object) (short) 1);
        java.util.Date date37 = week32.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone38);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        org.jfree.data.time.Year year44 = week42.getYear();
        java.lang.Class<?> wildcardClass45 = week42.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
        org.jfree.data.time.Year year48 = week46.getYear();
        int int50 = week46.compareTo((java.lang.Object) (short) 1);
        java.util.Date date51 = week46.getEnd();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date51, timeZone52);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        org.jfree.data.time.Year year56 = week54.getYear();
        java.lang.Class<?> wildcardClass57 = week54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.previous();
        org.jfree.data.time.Year year60 = week58.getYear();
        int int62 = week58.compareTo((java.lang.Object) (short) 1);
        java.util.Date date63 = week58.getEnd();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date63);
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date63, timeZone67);
        java.util.TimeZone timeZone69 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date63, timeZone69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date63, timeZone71);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date21, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date15, timeZone71);
        java.util.Calendar calendar75 = null;
        try {
            long long76 = regularTimePeriod74.getMiddleMillisecond(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(year60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        java.util.Calendar calendar12 = null;
        try {
            week11.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        java.lang.Class<?> wildcardClass7 = date6.getClass();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        long long2 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        long long5 = week2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62104809600000L) + "'", long5 == (-62104809600000L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Throwable throwable5 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        java.lang.Class<?> wildcardClass5 = year4.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year4);
        java.util.Date date7 = week6.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        java.lang.Class<?> wildcardClass6 = week4.getClass();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int5 = week0.compareTo((java.lang.Object) 100.0d);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        org.jfree.data.time.Year year9 = week6.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        int int30 = week6.compareTo((java.lang.Object) timePeriodFormatException22);
        boolean boolean31 = week0.equals((java.lang.Object) int30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        java.lang.Class<?> wildcardClass7 = date6.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        org.jfree.data.time.Year year15 = week13.getYear();
        int int17 = week13.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        org.jfree.data.time.Year year20 = week18.getYear();
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        int int22 = week13.compareTo((java.lang.Object) week18);
        java.util.Date date23 = week13.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        org.jfree.data.time.Year year27 = week25.getYear();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(6, year27);
        java.util.Date date29 = week28.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        org.jfree.data.time.Year year33 = week31.getYear();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(0, year33);
        java.lang.Class<?> wildcardClass35 = week34.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
        org.jfree.data.time.Year year38 = week36.getYear();
        java.lang.Class<?> wildcardClass39 = week36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        org.jfree.data.time.Year year42 = week40.getYear();
        int int44 = week40.compareTo((java.lang.Object) (short) 1);
        java.util.Date date45 = week40.getEnd();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date45, timeZone46);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        org.jfree.data.time.Year year52 = week50.getYear();
        java.lang.Class<?> wildcardClass53 = week50.getClass();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        org.jfree.data.time.Year year56 = week54.getYear();
        int int58 = week54.compareTo((java.lang.Object) (short) 1);
        java.util.Date date59 = week54.getEnd();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date59, timeZone60);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        org.jfree.data.time.Year year64 = week62.getYear();
        java.lang.Class<?> wildcardClass65 = week62.getClass();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
        org.jfree.data.time.Year year68 = week66.getYear();
        int int70 = week66.compareTo((java.lang.Object) (short) 1);
        java.util.Date date71 = week66.getEnd();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date71, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date71);
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date71, timeZone75);
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date71, timeZone77);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date71, timeZone79);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date29, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date23, timeZone79);
        java.util.Locale locale83 = null;
        try {
            org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date6, timeZone79, locale83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(year64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        org.jfree.data.time.Year year11 = week9.getYear();
        int int13 = week9.compareTo((java.lang.Object) (short) 1);
        java.util.Date date14 = week9.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        java.lang.Class<?> wildcardClass20 = week17.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        org.jfree.data.time.Year year23 = week21.getYear();
        int int25 = week21.compareTo((java.lang.Object) (short) 1);
        java.util.Date date26 = week21.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date26);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date26, timeZone30);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        org.jfree.data.time.Year year35 = week33.getYear();
        org.jfree.data.time.Year year36 = week33.getYear();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(0, year36);
        long long38 = year36.getMiddleMillisecond();
        java.util.Date date39 = year36.getStart();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        org.jfree.data.time.Year year42 = week40.getYear();
        java.lang.Class<?> wildcardClass43 = week40.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        org.jfree.data.time.Year year46 = week44.getYear();
        int int48 = week44.compareTo((java.lang.Object) (short) 1);
        java.util.Date date49 = week44.getEnd();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date49);
        java.util.Date date53 = week52.getStart();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date53, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date39, timeZone54);
        java.util.Locale locale57 = null;
        try {
            org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date4, timeZone54, locale57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1562097599999L + "'", long38 == 1562097599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.String str23 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException11.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        long long2 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        long long5 = week4.getFirstMillisecond();
        long long6 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1545552000000L + "'", long5 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 1, year3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str15 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException27.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException34.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str38 = timePeriodFormatException37.toString();
        java.lang.String str39 = timePeriodFormatException37.toString();
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Throwable[] throwableArray43 = timePeriodFormatException27.getSuppressed();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        long long7 = year5.getMiddleMillisecond();
        java.util.Date date8 = year5.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(8, year5);
        java.util.Calendar calendar10 = null;
        try {
            week9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.jfree.data.time.Year year9 = week7.getYear();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        int int15 = week11.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week11.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        org.jfree.data.time.Year year27 = week25.getYear();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(24, year27);
        java.util.Date date29 = year27.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        org.jfree.data.time.Year year32 = week30.getYear();
        java.lang.Class<?> wildcardClass33 = week30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        org.jfree.data.time.Year year36 = week34.getYear();
        int int38 = week34.compareTo((java.lang.Object) (short) 1);
        java.util.Date date39 = week34.getEnd();
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone46);
        java.util.Locale locale49 = null;
        try {
            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date6, timeZone46, locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int5 = week0.compareTo((java.lang.Object) 100.0d);
        java.util.Calendar calendar6 = null;
        try {
            week0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.String str16 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str21 = timePeriodFormatException11.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int5 = week0.compareTo((java.lang.Object) 100.0d);
//        boolean boolean7 = week0.equals((java.lang.Object) "hi!");
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        java.lang.Class<?> wildcardClass10 = week9.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        java.lang.Class<?> wildcardClass14 = week11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        org.jfree.data.time.Year year17 = week15.getYear();
        int int19 = week15.compareTo((java.lang.Object) (short) 1);
        java.util.Date date20 = week15.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date20, timeZone21);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        org.jfree.data.time.Year year27 = week25.getYear();
        java.lang.Class<?> wildcardClass28 = week25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        int int33 = week29.compareTo((java.lang.Object) (short) 1);
        java.util.Date date34 = week29.getEnd();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        org.jfree.data.time.Year year39 = week37.getYear();
        java.lang.Class<?> wildcardClass40 = week37.getClass();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        org.jfree.data.time.Year year43 = week41.getYear();
        int int45 = week41.compareTo((java.lang.Object) (short) 1);
        java.util.Date date46 = week41.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone47);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date46);
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date46, timeZone50);
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date46, timeZone52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date46, timeZone54);
        java.util.Locale locale56 = null;
        try {
            org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date4, timeZone54, locale56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.lang.Class<?> wildcardClass5 = week0.getClass();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        long long6 = year4.getMiddleMillisecond();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        int int16 = week12.compareTo((java.lang.Object) (short) 1);
        java.util.Date date17 = week12.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7, timeZone22);
        java.util.Calendar calendar25 = null;
        try {
            week24.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        org.jfree.data.time.Year year15 = week13.getYear();
        org.jfree.data.time.Year year16 = week13.getYear();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(0, year16);
        long long18 = year16.getMiddleMillisecond();
        java.util.Date date19 = year16.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        org.jfree.data.time.Year year22 = week20.getYear();
        java.lang.Class<?> wildcardClass23 = week20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        org.jfree.data.time.Year year26 = week24.getYear();
        int int28 = week24.compareTo((java.lang.Object) (short) 1);
        java.util.Date date29 = week24.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date29);
        java.util.Date date33 = week32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date19, timeZone34);
        java.util.Locale locale37 = null;
        try {
            org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date10, timeZone34, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week8.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date6, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.String str8 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str10 = timePeriodFormatException5.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        int int6 = week4.getWeek();
        long long7 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549180800000L + "'", long7 == 1549180800000L);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, 2);
//        long long11 = week10.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.previous();
//        boolean boolean13 = week0.equals((java.lang.Object) week10);
//        java.util.Calendar calendar14 = null;
//        try {
//            week10.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 106L + "'", long11 == 106L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (byte) 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(2019, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        java.util.Calendar calendar6 = null;
        try {
            week4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        boolean boolean11 = week0.equals((java.lang.Object) week10);
        int int12 = week10.getYearValue();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week10.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        long long4 = week1.getLastMillisecond();
//        int int6 = week1.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.Year year7 = week1.getYear();
//        long long8 = year7.getMiddleMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int5 = week0.compareTo((java.lang.Object) 100.0d);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        int int13 = week9.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass14 = week9.getClass();
//        int int15 = week9.getYearValue();
//        int int16 = week9.getWeek();
//        long long17 = week9.getSerialIndex();
//        int int18 = week0.compareTo((java.lang.Object) long17);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        boolean boolean6 = week4.equals((java.lang.Object) 5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(24, year3);
        int int5 = week4.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone28);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date21 = week16.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
//        int int28 = week27.getWeek();
//        long long29 = week27.getMiddleMillisecond();
//        java.util.Calendar calendar30 = null;
//        try {
//            week27.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        int int6 = week5.getYearValue();
        int int7 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
        boolean boolean9 = week2.equals((java.lang.Object) week5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        long long8 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 106L + "'", long3 == 106L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week0.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
//        int int7 = week0.compareTo((java.lang.Object) week6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 14 + "'", int7 == 14);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        int int5 = week4.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        java.util.Date date17 = week0.getStart();
//        int int18 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 0);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Date date13 = week12.getStart();
        int int14 = week12.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        org.jfree.data.time.Year year17 = week0.getYear();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = year17.getMiddleMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(year17);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week7.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 100);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58951684800001L) + "'", long3 == (-58951684800001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58951987200000L) + "'", long4 == (-58951987200000L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Year year12 = week10.getYear();
        int int14 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Date date15 = week10.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        java.util.Date date21 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        org.jfree.data.time.Year year25 = week23.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(6, year25);
        java.util.Date date27 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(0, year31);
        java.lang.Class<?> wildcardClass33 = week32.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        org.jfree.data.time.Year year36 = week34.getYear();
        java.lang.Class<?> wildcardClass37 = week34.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        org.jfree.data.time.Year year40 = week38.getYear();
        int int42 = week38.compareTo((java.lang.Object) (short) 1);
        java.util.Date date43 = week38.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        org.jfree.data.time.Year year50 = week48.getYear();
        java.lang.Class<?> wildcardClass51 = week48.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
        org.jfree.data.time.Year year54 = week52.getYear();
        int int56 = week52.compareTo((java.lang.Object) (short) 1);
        java.util.Date date57 = week52.getEnd();
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date57, timeZone58);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week60.previous();
        org.jfree.data.time.Year year62 = week60.getYear();
        java.lang.Class<?> wildcardClass63 = week60.getClass();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        org.jfree.data.time.Year year66 = week64.getYear();
        int int68 = week64.compareTo((java.lang.Object) (short) 1);
        java.util.Date date69 = week64.getEnd();
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date69, timeZone70);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date69);
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date69, timeZone73);
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date69, timeZone75);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date69, timeZone77);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date27, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone77);
        java.util.Locale locale81 = null;
        try {
            org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date5, timeZone77, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod80);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.String str16 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str43 = timePeriodFormatException42.toString();
        java.lang.String str44 = timePeriodFormatException42.toString();
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable[] throwableArray46 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException32.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
        timePeriodFormatException51.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        java.lang.String str59 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str59.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
        boolean boolean17 = week15.equals((java.lang.Object) 1560063600000L);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week15.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        long long6 = year4.getMiddleMillisecond();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        int int16 = week12.compareTo((java.lang.Object) (short) 1);
        java.util.Date date17 = week12.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7, timeZone22);
        long long25 = week24.getMiddleMillisecond();
        java.util.Calendar calendar26 = null;
        try {
            week24.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546459199999L + "'", long25 == 1546459199999L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        long long6 = year4.getMiddleMillisecond();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        int int16 = week12.compareTo((java.lang.Object) (short) 1);
        java.util.Date date17 = week12.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7, timeZone22);
        java.lang.Object obj25 = null;
        boolean boolean26 = week24.equals(obj25);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (byte) 10);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        long long7 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        int int12 = week8.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        int int17 = week8.compareTo((java.lang.Object) week13);
//        java.lang.String str18 = week8.toString();
//        org.jfree.data.time.Year year19 = week8.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
//        boolean boolean23 = week8.equals((java.lang.Object) week22);
//        boolean boolean24 = week0.equals((java.lang.Object) week8);
//        java.util.Date date25 = week0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) '4');
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60521443200000L) + "'", long3 == (-60521443200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year7.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date21 = week16.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
//        long long28 = week27.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str17 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 10, 2019" + "'", str3.equals("Week 10, 2019"));
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week7.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        long long5 = year3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(24, year3);
        java.util.Date date5 = year3.getEnd();
        long long6 = year3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        java.util.Date date13 = week12.getStart();
//        java.lang.String str14 = week12.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        int int5 = week0.compareTo((java.lang.Object) (-1.0f));
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        java.lang.Class<?> wildcardClass5 = year4.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year4);
        long long7 = week6.getFirstMillisecond();
        int int8 = week6.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1544947200000L + "'", long7 == 1544947200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        int int3 = week0.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        int int5 = week1.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass6 = week1.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.previous();
//        long long12 = week7.getFirstMillisecond();
//        java.util.Date date13 = week7.getEnd();
//        java.util.Date date14 = week7.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        java.lang.Class<?> wildcardClass19 = week16.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
//        org.jfree.data.time.Year year22 = week20.getYear();
//        int int24 = week20.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date25 = week20.getEnd();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date25);
//        java.util.Date date29 = week28.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
//        org.jfree.data.time.Year year35 = week33.getYear();
//        int int37 = week33.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date38 = week33.getEnd();
//        java.util.Date date39 = week33.getStart();
//        java.lang.Class<?> wildcardClass40 = date39.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (byte) -1, 0);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        int int48 = week44.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.previous();
//        org.jfree.data.time.Year year51 = week49.getYear();
//        java.lang.Class<?> wildcardClass52 = week49.getClass();
//        int int53 = week44.compareTo((java.lang.Object) week49);
//        java.util.Date date54 = week44.getEnd();
//        boolean boolean55 = week43.equals((java.lang.Object) date54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
//        org.jfree.data.time.Year year58 = week56.getYear();
//        java.lang.Class<?> wildcardClass59 = week56.getClass();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week60.previous();
//        org.jfree.data.time.Year year62 = week60.getYear();
//        int int64 = week60.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date65 = week60.getEnd();
//        java.util.TimeZone timeZone66 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date65, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = week68.previous();
//        org.jfree.data.time.Year year70 = week68.getYear();
//        java.lang.Class<?> wildcardClass71 = week68.getClass();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.previous();
//        org.jfree.data.time.Year year74 = week72.getYear();
//        int int76 = week72.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date77 = week72.getEnd();
//        java.util.TimeZone timeZone78 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date77, timeZone78);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date77);
//        java.util.TimeZone timeZone81 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date77, timeZone81);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date77);
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date77, timeZone84);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date54, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date39, timeZone84);
//        try {
//            org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date0, timeZone84);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        int int11 = week7.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date12 = week7.getEnd();
//        int int13 = week0.compareTo((java.lang.Object) date12);
//        int int14 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int9 = week5.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date10 = week5.getEnd();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        int int21 = week17.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date22 = week17.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Year year29 = week28.getYear();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        int int34 = week30.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        int int39 = week30.compareTo((java.lang.Object) week35);
//        java.lang.String str40 = week30.toString();
//        org.jfree.data.time.Year year41 = week30.getYear();
//        boolean boolean42 = week28.equals((java.lang.Object) year41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(1, year41);
//        long long44 = week43.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week43.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 24, 2019" + "'", str40.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 107008L + "'", long44 == 107008L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        long long8 = week7.getSerialIndex();
//        int int9 = week7.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str13 = timePeriodFormatException12.toString();
        java.lang.String str14 = timePeriodFormatException12.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str6 = timePeriodFormatException5.toString();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
//        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        int int24 = week0.compareTo((java.lang.Object) timePeriodFormatException16);
//        int int25 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertNotNull(throwableArray17);
//        org.junit.Assert.assertNotNull(throwableArray20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 10, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        java.lang.String str10 = week0.toString();
//        org.jfree.data.time.Year year11 = week0.getYear();
//        java.util.Date date12 = week0.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(2019, year16);
//        java.util.Date date18 = week17.getEnd();
//        int int19 = week0.compareTo((java.lang.Object) week17);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        java.util.Date date7 = week0.getStart();
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 12);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.previous();
//        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
//        java.util.Date date11 = regularTimePeriod9.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 0);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62107531200001L) + "'", long3 == (-62107531200001L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 100);
        long long3 = week2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58951684800001L) + "'", long3 == (-58951684800001L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        java.lang.Class<?> wildcardClass5 = year4.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year4);
        java.util.Date date7 = week6.getEnd();
        java.util.Date date8 = week6.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year5);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str10 = timePeriodFormatException1.toString();
        java.lang.String str11 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date21 = week16.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        java.lang.Class<?> wildcardClass33 = week30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
//        org.jfree.data.time.Year year36 = week34.getYear();
//        int int38 = week34.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date39 = week34.getEnd();
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
//        org.jfree.data.time.Year year49 = week47.getYear();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(6, year49);
//        java.util.Date date51 = week50.getEnd();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
//        org.jfree.data.time.Year year54 = week52.getYear();
//        java.lang.Class<?> wildcardClass55 = week52.getClass();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
//        org.jfree.data.time.Year year58 = week56.getYear();
//        int int60 = week56.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date61 = week56.getEnd();
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date51, timeZone68);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date21, timeZone68);
//        long long72 = week71.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 107031L + "'", long72 == 107031L);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        int int5 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week16.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        int int11 = week7.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date12 = week7.getEnd();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
//        org.jfree.data.time.Year year17 = week15.getYear();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        int int23 = week19.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date24 = week19.getEnd();
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date24, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Year year31 = week30.getYear();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        int int36 = week32.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
//        org.jfree.data.time.Year year39 = week37.getYear();
//        java.lang.Class<?> wildcardClass40 = week37.getClass();
//        int int41 = week32.compareTo((java.lang.Object) week37);
//        java.lang.String str42 = week32.toString();
//        org.jfree.data.time.Year year43 = week32.getYear();
//        boolean boolean44 = week30.equals((java.lang.Object) year43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(1, year43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(1, year43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) (byte) -1, year43);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int5 = week0.compareTo((java.lang.Object) 100.0d);
        int int6 = week0.getYearValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getWeek();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 100);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5400L + "'", long3 == 5400L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 100, 100" + "'", str4.equals("Week 100, 100"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        int int17 = week16.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        java.util.Date date5 = week4.getEnd();
        java.util.Date date6 = week4.getEnd();
        java.lang.String str7 = week4.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 6, 2019" + "'", str7.equals("Week 6, 2019"));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int5 = week0.compareTo((java.lang.Object) 100.0d);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        int int17 = week13.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date18 = week13.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(6, year28);
//        java.util.Date date30 = week29.getEnd();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        java.lang.Class<?> wildcardClass34 = week31.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        int int39 = week35.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date40 = week35.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class43);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class43);
//        java.util.Date date46 = null;
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date30, timeZone47);
//        int int50 = week0.compareTo((java.lang.Object) class21);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.String str6 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, (int) (short) -1);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.previous();
//        int int6 = week1.compareTo((java.lang.Object) 100.0d);
//        long long7 = week1.getLastMillisecond();
//        long long8 = week1.getSerialIndex();
//        org.jfree.data.time.Year year9 = week1.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(8, year9);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week10.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        long long6 = year4.getMiddleMillisecond();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        int int16 = week12.compareTo((java.lang.Object) (short) 1);
        java.util.Date date17 = week12.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7, timeZone22);
        long long25 = week24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546459199999L + "'", long25 == 1546459199999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 7);
        int int4 = week2.compareTo((java.lang.Object) '#');
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61947561600001L) + "'", long5 == (-61947561600001L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getEnd();
        int int5 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        java.lang.String str10 = week0.toString();
//        org.jfree.data.time.Year year11 = week0.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
//        boolean boolean15 = week0.equals((java.lang.Object) week14);
//        java.util.Date date16 = week14.getEnd();
//        int int17 = week14.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        org.jfree.data.time.Year year11 = week9.getYear();
        org.jfree.data.time.Year year12 = week9.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, year12);
        long long14 = year12.getMiddleMillisecond();
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        java.lang.Class<?> wildcardClass19 = week16.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        org.jfree.data.time.Year year22 = week20.getYear();
        int int24 = week20.compareTo((java.lang.Object) (short) 1);
        java.util.Date date25 = week20.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date25);
        java.util.Date date29 = week28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date15, timeZone30);
        java.util.Locale locale33 = null;
        try {
            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date6, timeZone30, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        org.jfree.data.time.Year year5 = week3.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(6, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year5);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        java.util.Date date17 = week0.getStart();
//        long long18 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        java.lang.Class<?> wildcardClass4 = week1.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        int int9 = week5.compareTo((java.lang.Object) (short) 1);
        java.util.Date date10 = week5.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        org.jfree.data.time.Year year21 = week19.getYear();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(24, year21);
        java.util.Date date23 = year21.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        org.jfree.data.time.Year year26 = week24.getYear();
        java.lang.Class<?> wildcardClass27 = week24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        org.jfree.data.time.Year year30 = week28.getYear();
        int int32 = week28.compareTo((java.lang.Object) (short) 1);
        java.util.Date date33 = week28.getEnd();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date33, timeZone34);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize(class36);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class36);
        java.util.Date date39 = null;
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone40);
        try {
            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date0, timeZone40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        int int7 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 6, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int5 = week0.compareTo((java.lang.Object) 100.0d);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 2019"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(24, year3);
        int int5 = week4.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        org.jfree.data.time.Year year30 = week28.getYear();
        java.lang.Class<?> wildcardClass31 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.Year year34 = week32.getYear();
        int int36 = week32.compareTo((java.lang.Object) (short) 1);
        java.util.Date date37 = week32.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date37);
        java.util.Date date41 = week40.getStart();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
        java.util.Locale locale44 = null;
        try {
            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date21, timeZone42, locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        org.jfree.data.time.Year year3 = week0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        java.lang.String str10 = week0.toString();
//        org.jfree.data.time.Year year11 = week0.getYear();
//        java.util.Date date12 = week0.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 8);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 423L + "'", long3 == 423L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int5 = week0.compareTo((java.lang.Object) 100.0d);
        boolean boolean7 = week0.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year8 = week0.getYear();
        java.util.Date date9 = week0.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date5 = week0.getEnd();
//        long long6 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str8 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) '4');
//        long long3 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.lang.Class<?> wildcardClass7 = week4.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        int int12 = week8.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date13 = week8.getEnd();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        java.util.Date date17 = week16.getStart();
//        boolean boolean18 = week2.equals((java.lang.Object) week16);
//        long long19 = week16.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60521443200000L) + "'", long3 == (-60521443200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        long long6 = week5.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546156799999L + "'", long6 == 1546156799999L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.String str6 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str43 = timePeriodFormatException42.toString();
        java.lang.String str44 = timePeriodFormatException42.toString();
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable[] throwableArray46 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str43.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray46);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.String str23 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        java.lang.String str32 = timePeriodFormatException30.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        long long10 = week0.getFirstMillisecond();
//        int int11 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 100);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, 2);
        long long7 = week6.getLastMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.util.Date date9 = week6.getStart();
        try {
            int int10 = week2.compareTo((java.lang.Object) week6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5400L + "'", long3 == 5400L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62104204800001L) + "'", long7 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        int int11 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.previous();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        org.jfree.data.time.Year year15 = week13.getYear();
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week13.previous();
        java.util.Date date18 = week13.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week13.previous();
        int int20 = week0.compareTo((java.lang.Object) week13);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getMiddleMillisecond();
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass15 = week10.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        java.lang.Class<?> wildcardClass19 = week16.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week16.previous();
//        long long21 = week16.getFirstMillisecond();
//        java.util.Date date22 = week16.getEnd();
//        java.util.Date date23 = week16.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
//        org.jfree.data.time.Year year27 = week25.getYear();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
//        org.jfree.data.time.Year year31 = week29.getYear();
//        int int33 = week29.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date34 = week29.getEnd();
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34);
//        java.util.Date date38 = week37.getStart();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date23, timeZone39);
//        java.util.Locale locale42 = null;
//        try {
//            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date9, timeZone39, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getLastMillisecond();
//        int int5 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.String str23 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        long long8 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(5, 1);
//        boolean boolean12 = week0.equals((java.lang.Object) 5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        java.util.Date date6 = week5.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        java.lang.Class<?> wildcardClass5 = week4.getClass();
        long long6 = week4.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 52, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.String str23 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException11.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(2019, year3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
//        long long10 = week5.getFirstMillisecond();
//        java.util.Date date11 = week5.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        int int15 = week4.compareTo((java.lang.Object) regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-54) + "'", int15 == (-54));
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.String str6 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException4.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(24, year13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 100, year13);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        java.lang.Class<?> wildcardClass19 = week16.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        org.jfree.data.time.Year year22 = week20.getYear();
        int int24 = week20.compareTo((java.lang.Object) (short) 1);
        java.util.Date date25 = week20.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        org.jfree.data.time.Year year30 = week28.getYear();
        java.lang.Class<?> wildcardClass31 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.Year year34 = week32.getYear();
        int int36 = week32.compareTo((java.lang.Object) (short) 1);
        java.util.Date date37 = week32.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date37);
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date37, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date37);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date37, timeZone44);
        boolean boolean46 = week15.equals((java.lang.Object) date37);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        org.jfree.data.time.Year year52 = week50.getYear();
        int int54 = week50.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.previous();
        org.jfree.data.time.Year year57 = week55.getYear();
        java.lang.Class<?> wildcardClass58 = week55.getClass();
        int int59 = week50.compareTo((java.lang.Object) week55);
        java.util.Date date60 = week50.getEnd();
        boolean boolean61 = week49.equals((java.lang.Object) date60);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        org.jfree.data.time.Year year64 = week62.getYear();
        java.lang.Class<?> wildcardClass65 = week62.getClass();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
        org.jfree.data.time.Year year68 = week66.getYear();
        int int70 = week66.compareTo((java.lang.Object) (short) 1);
        java.util.Date date71 = week66.getEnd();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date71, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = week74.previous();
        org.jfree.data.time.Year year76 = week74.getYear();
        java.lang.Class<?> wildcardClass77 = week74.getClass();
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.previous();
        org.jfree.data.time.Year year80 = week78.getYear();
        int int82 = week78.compareTo((java.lang.Object) (short) 1);
        java.util.Date date83 = week78.getEnd();
        java.util.TimeZone timeZone84 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date83, timeZone84);
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date83);
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date83, timeZone87);
        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date83);
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date83, timeZone90);
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date60, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date37, timeZone90);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(year57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(year64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(year76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(year80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        boolean boolean6 = week4.equals((java.lang.Object) 5);
        long long7 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549180800000L + "'", long7 == 1549180800000L);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        int int10 = week6.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        int int15 = week6.compareTo((java.lang.Object) week11);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        long long21 = week16.getLastMillisecond();
//        int int22 = week6.compareTo((java.lang.Object) week16);
//        org.jfree.data.time.Year year23 = week6.getYear();
//        java.lang.String str24 = week6.toString();
//        boolean boolean25 = week0.equals((java.lang.Object) str24);
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = week0.getLastMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 24, 2019" + "'", str24.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(6, year19);
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        org.jfree.data.time.Year year24 = week22.getYear();
        java.lang.Class<?> wildcardClass25 = week22.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        org.jfree.data.time.Year year28 = week26.getYear();
        int int30 = week26.compareTo((java.lang.Object) (short) 1);
        java.util.Date date31 = week26.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class34);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize(class34);
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date21, timeZone38);
        java.util.Date date41 = regularTimePeriod40.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(24, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 100, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.jfree.data.time.Year year9 = week7.getYear();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        int int15 = week11.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week11.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        org.jfree.data.time.Year year21 = week19.getYear();
        java.lang.Class<?> wildcardClass22 = week19.getClass();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        org.jfree.data.time.Year year25 = week23.getYear();
        int int27 = week23.compareTo((java.lang.Object) (short) 1);
        java.util.Date date28 = week23.getEnd();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date28);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date28, timeZone32);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date28);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date28, timeZone35);
        boolean boolean37 = week6.equals((java.lang.Object) date28);
        java.util.Calendar calendar38 = null;
        try {
            week6.peg(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        long long8 = week0.getMiddleMillisecond();
//        long long9 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 100);
        int int3 = week2.getWeek();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, (int) (byte) 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        long long5 = week4.getFirstMillisecond();
        long long6 = week4.getMiddleMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.jfree.data.time.Year year9 = week7.getYear();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        int int15 = week11.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week11.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
        int int22 = week4.compareTo((java.lang.Object) class21);
        long long23 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1545552000000L + "'", long5 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545854399999L + "'", long6 == 1545854399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1545552000000L + "'", long23 == 1545552000000L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 100);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        java.lang.Class<?> wildcardClass5 = week4.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Year year12 = week10.getYear();
        int int14 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Date date15 = week10.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        org.jfree.data.time.Year year22 = week20.getYear();
        java.lang.Class<?> wildcardClass23 = week20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        org.jfree.data.time.Year year26 = week24.getYear();
        int int28 = week24.compareTo((java.lang.Object) (short) 1);
        java.util.Date date29 = week24.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.Year year34 = week32.getYear();
        java.lang.Class<?> wildcardClass35 = week32.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
        org.jfree.data.time.Year year38 = week36.getYear();
        int int40 = week36.compareTo((java.lang.Object) (short) 1);
        java.util.Date date41 = week36.getEnd();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date41, timeZone42);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date41);
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date41, timeZone45);
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date41, timeZone47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date41, timeZone49);
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize(class51);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNotNull(class52);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Date date3 = week0.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.lang.Class<?> wildcardClass10 = year9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) -1, year9);
//        java.util.Date date12 = week11.getEnd();
//        boolean boolean13 = week0.equals((java.lang.Object) week11);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        boolean boolean11 = week0.equals((java.lang.Object) week10);
//        int int13 = week10.compareTo((java.lang.Object) 100.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week10.next();
//        long long15 = week10.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        java.util.Date date17 = week0.getStart();
//        org.jfree.data.time.Year year18 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(year18);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        long long8 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) '4');
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        java.lang.Class<?> wildcardClass7 = week4.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        int int12 = week8.compareTo((java.lang.Object) (short) 1);
        java.util.Date date13 = week8.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        java.util.Date date17 = week16.getStart();
        boolean boolean18 = week2.equals((java.lang.Object) week16);
        long long19 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60521443200000L) + "'", long3 == (-60521443200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-60520838400001L) + "'", long19 == (-60520838400001L));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        long long7 = year5.getMiddleMillisecond();
        java.util.Date date8 = year5.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 1, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.Year year7 = week0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        java.util.Date date11 = week0.getEnd();
        int int12 = week0.getYearValue();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        org.jfree.data.time.Year year15 = week13.getYear();
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        int int21 = week17.compareTo((java.lang.Object) (short) 1);
        java.util.Date date22 = week17.getEnd();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        org.jfree.data.time.Year year27 = week25.getYear();
        java.lang.Class<?> wildcardClass28 = week25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        int int33 = week29.compareTo((java.lang.Object) (short) 1);
        java.util.Date date34 = week29.getEnd();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date34, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date34, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        boolean boolean44 = week0.equals((java.lang.Object) regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        org.jfree.data.time.Year year30 = week28.getYear();
        org.jfree.data.time.Year year31 = week28.getYear();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(0, year31);
        long long33 = year31.getMiddleMillisecond();
        java.util.Date date34 = year31.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        org.jfree.data.time.Year year37 = week35.getYear();
        java.lang.Class<?> wildcardClass38 = week35.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        org.jfree.data.time.Year year41 = week39.getYear();
        int int43 = week39.compareTo((java.lang.Object) (short) 1);
        java.util.Date date44 = week39.getEnd();
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone45);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44);
        java.util.Date date48 = week47.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date48, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date34, timeZone49);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(class52);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 11);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61821158400000L) + "'", long3 == (-61821158400000L));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize(class24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class24);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class24);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(6, year31);
        java.util.Date date33 = week32.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        org.jfree.data.time.Year year36 = week34.getYear();
        java.lang.Class<?> wildcardClass37 = week34.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        org.jfree.data.time.Year year40 = week38.getYear();
        int int42 = week38.compareTo((java.lang.Object) (short) 1);
        java.util.Date date43 = week38.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize(class46);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize(class46);
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date33, timeZone50);
        java.util.Locale locale53 = null;
        try {
            org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date9, timeZone50, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        long long10 = week5.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
        java.lang.Class<?> wildcardClass16 = date13.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        boolean boolean11 = week0.equals((java.lang.Object) week10);
        int int12 = week10.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.next();
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        int int11 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.previous();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 52, 1");
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        org.jfree.data.time.Year year29 = week27.getYear();
        java.lang.Class<?> wildcardClass30 = week27.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        org.jfree.data.time.Year year33 = week31.getYear();
        int int35 = week31.compareTo((java.lang.Object) (short) 1);
        java.util.Date date36 = week31.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        org.jfree.data.time.Year year41 = week39.getYear();
        java.lang.Class<?> wildcardClass42 = week39.getClass();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.previous();
        org.jfree.data.time.Year year45 = week43.getYear();
        int int47 = week43.compareTo((java.lang.Object) (short) 1);
        java.util.Date date48 = week43.getEnd();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date48);
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date48, timeZone52);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date48);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date48, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.previous();
        org.jfree.data.time.Year year59 = week57.getYear();
        java.lang.Class<?> wildcardClass60 = week57.getClass();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.previous();
        org.jfree.data.time.Year year63 = week61.getYear();
        int int65 = week61.compareTo((java.lang.Object) (short) 1);
        java.util.Date date66 = week61.getEnd();
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date66, timeZone67);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.previous();
        org.jfree.data.time.Year year71 = week69.getYear();
        java.lang.Class<?> wildcardClass72 = week69.getClass();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week73.previous();
        org.jfree.data.time.Year year75 = week73.getYear();
        int int77 = week73.compareTo((java.lang.Object) (short) 1);
        java.util.Date date78 = week73.getEnd();
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date78, timeZone79);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date78);
        java.util.TimeZone timeZone82 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date78, timeZone82);
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date78);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date78, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date48, timeZone85);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(year45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(year59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(year63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(year71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(year75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        long long6 = year4.getMiddleMillisecond();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        int int16 = week12.compareTo((java.lang.Object) (short) 1);
        java.util.Date date17 = week12.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        java.util.Date date21 = week20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7, timeZone22);
        long long25 = week24.getMiddleMillisecond();
        long long26 = week24.getMiddleMillisecond();
        org.jfree.data.time.Year year27 = week24.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546459199999L + "'", long25 == 1546459199999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546459199999L + "'", long26 == 1546459199999L);
        org.junit.Assert.assertNotNull(year27);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        java.lang.String str8 = week6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549785599999L + "'", long7 == 1549785599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 6, 2019" + "'", str8.equals("Week 6, 2019"));
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        int int15 = week11.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date16 = week11.getEnd();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        java.util.Locale locale25 = null;
//        try {
//            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date6, timeZone23, locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(5, year4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.String str16 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable throwable21 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        java.util.Date date13 = week12.getStart();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        java.lang.Class<?> wildcardClass17 = week16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        org.jfree.data.time.Year year20 = week18.getYear();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week18.previous();
//        java.util.Date date23 = week18.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        int int30 = week26.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass31 = week26.getClass();
//        long long32 = week26.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass33 = week26.getClass();
//        long long34 = week26.getMiddleMillisecond();
//        java.util.Date date35 = week26.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
//        org.jfree.data.time.Year year38 = week36.getYear();
//        java.lang.Class<?> wildcardClass39 = week36.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        int int44 = week40.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date45 = week40.getEnd();
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
//        org.jfree.data.time.Year year50 = week48.getYear();
//        java.lang.Class<?> wildcardClass51 = week48.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
//        org.jfree.data.time.Year year54 = week52.getYear();
//        int int56 = week52.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date57 = week52.getEnd();
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date57, timeZone58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date57);
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date57, timeZone61);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
//        org.jfree.data.time.Year year66 = week64.getYear();
//        org.jfree.data.time.Year year67 = week64.getYear();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(0, year67);
//        long long69 = year67.getMiddleMillisecond();
//        java.util.Date date70 = year67.getStart();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.previous();
//        org.jfree.data.time.Year year73 = week71.getYear();
//        java.lang.Class<?> wildcardClass74 = week71.getClass();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week75.previous();
//        org.jfree.data.time.Year year77 = week75.getYear();
//        int int79 = week75.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date80 = week75.getEnd();
//        java.util.TimeZone timeZone81 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date80, timeZone81);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date80);
//        java.util.Date date84 = week83.getStart();
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date84, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date70, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date35, timeZone85);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560365999999L + "'", long34 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1562097599999L + "'", long69 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(year77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        long long8 = week0.getMiddleMillisecond();
//        long long9 = week0.getFirstMillisecond();
//        long long10 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (int) (byte) -1);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167406400001L) + "'", long3 == (-62167406400001L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        java.util.Date date10 = week8.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int5 = week0.compareTo((java.lang.Object) 100.0d);
        boolean boolean7 = week0.equals((java.lang.Object) "hi!");
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560970799999L + "'", long5 == 1560970799999L);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str15 = timePeriodFormatException14.toString();
        java.lang.String str16 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException4.getSuppressed();
        boolean boolean23 = week2.equals((java.lang.Object) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        org.jfree.data.time.Year year16 = week14.getYear();
        int int18 = week14.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        org.jfree.data.time.Year year21 = week19.getYear();
        java.lang.Class<?> wildcardClass22 = week19.getClass();
        int int23 = week14.compareTo((java.lang.Object) week19);
        java.util.Date date24 = week14.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        org.jfree.data.time.Year year29 = week27.getYear();
        java.lang.Class<?> wildcardClass30 = week27.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        org.jfree.data.time.Year year33 = week31.getYear();
        int int35 = week31.compareTo((java.lang.Object) (short) 1);
        java.util.Date date36 = week31.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone43);
        java.util.Locale locale45 = null;
        try {
            org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date24, timeZone43, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str12 = timePeriodFormatException11.toString();
//        java.lang.String str13 = timePeriodFormatException11.toString();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        boolean boolean15 = week0.equals((java.lang.Object) timePeriodFormatException11);
//        java.lang.String str16 = timePeriodFormatException11.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        java.util.Date date17 = week0.getStart();
//        java.util.Date date18 = week0.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) 1, year3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getWeek();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week0.equals(obj6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        long long5 = week4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        long long7 = week4.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1549180800000L + "'", long5 == 1549180800000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107013L + "'", long7 == 107013L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        int int9 = week0.compareTo((java.lang.Object) week5);
        java.util.Date date10 = week0.getEnd();
        java.util.Date date11 = week0.getEnd();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week0.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        long long5 = week4.getFirstMillisecond();
        long long6 = week4.getMiddleMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.jfree.data.time.Year year9 = week7.getYear();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        int int15 = week11.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week11.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
        int int22 = week4.compareTo((java.lang.Object) class21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week4.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1545552000000L + "'", long5 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545854399999L + "'", long6 == 1545854399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        java.lang.String str10 = week8.toString();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(2019, year15);
//        java.util.Date date17 = week16.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        org.jfree.data.time.Year year20 = week18.getYear();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
//        org.jfree.data.time.Year year24 = week22.getYear();
//        int int26 = week22.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date27 = week22.getEnd();
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date27, timeZone28);
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(6, year37);
//        java.util.Date date39 = week38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        int int48 = week44.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date49 = week44.getEnd();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone50);
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize(class52);
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize(class52);
//        java.util.Date date55 = null;
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date39, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone56);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date6, timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        int int10 = week6.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date11 = week6.getEnd();
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        org.jfree.data.time.Year year20 = week18.getYear();
//        int int22 = week18.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date23 = week18.getEnd();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date23);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date23, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date23);
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        int int35 = week31.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
//        org.jfree.data.time.Year year38 = week36.getYear();
//        java.lang.Class<?> wildcardClass39 = week36.getClass();
//        int int40 = week31.compareTo((java.lang.Object) week36);
//        java.lang.String str41 = week31.toString();
//        org.jfree.data.time.Year year42 = week31.getYear();
//        boolean boolean43 = week29.equals((java.lang.Object) year42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(1, year42);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(1, year42);
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = week45.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 24, 2019" + "'", str41.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, 2);
//        long long11 = week10.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.previous();
//        boolean boolean13 = week0.equals((java.lang.Object) week10);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
//        boolean boolean17 = week10.equals((java.lang.Object) week16);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 106L + "'", long11 == 106L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.util.Date date13 = week12.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
        java.lang.Class<?> wildcardClass17 = week16.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        org.jfree.data.time.Year year20 = week18.getYear();
        int int22 = week18.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        org.jfree.data.time.Year year25 = week23.getYear();
        java.lang.Class<?> wildcardClass26 = week23.getClass();
        int int27 = week18.compareTo((java.lang.Object) week23);
        java.util.Date date28 = week18.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date28, timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int5 = week0.compareTo((java.lang.Object) 100.0d);
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 0);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int9 = week5.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date10 = week5.getEnd();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        int int21 = week17.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date22 = week17.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Year year29 = week28.getYear();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        int int34 = week30.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        int int39 = week30.compareTo((java.lang.Object) week35);
//        java.lang.String str40 = week30.toString();
//        org.jfree.data.time.Year year41 = week30.getYear();
//        boolean boolean42 = week28.equals((java.lang.Object) year41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(1, year41);
//        java.util.Calendar calendar44 = null;
//        try {
//            long long45 = week43.getFirstMillisecond(calendar44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 24, 2019" + "'", str40.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Year year4 = week2.getYear();
        org.jfree.data.time.Year year5 = week2.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        org.jfree.data.time.Year year32 = week30.getYear();
        java.lang.Class<?> wildcardClass33 = week30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        org.jfree.data.time.Year year36 = week34.getYear();
        int int38 = week34.compareTo((java.lang.Object) (short) 1);
        java.util.Date date39 = week34.getEnd();
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        org.jfree.data.time.Year year49 = week47.getYear();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(6, year49);
        java.util.Date date51 = week50.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
        org.jfree.data.time.Year year54 = week52.getYear();
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
        org.jfree.data.time.Year year58 = week56.getYear();
        int int60 = week56.compareTo((java.lang.Object) (short) 1);
        java.util.Date date61 = week56.getEnd();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date51, timeZone68);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date21, timeZone68);
        int int73 = week71.compareTo((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (short) 1);
        java.lang.String str3 = week2.toString();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 52, 1" + "'", str3.equals("Week 52, 1"));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        int int5 = week1.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        int int10 = week1.compareTo((java.lang.Object) week6);
//        java.lang.String str11 = week1.toString();
//        org.jfree.data.time.Year year12 = week1.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(14, year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year12);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        long long7 = week6.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        long long11 = week8.getLastMillisecond();
//        int int13 = week8.compareTo((java.lang.Object) (-1.0f));
//        java.lang.String str14 = week8.toString();
//        int int15 = week6.compareTo((java.lang.Object) str14);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549785599999L + "'", long7 == 1549785599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        java.util.Date date5 = week0.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Year year12 = week10.getYear();
        int int14 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Date date15 = week10.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        org.jfree.data.time.Year year20 = week18.getYear();
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        org.jfree.data.time.Year year24 = week22.getYear();
        int int26 = week22.compareTo((java.lang.Object) (short) 1);
        java.util.Date date27 = week22.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date27, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date27);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date27, timeZone31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date27);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date27, timeZone34);
        java.util.Locale locale36 = null;
        try {
            org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date5, timeZone34, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
        java.lang.Class<?> wildcardClass5 = week4.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Year year12 = week10.getYear();
        int int14 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Date date15 = week10.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        org.jfree.data.time.Year year22 = week20.getYear();
        java.lang.Class<?> wildcardClass23 = week20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        org.jfree.data.time.Year year26 = week24.getYear();
        int int28 = week24.compareTo((java.lang.Object) (short) 1);
        java.util.Date date29 = week24.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.Year year34 = week32.getYear();
        java.lang.Class<?> wildcardClass35 = week32.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
        org.jfree.data.time.Year year38 = week36.getYear();
        int int40 = week36.compareTo((java.lang.Object) (short) 1);
        java.util.Date date41 = week36.getEnd();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date41, timeZone42);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date41);
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date41, timeZone45);
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date41, timeZone47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date41, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date41);
        java.util.TimeZone timeZone52 = null;
        java.util.Locale locale53 = null;
        try {
            org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date41, timeZone52, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(6, year10);
//        java.util.Date date12 = week11.getEnd();
//        java.util.Date date13 = week11.getEnd();
//        int int14 = week0.compareTo((java.lang.Object) date13);
//        int int15 = week0.getYearValue();
//        long long16 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int5 = week0.compareTo((java.lang.Object) 100.0d);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.jfree.data.time.Year year9 = week7.getYear();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        int int15 = week11.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week11.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        org.jfree.data.time.Year year21 = week19.getYear();
        java.lang.Class<?> wildcardClass22 = week19.getClass();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        org.jfree.data.time.Year year25 = week23.getYear();
        int int27 = week23.compareTo((java.lang.Object) (short) 1);
        java.util.Date date28 = week23.getEnd();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date28);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date28, timeZone32);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        org.jfree.data.time.Year year36 = week34.getYear();
        java.lang.Class<?> wildcardClass37 = week34.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        org.jfree.data.time.Year year40 = week38.getYear();
        int int42 = week38.compareTo((java.lang.Object) (short) 1);
        java.util.Date date43 = week38.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
        org.jfree.data.time.Year year48 = week46.getYear();
        java.lang.Class<?> wildcardClass49 = week46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        org.jfree.data.time.Year year52 = week50.getYear();
        int int54 = week50.compareTo((java.lang.Object) (short) 1);
        java.util.Date date55 = week50.getEnd();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone56);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date55);
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date55, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date55);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date55, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        org.jfree.data.time.Year year66 = week64.getYear();
        java.lang.Class<?> wildcardClass67 = week64.getClass();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = week68.previous();
        org.jfree.data.time.Year year70 = week68.getYear();
        int int72 = week68.compareTo((java.lang.Object) (short) 1);
        java.util.Date date73 = week68.getEnd();
        java.util.TimeZone timeZone74 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date73, timeZone74);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = week76.previous();
        org.jfree.data.time.Year year78 = week76.getYear();
        java.lang.Class<?> wildcardClass79 = week76.getClass();
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = week80.previous();
        org.jfree.data.time.Year year82 = week80.getYear();
        int int84 = week80.compareTo((java.lang.Object) (short) 1);
        java.util.Date date85 = week80.getEnd();
        java.util.TimeZone timeZone86 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass79, date85, timeZone86);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date85);
        java.util.TimeZone timeZone89 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date85, timeZone89);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date85);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date85, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date55, timeZone92);
        java.util.Locale locale95 = null;
        try {
            org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date6, timeZone92, locale95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(year70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(year78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(year82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        int int11 = week7.compareTo((java.lang.Object) (short) 1);
//        long long12 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week7.previous();
//        boolean boolean14 = week0.equals((java.lang.Object) week7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        long long7 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        int int12 = week8.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        int int17 = week8.compareTo((java.lang.Object) week13);
//        java.lang.String str18 = week8.toString();
//        org.jfree.data.time.Year year19 = week8.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
//        boolean boolean23 = week8.equals((java.lang.Object) week22);
//        boolean boolean24 = week0.equals((java.lang.Object) week8);
//        long long25 = week8.getSerialIndex();
//        org.jfree.data.time.Year year26 = week8.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(year26);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getLastMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 2019");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), (int) (short) -1);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date21 = week16.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        java.lang.Class<?> wildcardClass33 = week30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
//        org.jfree.data.time.Year year36 = week34.getYear();
//        int int38 = week34.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date39 = week34.getEnd();
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
//        org.jfree.data.time.Year year49 = week47.getYear();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(6, year49);
//        java.util.Date date51 = week50.getEnd();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
//        org.jfree.data.time.Year year54 = week52.getYear();
//        java.lang.Class<?> wildcardClass55 = week52.getClass();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
//        org.jfree.data.time.Year year58 = week56.getYear();
//        int int60 = week56.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date61 = week56.getEnd();
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date51, timeZone68);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date21, timeZone68);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date21);
//        long long73 = week72.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 107031L + "'", long73 == 107031L);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, 4);
        java.lang.Object obj3 = null;
        boolean boolean4 = week2.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        java.lang.Object obj7 = null;
//        int int8 = week0.compareTo(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        java.util.Date date17 = week0.getEnd();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week0.getFirstMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(6, year19);
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        org.jfree.data.time.Year year24 = week22.getYear();
        java.lang.Class<?> wildcardClass25 = week22.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        org.jfree.data.time.Year year28 = week26.getYear();
        int int30 = week26.compareTo((java.lang.Object) (short) 1);
        java.util.Date date31 = week26.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class34);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize(class34);
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date21, timeZone38);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = regularTimePeriod40.getMiddleMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.String str8 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str32 = timePeriodFormatException31.toString();
        java.lang.String str33 = timePeriodFormatException31.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str53 = timePeriodFormatException52.toString();
        java.lang.String str54 = timePeriodFormatException52.toString();
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        java.lang.Throwable[] throwableArray56 = timePeriodFormatException49.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException49);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str53.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str54.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray56);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        long long8 = week0.getSerialIndex();
//        long long9 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.Year year6 = week4.getYear();
        int int8 = week4.compareTo((java.lang.Object) (short) 1);
        java.util.Date date9 = week4.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date21, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        org.jfree.data.time.Year year32 = week30.getYear();
        java.lang.Class<?> wildcardClass33 = week30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        org.jfree.data.time.Year year36 = week34.getYear();
        int int38 = week34.compareTo((java.lang.Object) (short) 1);
        java.util.Date date39 = week34.getEnd();
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        org.jfree.data.time.Year year49 = week47.getYear();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(6, year49);
        java.util.Date date51 = week50.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
        org.jfree.data.time.Year year54 = week52.getYear();
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
        org.jfree.data.time.Year year58 = week56.getYear();
        int int60 = week56.compareTo((java.lang.Object) (short) 1);
        java.util.Date date61 = week56.getEnd();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date51, timeZone68);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date21, timeZone68);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date21);
        java.util.Calendar calendar73 = null;
        try {
            long long74 = week72.getMiddleMillisecond(calendar73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        long long8 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        int int17 = week13.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date18 = week13.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
//        java.util.Date date24 = null;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(6, year28);
//        java.util.Date date30 = week29.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(0, year34);
//        java.lang.Class<?> wildcardClass36 = week35.getClass();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
//        org.jfree.data.time.Year year39 = week37.getYear();
//        java.lang.Class<?> wildcardClass40 = week37.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
//        org.jfree.data.time.Year year43 = week41.getYear();
//        int int45 = week41.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date46 = week41.getEnd();
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone47);
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
//        org.jfree.data.time.Year year53 = week51.getYear();
//        java.lang.Class<?> wildcardClass54 = week51.getClass();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.previous();
//        org.jfree.data.time.Year year57 = week55.getYear();
//        int int59 = week55.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date60 = week55.getEnd();
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date60, timeZone61);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.previous();
//        org.jfree.data.time.Year year65 = week63.getYear();
//        java.lang.Class<?> wildcardClass66 = week63.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
//        org.jfree.data.time.Year year69 = week67.getYear();
//        int int71 = week67.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date72 = week67.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date72);
//        java.util.TimeZone timeZone76 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date72, timeZone76);
//        java.util.TimeZone timeZone78 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date72, timeZone78);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date72, timeZone80);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date30, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone80);
//        int int84 = week0.compareTo((java.lang.Object) class22);
//        int int85 = week0.getWeek();
//        org.jfree.data.time.Year year86 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 24 + "'", int85 == 24);
//        org.junit.Assert.assertNotNull(year86);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str32 = timePeriodFormatException31.toString();
        java.lang.String str33 = timePeriodFormatException31.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
        java.lang.String str51 = timePeriodFormatException49.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str54 = timePeriodFormatException53.toString();
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException53.getSuppressed();
        java.lang.String str56 = timePeriodFormatException53.toString();
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException53);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray60 = timePeriodFormatException59.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException62 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray63 = timePeriodFormatException62.getSuppressed();
        timePeriodFormatException59.addSuppressed((java.lang.Throwable) timePeriodFormatException62);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException59.addSuppressed((java.lang.Throwable) timePeriodFormatException66);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException69 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray70 = timePeriodFormatException69.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException72 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray73 = timePeriodFormatException72.getSuppressed();
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException72);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException76 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray77 = timePeriodFormatException76.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException79 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str80 = timePeriodFormatException79.toString();
        java.lang.String str81 = timePeriodFormatException79.toString();
        timePeriodFormatException76.addSuppressed((java.lang.Throwable) timePeriodFormatException79);
        java.lang.Throwable[] throwableArray83 = timePeriodFormatException76.getSuppressed();
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        java.lang.Throwable[] throwableArray85 = timePeriodFormatException69.getSuppressed();
        timePeriodFormatException59.addSuppressed((java.lang.Throwable) timePeriodFormatException69);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException88 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray89 = timePeriodFormatException88.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException91 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray92 = timePeriodFormatException91.getSuppressed();
        timePeriodFormatException88.addSuppressed((java.lang.Throwable) timePeriodFormatException91);
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException88);
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException69);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException69);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str51.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str54.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str56.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str80.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str81.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertNotNull(throwableArray85);
        org.junit.Assert.assertNotNull(throwableArray89);
        org.junit.Assert.assertNotNull(throwableArray92);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(24, year3);
        long long5 = year3.getMiddleMillisecond();
        long long6 = year3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int9 = week5.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week5.previous();
//        int int11 = week0.compareTo((java.lang.Object) regularTimePeriod10);
//        java.util.Date date12 = week0.getStart();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        long long7 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        int int12 = week8.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        int int17 = week8.compareTo((java.lang.Object) week13);
//        java.lang.String str18 = week8.toString();
//        org.jfree.data.time.Year year19 = week8.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 2019);
//        boolean boolean23 = week8.equals((java.lang.Object) week22);
//        boolean boolean24 = week0.equals((java.lang.Object) week8);
//        long long25 = week8.getSerialIndex();
//        java.lang.Class<?> wildcardClass26 = week8.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        int int20 = week16.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date21 = week16.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date21, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date21);
//        int int28 = week27.getWeek();
//        long long29 = week27.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        int int14 = week10.compareTo((java.lang.Object) (short) 1);
//        long long15 = week10.getLastMillisecond();
//        int int16 = week0.compareTo((java.lang.Object) week10);
//        org.jfree.data.time.Year year17 = week0.getYear();
//        java.lang.String str18 = week0.toString();
//        java.util.Calendar calendar19 = null;
//        try {
//            week0.peg(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        int int2 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (short) 1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        org.jfree.data.time.Year year5 = week3.getYear();
        int int7 = week3.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.jfree.data.time.Year year10 = week8.getYear();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        int int12 = week3.compareTo((java.lang.Object) week8);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        boolean boolean14 = week3.equals((java.lang.Object) week13);
        int int15 = week13.getYearValue();
        int int16 = week2.compareTo((java.lang.Object) week13);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-2018) + "'", int16 == (-2018));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        java.util.Date date5 = week0.getEnd();
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        org.jfree.data.time.Year year13 = week11.getYear();
        java.lang.Class<?> wildcardClass14 = week11.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.previous();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        java.lang.Class<?> wildcardClass20 = week17.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        org.jfree.data.time.Year year23 = week21.getYear();
        int int25 = week21.compareTo((java.lang.Object) (short) 1);
        java.util.Date date26 = week21.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
        java.util.Date date32 = null;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        org.jfree.data.time.Year year35 = week33.getYear();
        java.lang.Class<?> wildcardClass36 = week33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        org.jfree.data.time.Year year39 = week37.getYear();
        int int41 = week37.compareTo((java.lang.Object) (short) 1);
        java.util.Date date42 = week37.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date42);
        java.util.Date date46 = week45.getStart();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone47);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date6, timeZone47);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod50);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) (short) 100);
        long long3 = week2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59011862400001L) + "'", long3 == (-59011862400001L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (int) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.jfree.data.time.Year year7 = week5.getYear();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        org.jfree.data.time.Year year11 = week9.getYear();
        int int13 = week9.compareTo((java.lang.Object) (short) 1);
        java.util.Date date14 = week9.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        org.jfree.data.time.Year year19 = week17.getYear();
        java.lang.Class<?> wildcardClass20 = week17.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        org.jfree.data.time.Year year23 = week21.getYear();
        int int25 = week21.compareTo((java.lang.Object) (short) 1);
        java.util.Date date26 = week21.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date26);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date26, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date26);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date26, timeZone33);
        java.util.Locale locale35 = null;
        try {
            org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date4, timeZone33, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone33);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        int int5 = week1.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass6 = week1.getClass();
//        long long7 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year8 = week1.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((-2018), year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 1);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str12 = timePeriodFormatException11.toString();
//        java.lang.String str13 = timePeriodFormatException11.toString();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        boolean boolean15 = week0.equals((java.lang.Object) timePeriodFormatException11);
//        long long16 = week0.getSerialIndex();
//        org.jfree.data.time.Year year17 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(year17);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        int int4 = week0.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
        java.lang.Object obj6 = null;
        int int7 = week0.compareTo(obj6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int9 = week5.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date10 = week5.getEnd();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        org.jfree.data.time.Year year19 = week17.getYear();
//        int int21 = week17.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date22 = week17.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Year year29 = week28.getYear();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        int int34 = week30.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        int int39 = week30.compareTo((java.lang.Object) week35);
//        java.lang.String str40 = week30.toString();
//        org.jfree.data.time.Year year41 = week30.getYear();
//        boolean boolean42 = week28.equals((java.lang.Object) year41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(1, year41);
//        long long44 = week43.getSerialIndex();
//        long long45 = week43.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 24, 2019" + "'", str40.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 107008L + "'", long44 == 107008L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 107008L + "'", long45 == 107008L);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.previous();
//        int int13 = week8.getYearValue();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        long long18 = week14.getFirstMillisecond();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        org.jfree.data.time.Year year21 = week19.getYear();
//        int int23 = week19.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week19.previous();
//        int int25 = week14.compareTo((java.lang.Object) regularTimePeriod24);
//        java.util.Date date26 = week14.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (byte) -1, 0);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        int int34 = week30.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        int int39 = week30.compareTo((java.lang.Object) week35);
//        java.util.Date date40 = week30.getEnd();
//        boolean boolean41 = week29.equals((java.lang.Object) date40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.lang.Class<?> wildcardClass45 = week42.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
//        org.jfree.data.time.Year year48 = week46.getYear();
//        int int50 = week46.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date51 = week46.getEnd();
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date51, timeZone52);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
//        org.jfree.data.time.Year year56 = week54.getYear();
//        java.lang.Class<?> wildcardClass57 = week54.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.previous();
//        org.jfree.data.time.Year year60 = week58.getYear();
//        int int62 = week58.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date63 = week58.getEnd();
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date63, timeZone64);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date63);
//        java.util.TimeZone timeZone67 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date63, timeZone67);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date63);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date63, timeZone70);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date40, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date26, timeZone70);
//        boolean boolean74 = week8.equals((java.lang.Object) timeZone70);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date6, timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week7.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(6, year5);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(0, year11);
//        java.lang.Class<?> wildcardClass13 = week12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
//        org.jfree.data.time.Year year16 = week14.getYear();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        org.jfree.data.time.Year year20 = week18.getYear();
//        int int22 = week18.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date23 = week18.getEnd();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
//        org.jfree.data.time.Year year30 = week28.getYear();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
//        org.jfree.data.time.Year year34 = week32.getYear();
//        int int36 = week32.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date37 = week32.getEnd();
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
//        org.jfree.data.time.Year year42 = week40.getYear();
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        int int48 = week44.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date49 = week44.getEnd();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date49);
//        java.util.TimeZone timeZone53 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date49, timeZone53);
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date49, timeZone55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date49, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date7, timeZone57);
//        long long60 = week59.getSerialIndex();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.previous();
//        org.jfree.data.time.Year year63 = week61.getYear();
//        int int65 = week61.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
//        org.jfree.data.time.Year year68 = week66.getYear();
//        java.lang.Class<?> wildcardClass69 = week66.getClass();
//        int int70 = week61.compareTo((java.lang.Object) week66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        boolean boolean72 = week61.equals((java.lang.Object) week71);
//        boolean boolean73 = week59.equals((java.lang.Object) boolean72);
//        long long74 = week59.getFirstMillisecond();
//        int int75 = week0.compareTo((java.lang.Object) week59);
//        java.util.Calendar calendar76 = null;
//        try {
//            week0.peg(calendar76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 107013L + "'", long60 == 107013L);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1549180800000L + "'", long74 == 1549180800000L);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 18 + "'", int75 == 18);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.String str23 = timePeriodFormatException21.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException33.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.String str37 = timePeriodFormatException11.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(24, year3);
        int int5 = week4.getWeek();
        long long6 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        boolean boolean8 = week0.equals((java.lang.Object) 1545552000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException8.getSuppressed();
        java.lang.String str18 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        long long8 = week0.getSerialIndex();
//        long long9 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        java.lang.String str24 = timePeriodFormatException22.toString();
        java.lang.String str25 = timePeriodFormatException22.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.jfree.data.time.Year year9 = week7.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year9);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        org.jfree.data.time.Year year28 = week26.getYear();
        java.lang.Class<?> wildcardClass29 = week26.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        org.jfree.data.time.Year year32 = week30.getYear();
        int int34 = week30.compareTo((java.lang.Object) (short) 1);
        java.util.Date date35 = week30.getEnd();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        org.jfree.data.time.Year year40 = week38.getYear();
        java.lang.Class<?> wildcardClass41 = week38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        org.jfree.data.time.Year year44 = week42.getYear();
        int int46 = week42.compareTo((java.lang.Object) (short) 1);
        java.util.Date date47 = week42.getEnd();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47);
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date47, timeZone51);
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date47, timeZone53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date47, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date5, timeZone55);
        long long58 = week57.getSerialIndex();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        org.jfree.data.time.Year year61 = week59.getYear();
        int int63 = week59.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        org.jfree.data.time.Year year66 = week64.getYear();
        java.lang.Class<?> wildcardClass67 = week64.getClass();
        int int68 = week59.compareTo((java.lang.Object) week64);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
        boolean boolean70 = week59.equals((java.lang.Object) week69);
        boolean boolean71 = week57.equals((java.lang.Object) boolean70);
        java.lang.String str72 = week57.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 107013L + "'", long58 == 107013L);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Week 6, 2019" + "'", str72.equals("Week 6, 2019"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        int int9 = week0.compareTo((java.lang.Object) week5);
//        long long10 = week0.getFirstMillisecond();
//        long long11 = week0.getSerialIndex();
//        long long12 = week0.getSerialIndex();
//        long long13 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        int int8 = week4.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date9 = week4.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int17 = week16.getYearValue();
//        int int18 = week16.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week16.previous();
//        int int21 = week16.compareTo((java.lang.Object) 100.0d);
//        long long22 = week16.getLastMillisecond();
//        long long23 = week16.getSerialIndex();
//        org.jfree.data.time.Year year24 = week16.getYear();
//        java.util.Date date25 = year24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
//        org.jfree.data.time.Year year28 = week26.getYear();
//        java.lang.Class<?> wildcardClass29 = week26.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        int int34 = week30.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date35 = week30.getEnd();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
//        java.util.Date date41 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
//        org.jfree.data.time.Year year44 = week42.getYear();
//        java.lang.Class<?> wildcardClass45 = week42.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
//        org.jfree.data.time.Year year48 = week46.getYear();
//        int int50 = week46.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date51 = week46.getEnd();
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date51, timeZone52);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date51);
//        java.util.Date date55 = week54.getStart();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date55, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date25, timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560668399999L + "'", long22 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        boolean boolean6 = week4.equals((java.lang.Object) 5);
        long long7 = week4.getLastMillisecond();
        long long8 = week4.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549785599999L + "'", long7 == 1549785599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1549785599999L + "'", long8 == 1549785599999L);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int4 = week0.compareTo((java.lang.Object) (short) 1);
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        long long7 = week0.getLastMillisecond();
//        java.util.Date date8 = week0.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(6, year3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549785599999L + "'", long7 == 1549785599999L);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str6 = timePeriodFormatException5.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.String str8 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str32 = timePeriodFormatException31.toString();
        java.lang.String str33 = timePeriodFormatException31.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException43.getSuppressed();
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException21.getSuppressed();
        java.lang.String str49 = timePeriodFormatException21.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str49.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 7);
        int int4 = week2.compareTo((java.lang.Object) '#');
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 12);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = week0.getStart();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
        org.jfree.data.time.Year year3 = week1.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(2019, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        long long6 = week4.getLastMillisecond();
        java.lang.String str7 = week4.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1528613999999L + "'", long6 == 1528613999999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -29, 2019" + "'", str7.equals("Week -29, 2019"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
        java.util.Date date11 = week6.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.jfree.data.time.Year year14 = week12.getYear();
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.jfree.data.time.Year year18 = week16.getYear();
        int int20 = week16.compareTo((java.lang.Object) (short) 1);
        java.util.Date date21 = week16.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21);
        java.util.Date date25 = week24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date11, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        org.jfree.data.time.Year year31 = week29.getYear();
        java.lang.Class<?> wildcardClass32 = week29.getClass();
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
        java.util.Date date35 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray38 = timePeriodFormatException37.getSuppressed();
        java.lang.Class<?> wildcardClass39 = timePeriodFormatException37.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        org.jfree.data.time.Year year42 = week40.getYear();
        java.lang.Class<?> wildcardClass43 = week40.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week40.previous();
        java.util.Date date45 = regularTimePeriod44.getEnd();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
        org.jfree.data.time.Year year48 = week46.getYear();
        java.lang.Class<?> wildcardClass49 = week46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        org.jfree.data.time.Year year52 = week50.getYear();
        int int54 = week50.compareTo((java.lang.Object) (short) 1);
        java.util.Date date55 = week50.getEnd();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone56);
        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize(class59);
        java.util.Date date61 = null;
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        org.jfree.data.time.Year year64 = week62.getYear();
        java.lang.Class<?> wildcardClass65 = week62.getClass();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
        org.jfree.data.time.Year year68 = week66.getYear();
        int int70 = week66.compareTo((java.lang.Object) (short) 1);
        java.util.Date date71 = week66.getEnd();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date71, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date71);
        java.util.Date date75 = week74.getStart();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date61, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date45, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date35, timeZone76);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date11, timeZone76);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(year64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(year68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod80);
    }
}

