import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) (-1L), 100.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB(0, 0, (int) (short) 100, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            boolean boolean9 = categoryPlot0.removeRangeMarker((int) (short) 1, marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(layer8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            boolean boolean7 = categoryPlot0.removeAnnotation(categoryAnnotation5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot8.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        categoryPlot8.setRangeAxes(valueAxisArray11);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean15 = categoryPlot8.removeDomainMarker(marker13, layer14);
        try {
            categoryPlot0.addDomainMarker(categoryMarker7, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean11 = categoryPlot4.removeDomainMarker(marker9, layer10);
        try {
            categoryPlot0.addRangeMarker((int) (byte) 0, marker3, layer10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 6, (float) 100, (float) (byte) -1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 10, (double) ' ', (double) 8, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        try {
            categoryPlot0.setBackgroundImageAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.trimWidth((double) (short) -1);
        categoryPlot0.setAxisOffset(rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets9.createInsetRectangle(rectangle2D13, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str1.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        try {
            categoryPlot5.setBackgroundImageAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        try {
            categoryPlot0.setRenderer((int) (byte) -1, categoryItemRenderer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        java.lang.Class class6 = null;
        try {
            java.util.EventListener[] eventListenerArray7 = intervalMarker2.getListeners(class6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Object obj2 = null;
        boolean boolean3 = day0.equals(obj2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        java.util.Collection collection14 = categoryPlot0.getRangeMarkers((int) (byte) 10, layer12);
        java.lang.Object obj15 = categoryPlot0.clone();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            categoryPlot0.handleClick(13, 0, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setAnchorValue((double) (byte) 100, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis((int) (byte) 0);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            categoryPlot0.drawBackground(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot5.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot4.setDomainAxis((int) '#', categoryAxis7, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot4);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker14);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean17 = categoryPlot4.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker14, layer16);
        boolean boolean18 = layer3.equals((java.lang.Object) categoryPlot4);
        boolean boolean19 = axisLocation2.equals((java.lang.Object) categoryPlot4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot4.getIndexOf(categoryItemRenderer20);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot5.getRangeAxisLocation();
        java.awt.Font font11 = null;
        try {
            categoryPlot5.setNoDataMessageFont(font11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getLastMillisecond();
//        int int3 = day1.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day1.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        java.lang.Class class4 = null;
        try {
            java.util.EventListener[] eventListenerArray5 = intervalMarker2.getListeners(class4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color2 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        int int10 = color9.getBlue();
        java.awt.Color color11 = java.awt.Color.red;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color1, color2, color9, color11, color12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray13, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        try {
            java.awt.Paint paint19 = defaultDrawingSupplier17.getNextPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean12 = categoryPlot5.removeAnnotation(categoryAnnotation10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        java.awt.Paint paint5 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 12);
        double double4 = rectangleInsets0.calculateTopOutset((double) 0.8f);
        java.lang.String str5 = rectangleInsets0.toString();
        double double6 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str4 = rectangleAnchor3.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 10.0d, 1.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str4.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        categoryPlot6.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot11.setRenderer(categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot11.setRenderer((int) (byte) 0, categoryItemRenderer17, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot11.getDrawingSupplier();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace24 = categoryAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D21, rectangleEdge22, axisSpace23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(drawingSupplier20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color2 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color4 = java.awt.Color.black;
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker7.setLabelAnchor(rectangleAnchor8);
        java.awt.Font font10 = intervalMarker7.getLabelFont();
        java.awt.Stroke stroke11 = intervalMarker7.getOutlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) 10, (double) 13, (java.awt.Paint) color2, stroke3, (java.awt.Paint) color4, stroke11, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        categoryAxis1.setUpperMargin((double) (-1));
        double double7 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateTopOutset(0.0d);
        categoryPlot5.setInsets(rectangleInsets14, false);
        try {
            categoryPlot5.zoom(12.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        java.awt.Paint[] paintArray14 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color16 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color16.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        java.awt.Color color23 = java.awt.Color.CYAN;
        int int24 = color23.getBlue();
        java.awt.Color color25 = java.awt.Color.red;
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color15, color16, color23, color25, color26 };
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray30 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray27, strokeArray28, strokeArray29, shapeArray30);
        java.awt.Paint paint32 = defaultDrawingSupplier31.getNextOutlinePaint();
        categoryPlot5.setRangeGridlinePaint(paint32);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 12);
        double double4 = rectangleInsets0.calculateTopOutset((double) 0.8f);
        double double6 = rectangleInsets0.extendHeight((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.0d + "'", double6 == 7.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) '#');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot0.getIndexOf(categoryItemRenderer5);
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 0, (int) (byte) -1);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateTopOutset(0.0d);
        double double5 = rectangleInsets0.trimHeight((double) 10L);
        double double7 = rectangleInsets0.calculateLeftOutset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke10);
        java.awt.Paint paint12 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            boolean boolean15 = categoryPlot5.removeRangeMarker(marker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot5.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation10, plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot5.getDatasetRenderingOrder();
        java.lang.Object obj13 = null;
        boolean boolean14 = datasetRenderingOrder12.equals(obj13);
        java.lang.String str15 = datasetRenderingOrder12.toString();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str15.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 100L, 0.0d, 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        categoryAxis1.setFixedDimension((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace5, true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            categoryPlot5.drawOutline(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        try {
            int int14 = categoryPlot5.getRangeAxisIndex(valueAxis13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        java.awt.Paint[] paintArray10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color12 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Color color19 = java.awt.Color.CYAN;
        int int20 = color19.getBlue();
        java.awt.Color color21 = java.awt.Color.red;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color11, color12, color19, color21, color22 };
        java.awt.Stroke[] strokeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray23, strokeArray24, strokeArray25, shapeArray26);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        float float29 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.setForegroundAlpha((float) 15);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = categoryPlot0.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker10, layer12);
        boolean boolean14 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor3);
        java.awt.Font font5 = intervalMarker2.getLabelFont();
        java.awt.Stroke stroke6 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker2, jFreeChart7, chartChangeEventType8);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        chartChangeEvent11.setChart(jFreeChart12);
        org.jfree.chart.JFreeChart jFreeChart14 = chartChangeEvent11.getChart();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jFreeChart14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str2 = categoryAxis1.getLabel();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str2.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        float float5 = categoryAxis1.getTickMarkInsideLength();
        boolean boolean6 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        int int25 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge();
        int int27 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot16.getRangeAxisEdge();
        try {
            double double29 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor7, 500, 0, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        categoryPlot10.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot15.getRangeAxis();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        java.lang.String str18 = categoryPlot15.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryPlot15.getAxisOffset();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot15.setDomainGridlineStroke(stroke20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setRangeAxisLocation(1, axisLocation23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot15.getRangeMarkers(255, layer26);
        java.util.Collection collection28 = categoryPlot0.getRangeMarkers(layer26);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation8);
        java.lang.String str10 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font4);
        org.jfree.chart.plot.Plot plot6 = null;
        categoryAxis1.setPlot(plot6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        try {
            double double16 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 2.0d, (java.lang.Comparable) numberTickUnit11, categoryDataset12, (double) 2019, rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberTickUnit11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateTopOutset(0.0d);
        categoryPlot5.setInsets(rectangleInsets14, false);
        double double21 = rectangleInsets14.trimHeight((double) 12);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            rectangleInsets14.trim(rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12.0d + "'", double21 == 12.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.trimWidth((double) (short) -1);
        categoryPlot0.setAxisOffset(rectangleInsets9);
        double double14 = rectangleInsets9.calculateTopInset((double) 10);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setAnchorValue((double) (byte) 100, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot0.zoomRangeAxes((double) 0.0f, (double) 8, plotRenderingInfo18, point2D19);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean2 = color0.equals((java.lang.Object) rectangleAnchor1);
        java.awt.color.ColorSpace colorSpace3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color6 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        float[] floatArray17 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray18 = color6.getColorComponents(floatArray17);
        boolean boolean19 = plotOrientation5.equals((java.lang.Object) floatArray18);
        float[] floatArray20 = color4.getComponents(floatArray18);
        try {
            float[] floatArray21 = color0.getComponents(colorSpace3, floatArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str1.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) '#');
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot0.addChangeListener(plotChangeListener5);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getRGBColorComponents(floatArray3);
        try {
            float[] floatArray5 = color0.getComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color4 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        float[] floatArray15 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray16 = color4.getColorComponents(floatArray15);
        boolean boolean17 = plotOrientation3.equals((java.lang.Object) floatArray16);
        float[] floatArray18 = color2.getRGBColorComponents(floatArray16);
        try {
            float[] floatArray19 = color0.getColorComponents(colorSpace1, floatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot9.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot9.setRenderer((int) (byte) 0, categoryItemRenderer15, false);
        int int18 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot9.getRangeAxisEdge();
        int int20 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot9.getRangeAxisEdge();
        try {
            double double22 = numberAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=255,b=255]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets9.createOutsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 10L, (double) (short) 100, (double) 2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis5, categoryItemRenderer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = categoryAxis3.isAxisLineVisible();
        float float7 = categoryAxis3.getTickMarkInsideLength();
        boolean boolean8 = categoryAxis3.isAxisLineVisible();
        boolean boolean9 = valueMarker1.equals((java.lang.Object) categoryAxis3);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot13.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot13.getDataRange(valueAxis15);
        categoryPlot13.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        categoryPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot18.setRenderer(categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot18.setRenderer((int) (byte) 0, categoryItemRenderer24, false);
        int int27 = categoryPlot18.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot18.getRangeAxisEdge();
        int int29 = categoryPlot18.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot18.getRangeAxisEdge();
        try {
            double double31 = categoryAxis3.getCategoryMiddle(5, 7, rectangle2D12, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot5.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot5.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double14 = rectangleInsets12.trimWidth((double) 12);
        categoryPlot5.setInsets(rectangleInsets12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets12.createOutsetRectangle(rectangle2D16, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.0d + "'", double14 == 6.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(10);
        java.lang.Object obj4 = objectList0.get((int) (byte) 10);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str1.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis((int) (short) 10, valueAxis7, false);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str1.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot3.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.Range range6 = categoryPlot3.getDataRange(valueAxis5);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot8.getRangeAxis();
        categoryPlot3.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot8.setRenderer(categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot8.setRenderer((int) (byte) 0, categoryItemRenderer14, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets17.getRight();
        double double20 = rectangleInsets17.calculateTopOutset(0.0d);
        categoryPlot8.setInsets(rectangleInsets17, false);
        double double24 = rectangleInsets17.trimHeight((double) 12);
        categoryAxis1.setLabelInsets(rectangleInsets17);
        double double27 = rectangleInsets17.calculateBottomInset((double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 12.0d + "'", double24 == 12.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryMiddle((int) ' ', 15, rectangle2D8, rectangleEdge9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint14 = intervalMarker13.getLabelPaint();
        categoryAxis1.setTickLabelPaint(paint14);
        java.lang.Comparable comparable16 = null;
        try {
            categoryAxis1.removeCategoryLabelToolTip(comparable16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        java.awt.Paint[] paintArray10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color12 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Color color19 = java.awt.Color.CYAN;
        int int20 = color19.getBlue();
        java.awt.Color color21 = java.awt.Color.red;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color11, color12, color19, color21, color22 };
        java.awt.Stroke[] strokeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray23, strokeArray24, strokeArray25, shapeArray26);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        try {
            java.awt.Shape shape29 = defaultDrawingSupplier27.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis7.configure();
        java.awt.Shape shape9 = numberAxis7.getUpArrow();
        numberAxis1.setDownArrow(shape9);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color4 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        float[] floatArray15 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray16 = color4.getColorComponents(floatArray15);
        boolean boolean17 = plotOrientation3.equals((java.lang.Object) floatArray16);
        float[] floatArray18 = color2.getRGBColorComponents(floatArray16);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot19.setRangeAxes(valueAxisArray22);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = categoryPlot19.removeDomainMarker(marker24, layer25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot19.setDomainGridlineStroke(stroke27);
        java.awt.Color color29 = java.awt.Color.MAGENTA;
        java.awt.Color color31 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot34.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.data.Range range37 = categoryPlot34.getDataRange(valueAxis36);
        categoryPlot34.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot39.getRangeAxis();
        categoryPlot34.setParent((org.jfree.chart.plot.Plot) categoryPlot39);
        java.lang.String str42 = categoryPlot39.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryPlot39.getAxisOffset();
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot39.setDomainGridlineStroke(stroke44);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, (java.awt.Paint) color31, stroke32, (java.awt.Paint) color33, stroke44, (float) (short) 0);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) 0, (java.awt.Paint) color2, stroke27, (java.awt.Paint) color29, stroke32, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets25.getRight();
        double double28 = rectangleInsets25.calculateTopOutset(0.0d);
        categoryPlot16.setInsets(rectangleInsets25, false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        int int32 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot16.setRangeAxisLocation((int) (short) 10, axisLocation34, true);
        int int37 = categoryPlot16.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        float float5 = categoryAxis1.getTickMarkInsideLength();
        java.awt.Paint[] paintArray6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color8 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Color color15 = java.awt.Color.CYAN;
        int int16 = color15.getBlue();
        java.awt.Color color17 = java.awt.Color.red;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color7, color8, color15, color17, color18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray19, strokeArray20, strokeArray21, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        categoryAxis1.setTickLabelPaint(paint24);
        java.awt.Font font27 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.2d);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot32.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.Range range35 = categoryPlot32.getDataRange(valueAxis34);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot37.getRangeAxis();
        categoryPlot32.setParent((org.jfree.chart.plot.Plot) categoryPlot37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot37.setRenderer(categoryItemRenderer40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        categoryPlot37.setRenderer((int) (byte) 0, categoryItemRenderer43, false);
        int int46 = categoryPlot37.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot37.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = categoryAxis1.draw(graphics2D28, 7.0d, rectangle2D30, rectangle2D31, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer8);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        java.awt.Shape shape3 = numberAxis1.getUpArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource4);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = categoryPlot5.getDataRange(valueAxis7);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot10.setRenderer(categoryItemRenderer13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot10.setRenderer((int) (byte) 0, categoryItemRenderer16, false);
        int int19 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getRangeAxisEdge();
        try {
            java.util.List list21 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot16.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot16.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot0.handleClick((int) (short) 1, 7, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        categoryAxis1.setLabelURL("Category Plot");
        int int4 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor3);
        java.awt.Font font5 = intervalMarker2.getLabelFont();
        java.awt.Stroke stroke6 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker2, jFreeChart7, chartChangeEventType8);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean13 = chartChangeEventType8.equals((java.lang.Object) color12);
        int int14 = color12.getGreen();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 192 + "'", int14 == 192);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis((int) (short) 10, valueAxis7, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = categoryPlot0.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker10, layer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getRGBColorComponents(floatArray15);
        int int17 = color14.getRGB();
        intervalMarker10.setLabelPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-12517377) + "'", int17 == (-12517377));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets25.getRight();
        double double28 = rectangleInsets25.calculateTopOutset(0.0d);
        categoryPlot16.setInsets(rectangleInsets25, false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        int int32 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot16.setRangeAxisLocation((int) (short) 10, axisLocation34, true);
        org.jfree.data.general.DatasetGroup datasetGroup37 = categoryPlot16.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(datasetGroup37);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(10);
        java.lang.Object obj4 = objectList0.get((int) (short) 100);
        objectList0.clear();
        java.lang.Object obj7 = objectList0.get((int) (short) -1);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            boolean boolean9 = categoryPlot0.removeAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Color color0 = java.awt.Color.blue;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        java.awt.Color color13 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot14.getDataRange(valueAxis16);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        categoryPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.lang.String str22 = categoryPlot19.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot19.getAxisOffset();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot19.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color13, stroke24);
        java.awt.Paint paint27 = categoryMarker26.getOutlinePaint();
        categoryMarker26.setLabel("Layer.BACKGROUND");
        org.jfree.chart.util.Layer layer30 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 10, categoryMarker26, layer30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        categoryAxis1.setTickMarksVisible(false);
        categoryAxis1.setLabelToolTip("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            categoryAxis1.setLabelInsets(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot1.setDomainAxis((int) '#', categoryAxis4, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker11);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot1.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker11, layer13);
        boolean boolean15 = layer0.equals((java.lang.Object) categoryPlot1);
        boolean boolean17 = layer0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryMiddle((int) ' ', 15, rectangle2D8, rectangleEdge9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint14 = intervalMarker13.getLabelPaint();
        categoryAxis1.setTickLabelPaint(paint14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = categoryPlot19.getDataRange(valueAxis21);
        categoryPlot19.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot24.getRangeAxis();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot24.setRenderer(categoryItemRenderer27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot24.setRenderer((int) (byte) 0, categoryItemRenderer30, false);
        int int33 = categoryPlot24.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot24.getRangeAxisEdge();
        try {
            double double35 = categoryAxis1.getCategoryEnd((int) (byte) 10, 2, rectangle2D18, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        categoryPlot0.setAnchorValue((double) (short) 10, true);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray14 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot6.setDomainAxes(categoryAxisArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot6.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation((int) (short) 0, axisLocation16, false);
        java.lang.String str19 = axisLocation16.toString();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str19.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int3 = java.awt.Color.HSBtoRGB(0.8f, (float) (short) 1, (float) 1560495599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        org.jfree.data.RangeType rangeType12 = null;
        try {
            numberAxis1.setRangeType(rangeType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color2);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer((int) ' ');
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation((int) '4', axisLocation11, true);
        boolean boolean14 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, plotRenderingInfo16, point2D17);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        int int10 = categoryPlot5.getBackgroundImageAlignment();
        categoryPlot5.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double15 = rectangleInsets13.trimWidth((double) 12);
        double double17 = rectangleInsets13.calculateTopOutset((double) 0.8f);
        categoryPlot5.setAxisOffset(rectangleInsets13);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.0d + "'", double15 == 6.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] { valueAxis12 };
        categoryPlot10.setRangeAxes(valueAxisArray13);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot10.removeDomainMarker(marker15, layer16);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray18 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot10.setDomainAxes(categoryAxisArray18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot0.setDomainAxisLocation(2, axisLocation20, true);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        java.util.Collection collection14 = categoryPlot0.getRangeMarkers((int) (byte) 10, layer12);
        java.lang.String str15 = categoryPlot0.getPlotType();
        try {
            categoryPlot0.zoom((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis1.setRightArrow(shape6);
        numberAxis1.configure();
        try {
            numberAxis1.setRangeWithMargins((double) 10.0f, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) '#');
        categoryPlot0.setDomainGridlinesVisible(true);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot0.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(500, (int) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot5.getRangeAxisLocation();
        int int11 = categoryPlot5.getDatasetCount();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        java.awt.Stroke stroke3 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        categoryPlot10.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot15.getRangeAxis();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot15.setRenderer((int) (byte) 0, categoryItemRenderer21, false);
        int int24 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.axis.AxisState axisState27 = categoryAxis1.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color3 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.Color color10 = java.awt.Color.CYAN;
        int int11 = color10.getBlue();
        java.awt.Color color12 = java.awt.Color.red;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, color3, color10, color12, color13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray14, strokeArray15, strokeArray16, shapeArray17);
        java.lang.Object obj19 = defaultDrawingSupplier18.clone();
        boolean boolean20 = color0.equals(obj19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker3);
        float float5 = intervalMarker3.getAlpha();
        java.awt.Paint paint6 = intervalMarker3.getLabelPaint();
        intervalMarker3.setLabel("Category Plot");
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker3.setLabelPaint((java.awt.Paint) color9);
        double double11 = intervalMarker3.getEndValue();
        boolean boolean12 = rectangleInsets0.equals((java.lang.Object) double11);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateTopOutset(0.0d);
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot5.getLegendItems();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot3.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.Range range6 = categoryPlot3.getDataRange(valueAxis5);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot8.getRangeAxis();
        categoryPlot3.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot8.setRenderer(categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot8.setRenderer((int) (byte) 0, categoryItemRenderer14, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets17.getRight();
        double double20 = rectangleInsets17.calculateTopOutset(0.0d);
        categoryPlot8.setInsets(rectangleInsets17, false);
        double double24 = rectangleInsets17.trimHeight((double) 12);
        categoryAxis1.setLabelInsets(rectangleInsets17);
        double double26 = rectangleInsets17.getLeft();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent32 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker31);
        float float33 = intervalMarker31.getAlpha();
        java.awt.Paint paint34 = intervalMarker31.getLabelPaint();
        intervalMarker31.setLabel("Category Plot");
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker31.setLabelPaint((java.awt.Paint) color37);
        java.awt.Paint paint39 = intervalMarker31.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker31.setLabelOffsetType(lengthAdjustmentType40);
        try {
            java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets17.createAdjustedRectangle(rectangle2D27, lengthAdjustmentType28, lengthAdjustmentType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 12.0d + "'", double24 == 12.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.8f + "'", float33 == 0.8f);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color1 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        float[] floatArray12 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray13 = color1.getColorComponents(floatArray12);
        float[] floatArray14 = color0.getColorComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        java.util.Collection collection14 = categoryPlot0.getRangeMarkers((int) (byte) 10, layer12);
        java.lang.String str15 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = categoryAxis17.isAxisLineVisible();
        float float21 = categoryAxis17.getTickMarkInsideLength();
        boolean boolean22 = categoryAxis17.isAxisLineVisible();
        float float23 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis(categoryAxis17);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        float float26 = categoryPlot16.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = categoryAxis2.isAxisLineVisible();
        float float6 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        double double13 = numberAxis8.getLowerBound();
        org.jfree.data.RangeType rangeType14 = null;
        try {
            numberAxis8.setRangeType(rangeType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot13.draw(graphics2D16, rectangle2D17, point2D18, plotState19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        numberAxis1.setLowerBound((double) 10L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        java.util.List list12 = categoryPlot5.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        try {
            categoryPlot5.setDomainAxis((int) (byte) -1, categoryAxis17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot9.getDataRange(valueAxis11);
        categoryPlot9.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        categoryPlot9.setParent((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.String str17 = categoryPlot14.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot14.getAxisOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot14.setDomainGridlineStroke(stroke19);
        java.awt.Paint paint21 = categoryPlot14.getBackgroundPaint();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot14.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation22);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot1.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = categoryPlot1.getDataRange(valueAxis3);
        categoryPlot1.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        categoryPlot1.setParent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot6.setRenderer(categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer((int) (byte) 0, categoryItemRenderer12, false);
        int int15 = categoryPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getRangeAxisEdge();
        boolean boolean17 = categoryAnchor0.equals((java.lang.Object) categoryPlot6);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.lang.String str10 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 12);
        double double15 = rectangleInsets11.calculateTopOutset((double) 0.8f);
        java.lang.String str16 = rectangleInsets11.toString();
        java.lang.String str17 = rectangleInsets11.toString();
        double double19 = rectangleInsets11.calculateBottomInset((double) ' ');
        categoryPlot5.setInsets(rectangleInsets11, true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot5.setDataset((int) (byte) 1, categoryDataset23);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.0d + "'", double13 == 6.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str16.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str17.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        boolean boolean11 = categoryPlot0.isSubplot();
        float float12 = categoryPlot0.getBackgroundAlpha();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color16);
        java.awt.Font font18 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = null;
        try {
            dateAxis0.setTimeZone(timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        java.lang.String str10 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) rectangleAnchor1);
        java.lang.String str3 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str3.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = categoryAxis2.isAxisLineVisible();
        float float6 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot14.getDataRange(valueAxis16);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        categoryPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot19.getIndexOf(categoryItemRenderer24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot27.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        categoryPlot27.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot32.getRangeAxis();
        categoryPlot27.setParent((org.jfree.chart.plot.Plot) categoryPlot32);
        java.lang.String str35 = categoryPlot32.getPlotType();
        categoryPlot32.setForegroundAlpha((float) 255);
        categoryPlot32.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot32.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace43 = numberAxis8.reserveSpace(graphics2D13, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D26, rectangleEdge41, axisSpace42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot13.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        java.awt.Paint paint34 = xYPlot13.getRangeCrosshairPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation35 = null;
        try {
            boolean boolean37 = xYPlot13.removeAnnotation(xYAnnotation35, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent11.getPlot();
        java.lang.Class<?> wildcardClass13 = plot12.getClass();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date15, timeZone16);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        java.lang.String str12 = categoryPlot9.getPlotType();
        categoryPlot9.setForegroundAlpha((float) 255);
        categoryPlot9.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot9.getDomainAxisEdge((int) (short) 1);
        try {
            double double19 = dateAxis0.dateToJava2D(date1, rectangle2D3, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot8.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        categoryPlot8.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot13.getRangeAxis();
        categoryPlot8.setParent((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot13.setRenderer(categoryItemRenderer16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot13.setRenderer((int) (byte) 0, categoryItemRenderer19, false);
        int int22 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getRangeAxisEdge();
        try {
            double double24 = numberAxis1.lengthToJava2D((double) 4, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets25.getRight();
        double double28 = rectangleInsets25.calculateTopOutset(0.0d);
        categoryPlot16.setInsets(rectangleInsets25, false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        int int32 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot16.setRenderer(categoryItemRenderer33);
        categoryPlot16.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot16.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = null;
        try {
            categoryPlot16.setInsets(rectangleInsets37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.clearRangeMarkers();
        boolean boolean6 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getBlue();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16711681) + "'", int2 == (-16711681));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace34);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot13.getRangeAxisForDataset(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 5 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font4);
        categoryAxis1.setLabelAngle((double) 500);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        int int25 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge();
        int int27 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot16.getRangeAxisEdge();
        try {
            java.util.List list29 = categoryAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        intervalMarker2.setEndValue(3.0d);
        java.awt.Paint paint6 = intervalMarker2.getLabelPaint();
        java.lang.Object obj7 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        int int14 = categoryPlot5.getDomainAxisCount();
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot5.getRangeAxisForDataset(8);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color1 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        java.lang.String str12 = categoryPlot9.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot9.setDomainGridlineStroke(stroke14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke14, (float) (short) 0);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = valueMarker17.getLabelOffsetType();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((-1.0d), plotRenderingInfo5, point2D6, true);
        float float9 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        float float11 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke10);
        java.awt.Paint paint12 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot5.getRangeAxisLocation();
        double double14 = categoryPlot5.getRangeCrosshairValue();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        categoryAxis1.setLabelAngle((double) 1560495599999L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot16.setOrientation(plotOrientation26);
        categoryPlot16.setRangeCrosshairValue((double) (short) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        boolean boolean3 = categoryAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot3.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.Range range6 = categoryPlot3.getDataRange(valueAxis5);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot8.getRangeAxis();
        categoryPlot3.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot8.setRenderer(categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot8.setRenderer((int) (byte) 0, categoryItemRenderer14, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets17.getRight();
        double double20 = rectangleInsets17.calculateTopOutset(0.0d);
        categoryPlot8.setInsets(rectangleInsets17, false);
        double double24 = rectangleInsets17.trimHeight((double) 12);
        categoryAxis1.setLabelInsets(rectangleInsets17);
        categoryAxis1.setLabelAngle((double) 0.5f);
        java.awt.Paint paint28 = categoryAxis1.getLabelPaint();
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryAxis1.setTickLabelPaint(paint29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 12.0d + "'", double24 == 12.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str2 = categoryAxis1.getLabel();
        categoryAxis1.setTickMarkInsideLength((float) (byte) 100);
        float float5 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.java2DToValue(6.0d, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis17.configure();
        java.awt.Shape shape19 = numberAxis17.getUpArrow();
        boolean boolean20 = numberAxis17.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot22.getDomainAxisLocation((int) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot22.getRangeAxisEdge();
        try {
            java.util.List list28 = categoryAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str2.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot3.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.Range range6 = categoryPlot3.getDataRange(valueAxis5);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot8.getRangeAxis();
        categoryPlot3.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot8.setRenderer(categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot8.setRenderer((int) (byte) 0, categoryItemRenderer14, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets17.getRight();
        double double20 = rectangleInsets17.calculateTopOutset(0.0d);
        categoryPlot8.setInsets(rectangleInsets17, false);
        double double24 = rectangleInsets17.trimHeight((double) 12);
        categoryAxis1.setLabelInsets(rectangleInsets17);
        double double26 = rectangleInsets17.getLeft();
        org.jfree.chart.util.UnitType unitType27 = rectangleInsets17.getUnitType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 12.0d + "'", double24 == 12.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(unitType27);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Color color3 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        float[] floatArray14 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray15 = color3.getColorComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(100, 4, 500, floatArray14);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        int int34 = xYPlot13.getDatasetCount();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Point2D point2D37 = null;
        org.jfree.chart.plot.PlotState plotState38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            xYPlot13.draw(graphics2D35, rectangle2D36, point2D37, plotState38, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis1.setLabelFont(font13);
        categoryAxis1.setCategoryMargin((double) 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis1.setLabelFont(font13);
        double double15 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker11.setLabelAnchor(rectangleAnchor12);
        java.awt.Font font14 = intervalMarker11.getLabelFont();
        java.awt.Stroke stroke15 = intervalMarker11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker11, jFreeChart16, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart8, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = chartChangeEvent21.getType();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot13.drawAnnotations(graphics2D16, rectangle2D17, plotRenderingInfo18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot21.getDataRange(valueAxis23);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot26.getRangeAxis();
        categoryPlot21.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot26.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (byte) 0, axisLocation31, false);
        xYPlot13.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot13.zoomRangeAxes((double) (short) 1, (double) 13, plotRenderingInfo37, point2D38);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis1.getTickUnit();
        numberAxis1.setUpperBound(0.0d);
        java.awt.Font font14 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke10);
        java.awt.Paint paint12 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot5.getRangeAxisLocation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot5.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", color1);
        java.lang.Class<?> wildcardClass3 = color1.getClass();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font4);
        org.jfree.chart.plot.Plot plot6 = null;
        categoryAxis1.setPlot(plot6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10);
        java.lang.String str10 = categoryAxis1.getLabel();
        float float11 = categoryAxis1.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot15.getDataRange(valueAxis17);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot20.getRangeAxis();
        categoryPlot15.setParent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot20.setRenderer(categoryItemRenderer23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot20.setRenderer((int) (byte) 0, categoryItemRenderer26, false);
        int int29 = categoryPlot20.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot20.getRangeAxisEdge();
        int int31 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot20.getRangeAxisEdge();
        try {
            double double33 = categoryAxis1.getCategoryMiddle(1, 0, rectangle2D14, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str10.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        categoryPlot6.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot11.setRenderer(categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot11.setRenderer((int) (byte) 0, categoryItemRenderer17, false);
        int int20 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot11.getRangeAxisEdge();
        int int22 = categoryPlot11.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = numberAxis1.draw(graphics2D2, (double) 100.0f, rectangle2D4, rectangle2D5, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        double double2 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        numberAxis1.setVerticalTickLabels(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit5);
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker40.setLabelAnchor(rectangleAnchor41);
        java.awt.Font font43 = intervalMarker40.getLabelFont();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot13.removeRangeMarker(6, (org.jfree.chart.plot.Marker) intervalMarker40, layer44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        try {
            xYPlot13.setRangeAxisLocation(axisLocation46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        boolean boolean3 = day0.equals((java.lang.Object) 6);
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getEnd();
//        boolean boolean8 = day5.equals((java.lang.Object) 6);
//        long long9 = day5.getLastMillisecond();
//        int int10 = day0.compareTo((java.lang.Object) long9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        int int34 = xYPlot13.getDatasetCount();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray35 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot13.setRenderers(xYItemRendererArray35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            xYPlot13.drawBackground(graphics2D37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray35);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        float float11 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        double double12 = categoryAxis1.getLabelAngle();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
        categoryPlot16.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
        categoryPlot16.setParent((org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot21.setRenderer(categoryItemRenderer24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot21.setRenderer((int) (byte) 0, categoryItemRenderer27, false);
        int int30 = categoryPlot21.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot21.getRangeAxisEdge();
        int int32 = categoryPlot21.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot21.getRangeAxisEdge();
        try {
            java.util.List list34 = categoryAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.ABSOLUTE", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) 3, plotRenderingInfo6, point2D7);
        categoryPlot0.setAnchorValue((double) 6, true);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis1.getTickUnit();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        java.lang.String str16 = color15.toString();
        java.awt.Color color17 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color19 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        float[] floatArray30 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray31 = color19.getColorComponents(floatArray30);
        boolean boolean32 = plotOrientation18.equals((java.lang.Object) floatArray31);
        float[] floatArray33 = color17.getRGBColorComponents(floatArray31);
        float[] floatArray34 = color15.getComponents(floatArray33);
        boolean boolean35 = numberAxis1.equals((java.lang.Object) floatArray33);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker38.setLabelAnchor(rectangleAnchor39);
        java.awt.Font font41 = intervalMarker38.getLabelFont();
        numberAxis1.setLabelFont(font41);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=254,g=0,b=0]" + "'", str16.equals("java.awt.Color[r=254,g=0,b=0]"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        int int6 = color4.getRGB();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.java2DToValue(6.0d, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis15.configure();
        java.awt.Shape shape17 = numberAxis15.getUpArrow();
        boolean boolean18 = numberAxis15.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot20.setRenderer(xYItemRenderer21);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke23);
        java.awt.Paint[] paintArray25 = null;
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color27 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        java.awt.Color color34 = java.awt.Color.CYAN;
        int int35 = color34.getBlue();
        java.awt.Color color36 = java.awt.Color.red;
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] { color26, color27, color34, color36, color37 };
        java.awt.Stroke[] strokeArray39 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray41 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray25, paintArray38, strokeArray39, strokeArray40, shapeArray41);
        java.awt.Stroke stroke43 = defaultDrawingSupplier42.getNextStroke();
        java.awt.Paint paint44 = defaultDrawingSupplier42.getNextFillPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot45.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.Range range48 = categoryPlot45.getDataRange(valueAxis47);
        categoryPlot45.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot50.getRangeAxis();
        categoryPlot45.setParent((org.jfree.chart.plot.Plot) categoryPlot50);
        java.lang.String str53 = categoryPlot50.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = categoryPlot50.getAxisOffset();
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot50.setDomainGridlineStroke(stroke55);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker((double) 500, (double) 7, (java.awt.Paint) color4, stroke23, paint44, stroke55, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-32513) + "'", int6 == (-32513));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(shapeArray41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Category Plot" + "'", str53.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        int int14 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge();
        int int16 = categoryPlot5.getRangeAxisCount();
        java.awt.Color color18 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = categoryPlot19.getDataRange(valueAxis21);
        categoryPlot19.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot24.getRangeAxis();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        java.lang.String str27 = categoryPlot24.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot24.getAxisOffset();
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot24.setDomainGridlineStroke(stroke29);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color18, stroke29);
        org.jfree.chart.util.Layer layer32 = null;
        try {
            categoryPlot5.addDomainMarker(categoryMarker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color2 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color14 = java.awt.Color.BLACK;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot17.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = categoryPlot17.getDataRange(valueAxis19);
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot22.getRangeAxis();
        categoryPlot17.setParent((org.jfree.chart.plot.Plot) categoryPlot22);
        java.lang.String str25 = categoryPlot22.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot22.getAxisOffset();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot22.setDomainGridlineStroke(stroke27);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color16, stroke27);
        java.awt.Paint paint30 = null;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color14, stroke27, paint30, stroke31, (float) 1L);
        categoryAxis12.setTickMarkStroke(stroke31);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 10, (double) '#', (java.awt.Paint) color2, stroke9, (java.awt.Paint) color10, stroke31, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryEnd((int) '#', 6, rectangle2D8, rectangleEdge9);
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis1.setLabelFont(font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot23.getRangeAxis();
        categoryPlot18.setParent((org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot23.setRenderer(categoryItemRenderer26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot23.setRenderer((int) (byte) 0, categoryItemRenderer29, false);
        int int32 = categoryPlot23.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot23.getRangeAxisEdge();
        int int34 = categoryPlot23.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot23.getRangeAxisEdge();
        try {
            java.util.List list36 = categoryAxis1.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        java.lang.Object obj4 = intervalMarker2.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer5);
        double double7 = intervalMarker2.getStartValue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        int int14 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge();
        int int16 = categoryPlot5.getRangeAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            categoryPlot5.handleClick((int) (short) 1, 1, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) rectangleAnchor2);
        try {
            java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot2.setDomainAxis((int) '#', categoryAxis5, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot2);
        categoryPlot2.setDomainGridlinesVisible(false);
        boolean boolean11 = rectangleAnchor1.equals((java.lang.Object) categoryPlot2);
        try {
            java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        double double6 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(10);
        int int3 = objectList0.size();
        objectList0.clear();
        objectList0.clear();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16776961) + "'", int1 == (-16776961));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        int int9 = categoryPlot0.getBackgroundImageAlignment();
        double double10 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.lang.String str10 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 12);
        double double15 = rectangleInsets11.calculateTopOutset((double) 0.8f);
        java.lang.String str16 = rectangleInsets11.toString();
        java.lang.String str17 = rectangleInsets11.toString();
        double double19 = rectangleInsets11.calculateBottomInset((double) ' ');
        categoryPlot5.setInsets(rectangleInsets11, true);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis26.setLabelPaint((java.awt.Paint) color27);
        categoryAxis26.setLabelToolTip("RectangleAnchor.BOTTOM");
        categoryAxis26.setTickMarksVisible(false);
        categoryPlot5.setDomainAxis(categoryAxis26);
        float float34 = categoryAxis26.getTickMarkInsideLength();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.0d + "'", double13 == 6.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str16.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str17.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        numberAxis1.configure();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        categoryPlot5.setForegroundAlpha((float) 255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomRangeAxes((double) 7, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.plot.Plot plot16 = categoryPlot5.getRootPlot();
        try {
            categoryPlot5.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        categoryAxis1.setTickMarksVisible(false);
        categoryAxis1.setLabelToolTip("hi!");
        categoryAxis1.setAxisLineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot12.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.data.Range range15 = categoryPlot12.getDataRange(valueAxis14);
        categoryPlot12.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot17.getRangeAxis();
        categoryPlot12.setParent((org.jfree.chart.plot.Plot) categoryPlot17);
        java.lang.String str20 = categoryPlot17.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot17.getAxisOffset();
        java.lang.String str22 = categoryPlot17.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double25 = rectangleInsets23.trimWidth((double) 12);
        double double27 = rectangleInsets23.calculateTopOutset((double) 0.8f);
        java.lang.String str28 = rectangleInsets23.toString();
        java.lang.String str29 = rectangleInsets23.toString();
        double double31 = rectangleInsets23.calculateBottomInset((double) ' ');
        categoryPlot17.setInsets(rectangleInsets23, true);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Category Plot" + "'", str20.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 6.0d + "'", double25 == 6.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str29.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        int int34 = xYPlot13.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot13.zoomRangeAxes((double) (short) 100, plotRenderingInfo36, point2D37, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot13.getDomainAxisForDataset(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 11 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Color color3 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        java.lang.String str12 = categoryPlot9.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot9.setDomainGridlineStroke(stroke14);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color3, stroke14);
        java.awt.Paint paint17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color1, stroke14, paint17, stroke18, (float) 1L);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker23);
        float float25 = intervalMarker23.getAlpha();
        java.awt.Paint paint26 = intervalMarker23.getPaint();
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker23.setLabelFont(font27);
        categoryMarker20.setLabelFont(font27);
        categoryMarker20.setKey((java.lang.Comparable) "CategoryAnchor.END");
        boolean boolean32 = categoryMarker20.getDrawAsLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis1.getTickUnit();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        java.lang.String str16 = color15.toString();
        java.awt.Color color17 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color19 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        float[] floatArray30 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray31 = color19.getColorComponents(floatArray30);
        boolean boolean32 = plotOrientation18.equals((java.lang.Object) floatArray31);
        float[] floatArray33 = color17.getRGBColorComponents(floatArray31);
        float[] floatArray34 = color15.getComponents(floatArray33);
        boolean boolean35 = numberAxis1.equals((java.lang.Object) floatArray33);
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot39.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.data.Range range42 = categoryPlot39.getDataRange(valueAxis41);
        categoryPlot39.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot44.getRangeAxis();
        categoryPlot39.setParent((org.jfree.chart.plot.Plot) categoryPlot44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot44.setRenderer(categoryItemRenderer47);
        int int49 = categoryPlot44.getBackgroundImageAlignment();
        categoryPlot44.setRangeCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset52 = categoryPlot44.getDataset();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot54.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.data.Range range57 = categoryPlot54.getDataRange(valueAxis56);
        categoryPlot54.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot59.getRangeAxis();
        categoryPlot54.setParent((org.jfree.chart.plot.Plot) categoryPlot59);
        java.lang.String str62 = categoryPlot59.getPlotType();
        categoryPlot59.setForegroundAlpha((float) 255);
        categoryPlot59.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot59.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace70 = numberAxis1.reserveSpace(graphics2D38, (org.jfree.chart.plot.Plot) categoryPlot44, rectangle2D53, rectangleEdge68, axisSpace69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=254,g=0,b=0]" + "'", str16.equals("java.awt.Color[r=254,g=0,b=0]"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 15 + "'", int49 == 15);
        org.junit.Assert.assertNull(categoryDataset52);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Category Plot" + "'", str62.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        float float5 = categoryAxis1.getTickMarkInsideLength();
        boolean boolean6 = categoryAxis1.isAxisLineVisible();
        float float7 = categoryAxis1.getTickMarkInsideLength();
        int int8 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis7.setLabelPaint((java.awt.Paint) color8);
        categoryAxis7.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis7.getCategoryEnd((int) '#', 6, rectangle2D14, rectangleEdge15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot17.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = categoryPlot17.getDataRange(valueAxis19);
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot22.getRangeAxis();
        categoryPlot17.setParent((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot22.setRenderer(categoryItemRenderer25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot22.setRenderer((int) (byte) 0, categoryItemRenderer28, false);
        categoryAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot22.setDatasetRenderingOrder(datasetRenderingOrder32);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot35.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.data.Range range38 = categoryPlot35.getDataRange(valueAxis37);
        categoryPlot35.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot40.getRangeAxis();
        categoryPlot35.setParent((org.jfree.chart.plot.Plot) categoryPlot40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        categoryPlot40.setRenderer(categoryItemRenderer43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        categoryPlot40.setRenderer((int) (byte) 0, categoryItemRenderer46, false);
        int int49 = categoryPlot40.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot40.getRangeAxisEdge();
        int int51 = categoryPlot40.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot40.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace54 = dateAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot22, rectangle2D34, rectangleEdge52, axisSpace53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(10);
        java.lang.Object obj4 = objectList0.get((int) (short) 100);
        objectList0.clear();
        int int6 = objectList0.size();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset((int) (short) 10, categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        numberAxis1.setVerticalTickLabels(false);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.java2DToValue(6.0d, rectangle2D8, rectangleEdge9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis6.setRightArrow(shape11);
        numberAxis6.configure();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis15.configure();
        java.awt.Shape shape17 = numberAxis15.getUpArrow();
        numberAxis6.setLeftArrow(shape17);
        numberAxis1.setUpArrow(shape17);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = categoryAxis3.isAxisLineVisible();
        float float7 = categoryAxis3.getTickMarkInsideLength();
        boolean boolean8 = categoryAxis3.isAxisLineVisible();
        boolean boolean9 = valueMarker1.equals((java.lang.Object) categoryAxis3);
        categoryAxis3.setLabelToolTip("");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot15.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot15.getDataRange(valueAxis17);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot20.getRangeAxis();
        categoryPlot15.setParent((org.jfree.chart.plot.Plot) categoryPlot20);
        java.lang.String str23 = categoryPlot20.getPlotType();
        categoryPlot20.setForegroundAlpha((float) 255);
        categoryPlot20.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot20.getDomainAxisEdge((int) (short) 1);
        try {
            double double30 = categoryAxis3.getCategoryMiddle(6, 0, rectangle2D14, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            xYPlot13.drawBackground(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot13.drawAnnotations(graphics2D16, rectangle2D17, plotRenderingInfo18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot21.getDataRange(valueAxis23);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot26.getRangeAxis();
        categoryPlot21.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot26.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (byte) 0, axisLocation31, false);
        xYPlot13.clearDomainAxes();
        xYPlot13.setDomainZeroBaselineVisible(true);
        java.lang.String str37 = xYPlot13.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot13.getRangeAxis();
        valueAxis38.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "XY Plot" + "'", str37.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis38);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Color color2 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = categoryPlot5.getDataRange(valueAxis7);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.String str13 = categoryPlot10.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot10.getAxisOffset();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot10.setDomainGridlineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, (java.awt.Paint) color2, stroke3, (java.awt.Paint) color4, stroke15, (float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot19.setRangeAxes(valueAxisArray22);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = categoryPlot19.removeDomainMarker(marker24, layer25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot19.setRangeAxisLocation(axisLocation27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot19.setRangeCrosshairStroke(stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker33);
        float float35 = intervalMarker33.getAlpha();
        java.awt.Paint paint36 = intervalMarker33.getLabelPaint();
        intervalMarker33.setLabel("Category Plot");
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker33.setLabelPaint((java.awt.Paint) color39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0, (java.awt.Paint) color2, stroke29, (java.awt.Paint) color39, stroke41, (float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.8f + "'", float35 == 0.8f);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, true, true);
        java.util.Date date6 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot9.getDataRange(valueAxis11);
        categoryPlot9.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        categoryPlot9.setParent((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer(categoryItemRenderer17);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        categoryPlot14.setRangeCrosshairValue(1.0E-8d);
        boolean boolean22 = categoryPlot14.isSubplot();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot14.getDomainAxisEdge();
        try {
            double double26 = dateAxis0.valueToJava2D((double) 12, rectangle2D8, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot13.drawAnnotations(graphics2D16, rectangle2D17, plotRenderingInfo18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot21.getDataRange(valueAxis23);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot26.getRangeAxis();
        categoryPlot21.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot26.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (byte) 0, axisLocation31, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            xYPlot13.handleClick((int) '4', (int) (short) 10, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent11.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = plotChangeEvent11.getType();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        categoryAxis1.setLabelURL("Category Plot");
        java.awt.Paint paint5 = null;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 10.0d, paint5);
        double double7 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setAnchorValue((double) (byte) 100, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean17 = categoryAxis16.isAxisLineVisible();
        categoryAxis16.setTickMarksVisible(true);
        float float20 = categoryAxis16.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis16.getCategoryMiddle((int) ' ', 15, rectangle2D23, rectangleEdge24);
        boolean boolean26 = plotOrientation14.equals((java.lang.Object) rectangle2D23);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font4);
        categoryAxis1.setLabelAngle((double) 500);
        categoryAxis1.setUpperMargin((double) 7);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot14.getDataRange(valueAxis16);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        categoryPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.lang.String str22 = categoryPlot19.getPlotType();
        categoryPlot19.setForegroundAlpha((float) 255);
        categoryPlot19.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot19.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = categoryAxis1.draw(graphics2D10, (double) 100, rectangle2D12, rectangle2D13, rectangleEdge28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot5, jFreeChart10);
        java.awt.Stroke stroke12 = categoryPlot5.getRangeGridlineStroke();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        java.awt.Shape shape3 = numberAxis1.getUpArrow();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker6);
        float float8 = intervalMarker6.getAlpha();
        java.awt.Paint paint9 = intervalMarker6.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot10.getColumnRenderingOrder();
        categoryPlot10.clearRangeMarkers();
        boolean boolean16 = intervalMarker6.equals((java.lang.Object) categoryPlot10);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8f + "'", float8 == 0.8f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        categoryPlot0.axisChanged(axisChangeEvent10);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 12);
        double double4 = rectangleInsets0.calculateTopOutset((double) 0.8f);
        double double6 = rectangleInsets0.calculateRightInset((double) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createInsetRectangle(rectangle2D7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        numberAxis2.setAutoRange(false);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean23 = categoryPlot22.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot22.setDomainAxis((int) '#', categoryAxis25, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot22);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean35 = categoryPlot22.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker32, layer34);
        boolean boolean36 = layer21.equals((java.lang.Object) categoryPlot22);
        boolean boolean37 = axisLocation20.equals((java.lang.Object) categoryPlot22);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot22.getDomainAxisEdge(192);
        try {
            double double40 = numberAxis2.java2DToValue((double) (short) 0, rectangle2D17, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        java.awt.Paint paint18 = xYPlot13.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoRangeIncludesZero(true);
        boolean boolean14 = numberAxis1.isAutoRange();
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation((int) ' ');
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) '#');
        int int11 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        boolean boolean12 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor6);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis37.java2DToValue(6.0d, rectangle2D39, rectangleEdge40);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis43.configure();
        java.awt.Shape shape45 = numberAxis43.getUpArrow();
        boolean boolean46 = numberAxis43.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot48.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = numberAxis55.java2DToValue(6.0d, rectangle2D57, rectangleEdge58);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis61.configure();
        java.awt.Shape shape63 = numberAxis61.getUpArrow();
        boolean boolean64 = numberAxis61.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) numberAxis55, (org.jfree.chart.axis.ValueAxis) numberAxis61, xYItemRenderer65);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder67 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot66.setDatasetRenderingOrder(datasetRenderingOrder67);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot66.getDomainAxisLocation((int) 'a');
        xYPlot48.setDomainAxisLocation(axisLocation70);
        xYPlot13.setDomainAxisLocation(1, axisLocation70);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.POSITIVE_INFINITY + "'", double41 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder67);
        org.junit.Assert.assertNotNull(axisLocation70);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        boolean boolean11 = categoryPlot0.isSubplot();
        float float12 = categoryPlot0.getBackgroundAlpha();
        java.awt.Color color15 = java.awt.Color.BLACK;
        java.awt.Color color17 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot23.getRangeAxis();
        categoryPlot18.setParent((org.jfree.chart.plot.Plot) categoryPlot23);
        java.lang.String str26 = categoryPlot23.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot23.getAxisOffset();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot23.setDomainGridlineStroke(stroke28);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color17, stroke28);
        java.awt.Paint paint31 = null;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color15, stroke28, paint31, stroke32, (float) 1L);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker37);
        float float39 = intervalMarker37.getAlpha();
        java.awt.Paint paint40 = intervalMarker37.getPaint();
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker37.setLabelFont(font41);
        categoryMarker34.setLabelFont(font41);
        java.lang.Comparable comparable44 = categoryMarker34.getKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis46.setLabelPaint((java.awt.Paint) color47);
        categoryAxis46.setLabelToolTip("RectangleAnchor.BOTTOM");
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis46.getCategoryEnd((int) '#', 6, rectangle2D53, rectangleEdge54);
        float float56 = categoryAxis46.getMaximumCategoryLabelWidthRatio();
        double double57 = categoryAxis46.getLabelAngle();
        boolean boolean58 = categoryMarker34.equals((java.lang.Object) categoryAxis46);
        try {
            categoryPlot0.setDomainAxis((int) (short) -1, categoryAxis46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 1.0E-8d + "'", comparable44.equals(1.0E-8d));
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.0f + "'", float56 == 0.0f);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis((int) (short) 10, valueAxis7, false);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis13.setTickUnit(dateTickUnit14, true, true);
        java.util.TimeZone timeZone18 = dateAxis13.getTimeZone();
        boolean boolean20 = dateAxis13.isHiddenValue((long) (-12517377));
        java.lang.Class class21 = null;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone24);
        dateAxis13.setMinimumDate(date22);
        categoryPlot0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = null;
        try {
            dateAxis13.setTickMarkPosition(dateTickMarkPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) -1);
        double double4 = rectangleInsets0.calculateLeftInset((double) 11);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font4);
        org.jfree.chart.plot.Plot plot6 = null;
        categoryAxis1.setPlot(plot6);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10);
        java.lang.String str10 = categoryAxis1.getLabel();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str10.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot5.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot5.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double14 = rectangleInsets12.trimWidth((double) 12);
        categoryPlot5.setInsets(rectangleInsets12);
        categoryPlot5.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.0d + "'", double14 == 6.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, 12.0d, plotRenderingInfo7, point2D8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset(2019, categoryDataset11);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str2 = categoryAxis1.getLabel();
        categoryAxis1.setTickMarkInsideLength((float) (byte) 100);
        float float5 = categoryAxis1.getTickMarkOutsideLength();
        java.lang.String str6 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str2.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        java.awt.Color color19 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot20.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot25.getRangeAxis();
        categoryPlot20.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        java.lang.String str28 = categoryPlot25.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryPlot25.getAxisOffset();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot25.setDomainGridlineStroke(stroke30);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color19, stroke30);
        java.awt.Paint paint33 = categoryMarker32.getOutlinePaint();
        boolean boolean34 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker32);
        xYPlot13.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        java.util.Collection collection14 = categoryPlot0.getRangeMarkers((int) (byte) 10, layer12);
        java.lang.String str15 = categoryPlot0.getPlotType();
        java.awt.Color color16 = java.awt.Color.ORANGE;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        java.util.Collection collection14 = categoryPlot0.getRangeMarkers((int) (byte) 10, layer12);
        java.lang.String str15 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis18.setLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = categoryAxis18.isAxisLineVisible();
        float float22 = categoryAxis18.getTickMarkInsideLength();
        java.awt.Paint[] paintArray23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color25 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        java.awt.Color color32 = java.awt.Color.CYAN;
        int int33 = color32.getBlue();
        java.awt.Color color34 = java.awt.Color.red;
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color24, color25, color32, color34, color35 };
        java.awt.Stroke[] strokeArray37 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray39 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray36, strokeArray37, strokeArray38, shapeArray39);
        java.awt.Paint paint41 = defaultDrawingSupplier40.getNextOutlinePaint();
        categoryAxis18.setTickLabelPaint(paint41);
        try {
            categoryPlot0.setDomainAxis((-16711681), categoryAxis18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 255 + "'", int33 == 255);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(shapeArray39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color2 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        int int10 = color9.getBlue();
        java.awt.Color color11 = java.awt.Color.red;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color1, color2, color9, color11, color12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray13, strokeArray14, strokeArray15, shapeArray16);
        try {
            java.awt.Shape shape18 = defaultDrawingSupplier17.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        numberAxis2.setAutoRange(false);
        numberAxis2.setUpperBound((double) 255);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        boolean boolean7 = dateAxis0.isHiddenValue((long) (-12517377));
        java.lang.Class class8 = null;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone11);
        dateAxis0.setMinimumDate(date9);
        dateAxis0.zoomRange((double) (-1.0f), 10.0d);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint1 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
        categoryPlot0.clearDomainMarkers((-12517377));
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        boolean boolean11 = categoryPlot0.isSubplot();
        float float12 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint14 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setLabelToolTip("RectangleAnchor.BOTTOM");
        categoryAxis1.setTickMarksVisible(false);
        categoryAxis1.setLabelToolTip("hi!");
        java.awt.Font font10 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker3);
        float float5 = intervalMarker3.getAlpha();
        java.awt.Paint paint6 = intervalMarker3.getLabelPaint();
        intervalMarker3.setLabel("Category Plot");
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker3.setLabelPaint((java.awt.Paint) color9);
        java.awt.Paint paint11 = intervalMarker3.getOutlinePaint();
        int int12 = objectList0.indexOf((java.lang.Object) paint11);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { valueAxis7 };
        categoryPlot5.setRangeAxes(valueAxisArray8);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean12 = categoryPlot5.removeDomainMarker(marker10, layer11);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot5.setDomainAxes(categoryAxisArray13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation16 = axisLocation15.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation15, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        categoryPlot0.axisChanged(axisChangeEvent19);
        try {
            categoryPlot0.zoom((double) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot5.setRangeAxisLocation(1, axisLocation13);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.awt.Image image17 = categoryPlot5.getBackgroundImage();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Color color6 = java.awt.Color.BLACK;
        java.awt.Color color8 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot9.getDataRange(valueAxis11);
        categoryPlot9.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        categoryPlot9.setParent((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.String str17 = categoryPlot14.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot14.getAxisOffset();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot14.setDomainGridlineStroke(stroke19);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color8, stroke19);
        java.awt.Paint paint22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color6, stroke19, paint22, stroke23, (float) 1L);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker28);
        float float30 = intervalMarker28.getAlpha();
        java.awt.Paint paint31 = intervalMarker28.getPaint();
        java.awt.Font font32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker28.setLabelFont(font32);
        categoryMarker25.setLabelFont(font32);
        categoryAxis1.setTickLabelFont(font32);
        org.jfree.chart.JFreeChart jFreeChart36 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font32, jFreeChart36, chartChangeEventType37);
        org.jfree.chart.JFreeChart jFreeChart39 = chartChangeEvent38.getChart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.8f + "'", float30 == 0.8f);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertNull(jFreeChart39);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot1.setDomainAxis((int) '#', categoryAxis4, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker11);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot1.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker11, layer13);
        boolean boolean15 = layer0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean19 = categoryAxis18.isAxisLineVisible();
        categoryAxis18.setTickMarksVisible(true);
        float float22 = categoryAxis18.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis18.getCategoryMiddle((int) ' ', 15, rectangle2D25, rectangleEdge26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint31 = intervalMarker30.getLabelPaint();
        categoryAxis18.setTickLabelPaint(paint31);
        java.awt.Font font34 = null;
        categoryAxis18.setTickLabelFont((java.lang.Comparable) "AxisLocation.BOTTOM_OR_RIGHT", font34);
        float float36 = categoryAxis18.getTickMarkInsideLength();
        try {
            categoryPlot1.setDomainAxis((-32513), categoryAxis18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis16.setLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = categoryAxis16.isAxisLineVisible();
        float float20 = categoryAxis16.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis22.configure();
        java.awt.Shape shape24 = numberAxis22.getUpArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis22);
        numberAxis22.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        java.awt.Font font16 = null;
        try {
            xYPlot13.setNoDataMessageFont(font16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis1.setRightArrow(shape6);
        numberAxis1.configure();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis12.setRange((double) 0L, 0.05d);
        org.jfree.data.RangeType rangeType16 = numberAxis12.getRangeType();
        numberAxis1.setRangeType(rangeType16);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rangeType16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getColorComponents(floatArray1);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color0.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setAnchorValue((double) (byte) 100, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis((int) (byte) 0);
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.util.List list21 = categoryPlot0.getCategoriesForAxis(categoryAxis20);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        intervalMarker2.setEndValue(3.0d);
        java.awt.Paint paint6 = intervalMarker2.getLabelPaint();
        double double7 = intervalMarker2.getStartValue();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        dateAxis0.configure();
        double double7 = dateAxis0.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge((int) ' ');
        try {
            double double16 = dateAxis0.valueToJava2D((double) (byte) 10, rectangle2D9, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot1.setDomainAxis((int) '#', categoryAxis4, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker11);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = categoryPlot1.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker11, layer13);
        boolean boolean15 = layer0.equals((java.lang.Object) categoryPlot1);
        categoryPlot1.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot1.getRangeAxis(7);
        categoryPlot1.setAnchorValue((double) 192, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot1.zoomDomainAxes((double) 12, plotRenderingInfo25, point2D26);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        float float5 = categoryAxis1.getTickMarkInsideLength();
        java.awt.Paint[] paintArray6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color8 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Color color15 = java.awt.Color.CYAN;
        int int16 = color15.getBlue();
        java.awt.Color color17 = java.awt.Color.red;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color7, color8, color15, color17, color18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray19, strokeArray20, strokeArray21, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextOutlinePaint();
        categoryAxis1.setTickLabelPaint(paint24);
        double double26 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis5, categoryItemRenderer6);
        categoryPlot7.clearAnnotations();
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot5.setNoDataMessage("Layer.FOREGROUND");
        boolean boolean10 = categoryPlot5.isRangeZoomable();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        categoryPlot0.setAnchorValue((double) (short) -1, false);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        boolean boolean16 = xYPlot13.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Color color3 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        java.lang.String str12 = categoryPlot9.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot9.setDomainGridlineStroke(stroke14);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color3, stroke14);
        java.awt.Paint paint17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color1, stroke14, paint17, stroke18, (float) 1L);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker23);
        float float25 = intervalMarker23.getAlpha();
        java.awt.Paint paint26 = intervalMarker23.getPaint();
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker23.setLabelFont(font27);
        categoryMarker20.setLabelFont(font27);
        categoryMarker20.setKey((java.lang.Comparable) "CategoryAnchor.END");
        java.lang.Object obj32 = categoryMarker20.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker13);
        float float15 = intervalMarker13.getAlpha();
        java.awt.Paint paint16 = intervalMarker13.getLabelPaint();
        intervalMarker13.setLabel("Category Plot");
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker13.setLabelPaint((java.awt.Paint) color19);
        java.awt.Paint paint21 = intervalMarker13.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot22.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.Range range25 = categoryPlot22.getDataRange(valueAxis24);
        categoryPlot22.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot27.getRangeAxis();
        categoryPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot27.setRenderer(categoryItemRenderer30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot27.setRenderer((int) (byte) 0, categoryItemRenderer33, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double37 = rectangleInsets36.getRight();
        double double39 = rectangleInsets36.calculateTopOutset(0.0d);
        categoryPlot27.setInsets(rectangleInsets36, false);
        intervalMarker13.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot27);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean44 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer43);
        org.jfree.chart.plot.Marker marker45 = null;
        try {
            boolean boolean46 = categoryPlot0.removeRangeMarker(marker45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.8f + "'", float15 == 0.8f);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.trimWidth((double) (short) -1);
        categoryPlot0.setAxisOffset(rectangleInsets9);
        categoryPlot0.setBackgroundAlpha((float) 255);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        java.awt.Paint paint11 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker11.setLabelAnchor(rectangleAnchor12);
        java.awt.Font font14 = intervalMarker11.getLabelFont();
        java.awt.Stroke stroke15 = intervalMarker11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker11, jFreeChart16, chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart8, chartChangeEventType17);
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        chartChangeEvent21.setChart(jFreeChart22);
        java.lang.Object obj24 = chartChangeEvent21.getSource();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        int int10 = categoryPlot5.getBackgroundImageAlignment();
        double double11 = categoryPlot5.getRangeCrosshairValue();
        categoryPlot5.setRangeCrosshairValue(100.0d);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = null;
        try {
            categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot18.getDataRange(valueAxis20);
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot23.getRangeAxis();
        categoryPlot18.setParent((org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot23.setRenderer(categoryItemRenderer26);
        int int28 = categoryPlot23.getBackgroundImageAlignment();
        categoryPlot23.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        categoryAxis32.setLabelURL("Category Plot");
        java.awt.Paint paint36 = null;
        categoryAxis32.setTickLabelPaint((java.lang.Comparable) 10.0d, paint36);
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 8);
        java.util.List list40 = categoryPlot23.getCategoriesForAxis(categoryAxis32);
        xYPlot13.drawDomainTickBands(graphics2D16, rectangle2D17, list40);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        org.jfree.chart.text.TextAnchor textAnchor8 = intervalMarker2.getLabelTextAnchor();
        java.awt.Stroke stroke9 = intervalMarker2.getStroke();
        java.lang.Object obj10 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth(97.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.0d + "'", double2 == 91.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker5.setLabelAnchor(rectangleAnchor6);
        boolean boolean8 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.java2DToValue(6.0d, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis17.configure();
        java.awt.Shape shape19 = numberAxis17.getUpArrow();
        boolean boolean20 = numberAxis17.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot22.setRenderer(xYItemRenderer23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot22.setRangeCrosshairStroke(stroke25);
        categoryPlot0.setRangeGridlineStroke(stroke25);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) '#');
        categoryPlot0.setDomainGridlinesVisible(true);
        java.awt.Paint paint13 = categoryPlot0.getOutlinePaint();
        try {
            categoryPlot0.mapDatasetToRangeAxis((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis1.getCategoryMiddle((int) ' ', 15, rectangle2D8, rectangleEdge9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        java.awt.Paint paint14 = intervalMarker13.getLabelPaint();
        categoryAxis1.setTickLabelPaint(paint14);
        java.awt.Font font17 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) "AxisLocation.BOTTOM_OR_RIGHT", font17);
        categoryAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor3);
        java.lang.String str5 = rectangleAnchor3.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str5.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        boolean boolean3 = day0.equals((java.lang.Object) 6);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        int int14 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge();
        int int16 = categoryPlot5.getRangeAxisCount();
        double double17 = categoryPlot5.getAnchorValue();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        categoryAxis2.setLabelToolTip("RectangleAnchor.BOTTOM");
        categoryAxis2.setTickMarksVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis10.java2DToValue(6.0d, rectangle2D12, rectangleEdge13);
        numberAxis10.setAutoTickUnitSelection(false, false);
        numberAxis10.centerRange((double) 10);
        boolean boolean20 = numberAxis10.isNegativeArrowVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        numberAxis10.setLabelPaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + Double.POSITIVE_INFINITY + "'", double14 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker40.setLabelAnchor(rectangleAnchor41);
        java.awt.Font font43 = intervalMarker40.getLabelFont();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot13.removeRangeMarker(6, (org.jfree.chart.plot.Marker) intervalMarker40, layer44);
        xYPlot13.setRangeCrosshairValue((double) ' ', true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot13.drawAnnotations(graphics2D16, rectangle2D17, plotRenderingInfo18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot21.getDataRange(valueAxis23);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot26.getRangeAxis();
        categoryPlot21.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot26.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (byte) 0, axisLocation31, false);
        xYPlot13.clearDomainAxes();
        xYPlot13.setDomainZeroBaselineVisible(true);
        org.jfree.chart.JFreeChart jFreeChart37 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean40 = chartChangeEventType38.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true, jFreeChart37, chartChangeEventType38);
        org.jfree.chart.JFreeChart jFreeChart42 = chartChangeEvent41.getChart();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(jFreeChart42);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.lang.String str10 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 12);
        double double15 = rectangleInsets11.calculateTopOutset((double) 0.8f);
        java.lang.String str16 = rectangleInsets11.toString();
        java.lang.String str17 = rectangleInsets11.toString();
        double double19 = rectangleInsets11.calculateBottomInset((double) ' ');
        categoryPlot5.setInsets(rectangleInsets11, true);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis23);
        java.lang.String str25 = numberAxis23.getLabelToolTip();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.0d + "'", double13 == 6.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str16.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str17.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        int int34 = xYPlot13.getDatasetCount();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray35 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot13.setRenderers(xYItemRendererArray35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.java2DToValue(6.0d, rectangle2D41, rectangleEdge42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis45.configure();
        java.awt.Shape shape47 = numberAxis45.getUpArrow();
        boolean boolean48 = numberAxis45.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis45, xYItemRenderer49);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot50.setDatasetRenderingOrder(datasetRenderingOrder51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot50.getDomainAxisLocation((int) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = xYPlot50.getRangeAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent60 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker59);
        float float61 = intervalMarker59.getAlpha();
        java.awt.Paint paint62 = intervalMarker59.getPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker65 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent66 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker65);
        org.jfree.chart.plot.Marker marker67 = markerChangeEvent66.getMarker();
        org.jfree.chart.plot.Marker marker68 = markerChangeEvent66.getMarker();
        org.jfree.chart.text.TextAnchor textAnchor69 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        marker68.setLabelTextAnchor(textAnchor69);
        intervalMarker59.setLabelTextAnchor(textAnchor69);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean74 = categoryPlot73.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = null;
        categoryPlot73.setDomainAxis((int) '#', categoryAxis76, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent79 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot73);
        org.jfree.chart.plot.IntervalMarker intervalMarker83 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent84 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker83);
        org.jfree.chart.util.Layer layer85 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean86 = categoryPlot73.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker83, layer85);
        boolean boolean87 = layer72.equals((java.lang.Object) categoryPlot73);
        java.lang.String str88 = layer72.toString();
        xYPlot50.addRangeMarker(11, (org.jfree.chart.plot.Marker) intervalMarker59, layer72);
        org.jfree.chart.util.Layer layer90 = null;
        try {
            xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker59, layer90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray35);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.8f + "'", float61 == 0.8f);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(marker67);
        org.junit.Assert.assertNotNull(marker68);
        org.junit.Assert.assertNotNull(textAnchor69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(layer85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "Layer.BACKGROUND" + "'", str88.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot13.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1560495599999L, (double) 12, (double) 0, (double) 10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker5.setLabelAnchor(rectangleAnchor6);
        boolean boolean8 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis((int) (short) 10, valueAxis7, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = categoryPlot5.getDrawingSupplier();
        boolean boolean15 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot5.zoomDomainAxes((double) (-1), plotRenderingInfo17, point2D18, false);
        java.awt.Stroke stroke21 = null;
        try {
            categoryPlot5.setRangeGridlineStroke(stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setLowerMargin((double) 6);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Color color1 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot2.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.data.Range range5 = categoryPlot2.getDataRange(valueAxis4);
        categoryPlot2.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot7.getRangeAxis();
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot7);
        java.lang.String str10 = categoryPlot7.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot7.getAxisOffset();
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke12);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color1, stroke12);
        java.lang.Comparable comparable15 = categoryMarker14.getKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0f + "'", comparable15.equals(1.0f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) 3, plotRenderingInfo6, point2D7);
        double double9 = categoryPlot0.getAnchorValue();
        java.awt.Paint paint10 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        boolean boolean3 = day0.equals((java.lang.Object) 6);
        int int4 = day0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = categoryAxis2.isAxisLineVisible();
        float float6 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = null;
        try {
            categoryPlot12.setRangeAxes(valueAxisArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        dateAxis0.configure();
        double double7 = dateAxis0.getUpperMargin();
        java.lang.Class class8 = null;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone11);
        dateAxis0.setMinimumDate(date9);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) 3, plotRenderingInfo6, point2D7);
        categoryPlot0.setBackgroundImageAlignment(2);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str5 = categoryAxis4.getLabel();
        boolean boolean6 = intervalMarker2.equals((java.lang.Object) categoryAxis4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str5.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, true, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis0.getTickUnit();
        java.awt.Shape shape6 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        boolean boolean31 = layer16.equals((java.lang.Object) categoryPlot17);
        java.lang.Object obj32 = null;
        boolean boolean33 = layer16.equals(obj32);
        java.util.Collection collection34 = xYPlot13.getRangeMarkers(layer16);
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        xYPlot13.setRangeAxis(255, valueAxis37, false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot0.getIndexOf(categoryItemRenderer5);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis10.setLabelPaint((java.awt.Paint) color11);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis10.setTickLabelFont(font13);
        categoryAxis10.clearCategoryLabelToolTips();
        boolean boolean16 = sortOrder8.equals((java.lang.Object) categoryAxis10);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        java.util.List list12 = categoryPlot5.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot5.handleClick(0, 0, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        java.lang.String str4 = color3.toString();
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color3.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        java.awt.Color color11 = color3.darker();
        int int12 = color3.getRGB();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=254,g=0,b=0]" + "'", str4.equals("java.awt.Color[r=254,g=0,b=0]"));
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-131072) + "'", int12 == (-131072));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot13.zoomRangeAxes((double) 15, plotRenderingInfo38, point2D39, false);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = xYPlot13.getRendererForDataset(xYDataset42);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(xYItemRenderer43);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        float[] floatArray22 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray23 = color11.getColorComponents(floatArray22);
        boolean boolean24 = plotOrientation10.equals((java.lang.Object) floatArray23);
        float[] floatArray25 = color9.getRGBColorComponents(floatArray23);
        float[] floatArray26 = color7.getComponents(floatArray25);
        float[] floatArray27 = color3.getColorComponents(floatArray25);
        float[] floatArray28 = color0.getComponents(colorSpace2, floatArray27);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=254,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=254,g=0,b=0]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot0.getIndexOf(categoryItemRenderer5);
        categoryPlot0.setAnchorValue((double) 1L, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        boolean boolean3 = day0.equals((java.lang.Object) 6);
        int int4 = day0.getYear();
        int int5 = day0.getMonth();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) int5, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = categoryMarker8.getLabelOffsetType();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis((int) (short) 0, valueAxis10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        categoryPlot5.setOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot13.drawAnnotations(graphics2D16, rectangle2D17, plotRenderingInfo18);
        java.awt.Stroke stroke20 = xYPlot13.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot13.setDataset(500, xYDataset22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot25.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot25.getDataRange(valueAxis27);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot25.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot25.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot25.setDomainGridlinePosition(categoryAnchor31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot34.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot34.getDomainAxisLocation();
        categoryPlot25.setRangeAxisLocation((int) '4', axisLocation36, true);
        xYPlot13.setRangeAxisLocation(8, axisLocation36);
        boolean boolean40 = xYPlot13.isRangeCrosshairVisible();
        java.awt.geom.Point2D point2D41 = null;
        try {
            xYPlot13.setQuadrantOrigin(point2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.JFreeChart jFreeChart3 = markerChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        double double17 = rectangleInsets14.calculateTopOutset(0.0d);
        categoryPlot5.setInsets(rectangleInsets14, false);
        categoryPlot5.setOutlineVisible(false);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = categoryAxis2.isAxisLineVisible();
        float float6 = categoryAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer11);
        java.awt.Font font13 = numberAxis8.getTickLabelFont();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot5.setRenderer(categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot5.setRenderer((int) (byte) 0, categoryItemRenderer11, false);
        int int14 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge();
        int int16 = categoryPlot5.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot5.getDatasetRenderingOrder();
        categoryPlot5.mapDatasetToDomainAxis((int) '4', (int) (short) 10);
        java.awt.Paint paint22 = null;
        try {
            categoryPlot5.setNoDataMessagePaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getColumnRenderingOrder();
        categoryPlot6.clearRangeMarkers();
        boolean boolean12 = intervalMarker2.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot6.getDomainAxis((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot6.getDomainAxisForDataset((int) 'a');
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.centerRange((double) 10);
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        boolean boolean12 = numberAxis1.isTickLabelsVisible();
        numberAxis1.resizeRange((double) (short) 0, (double) 43629L);
        numberAxis1.setUpperMargin((double) 2019);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        java.awt.Color color1 = java.awt.Color.BLACK;
//        java.awt.Color color3 = java.awt.Color.WHITE;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot4.getRangeAxis();
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.data.Range range7 = categoryPlot4.getDataRange(valueAxis6);
//        categoryPlot4.configureRangeAxes();
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
//        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
//        java.lang.String str12 = categoryPlot9.getPlotType();
//        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
//        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        categoryPlot9.setDomainGridlineStroke(stroke14);
//        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color3, stroke14);
//        java.awt.Paint paint17 = null;
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color1, stroke14, paint17, stroke18, (float) 1L);
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        long long23 = day22.getLastMillisecond();
//        int int24 = day22.getDayOfMonth();
//        categoryMarker20.setKey((java.lang.Comparable) int24);
//        java.lang.Comparable comparable26 = categoryMarker20.getKey();
//        org.junit.Assert.assertNotNull(color1);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNull(valueAxis5);
//        org.junit.Assert.assertNull(range7);
//        org.junit.Assert.assertNull(valueAxis10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
//        org.junit.Assert.assertNotNull(rectangleInsets13);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 13 + "'", comparable26.equals(13));
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) -1);
        double double4 = rectangleInsets0.extendHeight((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createOutsetRectangle(rectangle2D5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker40.setLabelAnchor(rectangleAnchor41);
        java.awt.Font font43 = intervalMarker40.getLabelFont();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot13.removeRangeMarker(6, (org.jfree.chart.plot.Marker) intervalMarker40, layer44);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis50.setLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = categoryAxis50.isAxisLineVisible();
        float float54 = categoryAxis50.getTickMarkInsideLength();
        boolean boolean55 = categoryAxis50.isAxisLineVisible();
        boolean boolean56 = valueMarker48.equals((java.lang.Object) categoryAxis50);
        valueMarker48.setValue((double) 0);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = numberAxis61.java2DToValue(6.0d, rectangle2D63, rectangleEdge64);
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis67.configure();
        java.awt.Shape shape69 = numberAxis67.getUpArrow();
        boolean boolean70 = numberAxis67.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis61, (org.jfree.chart.axis.ValueAxis) numberAxis67, xYItemRenderer71);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder73 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot72.setDatasetRenderingOrder(datasetRenderingOrder73);
        org.jfree.chart.axis.AxisLocation axisLocation76 = xYPlot72.getDomainAxisLocation((int) 'a');
        org.jfree.chart.plot.IntervalMarker intervalMarker80 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis82 = categoryPlot81.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray84 = new org.jfree.chart.axis.ValueAxis[] { valueAxis83 };
        categoryPlot81.setRangeAxes(valueAxisArray84);
        org.jfree.chart.plot.Marker marker86 = null;
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean88 = categoryPlot81.removeDomainMarker(marker86, layer87);
        xYPlot72.addDomainMarker(192, (org.jfree.chart.plot.Marker) intervalMarker80, layer87);
        xYPlot13.addDomainMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker48, layer87);
        float float91 = valueMarker48.getAlpha();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.0f + "'", float54 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + Double.POSITIVE_INFINITY + "'", double65 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder73);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNull(valueAxis82);
        org.junit.Assert.assertNotNull(valueAxisArray84);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + float91 + "' != '" + 0.8f + "'", float91 == 0.8f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        double double6 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        xYPlot13.clearRangeMarkers(0);
        java.awt.Stroke stroke39 = xYPlot13.getDomainCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot41.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.Range range44 = categoryPlot41.getDataRange(valueAxis43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot41.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot41.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot41.setDomainGridlinePosition(categoryAnchor47);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot50.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation52 = categoryPlot50.getDomainAxisLocation();
        categoryPlot41.setRangeAxisLocation((int) '4', axisLocation52, true);
        xYPlot13.setDomainAxisLocation(15, axisLocation52);
        xYPlot13.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        java.awt.Paint paint34 = xYPlot13.getRangeCrosshairPaint();
        xYPlot13.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        try {
            xYPlot13.zoomDomainAxes((double) 8, (double) (-12517377), plotRenderingInfo39, point2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.4) <= upper (-1.314324585E7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        boolean boolean3 = day0.equals((java.lang.Object) 6);
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
//        categoryPlot0.setRangeAxes(valueAxisArray3);
//        org.jfree.chart.plot.Marker marker5 = null;
//        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
//        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot0.setRangeAxisLocation(axisLocation8);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
//        categoryPlot0.setRenderer(categoryItemRenderer10);
//        java.awt.Color color13 = java.awt.Color.BLACK;
//        java.awt.Color color15 = java.awt.Color.WHITE;
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
//        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
//        org.jfree.data.Range range19 = categoryPlot16.getDataRange(valueAxis18);
//        categoryPlot16.configureRangeAxes();
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
//        categoryPlot16.setParent((org.jfree.chart.plot.Plot) categoryPlot21);
//        java.lang.String str24 = categoryPlot21.getPlotType();
//        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot21.getAxisOffset();
//        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        categoryPlot21.setDomainGridlineStroke(stroke26);
//        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color15, stroke26);
//        java.awt.Paint paint29 = null;
//        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color13, stroke26, paint29, stroke30, (float) 1L);
//        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        long long35 = day34.getLastMillisecond();
//        int int36 = day34.getDayOfMonth();
//        categoryMarker32.setKey((java.lang.Comparable) int36);
//        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker32);
//        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot39.getRangeAxis();
//        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        categoryPlot39.setBackgroundPaint((java.awt.Paint) color41);
//        boolean boolean43 = categoryMarker32.equals((java.lang.Object) color41);
//        org.junit.Assert.assertNull(valueAxis1);
//        org.junit.Assert.assertNotNull(valueAxisArray3);
//        org.junit.Assert.assertNotNull(layer6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(axisLocation8);
//        org.junit.Assert.assertNotNull(color13);
//        org.junit.Assert.assertNotNull(color15);
//        org.junit.Assert.assertNull(valueAxis17);
//        org.junit.Assert.assertNull(range19);
//        org.junit.Assert.assertNull(valueAxis22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
//        org.junit.Assert.assertNotNull(rectangleInsets25);
//        org.junit.Assert.assertNotNull(stroke26);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560495599999L + "'", long35 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 13 + "'", int36 == 13);
//        org.junit.Assert.assertNull(valueAxis40);
//        org.junit.Assert.assertNotNull(color41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        java.lang.String str16 = xYPlot13.getNoDataMessage();
        int int17 = xYPlot13.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot13.getLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot13.getFixedDomainAxisSpace();
        xYPlot13.setRangeCrosshairValue((double) 10L);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = numberAxis24.java2DToValue(6.0d, rectangle2D26, rectangleEdge27);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis30.configure();
        java.awt.Shape shape32 = numberAxis30.getUpArrow();
        boolean boolean33 = numberAxis30.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot35.setDatasetRenderingOrder(datasetRenderingOrder36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot35.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = numberAxis42.java2DToValue(6.0d, rectangle2D44, rectangleEdge45);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis48.configure();
        java.awt.Shape shape50 = numberAxis48.getUpArrow();
        boolean boolean51 = numberAxis48.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis48, xYItemRenderer52);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot53.setDatasetRenderingOrder(datasetRenderingOrder54);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot53.getDomainAxisLocation((int) 'a');
        xYPlot35.setDomainAxisLocation(axisLocation57);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis61.setLabelPaint((java.awt.Paint) color62);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis61, valueAxis64, categoryItemRenderer65);
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot66.getRangeAxisLocation();
        xYPlot35.setRangeAxisLocation(axisLocation67);
        xYPlot13.setDomainAxisLocation(axisLocation67);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(axisLocation67);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean7 = categoryAxis6.isAxisLineVisible();
        categoryAxis6.setTickMarksVisible(true);
        java.awt.Color color11 = java.awt.Color.BLACK;
        java.awt.Color color13 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot14.getDataRange(valueAxis16);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot19.getRangeAxis();
        categoryPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.lang.String str22 = categoryPlot19.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot19.getAxisOffset();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot19.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color13, stroke24);
        java.awt.Paint paint27 = null;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color11, stroke24, paint27, stroke28, (float) 1L);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker33);
        float float35 = intervalMarker33.getAlpha();
        java.awt.Paint paint36 = intervalMarker33.getPaint();
        java.awt.Font font37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker33.setLabelFont(font37);
        categoryMarker30.setLabelFont(font37);
        categoryAxis6.setTickLabelFont(font37);
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType42 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font37, jFreeChart41, chartChangeEventType42);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 2, jFreeChart4, chartChangeEventType42);
        java.lang.String str45 = chartChangeEventType42.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.8f + "'", float35 == 0.8f);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(chartChangeEventType42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str45.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { valueAxis8 };
        categoryPlot6.setRangeAxes(valueAxisArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot6.removeDomainMarker(marker11, layer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace14, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Plot plot18 = plotChangeEvent17.getPlot();
        java.lang.Class<?> wildcardClass19 = plot18.getClass();
        java.util.EventListener[] eventListenerArray20 = intervalMarker2.getListeners((java.lang.Class) wildcardClass19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        try {
            intervalMarker2.setLabelAnchor(rectangleAnchor21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(eventListenerArray20);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getColumnRenderingOrder();
        categoryPlot6.clearRangeMarkers();
        boolean boolean12 = intervalMarker2.equals((java.lang.Object) categoryPlot6);
        java.awt.Stroke stroke13 = null;
        try {
            intervalMarker2.setStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        java.awt.Paint paint34 = xYPlot13.getRangeCrosshairPaint();
        xYPlot13.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot13.getRangeAxis(11);
        java.awt.Stroke stroke39 = xYPlot13.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        xYPlot13.clearRangeMarkers(0);
        java.awt.Stroke stroke39 = xYPlot13.getDomainCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot41.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.Range range44 = categoryPlot41.getDataRange(valueAxis43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot41.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot41.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot41.setDomainGridlinePosition(categoryAnchor47);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot50.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation52 = categoryPlot50.getDomainAxisLocation();
        categoryPlot41.setRangeAxisLocation((int) '4', axisLocation52, true);
        xYPlot13.setDomainAxisLocation(15, axisLocation52);
        xYPlot13.setDomainCrosshairValue((double) 10.0f, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot0.getIndexOf(categoryItemRenderer5);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(7);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        boolean boolean11 = categoryPlot0.isSubplot();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis15.setLabelPaint((java.awt.Paint) color16);
        boolean boolean18 = categoryAxis15.isAxisLineVisible();
        float float19 = categoryAxis15.getTickMarkInsideLength();
        boolean boolean20 = categoryAxis15.isAxisLineVisible();
        boolean boolean21 = valueMarker13.equals((java.lang.Object) categoryAxis15);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        valueMarker13.setOutlinePaint(paint22);
        valueMarker13.setValue((double) 5);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot6.getColumnRenderingOrder();
        categoryPlot6.clearRangeMarkers();
        boolean boolean12 = intervalMarker2.equals((java.lang.Object) categoryPlot6);
        intervalMarker2.setStartValue(100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.trimWidth((double) (short) -1);
        intervalMarker2.setLabelOffset(rectangleInsets15);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets15.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) 1L, (double) 8, (double) (byte) 10, (double) 10L);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertNotNull(unitType19);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis16.setLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = categoryAxis16.isAxisLineVisible();
        float float20 = categoryAxis16.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis22.configure();
        java.awt.Shape shape24 = numberAxis22.getUpArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer25);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot13.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = categoryPlot0.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker10, layer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14, false);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.String str8 = categoryPlot5.getPlotType();
        categoryPlot5.setForegroundAlpha((float) 255);
        categoryPlot5.clearDomainMarkers();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot13.drawAnnotations(graphics2D16, rectangle2D17, plotRenderingInfo18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot21.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot21.getDataRange(valueAxis23);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot26.getRangeAxis();
        categoryPlot21.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot26.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (byte) 0, axisLocation31, false);
        xYPlot13.clearDomainAxes();
        xYPlot13.setDomainZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color38 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        float[] floatArray49 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray50 = color38.getColorComponents(floatArray49);
        boolean boolean51 = plotOrientation37.equals((java.lang.Object) floatArray50);
        java.awt.Color color52 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color54 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel55 = null;
        java.awt.Rectangle rectangle56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.awt.geom.AffineTransform affineTransform58 = null;
        java.awt.RenderingHints renderingHints59 = null;
        java.awt.PaintContext paintContext60 = color54.createContext(colorModel55, rectangle56, rectangle2D57, affineTransform58, renderingHints59);
        float[] floatArray65 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray66 = color54.getColorComponents(floatArray65);
        boolean boolean67 = plotOrientation53.equals((java.lang.Object) floatArray66);
        float[] floatArray68 = color52.getRGBColorComponents(floatArray66);
        int int69 = color52.getRed();
        boolean boolean70 = plotOrientation37.equals((java.lang.Object) int69);
        xYPlot13.setOrientation(plotOrientation37);
        org.jfree.chart.axis.AxisSpace axisSpace72 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace72);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paintContext60);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 255 + "'", int69 == 255);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        java.awt.Paint paint34 = xYPlot13.getRangeCrosshairPaint();
        xYPlot13.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot13.getRangeAxis(11);
        xYPlot13.setDomainCrosshairValue((double) 1560495599999L, true);
        xYPlot13.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        try {
            xYPlot13.setDataset((-16711681), xYDataset44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(valueAxis38);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = categoryPlot0.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker10, layer12);
        java.lang.String str14 = layer12.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.BACKGROUND" + "'", str14.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker40.setLabelAnchor(rectangleAnchor41);
        java.awt.Font font43 = intervalMarker40.getLabelFont();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot13.removeRangeMarker(6, (org.jfree.chart.plot.Marker) intervalMarker40, layer44);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = numberAxis47.java2DToValue(6.0d, rectangle2D49, rectangleEdge50);
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis47.setRightArrow(shape52);
        org.jfree.chart.axis.TickUnitSource tickUnitSource54 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis47.setStandardTickUnits(tickUnitSource54);
        java.text.NumberFormat numberFormat56 = null;
        numberAxis47.setNumberFormatOverride(numberFormat56);
        numberAxis47.setAutoRangeMinimumSize((double) 12, false);
        boolean boolean61 = layer44.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + Double.POSITIVE_INFINITY + "'", double51 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(tickUnitSource54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        java.awt.Paint paint34 = xYPlot13.getRangeCrosshairPaint();
        xYPlot13.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot13.getRangeAxis(11);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color39);
        java.lang.String str41 = color39.toString();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=255,g=64,b=64]" + "'", str41.equals("java.awt.Color[r=255,g=64,b=64]"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) '#');
        categoryPlot0.setDomainGridlinesVisible(true);
        java.awt.Color color14 = java.awt.Color.GREEN;
        java.awt.Color color15 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", color14);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 1, (float) 2);
        java.lang.String str23 = color22.toString();
        java.awt.Color color24 = java.awt.Color.WHITE;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color26 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color26.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        float[] floatArray37 = new float[] { (byte) 0, 1, (-1.0f), (-1) };
        float[] floatArray38 = color26.getColorComponents(floatArray37);
        boolean boolean39 = plotOrientation25.equals((java.lang.Object) floatArray38);
        float[] floatArray40 = color24.getRGBColorComponents(floatArray38);
        float[] floatArray41 = color22.getComponents(floatArray40);
        float[] floatArray42 = color15.getComponents(colorSpace18, floatArray40);
        org.jfree.data.general.Dataset dataset43 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) floatArray40, dataset43);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=254,g=0,b=0]" + "'", str23.equals("java.awt.Color[r=254,g=0,b=0]"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = categoryAxis3.isAxisLineVisible();
        float float7 = categoryAxis3.getTickMarkInsideLength();
        boolean boolean8 = categoryAxis3.isAxisLineVisible();
        boolean boolean9 = valueMarker1.equals((java.lang.Object) categoryAxis3);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        valueMarker1.setOutlinePaint(paint10);
        double double12 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets25.getRight();
        double double28 = rectangleInsets25.calculateTopOutset(0.0d);
        categoryPlot16.setInsets(rectangleInsets25, false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        boolean boolean33 = intervalMarker2.equals((java.lang.Object) "ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean2 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setTickMarksVisible(true);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot7.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { valueAxis9 };
        categoryPlot7.setRangeAxes(valueAxisArray10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = categoryPlot7.removeDomainMarker(marker12, layer13);
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker18.setLabelAnchor(rectangleAnchor19);
        java.awt.Font font21 = intervalMarker18.getLabelFont();
        java.awt.Stroke stroke22 = intervalMarker18.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean26 = chartChangeEventType24.equals((java.lang.Object) (-1.0f));
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker18, jFreeChart23, chartChangeEventType24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot7, jFreeChart15, chartChangeEventType24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart6, chartChangeEventType24);
        java.lang.Object obj30 = chartChangeEvent29.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.configure();
        numberAxis1.setVerticalTickLabels(false);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.java2DToValue(6.0d, rectangle2D8, rectangleEdge9);
        numberAxis6.setAutoTickUnitSelection(false, false);
        numberAxis6.centerRange((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis6.getTickUnit();
        numberAxis6.setUpperBound(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        numberAxis20.setAutoTickUnitSelection(false, false);
        numberAxis20.centerRange((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = numberAxis20.getTickUnit();
        numberAxis6.setTickUnit(numberTickUnit30, false, false);
        numberAxis1.setTickUnit(numberTickUnit30, true, true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit30);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot9.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation((int) '4', axisLocation11, true);
        java.lang.String str14 = axisLocation11.toString();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str14.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes((double) (-12517377), plotRenderingInfo15, point2D16);
        xYPlot13.setForegroundAlpha(2.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.05d, (-1.0d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Color color2 = java.awt.Color.getColor("", 15);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        float float4 = intervalMarker2.getAlpha();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        intervalMarker2.setLabel("Category Plot");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot11.getDataRange(valueAxis13);
        categoryPlot11.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot16.getRangeAxis();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot16.setRenderer((int) (byte) 0, categoryItemRenderer22, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets25.getRight();
        double double28 = rectangleInsets25.calculateTopOutset(0.0d);
        categoryPlot16.setInsets(rectangleInsets25, false);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        int int32 = categoryPlot16.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot16.setRenderer(categoryItemRenderer33);
        categoryPlot16.configureRangeAxes();
        java.util.List list36 = categoryPlot16.getAnnotations();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
        java.lang.String str8 = categoryAnchor6.toString();
        java.lang.String str9 = categoryAnchor6.toString();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CategoryAnchor.END" + "'", str8.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryAnchor.END" + "'", str9.equals("CategoryAnchor.END"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str2 = categoryAxis1.getLabel();
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint();
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        boolean boolean5 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str2.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 15, (float) (-16776961), (float) (short) -1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        java.awt.Color color19 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot20.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        categoryPlot20.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot25.getRangeAxis();
        categoryPlot20.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        java.lang.String str28 = categoryPlot25.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryPlot25.getAxisOffset();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot25.setDomainGridlineStroke(stroke30);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color19, stroke30);
        java.awt.Paint paint33 = categoryMarker32.getOutlinePaint();
        boolean boolean34 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker32);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener35 = null;
        categoryMarker32.removeChangeListener(markerChangeListener35);
        categoryMarker32.setKey((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Color color3 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", color2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.BOTTOM", (java.awt.Paint) color2, stroke4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.java2DToValue(6.0d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis26.configure();
        java.awt.Shape shape28 = numberAxis26.getUpArrow();
        boolean boolean29 = numberAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot31.getDomainAxisLocation((int) 'a');
        xYPlot13.setDomainAxisLocation(axisLocation35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis39.setLabelPaint((java.awt.Paint) color40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis39, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot44.getRangeAxisLocation();
        xYPlot13.setRangeAxisLocation(axisLocation45);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        xYPlot13.drawAnnotations(graphics2D47, rectangle2D48, plotRenderingInfo49);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        try {
            xYPlot13.setDataset((-16711681), xYDataset52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        int int18 = xYPlot13.getDatasetCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.8f);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean23 = categoryPlot22.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot22.setDomainAxis((int) '#', categoryAxis25, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot22);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean35 = categoryPlot22.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker32, layer34);
        xYPlot13.addDomainMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker21, layer34);
        java.lang.Comparable comparable37 = categoryMarker21.getKey();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 0.8f + "'", comparable37.equals(0.8f));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis((int) (short) 10, valueAxis7, false);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis13.setTickUnit(dateTickUnit14, true, true);
        java.util.TimeZone timeZone18 = dateAxis13.getTimeZone();
        boolean boolean20 = dateAxis13.isHiddenValue((long) (-12517377));
        java.lang.Class class21 = null;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone24);
        dateAxis13.setMinimumDate(date22);
        categoryPlot0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        boolean boolean28 = dateAxis13.isNegativeArrowVisible();
        java.awt.Paint paint29 = dateAxis13.getLabelPaint();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        double double31 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot13.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker27, layer32);
        int int34 = xYPlot13.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot13.zoomRangeAxes((double) (short) 100, plotRenderingInfo36, point2D37, false);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot13.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(axisSpace40);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot5.getRangeAxis();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.trimWidth((double) (short) -1);
        categoryPlot0.setAxisOffset(rectangleInsets9);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-12517377), (double) 500, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot13.setRenderer(xYItemRenderer14);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot17.setDomainAxis((int) '#', categoryAxis20, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot17);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot17.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
        boolean boolean31 = layer16.equals((java.lang.Object) categoryPlot17);
        java.lang.Object obj32 = null;
        boolean boolean33 = layer16.equals(obj32);
        java.util.Collection collection34 = xYPlot13.getRangeMarkers(layer16);
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot13.getFixedDomainAxisSpace();
        xYPlot13.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, true, true);
        java.util.Date date6 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot10.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        categoryPlot10.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot15.getRangeAxis();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        java.lang.String str18 = categoryPlot15.getPlotType();
        categoryPlot15.setForegroundAlpha((float) 255);
        categoryPlot15.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot15.getDomainAxisEdge((int) (short) 1);
        try {
            java.util.List list25 = dateAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        boolean boolean2 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot13.setRenderer(0, xYItemRenderer17);
        java.awt.Color color19 = java.awt.Color.black;
        xYPlot13.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_RIGHT");
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis23.setLabelPaint((java.awt.Paint) color24);
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis23.setTickLabelFont(font26);
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) (short) 10, "RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis31.setTickUnit(dateTickUnit32, true, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis31.getTickUnit();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer37);
        org.jfree.data.Range range39 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, true, true);
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", timeZone6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis7.setDateFormatOverride(dateFormat8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.java2DToValue(6.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis18.configure();
        java.awt.Shape shape20 = numberAxis18.getUpArrow();
        boolean boolean21 = numberAxis18.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot27.setDomainAxis((int) '#', categoryAxis30, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot27);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean40 = categoryPlot27.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker37, layer39);
        double double41 = intervalMarker37.getEndValue();
        org.jfree.chart.util.Layer layer42 = null;
        xYPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker37, layer42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace44);
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        xYPlot23.removeChangeListener(plotChangeListener47);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 10.0d + "'", double41 == 10.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] { valueAxis2 };
        categoryPlot0.setRangeAxes(valueAxisArray3);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setAnchorValue((double) (byte) 100, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis((int) (byte) 0);
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace17);
        boolean boolean19 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        int int18 = xYPlot13.getDatasetCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.8f);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean23 = categoryPlot22.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot22.setDomainAxis((int) '#', categoryAxis25, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot22);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean35 = categoryPlot22.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker32, layer34);
        xYPlot13.addDomainMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker21, layer34);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.CrosshairState crosshairState41 = null;
        boolean boolean42 = xYPlot13.render(graphics2D37, rectangle2D38, 2, plotRenderingInfo40, crosshairState41);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.java2DToValue(6.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis8.configure();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        boolean boolean11 = numberAxis8.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot13.getDomainAxisLocation((int) 'a');
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100, (double) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot22.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { valueAxis24 };
        categoryPlot22.setRangeAxes(valueAxisArray25);
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean29 = categoryPlot22.removeDomainMarker(marker27, layer28);
        xYPlot13.addDomainMarker(192, (org.jfree.chart.plot.Marker) intervalMarker21, layer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot13.zoomRangeAxes((double) 12, plotRenderingInfo32, point2D33);
        java.awt.Paint paint35 = xYPlot13.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.BOTTOM_LEFT");
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
        java.lang.String str8 = categoryAnchor6.toString();
        java.awt.Color color10 = java.awt.Color.BLACK;
        java.awt.Color color12 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot13.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot13.getDataRange(valueAxis15);
        categoryPlot13.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        categoryPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.String str21 = categoryPlot18.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot18.getAxisOffset();
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot18.setDomainGridlineStroke(stroke23);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0f, (java.awt.Paint) color12, stroke23);
        java.awt.Paint paint26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0E-8d, (java.awt.Paint) color10, stroke23, paint26, stroke27, (float) 1L);
        java.awt.Paint paint30 = categoryMarker29.getLabelPaint();
        boolean boolean31 = categoryAnchor6.equals((java.lang.Object) paint30);
        java.lang.String str32 = categoryAnchor6.toString();
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CategoryAnchor.END" + "'", str8.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CategoryAnchor.END" + "'", str32.equals("CategoryAnchor.END"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.java2DToValue(6.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis1.setRightArrow(shape6);
        numberAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis10.configure();
        java.awt.Shape shape12 = numberAxis10.getUpArrow();
        numberAxis1.setLeftArrow(shape12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRange((org.jfree.data.Range) dateRange14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getDomainAxisLocation();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean23 = categoryPlot22.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot22.setDomainAxis((int) '#', categoryAxis25, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot22);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean35 = categoryPlot22.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker32, layer34);
        boolean boolean36 = layer21.equals((java.lang.Object) categoryPlot22);
        boolean boolean37 = axisLocation20.equals((java.lang.Object) categoryPlot22);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot22.getDomainAxisEdge(192);
        try {
            double double40 = numberAxis1.lengthToJava2D(1.0E-8d, rectangle2D17, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, true, true);
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", timeZone6);
        java.text.DateFormat dateFormat8 = null;
        dateAxis7.setDateFormatOverride(dateFormat8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.java2DToValue(6.0d, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis18.configure();
        java.awt.Shape shape20 = numberAxis18.getUpArrow();
        boolean boolean21 = numberAxis18.isTickLabelsVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot27.setDomainAxis((int) '#', categoryAxis30, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot27);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean40 = categoryPlot27.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker37, layer39);
        double double41 = intervalMarker37.getEndValue();
        org.jfree.chart.util.Layer layer42 = null;
        xYPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker37, layer42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace44);
        dateAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot23);
        dateAxis7.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 10.0d + "'", double41 == 10.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot0.setDomainAxis((int) '#', categoryAxis3, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureDomainAxes();
        categoryPlot0.setBackgroundAlpha(10.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(collection8);
    }
}

