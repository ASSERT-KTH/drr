import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        long long19 = month18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month18, (double) 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        long long20 = day13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day13.previous();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries26.addPropertyChangeListener(propertyChangeListener27);
//        java.lang.String str29 = timeSeries26.getRangeDescription();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day32);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries26.addAndOrUpdate(timeSeries40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getSerialIndex();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        boolean boolean46 = year42.equals((java.lang.Object) day44);
//        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) day44);
//        boolean boolean48 = day13.equals((java.lang.Object) timeSeries40);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "13-June-2019" + "'", str45.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener11);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        int int33 = day13.getYear();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Object obj11 = null;
        boolean boolean12 = year8.equals(obj11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 2019L);
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(0, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        timeSeries4.clear();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate10.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
//        boolean boolean21 = spreadsheetDate14.isOnOrAfter(serialDate20);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Object obj40 = null;
//        boolean boolean41 = day35.equals(obj40);
//        java.util.Date date42 = day35.getStart();
//        java.lang.Class<?> wildcardClass43 = day35.getClass();
//        java.lang.ClassLoader classLoader44 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
//        boolean boolean45 = spreadsheetDate14.equals((java.lang.Object) classLoader44);
//        java.util.Date date46 = spreadsheetDate14.toDate();
//        boolean boolean47 = spreadsheetDate10.equals((java.lang.Object) spreadsheetDate14);
//        int int48 = spreadsheetDate10.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate49 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        boolean boolean55 = day53.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate56 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate56);
//        boolean boolean58 = spreadsheetDate51.isOnOrAfter(serialDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean61 = spreadsheetDate51.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        int int62 = spreadsheetDate51.getDayOfWeek();
//        try {
//            boolean boolean64 = spreadsheetDate10.isInRange(serialDate49, (org.jfree.data.time.SerialDate) spreadsheetDate51, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(classLoader44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 3 + "'", int62 == 3);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        boolean boolean4 = year0.equals((java.lang.Object) day2);
//        int int5 = year0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(13, serialDate6);
        java.lang.String str9 = serialDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setDomainDescription("30-June-2019");
//        java.lang.String str13 = timeSeries4.getDescription();
//        timeSeries4.setDomainDescription("Thursday");
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries4.getTimePeriod((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertNull(class10);
//        org.junit.Assert.assertNull(str13);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        long long15 = timeSeries14.getMaximumItemAge();
//        timeSeries14.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        timeSeries14.setMaximumItemCount(0);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        timeSeries24.setRangeDescription("hi!");
//        timeSeries24.setRangeDescription("");
//        boolean boolean29 = timeSeries24.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries14.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries4.addAndOrUpdate(timeSeries30);
//        java.lang.Object obj32 = timeSeries4.clone();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(obj32);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-41610));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("30-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class61);
//        java.beans.PropertyChangeListener propertyChangeListener63 = null;
//        timeSeries62.addPropertyChangeListener(propertyChangeListener63);
//        java.lang.String str65 = timeSeries62.getRangeDescription();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.lang.String str67 = day66.toString();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        boolean boolean70 = day68.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries62.createCopy((org.jfree.data.time.RegularTimePeriod) day66, (org.jfree.data.time.RegularTimePeriod) day68);
//        long long72 = timeSeries62.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener73 = null;
//        timeSeries62.addPropertyChangeListener(propertyChangeListener73);
//        boolean boolean75 = year57.equals((java.lang.Object) propertyChangeListener73);
//        java.util.Calendar calendar76 = null;
//        try {
//            long long77 = year57.getFirstMillisecond(calendar76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "13-June-2019" + "'", str67.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(timeSeries71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        int int18 = day13.getYear();
//        long long19 = day13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day13.next();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str15 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries26.getMaximumItemCount();
//        timeSeries26.setRangeDescription("December 3");
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean9 = day7.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(13, serialDate10);
        int int13 = day2.compareTo((java.lang.Object) serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(9999, serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate35);
//        java.lang.String str37 = serialDate35.toString();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
//        boolean boolean39 = spreadsheetDate1.isOnOrBefore(serialDate38);
//        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate1.getPreviousDayOfWeek(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        boolean boolean47 = day45.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate48 = day45.getSerialDate();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        boolean boolean51 = day49.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate52 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = serialDate48.getEndOfCurrentMonth(serialDate52);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        boolean boolean57 = day55.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate58 = day55.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate58);
//        java.lang.String str60 = serialDate58.toString();
//        org.jfree.data.time.SerialDate serialDate61 = serialDate53.getEndOfCurrentMonth(serialDate58);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        boolean boolean64 = day62.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate65 = day62.getSerialDate();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        boolean boolean68 = day66.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate70 = serialDate65.getEndOfCurrentMonth(serialDate69);
//        boolean boolean72 = spreadsheetDate44.isInRange(serialDate58, serialDate70, 2019);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addMonths(2, serialDate58);
//        org.jfree.data.time.SerialDate serialDate75 = serialDate58.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate76 = serialDate41.getEndOfCurrentMonth(serialDate58);
//        java.lang.String str77 = serialDate58.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "13-June-2019" + "'", str60.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "13-June-2019" + "'", str77.equals("13-June-2019"));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        java.lang.Comparable comparable9 = timeSeries4.getKey();
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        boolean boolean4 = year0.equals((java.lang.Object) day2);
//        long long5 = day2.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str9 = serialDate3.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str9);
//        java.lang.String str11 = timeSeries10.getDomainDescription();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        java.lang.Number number23 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 10.0f);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day29.equals(obj34);
//        java.util.Date date36 = day29.getStart();
//        java.lang.Class<?> wildcardClass37 = day29.getClass();
//        java.io.InputStream inputStream38 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass37);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.lang.String str46 = day45.toString();
//        java.lang.Number number47 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) day45);
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.String str54 = day53.toString();
//        java.lang.Number number55 = timeSeries52.getValue((org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day53, (double) 10.0f);
//        java.lang.Object obj58 = null;
//        boolean boolean59 = day53.equals(obj58);
//        java.util.Date date60 = day53.getStart();
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date60, timeZone61);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date60, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month64.previous();
//        java.lang.Number number66 = null;
//        try {
//            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month64, number66);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(inputStream38);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "13-June-2019" + "'", str46.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "13-June-2019" + "'", str54.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate35);
//        java.lang.String str37 = serialDate35.toString();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
//        boolean boolean39 = spreadsheetDate1.isOnOrBefore(serialDate38);
//        int int40 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        boolean boolean47 = day45.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate48 = day45.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate48);
//        boolean boolean50 = spreadsheetDate43.isOnOrAfter(serialDate49);
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.String str57 = day56.toString();
//        java.lang.Number number58 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.String str65 = day64.toString();
//        java.lang.Number number66 = timeSeries63.getValue((org.jfree.data.time.RegularTimePeriod) day64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries55.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day64, (double) 10.0f);
//        java.lang.Object obj69 = null;
//        boolean boolean70 = day64.equals(obj69);
//        java.util.Date date71 = day64.getStart();
//        java.lang.Class<?> wildcardClass72 = day64.getClass();
//        java.lang.ClassLoader classLoader73 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass72);
//        boolean boolean74 = spreadsheetDate43.equals((java.lang.Object) classLoader73);
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate43);
//        int int76 = spreadsheetDate43.getDayOfWeek();
//        int int77 = spreadsheetDate43.toSerial();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        boolean boolean79 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "13-June-2019" + "'", str57.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "13-June-2019" + "'", str65.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number66);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(classLoader73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 10 + "'", int77 == 10);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries4.removeChangeListener(seriesChangeListener9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.lang.String str4 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 3" + "'", str4.equals("December 3"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        int int7 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        java.util.Calendar calendar9 = null;
        try {
            month2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 3" + "'", str5.equals("December 3"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041132800001L) + "'", long6 == (-62041132800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        int int9 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
//        java.lang.Class<?> wildcardClass16 = serialDate14.getClass();
//        boolean boolean17 = spreadsheetDate1.isOnOrBefore(serialDate14);
//        int int18 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate26);
//        boolean boolean28 = spreadsheetDate21.isOnOrAfter(serialDate27);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        java.lang.Number number36 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        java.lang.Number number44 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) day42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) 10.0f);
//        java.lang.Object obj47 = null;
//        boolean boolean48 = day42.equals(obj47);
//        java.util.Date date49 = day42.getStart();
//        java.lang.Class<?> wildcardClass50 = day42.getClass();
//        java.lang.ClassLoader classLoader51 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass50);
//        boolean boolean52 = spreadsheetDate21.equals((java.lang.Object) classLoader51);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean54 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        java.lang.Class class58 = null;
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.lang.String str61 = day60.toString();
//        java.lang.Number number62 = timeSeries59.getValue((org.jfree.data.time.RegularTimePeriod) day60);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class66);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.String str69 = day68.toString();
//        java.lang.Number number70 = timeSeries67.getValue((org.jfree.data.time.RegularTimePeriod) day68);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day68, (double) 10.0f);
//        int int73 = day68.getYear();
//        org.jfree.data.time.SerialDate serialDate74 = day68.getSerialDate();
//        int int75 = spreadsheetDate1.compare(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(classLoader51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "13-June-2019" + "'", str61.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number62);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "13-June-2019" + "'", str69.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number70);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-43619) + "'", int75 == (-43619));
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        long long33 = day13.getFirstMillisecond();
//        int int34 = day13.getMonth();
//        int int35 = day13.getMonth();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 716968);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        int int15 = timeSeriesDataItem12.compareTo((java.lang.Object) regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        boolean boolean36 = year32.equals((java.lang.Object) day34);
//        int int37 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        timeSeries42.setRangeDescription("hi!");
//        java.lang.Class class45 = timeSeries42.getTimePeriodClass();
//        java.util.Collection collection46 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries42);
//        boolean boolean47 = timeSeries42.isEmpty();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, 100.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNull(class45);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries4.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        int int32 = day28.getYear();
//        long long33 = day28.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        java.lang.Number number35 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, number35);
//        int int37 = timeSeries4.getItemCount();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.Class<?> wildcardClass17 = serialDate15.getClass();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) 10.0f);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = day33.equals(obj38);
//        java.util.Date date40 = day33.getStart();
//        java.lang.Class<?> wildcardClass41 = day33.getClass();
//        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass41);
//        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass41);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date7, "ERROR : Relative To String", "December 3", (java.lang.Class) wildcardClass41);
//        timeSeries45.removeAgedItems((long) 'a', true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(inputStream42);
//        org.junit.Assert.assertNull(uRL43);
//        org.junit.Assert.assertNull(obj44);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1.0d + "'", obj2.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=1.0]"));
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        boolean boolean36 = year32.equals((java.lang.Object) day34);
//        int int37 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        timeSeries42.setRangeDescription("hi!");
//        java.lang.Class class45 = timeSeries42.getTimePeriodClass();
//        java.util.Collection collection46 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries42);
//        timeSeries42.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNull(class45);
//        org.junit.Assert.assertNotNull(collection46);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("SerialDate.weekInMonthToString(): invalid code.");
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setDomainDescription("30-June-2019");
//        java.lang.String str13 = timeSeries4.getDescription();
//        timeSeries4.setDomainDescription("Thursday");
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
//        java.lang.String str23 = timeSeries20.getRangeDescription();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        boolean boolean28 = day26.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries20.addAndOrUpdate(timeSeries34);
//        java.util.Collection collection36 = timeSeries20.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries20.addChangeListener(seriesChangeListener37);
//        timeSeries20.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries4.addAndOrUpdate(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertNull(class10);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        boolean boolean10 = day5.equals((java.lang.Object) "");
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day5.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Object obj5 = null;
        int int6 = month2.compareTo(obj5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day28.previous();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.util.Collection collection20 = timeSeries4.getTimePeriods();
//        boolean boolean21 = timeSeries4.getNotify();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.util.Collection collection20 = timeSeries4.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.Number number23 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNull(number23);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate10.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
//        boolean boolean21 = spreadsheetDate14.isOnOrAfter(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean24 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean31 = day29.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate28.getEndOfCurrentMonth(serialDate32);
//        java.lang.String str34 = serialDate33.toString();
//        java.lang.String str35 = serialDate33.toString();
//        java.lang.String str36 = serialDate33.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        boolean boolean42 = day40.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate43 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate43);
//        boolean boolean45 = spreadsheetDate38.isOnOrAfter(serialDate44);
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        java.lang.Number number53 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) day51);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        java.lang.String str60 = day59.toString();
//        java.lang.Number number61 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) day59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (double) 10.0f);
//        java.lang.Object obj64 = null;
//        boolean boolean65 = day59.equals(obj64);
//        java.util.Date date66 = day59.getStart();
//        java.lang.Class<?> wildcardClass67 = day59.getClass();
//        java.lang.ClassLoader classLoader68 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass67);
//        boolean boolean69 = spreadsheetDate38.equals((java.lang.Object) classLoader68);
//        boolean boolean71 = spreadsheetDate14.isInRange(serialDate33, (org.jfree.data.time.SerialDate) spreadsheetDate38, (int) (short) -1);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        boolean boolean76 = day74.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate77 = day74.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate77);
//        java.lang.String str79 = serialDate77.toString();
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addMonths(0, serialDate77);
//        org.jfree.data.time.SerialDate serialDate81 = spreadsheetDate14.getEndOfCurrentMonth(serialDate77);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        boolean boolean86 = day84.equals((java.lang.Object) 1);
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day();
//        boolean boolean91 = day89.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate92 = day89.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate92);
//        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.addYears(13, serialDate92);
//        int int95 = day84.compareTo((java.lang.Object) serialDate92);
//        org.jfree.data.time.SerialDate serialDate96 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate92);
//        org.jfree.data.time.SerialDate serialDate97 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate92);
//        boolean boolean99 = spreadsheetDate10.isInRange(serialDate81, serialDate97, 1900);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "30-June-2019" + "'", str34.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "30-June-2019" + "'", str35.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "13-June-2019" + "'", str52.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number53);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "13-June-2019" + "'", str60.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number61);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(classLoader68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "13-June-2019" + "'", str79.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertNotNull(serialDate93);
//        org.junit.Assert.assertNotNull(serialDate94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
//        org.junit.Assert.assertNotNull(serialDate96);
//        org.junit.Assert.assertNotNull(serialDate97);
//        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        java.util.Date date33 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getFirstMillisecond(calendar35);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2208268799252L) + "'", long36 == (-2208268799252L));
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        timeSeries12.clear();
//        int int17 = timeSeries12.getMaximumItemCount();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        java.lang.Number number33 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (double) 10.0f);
//        java.lang.Object obj36 = null;
//        boolean boolean37 = day31.equals(obj36);
//        java.util.Date date38 = day31.getStart();
//        java.lang.Number number39 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        java.lang.String str40 = day31.toString();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 1560495599999L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        java.lang.Comparable comparable9 = timeSeries4.getKey();
//        try {
//            timeSeries4.delete(5, 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener9);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getTimePeriod((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = timeSeries4.clone();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(obj18);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        timeSeries4.setMaximumItemAge((long) 2019);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.Number number22 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 10.0f);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        java.lang.Number number32 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries11.addAndOrUpdate(timeSeries29);
//        boolean boolean34 = timeSeries4.equals((java.lang.Object) timeSeries29);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        int int37 = month35.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries4.addOrUpdate(regularTimePeriod38, (double) 100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thursday");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) 10.0f);
//        java.lang.Object obj46 = null;
//        boolean boolean47 = day41.equals(obj46);
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date48, timeZone49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48, timeZone51);
//        int int53 = month52.getMonth();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
//        java.lang.String str61 = timeSeries58.getRangeDescription();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) day62, (org.jfree.data.time.RegularTimePeriod) day64);
//        java.lang.Class class71 = null;
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class71);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries58.addAndOrUpdate(timeSeries72);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        java.lang.String str75 = day74.toString();
//        java.lang.Object obj76 = null;
//        boolean boolean77 = day74.equals(obj76);
//        java.lang.Number number78 = timeSeries73.getValue((org.jfree.data.time.RegularTimePeriod) day74);
//        boolean boolean79 = month52.equals((java.lang.Object) day74);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "13-June-2019" + "'", str75.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNull(number78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        long long15 = timeSeries14.getMaximumItemAge();
//        timeSeries14.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        timeSeries14.setMaximumItemCount(0);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        timeSeries24.setRangeDescription("hi!");
//        timeSeries24.setRangeDescription("");
//        boolean boolean29 = timeSeries24.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries14.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries4.addAndOrUpdate(timeSeries30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener32);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        int int18 = day13.getYear();
//        org.jfree.data.time.SerialDate serialDate19 = day13.getSerialDate();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
//        java.lang.String str27 = timeSeries24.getRangeDescription();
//        timeSeries24.setNotify(true);
//        java.util.List list30 = timeSeries24.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
//        java.lang.String str41 = timeSeries38.getRangeDescription();
//        timeSeries38.setNotify(true);
//        java.util.List list44 = timeSeries38.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        long long48 = fixedMillisecond46.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond46.previous();
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.util.Date date51 = fixedMillisecond46.getTime();
//        int int52 = day13.compareTo((java.lang.Object) fixedMillisecond46);
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond46.getLastMillisecond(calendar53);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNotNull(list44);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 5L + "'", long48 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 5L + "'", long54 == 5L);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        long long33 = day13.getFirstMillisecond();
//        int int34 = day13.getMonth();
//        long long35 = day13.getFirstMillisecond();
//        java.lang.String str36 = day13.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        long long24 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond12.previous();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class61);
//        java.beans.PropertyChangeListener propertyChangeListener63 = null;
//        timeSeries62.addPropertyChangeListener(propertyChangeListener63);
//        java.lang.String str65 = timeSeries62.getRangeDescription();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.lang.String str67 = day66.toString();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        boolean boolean70 = day68.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries62.createCopy((org.jfree.data.time.RegularTimePeriod) day66, (org.jfree.data.time.RegularTimePeriod) day68);
//        long long72 = timeSeries62.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener73 = null;
//        timeSeries62.addPropertyChangeListener(propertyChangeListener73);
//        boolean boolean75 = year57.equals((java.lang.Object) propertyChangeListener73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year57.previous();
//        java.util.Date date77 = regularTimePeriod76.getStart();
//        long long78 = regularTimePeriod76.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "13-June-2019" + "'", str67.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(timeSeries71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1530561599999L + "'", long78 == 1530561599999L);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        int int14 = timeSeries4.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        java.lang.Number number33 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) 10.0f);
//        java.lang.Object obj44 = null;
//        boolean boolean45 = day39.equals(obj44);
//        java.util.Date date46 = day39.getStart();
//        java.lang.Class<?> wildcardClass47 = day39.getClass();
//        java.io.InputStream inputStream48 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass47);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.lang.Number number57 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) day55);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.lang.String str64 = day63.toString();
//        java.lang.Number number65 = timeSeries62.getValue((org.jfree.data.time.RegularTimePeriod) day63);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day63, (double) 10.0f);
//        java.lang.Object obj68 = null;
//        boolean boolean69 = day63.equals(obj68);
//        java.util.Date date70 = day63.getStart();
//        java.util.TimeZone timeZone71 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date70, timeZone71);
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16, (java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException75 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        boolean boolean76 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries73, (java.lang.Object) timePeriodFormatException75);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(inputStream48);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "13-June-2019" + "'", str64.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        java.lang.Number number33 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) 10.0f);
//        java.lang.Object obj44 = null;
//        boolean boolean45 = day39.equals(obj44);
//        java.util.Date date46 = day39.getStart();
//        java.lang.Class<?> wildcardClass47 = day39.getClass();
//        java.io.InputStream inputStream48 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass47);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.lang.Number number57 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) day55);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.lang.String str64 = day63.toString();
//        java.lang.Number number65 = timeSeries62.getValue((org.jfree.data.time.RegularTimePeriod) day63);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day63, (double) 10.0f);
//        java.lang.Object obj68 = null;
//        boolean boolean69 = day63.equals(obj68);
//        java.util.Date date70 = day63.getStart();
//        java.util.TimeZone timeZone71 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date70, timeZone71);
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16, (java.lang.Class) wildcardClass47);
//        long long74 = day16.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day16.previous();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(inputStream48);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "13-June-2019" + "'", str64.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560452399999L + "'", long74 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        try {
            timeSeries4.update(2019, (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries18.setDescription("30-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = serialDate27.getEndOfCurrentMonth(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        boolean boolean36 = day34.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate37 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate37);
//        java.lang.String str39 = serialDate37.toString();
//        org.jfree.data.time.SerialDate serialDate40 = serialDate32.getEndOfCurrentMonth(serialDate37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        boolean boolean43 = day41.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        boolean boolean47 = day45.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate48 = day45.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate49 = serialDate44.getEndOfCurrentMonth(serialDate48);
//        boolean boolean51 = spreadsheetDate23.isInRange(serialDate37, serialDate49, 2019);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        boolean boolean56 = day54.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate57 = day54.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate57);
//        java.lang.String str59 = serialDate57.toString();
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths(0, serialDate57);
//        boolean boolean61 = spreadsheetDate23.isOnOrBefore(serialDate60);
//        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate23.getPreviousDayOfWeek(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        boolean boolean69 = day67.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate70 = day67.getSerialDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        boolean boolean73 = day71.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate75 = serialDate70.getEndOfCurrentMonth(serialDate74);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        boolean boolean79 = day77.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate80 = day77.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate80);
//        java.lang.String str82 = serialDate80.toString();
//        org.jfree.data.time.SerialDate serialDate83 = serialDate75.getEndOfCurrentMonth(serialDate80);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        boolean boolean86 = day84.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate87 = day84.getSerialDate();
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day();
//        boolean boolean90 = day88.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate91 = day88.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate92 = serialDate87.getEndOfCurrentMonth(serialDate91);
//        boolean boolean94 = spreadsheetDate66.isInRange(serialDate80, serialDate92, 2019);
//        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addMonths(2, serialDate80);
//        org.jfree.data.time.SerialDate serialDate97 = serialDate80.getFollowingDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate98 = serialDate63.getEndOfCurrentMonth(serialDate80);
//        timeSeries18.setKey((java.lang.Comparable) serialDate98);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "13-June-2019" + "'", str59.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "13-June-2019" + "'", str82.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertNotNull(serialDate95);
//        org.junit.Assert.assertNotNull(serialDate97);
//        org.junit.Assert.assertNotNull(serialDate98);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
        serialDate7.setDescription("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
//        java.lang.Number number12 = timeSeries4.getValue(regularTimePeriod11);
//        java.lang.Object obj13 = timeSeries4.clone();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        long long15 = month14.getMiddleMillisecond();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        long long23 = timeSeries22.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass24 = timeSeries22.getClass();
//        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass24);
//        java.net.URL uRL26 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass24);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        java.lang.Number number42 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (double) 10.0f);
//        java.lang.Object obj45 = null;
//        boolean boolean46 = day40.equals(obj45);
//        java.util.Date date47 = day40.getStart();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date47, timeZone48);
//        boolean boolean50 = month14.equals((java.lang.Object) date47);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month14);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        long long59 = timeSeries58.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass60 = timeSeries58.getClass();
//        java.net.URL uRL61 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass60);
//        java.net.URL uRL62 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass60);
//        java.lang.ClassLoader classLoader63 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass60);
//        int int64 = month14.compareTo((java.lang.Object) classLoader63);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNull(uRL25);
//        org.junit.Assert.assertNull(uRL26);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNull(uRL61);
//        org.junit.Assert.assertNull(uRL62);
//        org.junit.Assert.assertNotNull(classLoader63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        long long11 = year7.getFirstMillisecond();
        int int12 = year7.getYear();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441076692L + "'", long1 == 1560441076692L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        long long24 = fixedMillisecond12.getFirstMillisecond();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond12.getFirstMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond12.getFirstMillisecond(calendar27);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 5L + "'", long28 == 5L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass9);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-460));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.Class<?> wildcardClass17 = serialDate15.getClass();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) 10.0f);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = day33.equals(obj38);
//        java.util.Date date40 = day33.getStart();
//        java.lang.Class<?> wildcardClass41 = day33.getClass();
//        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass41);
//        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass41);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date7, "ERROR : Relative To String", "December 3", (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date7);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(inputStream42);
//        org.junit.Assert.assertNull(uRL43);
//        org.junit.Assert.assertNull(obj44);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
        java.lang.String str10 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((-43619), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.Calendar calendar59 = null;
//        try {
//            long long60 = day58.getFirstMillisecond(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate15.getEndOfCurrentMonth(serialDate19);
//        java.lang.String str21 = serialDate20.toString();
//        java.lang.String str22 = serialDate20.toString();
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        boolean boolean29 = day27.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate30);
//        boolean boolean32 = spreadsheetDate25.isOnOrAfter(serialDate31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.lang.Class<?> wildcardClass54 = day46.getClass();
//        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass54);
//        boolean boolean56 = spreadsheetDate25.equals((java.lang.Object) classLoader55);
//        boolean boolean58 = spreadsheetDate1.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) (short) -1);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        boolean boolean63 = day61.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate64 = day61.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate64);
//        java.lang.String str66 = serialDate64.toString();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(0, serialDate64);
//        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate1.getEndOfCurrentMonth(serialDate64);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(classLoader55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "13-June-2019" + "'", str66.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        long long14 = day8.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        java.lang.Number number28 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) day26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (double) 10.0f);
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day26.equals(obj31);
//        java.util.Date date33 = day26.getStart();
//        java.lang.Class<?> wildcardClass34 = day26.getClass();
//        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass34);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        java.lang.Number number44 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) day42);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        java.lang.Number number52 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, (double) 10.0f);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = day50.equals(obj55);
//        java.util.Date date57 = day50.getStart();
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date57, timeZone58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day60, 0.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(inputStream35);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "13-June-2019" + "'", str51.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        int int9 = timeSeries4.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = day10.equals(obj12);
//        java.util.Date date14 = day10.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (double) 10.0f);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = day32.equals(obj37);
//        java.util.Date date39 = day32.getStart();
//        java.lang.Class<?> wildcardClass40 = day32.getClass();
//        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass40);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Number number50 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.String str57 = day56.toString();
//        java.lang.Number number58 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (double) 10.0f);
//        java.lang.Object obj61 = null;
//        boolean boolean62 = day56.equals(obj61);
//        java.util.Date date63 = day56.getStart();
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date63, timeZone64);
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date63, timeZone66);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date14, timeZone66);
//        int int69 = year68.getYear();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(inputStream41);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number50);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "13-June-2019" + "'", str57.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, 9999, 716968);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
//        int int3 = month2.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate10);
//        boolean boolean12 = spreadsheetDate5.isOnOrAfter(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean15 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getEndOfCurrentMonth(serialDate23);
//        java.lang.String str25 = serialDate24.toString();
//        java.lang.String str26 = serialDate24.toString();
//        java.lang.String str27 = serialDate24.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        boolean boolean33 = day31.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate34);
//        boolean boolean36 = spreadsheetDate29.isOnOrAfter(serialDate35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        java.lang.Number number44 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) day42);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        java.lang.Number number52 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, (double) 10.0f);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = day50.equals(obj55);
//        java.util.Date date57 = day50.getStart();
//        java.lang.Class<?> wildcardClass58 = day50.getClass();
//        java.lang.ClassLoader classLoader59 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass58);
//        boolean boolean60 = spreadsheetDate29.equals((java.lang.Object) classLoader59);
//        boolean boolean62 = spreadsheetDate5.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) (short) -1);
//        boolean boolean63 = month2.equals((java.lang.Object) (short) -1);
//        java.util.Date date64 = month2.getStart();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "30-June-2019" + "'", str25.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "13-June-2019" + "'", str51.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(classLoader59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(date64);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Date date14 = day8.getEnd();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date14);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate18);
//        boolean boolean20 = spreadsheetDate13.isOnOrAfter(serialDate19);
//        int int21 = spreadsheetDate1.compareTo((java.lang.Object) serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-80143) + "'", int21 == (-80143));
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        timeSeriesDataItem3.setValue((java.lang.Number) (byte) 10);
        int int7 = timeSeriesDataItem3.compareTo((java.lang.Object) 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        java.util.Calendar calendar17 = null;
        long long18 = regularTimePeriod15.getMiddleMillisecond(calendar17);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4L + "'", long18 == 4L);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        timeSeries4.setMaximumItemCount(3);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
//        java.lang.String str22 = timeSeries19.getRangeDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries19.addAndOrUpdate(timeSeries33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getSerialIndex();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        boolean boolean39 = year35.equals((java.lang.Object) day37);
//        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (double) 1L);
//        timeSeries4.setKey((java.lang.Comparable) (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        int int18 = day13.getMonth();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond1.getLastMillisecond();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass30);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond1.getFirstMillisecond(calendar57);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(716968);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.util.List list7 = timeSeries4.getItems();
        timeSeries4.clear();
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
        java.lang.String str9 = serialDate8.toString();
        java.lang.String str10 = serialDate8.toString();
        java.lang.String str11 = serialDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean17 = day15.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate18);
        boolean boolean20 = spreadsheetDate13.isOnOrAfter(serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean23 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean26 = day24.equals((java.lang.Object) 1);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean31 = day29.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears(13, serialDate32);
        int int35 = day24.compareTo((java.lang.Object) serialDate32);
        boolean boolean36 = spreadsheetDate13.isOnOrAfter(serialDate32);
        org.jfree.data.time.SerialDate serialDate37 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "30-June-2019" + "'", str9.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2019" + "'", str10.equals("30-June-2019"));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        java.lang.Class class0 = null;
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 10.0f);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day14.equals(obj19);
//        java.util.Date date21 = day14.getStart();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date21, timeZone22);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day29);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        java.lang.Number number39 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (double) 10.0f);
//        java.lang.Object obj42 = null;
//        boolean boolean43 = day37.equals(obj42);
//        java.util.Date date44 = day37.getStart();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44, timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date21, timeZone46);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date21);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone46);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond1.getLastMillisecond();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond58.previous();
//        java.util.Date date60 = fixedMillisecond58.getStart();
//        boolean boolean61 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) wildcardClass30, (java.lang.Object) fixedMillisecond58);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getStart();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        timeSeries27.setKey((java.lang.Comparable) 100.0d);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries34.addPropertyChangeListener(propertyChangeListener35);
//        java.lang.String str37 = timeSeries34.getRangeDescription();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        boolean boolean42 = day40.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) day40);
//        long long44 = timeSeries34.getMaximumItemAge();
//        java.lang.Object obj45 = null;
//        boolean boolean46 = timeSeries34.equals(obj45);
//        java.util.List list47 = timeSeries34.getItems();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries27.addAndOrUpdate(timeSeries34);
//        try {
//            timeSeries48.delete(12, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(list47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        int int36 = spreadsheetDate2.toSerial();
//        int int37 = spreadsheetDate2.getDayOfWeek();
//        java.util.Date date38 = spreadsheetDate2.toDate();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
//        org.junit.Assert.assertNotNull(date38);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
//        int int3 = month2.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate10);
//        boolean boolean12 = spreadsheetDate5.isOnOrAfter(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean15 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getEndOfCurrentMonth(serialDate23);
//        java.lang.String str25 = serialDate24.toString();
//        java.lang.String str26 = serialDate24.toString();
//        java.lang.String str27 = serialDate24.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        boolean boolean33 = day31.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate34);
//        boolean boolean36 = spreadsheetDate29.isOnOrAfter(serialDate35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        java.lang.Number number44 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) day42);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        java.lang.Number number52 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, (double) 10.0f);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = day50.equals(obj55);
//        java.util.Date date57 = day50.getStart();
//        java.lang.Class<?> wildcardClass58 = day50.getClass();
//        java.lang.ClassLoader classLoader59 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass58);
//        boolean boolean60 = spreadsheetDate29.equals((java.lang.Object) classLoader59);
//        boolean boolean62 = spreadsheetDate5.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) (short) -1);
//        boolean boolean63 = month2.equals((java.lang.Object) (short) -1);
//        long long64 = month2.getLastMillisecond();
//        long long65 = month2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "30-June-2019" + "'", str25.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "13-June-2019" + "'", str51.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(classLoader59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-62041132800001L) + "'", long64 == (-62041132800001L));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-62043811200000L) + "'", long65 == (-62043811200000L));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        long long15 = fixedMillisecond12.getSerialIndex();
        java.lang.Object obj16 = null;
        boolean boolean17 = fixedMillisecond12.equals(obj16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond12.previous();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 9999, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        int int36 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = day37.getLastMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries23.getDataItem((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        boolean boolean3 = day1.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate9);
        java.lang.String str11 = serialDate10.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8-October-2019" + "'", str11.equals("8-October-2019"));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond1.getLastMillisecond();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass30);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(class57);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries18.addChangeListener(seriesChangeListener32);
//        timeSeries18.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.lang.String str50 = day49.toString();
//        java.lang.Number number51 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) day49);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (double) 10.0f);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
//        java.lang.String str61 = timeSeries58.getRangeDescription();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) day62, (org.jfree.data.time.RegularTimePeriod) day64);
//        int int68 = day49.compareTo((java.lang.Object) day64);
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day64);
//        int int70 = day64.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day64, (double) 5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond73.previous();
//        long long76 = fixedMillisecond73.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "13-June-2019" + "'", str50.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560441081340L + "'", long76 == 1560441081340L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        boolean boolean10 = timeSeries4.getNotify();
        timeSeries4.setDescription("Time");
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        long long15 = fixedMillisecond12.getSerialIndex();
        java.lang.String str16 = fixedMillisecond12.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str16.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.util.Date date4 = day0.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date53, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date4, timeZone56);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.String str65 = day64.toString();
//        java.lang.Number number66 = timeSeries63.getValue((org.jfree.data.time.RegularTimePeriod) day64);
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        java.lang.String str73 = day72.toString();
//        java.lang.Number number74 = timeSeries71.getValue((org.jfree.data.time.RegularTimePeriod) day72);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day72, (double) 10.0f);
//        java.lang.Object obj77 = null;
//        boolean boolean78 = day72.equals(obj77);
//        java.util.Date date79 = day72.getStart();
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date79);
//        int int81 = year58.compareTo((java.lang.Object) date79);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "13-June-2019" + "'", str65.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number66);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "13-June-2019" + "'", str73.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number74);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean12 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean19 = day17.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate16.getEndOfCurrentMonth(serialDate20);
//        java.lang.String str22 = serialDate21.toString();
//        java.lang.String str23 = serialDate21.toString();
//        java.lang.String str24 = serialDate21.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate31);
//        boolean boolean33 = spreadsheetDate26.isOnOrAfter(serialDate32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (double) 10.0f);
//        java.lang.Object obj52 = null;
//        boolean boolean53 = day47.equals(obj52);
//        java.util.Date date54 = day47.getStart();
//        java.lang.Class<?> wildcardClass55 = day47.getClass();
//        java.lang.ClassLoader classLoader56 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass55);
//        boolean boolean57 = spreadsheetDate26.equals((java.lang.Object) classLoader56);
//        boolean boolean59 = spreadsheetDate2.isInRange(serialDate21, (org.jfree.data.time.SerialDate) spreadsheetDate26, (int) (short) -1);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2019" + "'", str23.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(classLoader56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate60);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 5L + "'", long10 == 5L);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries7.addChangeListener(seriesChangeListener21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) day36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries27.addChangeListener(seriesChangeListener41);
//        timeSeries27.setMaximumItemAge((long) (short) 10);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getSerialIndex();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        boolean boolean49 = year45.equals((java.lang.Object) day47);
//        java.lang.Number number50 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        java.util.Collection collection51 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries2.addAndOrUpdate(timeSeries27);
//        timeSeries2.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1.0]");
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 10.0d + "'", number50.equals(10.0d));
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        timeSeries4.setMaximumItemCount(3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries4.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        timeSeries4.setMaximumItemCount(3);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        java.lang.Number number23 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        timeSeries20.clear();
//        int int25 = timeSeries20.getMaximumItemCount();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        java.lang.Number number33 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) 10.0f);
//        java.lang.Object obj44 = null;
//        boolean boolean45 = day39.equals(obj44);
//        java.util.Date date46 = day39.getStart();
//        java.lang.Number number47 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.String str48 = day39.toString();
//        int int49 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.Object obj50 = null;
//        int int51 = day39.compareTo(obj50);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) 10.0d);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond1.getFirstMillisecond(calendar10);
//        long long12 = fixedMillisecond1.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate10.equals((java.lang.Object) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean19 = day17.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        boolean boolean22 = spreadsheetDate15.isOnOrAfter(serialDate21);
        java.lang.String str23 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        boolean boolean29 = day27.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate30);
        boolean boolean32 = spreadsheetDate25.isOnOrAfter(serialDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.util.Date date36 = spreadsheetDate34.toDate();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        boolean boolean38 = spreadsheetDate15.isOn(serialDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean44 = day42.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate45 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate45);
        boolean boolean47 = spreadsheetDate40.isOnOrAfter(serialDate46);
        int int48 = spreadsheetDate40.getMonth();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        boolean boolean52 = day50.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate53);
        java.lang.Class<?> wildcardClass55 = serialDate53.getClass();
        boolean boolean56 = spreadsheetDate40.isOnOrBefore(serialDate53);
        boolean boolean57 = spreadsheetDate15.isOnOrAfter(serialDate53);
        boolean boolean58 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        int int36 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        boolean boolean39 = day37.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate40 = day37.getSerialDate();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        boolean boolean43 = day41.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate45 = serialDate40.getEndOfCurrentMonth(serialDate44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate50);
//        java.lang.String str52 = serialDate50.toString();
//        org.jfree.data.time.SerialDate serialDate53 = serialDate45.getEndOfCurrentMonth(serialDate50);
//        int int54 = spreadsheetDate2.compare(serialDate45);
//        try {
//            org.jfree.data.time.SerialDate serialDate56 = serialDate45.getNearestDayOfWeek((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 9 + "'", int36 == 9);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "13-June-2019" + "'", str52.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-43636) + "'", int54 == (-43636));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean37 = day35.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate38 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate38);
//        boolean boolean40 = spreadsheetDate33.isOnOrAfter(serialDate39);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.String str55 = day54.toString();
//        java.lang.Number number56 = timeSeries53.getValue((org.jfree.data.time.RegularTimePeriod) day54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day54, (double) 10.0f);
//        java.lang.Object obj59 = null;
//        boolean boolean60 = day54.equals(obj59);
//        java.util.Date date61 = day54.getStart();
//        java.lang.Class<?> wildcardClass62 = day54.getClass();
//        java.lang.ClassLoader classLoader63 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass62);
//        boolean boolean64 = spreadsheetDate33.equals((java.lang.Object) classLoader63);
//        java.util.Date date65 = spreadsheetDate33.toDate();
//        boolean boolean66 = spreadsheetDate1.isInRange(serialDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "13-June-2019" + "'", str55.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number56);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(classLoader63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        java.lang.Class<?> wildcardClass21 = day13.getClass();
//        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
//        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(classLoader22);
//        org.junit.Assert.assertNotNull(classLoader23);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) 10.0f);
//        java.lang.Object obj46 = null;
//        boolean boolean47 = day41.equals(obj46);
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date48, timeZone49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48, timeZone51);
//        int int53 = month52.getMonth();
//        int int54 = month52.getYearValue();
//        int int55 = month52.getMonth();
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        long long8 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate35);
//        java.lang.String str37 = serialDate35.toString();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
//        boolean boolean39 = spreadsheetDate1.isOnOrBefore(serialDate38);
//        spreadsheetDate1.setDescription("May");
//        int int42 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate15.getEndOfCurrentMonth(serialDate19);
//        java.lang.String str21 = serialDate20.toString();
//        java.lang.String str22 = serialDate20.toString();
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        boolean boolean29 = day27.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate30);
//        boolean boolean32 = spreadsheetDate25.isOnOrAfter(serialDate31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.lang.Class<?> wildcardClass54 = day46.getClass();
//        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass54);
//        boolean boolean56 = spreadsheetDate25.equals((java.lang.Object) classLoader55);
//        boolean boolean58 = spreadsheetDate1.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) (short) -1);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        boolean boolean63 = day61.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate64 = day61.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate64);
//        java.lang.String str66 = serialDate64.toString();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(0, serialDate64);
//        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate1.getEndOfCurrentMonth(serialDate64);
//        java.lang.String str69 = serialDate68.toString();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(classLoader55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "13-June-2019" + "'", str66.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "30-June-2019" + "'", str69.equals("30-June-2019"));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener9);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries18.addChangeListener(seriesChangeListener32);
//        timeSeries18.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.lang.String str50 = day49.toString();
//        java.lang.Number number51 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) day49);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (double) 10.0f);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
//        java.lang.String str61 = timeSeries58.getRangeDescription();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) day62, (org.jfree.data.time.RegularTimePeriod) day64);
//        int int68 = day49.compareTo((java.lang.Object) day64);
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day64);
//        int int70 = day64.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day64, (double) 5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = timeSeries4.getNextTimePeriod();
//        java.lang.Class class77 = null;
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class77);
//        java.beans.PropertyChangeListener propertyChangeListener79 = null;
//        timeSeries78.addPropertyChangeListener(propertyChangeListener79);
//        java.lang.String str81 = timeSeries78.getRangeDescription();
//        timeSeries78.setNotify(true);
//        java.util.List list84 = timeSeries78.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries78.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86);
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries4.addAndOrUpdate(timeSeries78);
//        int int89 = timeSeries88.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "13-June-2019" + "'", str50.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "" + "'", str81.equals(""));
//        org.junit.Assert.assertNotNull(list84);
//        org.junit.Assert.assertNull(timeSeriesDataItem87);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 2147483647 + "'", int89 == 2147483647);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        long long17 = regularTimePeriod15.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4L + "'", long17 == 4L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean14 = day12.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(13, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate8.getEndOfCurrentMonth(serialDate17);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(11, serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        boolean boolean11 = day9.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate8.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate13);
        boolean boolean15 = month2.equals((java.lang.Object) (short) 100);
        int int16 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        boolean boolean11 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56);
//        java.util.Calendar calendar59 = null;
//        try {
//            year58.peg(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        timeSeriesDataItem3.setValue((java.lang.Number) (byte) 10);
        java.lang.Number number6 = timeSeriesDataItem3.getValue();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean9 = day7.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean13 = day11.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate14);
        java.lang.String str16 = serialDate10.getDescription();
        int int17 = timeSeriesDataItem3.compareTo((java.lang.Object) serialDate10);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate10.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean19 = day17.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
//        boolean boolean22 = spreadsheetDate15.isOnOrAfter(serialDate21);
//        int int23 = spreadsheetDate15.getMonth();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate28);
//        java.lang.String str30 = serialDate28.toString();
//        java.lang.String str31 = serialDate28.toString();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        boolean boolean38 = day36.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate40 = serialDate35.getEndOfCurrentMonth(serialDate39);
//        java.lang.String str41 = serialDate35.toString();
//        boolean boolean43 = spreadsheetDate15.isInRange(serialDate28, serialDate35, (int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, serialDate35);
//        boolean boolean45 = spreadsheetDate10.isOnOrAfter(serialDate35);
//        int int46 = spreadsheetDate10.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        timeSeries27.setKey((java.lang.Comparable) 100.0d);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries34.addPropertyChangeListener(propertyChangeListener35);
//        java.lang.String str37 = timeSeries34.getRangeDescription();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        boolean boolean42 = day40.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) day40);
//        long long44 = timeSeries34.getMaximumItemAge();
//        java.lang.Object obj45 = null;
//        boolean boolean46 = timeSeries34.equals(obj45);
//        java.util.List list47 = timeSeries34.getItems();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries27.addAndOrUpdate(timeSeries34);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.String str55 = day54.toString();
//        java.lang.Number number56 = timeSeries53.getValue((org.jfree.data.time.RegularTimePeriod) day54);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        java.lang.Number number64 = timeSeries61.getValue((org.jfree.data.time.RegularTimePeriod) day62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) 10.0f);
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class70);
//        java.beans.PropertyChangeListener propertyChangeListener72 = null;
//        timeSeries71.addPropertyChangeListener(propertyChangeListener72);
//        java.lang.String str74 = timeSeries71.getRangeDescription();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        java.lang.String str76 = day75.toString();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        boolean boolean79 = day77.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) day75, (org.jfree.data.time.RegularTimePeriod) day77);
//        int int81 = day62.compareTo((java.lang.Object) day77);
//        long long82 = day62.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day62.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = day62.previous();
//        java.util.Date date85 = day62.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (java.lang.Number) 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(list47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "13-June-2019" + "'", str55.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number56);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number64);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "13-June-2019" + "'", str76.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560409200000L + "'", long82 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNull(timeSeriesDataItem87);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Object obj9 = timeSeries4.clone();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 100.0d);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        try {
//            timeSeries4.add(timeSeriesDataItem31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(obj32);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        java.util.List list10 = timeSeries4.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long14 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
//        java.util.Calendar calendar22 = null;
//        fixedMillisecond12.peg(calendar22);
//        long long24 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate31);
//        boolean boolean33 = spreadsheetDate26.isOnOrAfter(serialDate32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (double) 10.0f);
//        java.lang.Object obj52 = null;
//        boolean boolean53 = day47.equals(obj52);
//        java.util.Date date54 = day47.getStart();
//        java.lang.Class<?> wildcardClass55 = day47.getClass();
//        java.lang.ClassLoader classLoader56 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass55);
//        boolean boolean57 = spreadsheetDate26.equals((java.lang.Object) classLoader56);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader56);
//        int int59 = fixedMillisecond12.compareTo((java.lang.Object) classLoader56);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        boolean boolean61 = fixedMillisecond12.equals((java.lang.Object) month60);
//        java.util.Date date62 = month60.getEnd();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(date62);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(classLoader56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(date62);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
        java.lang.String str9 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate16);
        boolean boolean18 = spreadsheetDate11.isOnOrAfter(serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean21 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date22 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        boolean boolean24 = spreadsheetDate1.isOn(serialDate23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean27 = day25.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean31 = day29.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = serialDate28.getEndOfCurrentMonth(serialDate32);
        boolean boolean34 = spreadsheetDate1.isOnOrAfter(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        timeSeries4.setNotify(true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.lang.Class<?> wildcardClass6 = fixedMillisecond1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str9 = serialDate3.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str9);
//        java.lang.String str11 = timeSeries10.getDomainDescription();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (double) 10.0f);
//        java.lang.Object obj30 = null;
//        boolean boolean31 = day25.equals(obj30);
//        long long32 = day25.getSerialIndex();
//        long long33 = day25.getFirstMillisecond();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day25, (double) 100, false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        timeSeries4.setMaximumItemCount(3);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
//        java.lang.String str22 = timeSeries19.getRangeDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries19.addAndOrUpdate(timeSeries33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getSerialIndex();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        boolean boolean39 = year35.equals((java.lang.Object) day37);
//        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (double) 1L);
//        java.lang.String str43 = timeSeries4.getDescription();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNull(str43);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        boolean boolean61 = day59.equals((java.lang.Object) 1);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate67 = day64.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate67);
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addYears(13, serialDate67);
//        int int70 = day59.compareTo((java.lang.Object) serialDate67);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate67);
//        int int72 = year57.compareTo((java.lang.Object) serialDate67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year57.next();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean14 = day12.equals((java.lang.Object) 1);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean19 = day17.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(13, serialDate20);
        int int23 = day12.compareTo((java.lang.Object) serialDate20);
        boolean boolean24 = spreadsheetDate1.isOnOrAfter(serialDate20);
        int int25 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.util.Calendar calendar58 = null;
//        try {
//            long long59 = year57.getFirstMillisecond(calendar58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5L + "'", long16 == 5L);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone22);
//        java.lang.String str24 = year23.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries18.addChangeListener(seriesChangeListener32);
//        timeSeries18.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.lang.String str50 = day49.toString();
//        java.lang.Number number51 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) day49);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day49, (double) 10.0f);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
//        java.lang.String str61 = timeSeries58.getRangeDescription();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) day62, (org.jfree.data.time.RegularTimePeriod) day64);
//        int int68 = day49.compareTo((java.lang.Object) day64);
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day64);
//        int int70 = day64.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day64, (double) 5);
//        long long73 = day64.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "13-June-2019" + "'", str50.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43629L + "'", long73 == 43629L);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1L + "'", obj2.equals(1L));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1L + "'", obj3.equals(1L));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1L + "'", obj4.equals(1L));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 1L + "'", obj5.equals(1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        timeSeries4.setRangeDescription("hi!");
//        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
//        java.lang.Number number12 = timeSeries4.getValue(regularTimePeriod11);
//        java.lang.Object obj13 = timeSeries4.clone();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        long long15 = month14.getMiddleMillisecond();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        long long23 = timeSeries22.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass24 = timeSeries22.getClass();
//        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass24);
//        java.net.URL uRL26 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass24);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        java.lang.Number number42 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (double) 10.0f);
//        java.lang.Object obj45 = null;
//        boolean boolean46 = day40.equals(obj45);
//        java.util.Date date47 = day40.getStart();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date47, timeZone48);
//        boolean boolean50 = month14.equals((java.lang.Object) date47);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month14);
//        java.util.Date date52 = month14.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNull(uRL25);
//        org.junit.Assert.assertNull(uRL26);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate10.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
//        boolean boolean21 = spreadsheetDate14.isOnOrAfter(serialDate20);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Object obj40 = null;
//        boolean boolean41 = day35.equals(obj40);
//        java.util.Date date42 = day35.getStart();
//        java.lang.Class<?> wildcardClass43 = day35.getClass();
//        java.lang.ClassLoader classLoader44 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
//        boolean boolean45 = spreadsheetDate14.equals((java.lang.Object) classLoader44);
//        java.util.Date date46 = spreadsheetDate14.toDate();
//        boolean boolean47 = spreadsheetDate10.equals((java.lang.Object) spreadsheetDate14);
//        int int48 = spreadsheetDate10.getDayOfMonth();
//        java.lang.String str49 = spreadsheetDate10.toString();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(classLoader44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-January-1900" + "'", str49.equals("9-January-1900"));
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(13, serialDate5);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate5, obj8);
//        java.lang.String str10 = serialDate5.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) 10.0f);
//        java.lang.Object obj46 = null;
//        boolean boolean47 = day41.equals(obj46);
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date48, timeZone49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month52.previous();
//        int int54 = month52.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month52.next();
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = day10.equals(obj12);
//        java.util.Date date14 = day10.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (double) 10.0f);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = day32.equals(obj37);
//        java.util.Date date39 = day32.getStart();
//        java.lang.Class<?> wildcardClass40 = day32.getClass();
//        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass40);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Number number50 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.String str57 = day56.toString();
//        java.lang.Number number58 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (double) 10.0f);
//        java.lang.Object obj61 = null;
//        boolean boolean62 = day56.equals(obj61);
//        java.util.Date date63 = day56.getStart();
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date63, timeZone64);
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date63, timeZone66);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date14, timeZone66);
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date7, timeZone66);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(inputStream41);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number50);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "13-June-2019" + "'", str57.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(timeZone66);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number26);
        timeSeriesDataItem27.setValue((java.lang.Number) (byte) 1);
        java.lang.Object obj30 = null;
        int int31 = timeSeriesDataItem27.compareTo(obj30);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate35);
//        java.lang.String str37 = serialDate35.toString();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
//        boolean boolean39 = spreadsheetDate1.isOnOrBefore(serialDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        boolean boolean45 = day43.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate46 = day43.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate46);
//        boolean boolean48 = spreadsheetDate41.isOnOrAfter(serialDate47);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean51 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        int int52 = spreadsheetDate50.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        boolean boolean58 = day56.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate59 = day56.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate59);
//        boolean boolean61 = spreadsheetDate54.isOnOrAfter(serialDate60);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.lang.String str68 = day67.toString();
//        java.lang.Number number69 = timeSeries66.getValue((org.jfree.data.time.RegularTimePeriod) day67);
//        java.lang.Class class73 = null;
//        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        java.lang.String str76 = day75.toString();
//        java.lang.Number number77 = timeSeries74.getValue((org.jfree.data.time.RegularTimePeriod) day75);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day75, (double) 10.0f);
//        java.lang.Object obj80 = null;
//        boolean boolean81 = day75.equals(obj80);
//        java.util.Date date82 = day75.getStart();
//        java.lang.Class<?> wildcardClass83 = day75.getClass();
//        java.lang.ClassLoader classLoader84 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass83);
//        boolean boolean85 = spreadsheetDate54.equals((java.lang.Object) classLoader84);
//        java.util.Date date86 = spreadsheetDate54.toDate();
//        boolean boolean87 = spreadsheetDate50.equals((java.lang.Object) spreadsheetDate54);
//        java.lang.String str88 = spreadsheetDate50.getDescription();
//        org.jfree.data.time.SerialDate serialDate89 = serialDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "13-June-2019" + "'", str68.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number69);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "13-June-2019" + "'", str76.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number77);
//        org.junit.Assert.assertNull(timeSeriesDataItem79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(wildcardClass83);
//        org.junit.Assert.assertNotNull(classLoader84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNull(str88);
//        org.junit.Assert.assertNotNull(serialDate89);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int4 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        java.util.Date date33 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class38);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries39.addPropertyChangeListener(propertyChangeListener40);
//        java.lang.String str42 = timeSeries39.getRangeDescription();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        boolean boolean47 = day45.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day45);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries39.addAndOrUpdate(timeSeries53);
//        int int55 = fixedMillisecond34.compareTo((java.lang.Object) timeSeries39);
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond34.getLastMillisecond(calendar56);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "13-June-2019" + "'", str44.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-2208268799984L) + "'", long57 == (-2208268799984L));
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries26.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries26.addChangeListener(seriesChangeListener28);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Object obj9 = timeSeries4.clone();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
        long long15 = timeSeries14.getMaximumItemAge();
        java.lang.Class<?> wildcardClass16 = timeSeries14.getClass();
        timeSeries14.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries14);
        java.lang.String str20 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        timeSeries4.setMaximumItemCount(3);
        boolean boolean12 = timeSeries4.isEmpty();
        timeSeries4.setDomainDescription("8-October-2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-460));
//        long long22 = day13.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43629L + "'", long22 == 43629L);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "December" + "'", str1.equals("December"));
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        int int9 = timeSeries4.getItemCount();
//        timeSeries4.setDescription("Wed Dec 31 16:00:00 PST 1969");
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) day11);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) 10.0f);
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day19.equals(obj24);
//        java.util.Date date26 = day19.getStart();
//        java.lang.Class<?> wildcardClass27 = day19.getClass();
//        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass27);
//        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass27);
//        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass27);
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("30-June-2019", (java.lang.Class) wildcardClass27);
//        java.io.InputStream inputStream32 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass27);
//        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thursday", (java.lang.Class) wildcardClass27);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(inputStream28);
//        org.junit.Assert.assertNull(uRL29);
//        org.junit.Assert.assertNull(obj30);
//        org.junit.Assert.assertNull(inputStream31);
//        org.junit.Assert.assertNotNull(inputStream32);
//        org.junit.Assert.assertNull(uRL33);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class10);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getRangeDescription();
        java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year22);
        java.lang.Object obj25 = null;
        boolean boolean26 = year22.equals(obj25);
        long long27 = year22.getLastMillisecond();
        int int28 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        java.lang.String str29 = year22.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        timeSeriesDataItem3.setValue((java.lang.Number) (byte) 10);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str9 = month8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        java.lang.String str11 = month8.toString();
        boolean boolean12 = timeSeriesDataItem3.equals((java.lang.Object) month8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "December 3" + "'", str9.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December 3" + "'", str11.equals("December 3"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 7);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "Time", "ClassContext", class5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
        java.lang.String str9 = serialDate8.toString();
        java.lang.String str10 = serialDate8.toString();
        java.lang.String str11 = serialDate8.getDescription();
        java.lang.String str12 = serialDate8.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "30-June-2019" + "'", str9.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2019" + "'", str10.equals("30-June-2019"));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "30-June-2019" + "'", str12.equals("30-June-2019"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
//        boolean boolean10 = spreadsheetDate3.isOnOrAfter(serialDate9);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (double) 10.0f);
//        java.lang.Object obj29 = null;
//        boolean boolean30 = day24.equals(obj29);
//        java.util.Date date31 = day24.getStart();
//        java.lang.Class<?> wildcardClass32 = day24.getClass();
//        java.lang.ClassLoader classLoader33 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass32);
//        boolean boolean34 = spreadsheetDate3.equals((java.lang.Object) classLoader33);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int36 = spreadsheetDate3.getDayOfWeek();
//        int int37 = spreadsheetDate3.toSerial();
//        try {
//            org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(13, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(classLoader33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        int int36 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) 6);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) 10.0f);
//        java.lang.Object obj46 = null;
//        boolean boolean47 = day41.equals(obj46);
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date48, timeZone49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48, timeZone51);
//        java.util.Calendar calendar53 = null;
//        try {
//            long long54 = month52.getFirstMillisecond(calendar53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeZone51);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        boolean boolean36 = day34.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate37 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate38 = serialDate33.getEndOfCurrentMonth(serialDate37);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        boolean boolean42 = day40.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate43 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate43);
//        java.lang.String str45 = serialDate43.toString();
//        org.jfree.data.time.SerialDate serialDate46 = serialDate38.getEndOfCurrentMonth(serialDate43);
//        boolean boolean47 = spreadsheetDate1.isOn(serialDate46);
//        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str50 = seriesException49.toString();
//        java.lang.Throwable[] throwableArray51 = seriesException49.getSuppressed();
//        try {
//            int int52 = spreadsheetDate1.compareTo((java.lang.Object) seriesException49);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.general.SeriesException cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "13-June-2019" + "'", str45.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str50.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertNotNull(throwableArray51);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        long long15 = timeSeries14.getMaximumItemAge();
//        timeSeries14.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        timeSeries14.setMaximumItemCount(0);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        timeSeries24.setRangeDescription("hi!");
//        timeSeries24.setRangeDescription("");
//        boolean boolean29 = timeSeries24.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries14.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries4.addAndOrUpdate(timeSeries30);
//        java.lang.Number number33 = null;
//        try {
//            timeSeries30.update((-43619), number33);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate10.toSerial();
        spreadsheetDate10.setDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean17 = day15.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        boolean boolean21 = day19.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = serialDate18.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean26 = day24.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        boolean boolean30 = day28.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate32 = serialDate27.getEndOfCurrentMonth(serialDate31);
        java.lang.String str33 = serialDate32.toString();
        java.lang.String str34 = serialDate32.toString();
        boolean boolean36 = spreadsheetDate10.isInRange(serialDate18, serialDate32, 0);
        int int37 = spreadsheetDate10.getYYYY();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "30-June-2019" + "'", str33.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "30-June-2019" + "'", str34.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        java.lang.Class<?> wildcardClass8 = timeSeries4.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int11 = spreadsheetDate10.getDayOfMonth();
        java.util.Date date12 = spreadsheetDate10.toDate();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) day11);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) 10.0f);
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day19.equals(obj24);
//        java.util.Date date26 = day19.getStart();
//        java.lang.Class<?> wildcardClass27 = day19.getClass();
//        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass27);
//        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass27);
//        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass27);
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("30-June-2019", (java.lang.Class) wildcardClass27);
//        java.lang.Class class32 = null;
//        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", (java.lang.Class) wildcardClass27, class32);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("9-January-1900", class32);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(inputStream28);
//        org.junit.Assert.assertNull(uRL29);
//        org.junit.Assert.assertNull(obj30);
//        org.junit.Assert.assertNull(inputStream31);
//        org.junit.Assert.assertNull(obj33);
//        org.junit.Assert.assertNull(obj34);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        java.util.List list10 = timeSeries4.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        long long18 = month17.getMiddleMillisecond();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class24);
//        long long26 = timeSeries25.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass27 = timeSeries25.getClass();
//        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass27);
//        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        java.lang.Number number45 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (double) 10.0f);
//        java.lang.Object obj48 = null;
//        boolean boolean49 = day43.equals(obj48);
//        java.util.Date date50 = day43.getStart();
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date50, timeZone51);
//        boolean boolean53 = month17.equals((java.lang.Object) date50);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        java.lang.String str60 = day59.toString();
//        java.lang.Number number61 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) day59);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.lang.String str68 = day67.toString();
//        java.lang.Number number69 = timeSeries66.getValue((org.jfree.data.time.RegularTimePeriod) day67);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day67, (double) 10.0f);
//        java.lang.Object obj72 = null;
//        boolean boolean73 = day67.equals(obj72);
//        java.util.Date date74 = day67.getStart();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date74, timeZone76);
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date50, timeZone76);
//        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month(date16, timeZone76);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNull(uRL28);
//        org.junit.Assert.assertNull(uRL29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "13-June-2019" + "'", str44.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "13-June-2019" + "'", str60.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number61);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "13-June-2019" + "'", str68.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number69);
//        org.junit.Assert.assertNull(timeSeriesDataItem71);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone76);
//    }
//}

